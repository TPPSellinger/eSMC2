
###################
# Source function #
###################
library(eSMC2)
########
#Script#
########
L=10^7
M=10
NC=1
nsim=1
Pop=10^5
mu=10^-8
r=10^-8
NC=1
x_ab=c(seq(0,10*Pop,0.0001*Pop),seq(((10*Pop)+(0.01*Pop)),100*Pop,0.01*Pop),seq(((100*Pop)+(0.01*Pop)),1000*Pop,5*Pop))
Pop_size=c()
sigma_t=rep(0.8,length(x_ab))
sigma_t[which(x_ab>(0.5*Pop))]=0.2

for(t in x_ab){
  if(t<=(0.1*Pop)){
    Pop_t=Pop
  }
  if(t>=(0.1*Pop)){
    Pop_t=Pop/5
  }
  if(t>(Pop)){
    Pop_t=Pop
  }
  Pop_size=c(Pop_size,Pop_t)
}
results=list()
setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
for(x in 1:nsim){
  results[[x]]=Optimize_N_t(file=paste("Tutorial_4_A_simul_ARG_","x",(x-1),".txt",sep =""),theta = mu,gamma=r/mu,L=L,n=40,ER=F,Pop=T,SB=F,SF=3,BoxP=c(3,3),Boxs=list(c(0,0.99),c(0,0.99)),M=M,NC=NC,simulator = "msprime")
}

gen <- 1
pdf(paste("Results_Tutorial_teSMC_ARG.pdf",sep = ""),)
par(mfrow=c(1,2),pty="s")
plot(c(1000,10^6),c(1,1), log=c("x"), ylim =c(2,6) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")


for(x in 1:nsim){
  Ne_t<-results[[x]]$Xi
  Ne=results[[x]]$mu/mu
  lines((results[[x]]$Tc*Ne), log10((Ne_t)*0.5*Ne), type="s", col="red")
}
lines(x_ab,log10(Pop_size), type="s", col="black")
legend("topright",legend=c("M:10 L:10^7","True"), col=c("red","black"), lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)



plot(c(1000,10^6),c(1,1), log=c("x"), ylim =c(0,1.1) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="selfing rate",main = "")


for(x in 1:nsim){
  Ne=results[[x]]$mu/mu
  lines((results[[x]]$Tc*Ne),results[[x]]$sigma, type="s", col="red")
}
lines(x_ab,sigma_t)
dev.off()
