
###################
# Source function #
###################
library(eSMC2)
########
#Script#
########


population="CEU"
M=20
NC=5
mu <- 6.95*10^-9
r=3.6*10^-8 

setwd("~/Documents/eSMC2_tutorial/Tutorial_4(teSMC)/")

Os=Get_real_data(paste("~/Documents/eSMC2_tutorial/Tutorial_4(teSMC)/",sep=""),M,paste(population,"_regions.mhs",sep =""),delim = "\t")
# Os=Os[[1]] #To select only chromosome 1
# Os=Os[c(1,2,21,22),] # to run on only 2 haploid genome
results=teSMC(n=40, rho=r/mu, Os,model = "One transition",estimate = "SF",Constant_Pop = F,BoxP=c(3,3),Boxs =list(list(c(0.5,0.99),c(0,0.5))),NC=length(Os)) # Or NC=1
gen <- 1
pdf(paste("Results_Tutorial_teSMC_real_data.pdf",sep = ""))
par(mfrow=c(1,2),pty="s")
plot(c(1000,2*10^6),c(1,1), log=c("x"), ylim =c(3,7) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")
Ne_t<-results$Xi
Ne=mean(results$mu/mu)
lines((results$Tc*Ne), log10((Ne_t)*0.5*Ne), type="s", col="red")
legend("topright",legend=c("CEU"), col=c("red"), lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
plot(c(1000,2*10^6),c(1,1), log=c("x"), ylim =c(0,1.1) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="selfing rate",main = "")
Ne=mean(results$mu/mu)
lines((results$Tc*Ne),results$sigma, type="s", col="red")
dev.off()






