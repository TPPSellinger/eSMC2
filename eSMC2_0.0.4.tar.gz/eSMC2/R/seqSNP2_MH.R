#' Build signal for the model
#'
#' @param DNA : matrix of segregating sites for the whole sample
#' @param n : sequence length
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seqSNP2_MH<-function(DNA,n){
  DNA=as.matrix(DNA)
  pos=which(DNA[1,]!=DNA[2,])
  seq=rep(0,n)
  seq[as.numeric(DNA[3,pos])]=1
  return(seq)
}
