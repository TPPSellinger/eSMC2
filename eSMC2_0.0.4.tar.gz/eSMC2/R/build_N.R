#' Build the exact transition matrix from sequence of genealogy 
#'
#' Runs the eSMC to estimate demographic history and ecological parameters
#' @param genealogy : Matrix of sequence of genealogy (output of get_first_coal_time)
#' @param Tc : numerical vector containing the discretization of time
#' @export
#' @return a square matrix of size TC counting the transition event
build_N<-function(genealogy,Tc){
  Output=matrix(0,ncol=length(Tc),nrow=length(Tc))
  for(i in 1:dim(genealogy)[2]){
    state=max(which(Tc<genealogy[3,i]))
    if(i==1){
      former_state=state
      length_seq=genealogy[4,i]
      if(length_seq>1){
        Output[former_state,state]=Output[former_state,state]+1

        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)

      }
    }else{
      length_seq=genealogy[4,i]
      if(length_seq>1){
        Output[former_state,state]=Output[former_state,state]+1
        former_state=state
        Output[former_state,state]=Output[former_state,state]+(length_seq-1)

      } else {
        Output[former_state,state]=Output[former_state,state]+1
        former_state=state
      }
    }

  }
  return(Output)
}
