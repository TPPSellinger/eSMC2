
###################
# Source function #
###################
library(eSMC2)
########
#Script#
########


population="CEU"
M=20 # Nb haploid genome
NC=5 # Nb chromosome 
mu <- 6.95*10^-9 # mutation rate
r=3.6*10^-8  # Recombination rate

# Reading multi het sep file  and creating inpute file 
Os=Get_real_data(paste("~/Documents/eSMC2_tutorial/Tutorial_3(eSMC2)/",sep=""),M,paste(population,"_regions.mhs",sep =""),delim = "\t")
for(chr in 1:length(Os)){ # Looping on all chromosome
  Os[[chr]]=Os[[chr]][c(1:10,21,22),] # To speed up the analyses we only select the 10 first individual
}
# All chromosome (very slow)
results=eSMC2(n=40, rho=r/mu, Os,SF=T,Rho = F,BoxP=c(3,3),NC=length(Os))
# Chromosome 1
results=eSMC2(n=40, rho=r/mu, Os[[1]],SF=T,Rho = F,BoxP=c(3,3),NC=1)


# Selfing
print(results$sigma)
gen <- 1
pdf(paste("Results_Tutorial_eSMC2_real_data.pdf",sep = ""))

plot(c(1000,2*10^6),c(1,1), log=c("x"), ylim =c(3,7) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")
Ne_t<-results$Xi
Ne=mean(results$mu/mu)
lines((results$Tc*Ne), log10((Ne_t)*0.5*Ne), type="s", col="red") # Ne*0.5 because of diploidy otherwise remove
legend("topright",legend=c("CEU"), col=c("red"), lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
dev.off()





