
###################
# Source function #
###################
library(eSMC2)
#install.packages("plot.matrix") # To install package if not present
library(plot.matrix)
########
#Script#
########

##############
# parameters #
##############

mu=10^-8 # mutation rate
L=10^8 # sequence length
M=4 # number of haploid genome 
r=10^-8 # recombination rate
nsim=1 # number of simulation 

shartp_v=c(2,5,10,50)
N_list=list()
par(mfrow=c(2,2))
for(sharp in c(1,2,3,4)){
  strength=shartp_v[sharp]
  N=matrix(nrow = 40*40,ncol = nsim)
  for(x in 1:nsim){
    setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
    test=Optimize_N(file=paste("Scenario_2_x",x,"_Strength_",strength,"_Length_",log10(L),"_rec_",-log10(r),"_m_",-(log10(mu)),".txt",sep ="" ),theta=mu,gamma=1,L=L,n=40,ER=T,Pop=F,Boxr=c(1,1),simulator = "msprime",M=M,decimal_separator ="\\.")# Add the decimal separator ("," or "\\.") used in simulation (look at the simulated .txt file)
    N[,x]=as.numeric(test$N)
    N[which(is.na(as.numeric(N[,x]))),x]<-0
  }
  N_list[[sharp]]=N
  ##################
  # Amount of data #
  ##################
  plot(test$N,main=paste( letters[sharp],") Amplitude : ",shartp_v[sharp],sep=""),breaks=c(0,1,10,1000,10^9))
  }

# We can see that information is not distributed evenly through time

#dev.off()

######################
# Did you converge ? #
######################

# Absence of information is in white
if(nsim>2){
par(mfrow=c(2,2))
for(sharp in c(1,2,3,4)){
  N_heat=matrix(c(apply(N_list[[sharp]],1,sd)/apply(N_list[[sharp]],1,mean)),nrow = 40,ncol = 40)
  plot(N_heat,main=paste( letters[sharp],") Amplitude : ",shartp_v[sharp],sep=""),breaks=c(0,0.1,1,2,3,4))
}
}


