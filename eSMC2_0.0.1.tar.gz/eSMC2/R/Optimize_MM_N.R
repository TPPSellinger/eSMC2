#' Runs MSMC on sequence of genealogy
#'
#' @param file : path to the simulated data  ( .txt )
#' @param theta : theta used for simulation (i.e theta=1000 if command line is scrm :  -t 1000 )
#' @param gamma : initial ration of recombination over mutation
#' @param L : length of simulated sequence
#' @param n : Number of hidden states
#' @param ER : True to estimate recombination rate
#' @param Pop : True  top estimate population size
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9.
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param SCALED : TRUE to scale estimated matrices
#' @param NC : Number of scaffold
#' @param M_a : Number of sequences simulated
#' @param mut : True if mutation were simulated
#' @param Correct_window : True to adapt window to scenario
#' @export
#' @return A list containing all estimations in same format as eSMC.
Optimize_MM_N<-function(file,theta=NA,gamma=1,L,n=40,ER=T,Pop=T,SB=FALSE,SF=FALSE,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.97),pop_vect=NA,window_scaling=c(1,0),sigma=0,beta=1,SCALED=F,NC=1,M_a=3,mut=F,Correct_window=F){
  npair=2
  cut_edge=F
  FS=F
  Big_Window=F
  b=get_first_coal_time(file,mut)
  b[3,]=b[3,]/2
  Popfix=!Pop
    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5
    mu=theta/(2*L)
    scale_T=1
    if(Correct_window&!is.na(mu)){
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M_a-1))))*L)
      scale_T=mu_/mu
      mu=mu_
    }
    if(mut&is.na(mu)){
      theta=get_theta(file)
      mu=theta/((2*sum(1/(1:(M_a-1))))*L)
    }
    Rho=gamma*2*L*mu
    Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/(extra_l*(beta^2)*window_scaling[1]))
    Tc=Tc*scale_T
  N=build_N_MM(b,Tc,M_a=M_a)
  if(SCALED){
    corrector_N=rowSums(N)
    N=diag(1/corrector_N)%*%N
  }
  Tc=Tc/scale_T
  scale_T=1
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- n
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$Pop<-!Pop
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$Big_Window <- Big_Window
  test.env$npair <- npair
  test.env$sigma <- sigma
  test.env$beta <- beta
  test.env$Beta <- beta
  test.env$Self <- sigma
  test.env$BoxB <- BoxB
  test.env$Boxs <- Boxs
  test.env$Big_Xi <- N
  test.env$scale_T <- scale_T
  test.env$M_a<-M_a
  lr=length(Rho)
  test.env$lr<-lr
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=n)){
    Klink=0.5*n
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(SB){
    oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
  }
  if(SF){
    oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
  }
  if(Pop){
    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }

  if(!ER){
    oldrho=0
    if(NC>1){
      oldrho=rep(0,NC)
    }

  }
  if(ER){
    oldrho=(Boxr[1]/sum(Boxr))
    if(NC>1){
      oldrho=rep((Boxr[1]/sum(Boxr)),NC)
    }

  }

  if(NC==1){
    if(ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[3]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)
              M_a=get('M_a', envir=test.env)
              Pop=get('Pop', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:3,1])
            rho=sol[1]
            beta_=sol[2]
            sigma_=sol[3]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_)))
            oldrho=rho
            oldbeta=beta_
            oldsigma=sigma_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[3]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              Xi_=param[4:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(3+(Klink)),1])
            rho=sol[1]
            beta_=sol[2]
            sigma_=sol[3]
            Xi_=sol[4:length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              sigma=get('sigma',envir = test.env)
              Self=get('Self',envir = test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta), function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            rho=sol[1]
            beta_=sol[2]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho,oldbeta-beta_)))
            oldrho=rho
            oldbeta=beta_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              sigma=get('sigma',envir = test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[2]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BETA=get('BETA',envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]

              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldbeta,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            rho=sol[1]
            beta_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
      }
      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma), function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            rho=sol[1]
            sigma_=sol[2]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho,oldsigma-sigma_)))
            oldrho=rho
            oldsigma=sigma_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]

              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            rho=sol[1]
            sigma_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_,oldsigma-sigma_)))
            oldrho=rho
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              sigma=get('sigma', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            rho=sol[1]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(rho- oldrho)))
            oldrho=rho

          }

          if(!Popfix){

            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              sigma=get('sigma', envir=test.env)
              rho_=param[1]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldrho,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            rho=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_)))
            oldrho=rho
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
      }
    }
    if(!ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            beta_=sol[1]
            sigma_=sol[2]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(oldbeta-beta_,oldsigma-sigma_)))
            oldbeta=beta_
            oldsigma=sigma_

          }
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            beta_=sol[1]
            sigma_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)
              sigma=get('sigma', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            beta_=sol[1]
            print(paste(" new Complete likelihood : ", LH ))

            diff=max(abs(c(oldbeta-beta_)))
            oldbeta=beta_

          }
          if(!Popfix){
            function_to_minimize<-function(param){

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              sigma=get('sigma', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldbeta,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            beta_=sol[1]
            Xi_=sol[2:length(sol)]

            diff=max(abs(c(oldbeta-beta_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
      }
      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldsigma)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            sigma_=sol[1]
            print(paste(" new Complete likelihood : ", LH ))
            diff=max(abs(c(oldsigma-sigma_)))
            oldsigma=sigma_

          }

          if(!Popfix){

            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              Rho=get('Rho', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T
              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma,oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldsigma,oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            sigma_=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(Xi_-oldXi_,oldsigma-sigma_)))
            oldXi_=Xi_
            oldsigma=sigma_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(!Popfix){
            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              sigma=get('sigma', envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[1:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              Self=get('Self', envir=test.env)
              M_a=get('M_a', envir=test.env)
              builder=build_MM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              Tc=builder[[3]]
              scale_T=get('scale_T', envir=test.env)
              Tc=Tc*scale_T

              LH=-sum(log(A)*Big_Xi)

              return(LH)
            }
            sol= BB::BBoptim(c(oldXi_),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(c(oldXi_)),M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:((Klink)),1])
            Xi_=sol[1:length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_)))
            oldXi_=Xi_

            print(paste(" new Complete likelihood : ",  -LH ))
            print(paste("Xi:",oldXi_))
          }
        }


      }
    }
  }
  if(NC>1){
    if(ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[lr+2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              LH=0
              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+2),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[length(oldrho)+1]
            sigma_=sol[length(oldrho)+2]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_)))
            oldrho=rho
            oldbeta=beta_
            oldsigma=sigma_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[lr+2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              Xi_=param[3+lr:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0

              M_a=get('M_a', envir=test.env)
              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                LH=LH-sum(log(A)*Big_Xi[[chr]])

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[length(oldrho)+1]
            sigma_=sol[length(oldrho)+2]
            Xi_=sol[(length(oldrho)+3):length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]

                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+1),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[length(oldrho)+1]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_)))
            oldrho=rho
            oldbeta=beta_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC',envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[(lr+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[(lr+2):length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)

              M_a=get('M_a', envir=test.env)
              Pop=get('Pop', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for( chr in 1:chr){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldbeta,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            beta_=sol[1+length(oldrho)]
            Xi_=sol[(2+length(oldrho)):length(sol)]
            diff=max(abs(c(rho- oldrho,oldbeta-beta_,Xi_-oldXi_)))
            oldrho=rho
            oldbeta=beta_
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))
          }
        }
      }

      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)

              sigma=param[1+lr]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              LH=0
              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+1),1])
            rho=sol[1:length(oldrho)]
            sigma_=sol[length(oldrho)+1]
            diff=max(abs(c(rho- oldrho,oldsigma-sigma_)))
            oldrho=rho
            oldsigma=sigma_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[(2+lr):length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1+lr]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)

              M_a=get('M_a', envir=test.env)
              LH=0
              for( chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            sigma_=sol[1+length(oldrho)]
            Xi_=sol[(2+length(oldrho)):length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_,oldsigma-sigma_)))
            oldrho=rho
            oldXi_=Xi_
            oldsigma=sigma_
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for( chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)),1])
            rho=sol[1:length(oldrho)]
            diff=max(abs(c(rho- oldrho)))
            oldrho=rho
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC', envir=test.env)
              lr=get('lr', envir=test.env)
              rho_=param[1:lr]
              rho_=rho_*sum(Boxr)
              rho_=rho_-(Boxr[1])
              rho_=10^(rho_)
              Rho=get('Rho', envir=test.env)
              rho_=rho_*Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[(1+lr):length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for( chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldrho,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(length(oldrho)+(Klink)),1])
            rho=sol[1:length(oldrho)]
            Xi_=sol[(1+length(oldrho)):length(sol)]
            diff=max(abs(c(rho- oldrho,Xi_-oldXi_)))
            oldrho=rho
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))
          }
        }
      }
    }
    if(!ER){
      if(SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              M_a=get('M_a', envir=test.env)
              LH=0
              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:2,1])
            beta_=sol[1]
            sigma_=sol[2]
            diff=max(abs(c(oldbeta- beta,oldsigma-sigma)))
            oldbeta=sol[1]
            oldsigma=sol[2]
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC',envir = test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              sigma=param[2]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              Xi_=param[3:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0

              M_a=get('M_a', envir=test.env)
              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(2+(Klink)),1])
            beta_=sol[1]
            sigma_=sol[2]
            Xi_=sol[3:length(sol)]
            diff=max(abs(c(oldbeta-beta_,oldsigma-sigma_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_
            oldsigma=sigma_
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC',envir = test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)

              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)
              M_a=get('M_a', envir=test.env)
              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta),function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            beta_=sol[1]
            diff=max(abs(c(oldbeta-beta_)))
            oldbeta=beta_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC',envir = test.env)
              rho_=Rho
              BoxB=get('BoxB', envir=test.env)
              beta=((param[1]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)


              Pop=get('Pop', envir=test.env)
              LH=0
              M_a=get('M_a', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldbeta,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            beta_=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(oldbeta-beta_,Xi_-oldXi_)))
            oldbeta=beta_
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))
          }
        }
      }
      if(!SB){
        if(SF){
          if(Popfix){
            function_to_minimize <-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC',envir=test.env)
              Rho=get('Rho', envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)
              M_a=get('M_a', envir=test.env)

              Pop=get('Pop', envir=test.env)
              LH=0

              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]

                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1,1])
            sigma_=sol[1]
            diff=max(abs(c(oldsigma-sigma_)))
            oldsigma=sigma_
          }
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)
              Rho=get('Rho', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              NC=get('NC',envir = test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[2:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              Self=get('Self', envir=test.env)
              sigma=param[1]
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma=sigma+Boxs[1]
              sigma=min(sigma,0.99)
              window_scaling=get('window_scaling', envir=test.env)

              M_a=get('M_a', envir=test.env)
              Pop=get('Pop', envir=test.env)
              LH=0


              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T
                LH=LH-sum(log(A)*Big_Xi[[chr]])

              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldsigma,oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:(1+(Klink)),1])
            sigma_=sol[1]
            Xi_=sol[2:length(sol)]
            diff=max(abs(c(Xi_-oldXi_,oldsigma-sigma_)))
            oldXi_=Xi_
            oldsigma=sigma_
            print(sigma_)
            print(paste("Xi:",oldXi_))
          }
        }
        if(!SF){
          if(!Popfix){
            function_to_minimize_optim<-function(param){
              Boxr=get('Boxr', envir=test.env)

              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)

              FS=get('FS', envir=test.env)
              Rho=get('Rho', envir=test.env)
              NC=get('NC',envir=test.env)
              rho_=Rho
              beta=get('beta', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Xi_=param[1:length(param)]
              Xi=vector()
              pop_vect=get('pop_vect', envir=test.env)
              xx=0
              for(ix in 1:length(Xi_)){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              Beta=get('Beta', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)

              M_a=get('M_a', envir=test.env)
              Pop=get('Pop', envir=test.env)
              LH=0

              Self=get('Self', envir=test.env)
              sigma=get('sigma', envir=test.env)

              for(chr in 1:NC){
                builder=build_MM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,M_a=M_a)
                Q=builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                Tc=builder[[3]]
                scale_T=get('scale_T', envir=test.env)
                Tc=Tc*scale_T

                LH=LH-sum(log(A)*Big_Xi[[chr]])


              }
              return(LH)
            }
            sol= BB::BBoptim(c(oldXi_),function_to_minimize_optim,lower=0,upper=1,method=c(2),control = list(maxit=30,M=c(20)))
            LH=as.numeric(as.matrix(sol[[2]]))
            sol=as.matrix(sol[[1]])
            sol=as.numeric(sol[1:((Klink)),1])
            Xi_=sol[1:length(sol)]
            diff=max(abs(Xi_-oldXi_))
            oldXi_=Xi_
            print(paste("Xi:",oldXi_))

          }
        }
      }
    }
  }

  if(SB){
    beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
  }
  if(SF){
    sigma=oldsigma*(Boxs[2]-Boxs[1])
    sigma=sigma+Boxs[1]
  }
  rho_=oldrho*sum(Boxr)
  rho_=rho_-(Boxr[1])
  rho_=10^(rho_)
  rho_=rho_*Rho
  rho_=rho_/(2*L)
  if(Pop){
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }
  res<-list()
  res$beta=beta
  res$sigma=sigma
  res$rho=rho_

  if(Pop){
    res$Xi=Xi_
  }
  Beta=get('Beta', envir=test.env)
  Self=get('Self', envir=test.env)
  res$scale_T=scale_T
  res$mu=mu
  res$Tc=Tc
  res$N=N
  return(res)
}


