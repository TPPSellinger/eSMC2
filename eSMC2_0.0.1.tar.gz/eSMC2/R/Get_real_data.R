#' Gets real data from multihetsep file
#'
#' Builds segregating matrix from a multihetsep file
#' @param path : location of the file
#' @param M : number of haplotypes
#' @param filename : name of the file to read
#' @export
#' @return a list with the segregating matrix for each repetition
Get_real_data<-function(path,M,filename){
  O_total_=create_good_file(path,M,filename)
  O=O_total_$output
  return(O)
}

