#' Builds the emission matrix of the Sequentially Markovian Coalescent with methylation
#'
#' @param mu : estimated mutation rate given prior
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Tc : coalescent times to discretize time
#' @param beta : germination rate of vector of germination rates
#' @param nb_methylation_context : number of different methylation context
#' @param mu_m : vector of size two of methylation and demethylation rate in -log10 scale
#' @param mu_m_reg :vector of size two of region methylation and demethylation  rate in -log10 scale
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param scale_meth : Proportion of the genome with methylation information
#' @return The emission matrix
build_emi_m<-function(mu,mu_b,Tc,beta,nb_methylation_context,mu_m,mu_m_reg,Region,scale_meth){

  if(as.numeric(Region)==0){
     if(nb_methylation_context==1){
    g=matrix(0,nrow=length(Tc),ncol=6)


    p=(mu_m[2]/(sum(mu_m)))
    p_m1=(p+((1-p)*exp(-sum(mu_m)*Tc))) # *Ne
    p_m2=((1-p)+(p*exp(-sum(mu_m)*Tc))) # *Ne
    g[,1]= scale_meth*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,3]=1
    g[,6]=(1-scale_meth)*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,4]=(1-scale_meth)*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,5]=(1-scale_meth)*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
  }else{

    mu_m_s=mu_m

    g=matrix(0,nrow=length(Tc),ncol=9)


    mu_m=mu_m_s[1,]
    p=(mu_m[2]/(sum(mu_m)))
    p_m1=(p+((1-p)*exp(-sum(mu_m)*Tc))) # *Ne
    p_m2=((1-p)+(p*exp(-sum(mu_m)*Tc))) # *Ne
    g[,1]= (1-sum(scale_meth))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,3]=1
    g[,6]=(scale_meth[1,1])*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,4]=(scale_meth[1,1])*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,5]=(scale_meth[1,1])*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

    mu_m=mu_m_s[2,]

    p=(mu_m[2]/(sum(mu_m)))
    p_m1=(p+((1-p)*exp(-sum(mu_m)*Tc))) # *Ne
    p_m2=((1-p)+(p*exp(-sum(mu_m)*Tc))) # *Ne
    g[,9]=(scale_meth[2,1])*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,7]=(scale_meth[2,1])*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,8]=(scale_meth[2,1])*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
  }
  }else{

    if(Region!=2){
      g=matrix(0,nrow=length(Tc),ncol=10)





      p_reg=(mu_m_reg[2]/(sum(mu_m_reg)))
      p_m1_reg=(p_reg+((1-p_reg)*exp(-sum(mu_m_reg)*Tc))) # *Ne
      p_m2_reg=((1-p_reg)+(p_reg*exp(-sum(mu_m_reg)*Tc))) # *Ne

      p=(mu_m[2]/(sum(mu_m)))

      t_m=rep((1/sum(mu_m_reg)),length(Tc))
      for(tt in 1:length(t_m)){
        t_m[tt]=min(t_m[tt],Tc[tt])
      }

      p_m1=(p+((1-p)*exp(-sum(mu_m)*(t_m)))) # Unmethylated
      p_m2=((1-p)+(p*exp(-sum(mu_m)*(t_m)))) # methylated

      g[,1]= scale_meth*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,3]=1

      #g[,6]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,4]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,5]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

      #g[,9]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(p*(2*p_m1*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,7]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(p*(p_m1*p_m1))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,8]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(p*((1-p_m1)*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))



      g[,6]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,4]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,5]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

      g[,9]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*((2*p_m1*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,7]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*((p_m1*p_m1))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,8]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(((1-p_m1)*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

      g[,10]= (1-scale_meth)*((p_reg*(2*p_m1_reg*(1-p_m1_reg)))+((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))



    }else{
      g=matrix(0,nrow=length(Tc),ncol=6)
      p=(mu_m_reg[2]/(sum(mu_m_reg)))
      p_m1=(p+((1-p)*exp(-sum(mu_m_reg)*Tc))) # *Ne
      p_m2=((1-p)+(p*exp(-sum(mu_m_reg)*Tc))) # *Ne
      g[,1]= scale_meth*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,3]=1
      g[,6]=(1-scale_meth)*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,4]=(1-scale_meth)*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,5]=(1-scale_meth)*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    }
  }
  return(g)
}
