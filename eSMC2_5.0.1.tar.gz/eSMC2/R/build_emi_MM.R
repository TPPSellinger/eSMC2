#' Builds the emission matrix of SMBC
#'
#' @param n : Hidden state number
#' @param mu : estimated mutation rate given prior
#' @param alpha : multiple merger parameter
#' @param M_a : effective number of simultaneously analyzedf sequence
#' @param t : expected coalescence times of each hiddens states
#' @param Ts_t : expected coalescence times of the external branch length
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param beta : germination rate
#' @param Beta : Original germination rate
#' @param Tc : coalescent times used to define hidden states
#' @return A list containing all possible emission matrix of MSMC conditionned to the external branch length
build_emi_MM<-function(n=20,mu,alpha=1.99,M_a=3,t,Ts_t,mu_b=1,beta=1,Beta=1,Tc){

  g_t=list()
  for(i in 1:length(Ts_t)){
    Ts=Ts_t[[i]]#/(Beta*Beta)
    #print(mean(Ts))
    if(M_a==3){
      #scale_v=rep(1,n)
      #scale_v=c((exp(-(3*Tc[1:(n-1)])*(1/Ts))-exp(-(3*Tc[2:n])*(1/Ts))),exp(-(3*Tc[n])*(1/Ts)))
      #Ts_v=c(((((3*Tc[1:(n-1)])+Ts)*exp(-(3*Tc[1:(n-1)])*(1/Ts)))-(((3*Tc[2:n])+(Ts))*exp(-(3*Tc[2:n])*(1/Ts)))),(((3*Tc[n])+(Ts))*exp(-(3*Tc[n])*(1/Ts))))/scale_v   #rep(Ts,length(Tc))
      y=5
      #Ts=0
      #
      g=matrix(0,nrow=(4*n),ncol=y)
      cc=max(which(Ts>(3*Tc[1:n])),na.rm = T)
      g[1:(3*n),1]=exp(-mu*Ts)
      g[1:cc,2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[1:cc])))
      g[1:cc,4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts-(2*t[1:cc]))))
      g[((3*n)+1):((3*n)+n),1]=exp(-mu*(((3*t[((3*n)+1):((3*n)+n)]))))
      g[((3*n)+1):((3*n)+n),2]=(1-exp(-mu*(((t[((3*n)+1):((3*n)+n)])))))
      #Ts=3*t[cc:n]
      for(xx in 0:2){
      g[((xx*n)+cc):((xx*n)+n),1]=0#exp(-mu*Ts)
      g[((xx*n)+cc):((xx*n)+n),2]=0#(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((xx*n)+cc):((xx*n)+n)])))
      g[((xx*n)+cc):((xx*n)+n),4]=0##(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts-(2*t[((xx*n)+cc):((xx*n)+n)]))))
      g[((xx*n)+n),1:4]=0
      g[((xx*n)+cc),1:4]=0
      }
      g[(1:n),3]=g[(1:n),2]
      g[((n+1):(2*n)),2]=g[(1:n),2]
      g[((n+1):(2*n)),4]=g[(1:n),2]
      g[(((2*n)+1):(3*n)),3]=g[(1:n),2]
      g[(((2*n)+1):(3*n)),4]=g[(1:n),2]
      g[((n+1):(2*n)),3]=g[(1:n),4]
      g[(((2*n)+1):(3*n)),2]=g[(1:n),4]
      g[((3*n)+1):(4*n),3]=g[((3*n)+1):(4*n),2]
      g[((3*n)+1):(4*n),4]=g[((3*n)+1):(4*n),2]
      Divide=apply(g,1,sum)
      Divide[which(Divide==0)]=1
      g=diag(1/Divide)%*%g
      g[,5]=1
      if(any(as.numeric(g<0))){browser()}
    }
    if(M_a==4){
      y=9
      Ts=rep(Ts,length(t))
      if(any(Ts<(4*t))){
        Ts[which(Ts<(4*t))]<-4*t
      }
      g=matrix(nrow =(11*n),ncol=y)
      lambda=beta((2-alpha), alpha)/(gamma((2-alpha))*gamma((alpha)))
      L3_2=3*(beta((2-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha))))
      L3=L3_2+((beta((3-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))

      g[((10*n)+1):(11*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(4*t[((10*n)+1):(11*n)]))
      g[((10*n)+1):(11*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*t[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*t[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*t[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(4*t[((10*n)+1):(11*n)])))/4
      g[((10*n)+1):(11*n),(6:8)]=0

      g[((6*n)+1):(10*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((6*n)+1):(10*n)]))
      g[((6*n)+1):(10*n),(6:8)]=0

      g[((6*n)+1):(7*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((6*n)+1):(7*n)])))
      g[((6*n)+1):(7*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((6*n)+1):(7*n)])))
      g[((6*n)+1):(7*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((6*n)+1):(7*n)])))
      g[((6*n)+1):(7*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((6*n)+1):(7*n)]-(3*t[((6*n)+1):(7*n)]))))

      g[((7*n)+1):(8*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((7*n)+1):(8*n)])))
      g[((7*n)+1):(8*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((7*n)+1):(8*n)])))
      g[((7*n)+1):(8*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((7*n)+1):(8*n)]-(3*t[((7*n)+1):(8*n)]))))
      g[((7*n)+1):(8*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((7*n)+1):(8*n)])))

      g[((8*n)+1):(9*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((8*n)+1):(9*n)]-(3*t[((8*n)+1):(9*n)]))))
      g[((8*n)+1):(9*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((8*n)+1):(9*n)])))
      g[((8*n)+1):(9*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((8*n)+1):(9*n)])))
      g[((8*n)+1):(9*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((8*n)+1):(9*n)])))

      g[((9*n)+1):(10*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((9*n)+1):(10*n)]-(3*t[((9*n)+1):(10*n)]))))
      g[((9*n)+1):(10*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((9*n)+1):(10*n)])))
      g[((9*n)+1):(10*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((9*n)+1):(10*n)])))
      g[((9*n)+1):(10*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((9*n)+1):(10*n)])))

      g[1:(6*n),1]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[1:(6*n)]))

      g[1:n,2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[1:n])))
      g[1:n,3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[1:n])))
      g[1:n,4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[1:n]-(4*t[1:n])*0.5)+t[1:n])))
      g[1:n,5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[1:n]-(4*t[1:n])*0.5)+t[1:n])))
      g[1:n,6]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[1:(n)]))
      g[1:n,7]=0
      g[1:n,8]=0

      g[(n+1):(2*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[(n+1):(2*n)])))
      g[(n+1):(2*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[(n+1):(2*n)]-(4*t[(n+1):(2*n)])*0.5)+t[(n+1):(2*n)])))
      g[(n+1):(2*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[(n+1):(2*n)])))
      g[(n+1):(2*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[(n+1):(2*n)]-(4*t[(n+1):(2*n)])*0.5)+t[(n+1):(2*n)])))
      g[(n+1):(2*n),6]=0
      g[(n+1):(2*n),7]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[(n+1):(2*n)]))
      g[(n+1):(2*n),8]=0

      g[((2*n)+1):(3*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((2*n)+1):(3*n)]-(4*t[((2*n)+1):(3*n)])*0.5)+t[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((2*n)+1):(3*n)]-(4*t[((2*n)+1):(3*n)])*0.5)+t[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((2*n)+1):(3*n)])))
      g[((2*n)+1):(3*n),6]=0
      g[((2*n)+1):(3*n),7]=0
      g[((2*n)+1):(3*n),8]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((2*n)+1):(3*n)]))

      g[((3*n)+1):(4*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((3*n)+1):(4*n)]-(4*t[((3*n)+1):(4*n)])*0.5)+t[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((3*n)+1):(4*n)]-(4*t[((3*n)+1):(4*n)])*0.5)+t[((3*n)+1):(4*n)])))
      g[((3*n)+1):(4*n),6]=0
      g[((3*n)+1):(4*n),7]=0
      g[((3*n)+1):(4*n),8]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((3*n)+1):(4*n)]))

      g[((4*n)+1):(5*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((4*n)+1):(5*n)]-(4*t[((4*n)+1):(5*n)])*0.5)+t[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((4*n)+1):(5*n)]-(4*t[((4*n)+1):(5*n)])*0.5)+t[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((4*n)+1):(5*n)])))
      g[((4*n)+1):(5*n),6]=0
      g[((4*n)+1):(5*n),7]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((4*n)+1):(5*n)]))
      g[((4*n)+1):(5*n),8]=0

      g[((5*n)+1):(6*n),2]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((5*n)+1):(6*n)]-(4*t[((5*n)+1):(6*n)])*0.5)+t[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),3]=(1-exp(-mu*(beta+((1-beta)*mu_b))*( (Ts[((5*n)+1):(6*n)]-(4*t[((5*n)+1):(6*n)])*0.5)+t[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),4]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),5]=(1-exp(-mu*(beta+((1-beta)*mu_b))*(t[((5*n)+1):(6*n)])))
      g[((5*n)+1):(6*n),6]=exp(-mu*(beta+((1-beta)*mu_b))*(Ts[((5*n)+1):(6*n)]))
      g[((5*n)+1):(6*n),7]=0
      g[((5*n)+1):(6*n),8]=0
      g[,9]=1
    }
    g_t[[i]]=g#/rowSums(g)
  }
  if(any(as.numeric(g<0))){browser()}
  return(g_t)
}
