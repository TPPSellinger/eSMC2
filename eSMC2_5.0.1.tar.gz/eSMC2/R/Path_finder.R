#' Estimates coalescent time at each position under the SMC
#'
#' @param Os : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param L : Sequence length
#' @param mu : mutation rate
#' @param theta_W : estimated theta waterson
#' @param Rho : recombination rate per loci
#' @param k : number of hidden state
#' @param NC : Number of scaffold
#' @return list of size 2, first one containing hidden states (i.e. coalescence time) and second one the sequences of expected hidden state along the genome
Path_finder<-function(Os,L,mu,theta_W,Rho,k=20,NC){
  Xi=NA
  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  old_list=list()
  n <- length(Os[[1]][[1]]);
  Pop=T
  Popfix=T
  theta=mu*2*L
  gamma=Rho/theta
  gamma_o=gamma
  print(gamma)
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- k
  test.env$mu <- mu
  test.env$Rho <- Rho
  test.env$NC<-NC
  oldrho=0
  Boxr=c(0,0)
  s_t=Sys.time()
  if(length(unique(round(gamma,digits=3)))>1){
    oldrho=rep(0,NC)
  }
  print(length(oldrho))
  start_time <- Sys.time()
  if(Popfix){
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho
    print(c("rho/theta:",rho_/theta))
    if(NC==1){
      builder=build_HMM_matrix(k,(rho_),L=L,Pop=T,scale=c(1,0))
    }
    if(NC>1){
      builder=list()
      for(chr in 1:NC){
        builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),L=L[chr],Pop=T,scale=c(1,0))
      }
    }
  }
  if(NC==1){
    Q = builder[[1]]
    nu= builder[[2]]
    Tc=builder[[3]]
    g=matrix(0,nrow=length(Tc),ncol=3)
    g[,2]=1-exp(-mu*2*Tc)
    g[,1]=exp(-mu*2*Tc)
    g[,3]=1
    #print(Os[[1]][[2]])

    test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
    e_t=Sys.time()
    print("time to build path mat")
    print(e_t-s_t)
    Seq_out=list()
    for(i in 1:length(Os)){
      Seq_int=numeric(L)
      s_t <- Sys.time()
      fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
      e_t=Sys.time()
      print("time fo")
      print(e_t-s_t)
      c=exp(fo[[2]])
      s_t <- Sys.time()
      ba=Backward_zip_mailund(Os[[i]][[1]],test[[3]],length(Tc),c)
      e_t=Sys.time()
      print("time ba")
      print(e_t-s_t)
      s_t <- Sys.time()
      W=list()
      int=t(Q)%*%diag(g[,1])
      int=eigen(int)
      W$P=int$vectors
      W$P_=MASS::ginv(W$P)
      symbol= Os[[i]][[3]][,1]
      count_seq=1
      SAVE=F
      for(ob in 1:length(Os[[i]][[1]])){
        truc_t=(fo[[1]][,ob]*ba[,ob])/c[ob]
        truc_t=truc_t/sum(truc_t)
        Seq_int[count_seq]=sum(truc_t*Tc)

        if(SAVE){
          Seq_int[(count_seq-l):(-1+count_seq)]=Seq_int[count_seq]
        }
        count_seq=count_seq+1
        SAVE=F

        if(T){
          if(as.numeric(Os[[i]][[1]][(ob+1)])>2&ob<length(Os[[i]][[1]])){
            l=as.numeric(Os[[i]][[3]][(as.numeric(Os[[i]][[1]][(ob+1)])),2])
            SAVE=T
            count_seq=count_seq-1+l
          }
        }
      }
      e_t=Sys.time()
      print("finding hidden state")
      print(e_t-s_t)
      s_t <- Sys.time()
      print(length(Seq_int))
      print(count_seq)
      r_Seq_int=numeric(L)
      r_Tc=builder[[4]]
      for(iii in 2:k){
        pos=which(Seq_int<=r_Tc[iii]&Seq_int>r_Tc[(iii-1)])
        r_Seq_int[pos]=(iii-1)
      }
      pos=which(Seq_int>r_Tc[k])
      r_Seq_int[pos]=k
      pos_1=which(r_Seq_int==0)
      e_t=Sys.time()
      print("building output sequence")
      print(e_t-s_t)
      s_t <- Sys.time()
      #print("length pos 1")
      #print(length(pos_1))
      if(length(pos_1)>0){
        for(iii in 1:length(pos_1)){
          if(iii==1){
            r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[1:(pos_1[iii]-1)]>0))]
          }
          if(iii>1){
            r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[pos_1[(iii-1)]:(pos_1[iii]-1)]>0))]
          }
        }
      }
      Seq_out[[i]]=r_Seq_int
      e_t=Sys.time()
      print(e_t-s_t)
    }
    res=list()
    res$Tc=Tc
    res$seq=Seq_out

    return(res)
  }
  if(NC>1){
    Q=list()
    nu=list()
    Tc=list()
    g=list()
    M=list()
    N=list()
    MLH=list()
    q_=list()
    Seq_out=list()
    for(chr in 1:NC){
      Q[[chr]] = builder[[chr]][[1]]
      nu[[chr]]= builder[[chr]][[2]]
      Tc[[chr]]=builder[[chr]][[3]]
      g[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=3)
      g[[chr]][,3]=1
      g[[chr]][,2]=1-exp(-mu*2*Tc[[chr]])
      g[[chr]][,1]=exp(-mu*2*Tc[[chr]])
      test=Build_zip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])
      Seq_out_chr=list()
      for(i in 1:length(Os[[chr]])){
        Seq_int=numeric(L[chr])
        s_t <- Sys.time()
        fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
        e_t=Sys.time()
        print("time fo")
        print(e_t-s_t)
        c=exp(fo[[2]])
        s_t <- Sys.time()
        ba=Backward_zip_mailund(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
        e_t=Sys.time()
        print("time ba")
        print(e_t-s_t)
        s_t <- Sys.time()
        W=list()
        int=t(Q[[chr]])%*%diag(g[[chr]][,1])
        int=eigen(int)
        W$P=int$vectors
        W$P_=MASS::ginv(W$P)
        symbol= Os[[chr]][[i]][[3]][,1]
        count_seq=1
        SAVE=F
        for(ob in 1:length(Os[[chr]][[i]][[1]])){
          truc_t=(fo[[1]][,ob]*ba[,ob])/c[ob]
          truc_t=truc_t/sum(truc_t)
          Seq_int[count_seq]=sum(truc_t*Tc[[chr]])

          if(SAVE){
            Seq_int[(count_seq-l):(-1+count_seq)]=Seq_int[count_seq]
          }
          count_seq=count_seq+1
          SAVE=F

          if(T){
            if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])>1&ob<length(Os[[chr]][[i]][[1]])){
              l=as.numeric(Os[[chr]][[i]][[3]][(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1),2])
              SAVE=T
              count_seq=count_seq-1+l
            }
          }
        }
        e_t=Sys.time()
        print("finding hidden state")
        print(e_t-s_t)
        s_t <- Sys.time()
        #print(length(Seq_int))
        r_Seq_int=numeric(L[chr])
        r_Tc=builder[[chr]][[4]]
        for(iii in 2:k){
          pos=which(Seq_int<=r_Tc[iii]&Seq_int>r_Tc[(iii-1)])
          r_Seq_int[pos]=(iii-1)
        }
        pos=which(Seq_int>r_Tc[k])
        r_Seq_int[pos]=k
        pos_1=which(r_Seq_int==0)
        e_t=Sys.time()
        print("building output sequence")
        print(e_t-s_t)
        s_t <- Sys.time()
        #print("length pos 1")
        #print(length(pos_1))
        if(length(pos_1)>0){
          for(iii in 1:length(pos_1)){
            if(iii==1){
              r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[1:(pos_1[iii]-1)]>0))]
            }
            if(iii>1){
              r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[pos_1[(iii-1)]:(pos_1[iii]-1)]>0))]
            }
          }
        }
        Seq_out_chr[[i]]=r_Seq_int
        e_t=Sys.time()
        print(e_t-s_t)
      }
      Seq_out[[chr]]=Seq_out_chr
    }
    res=list()
    res$Tc=Tc
    res$seq=Seq_out
    return(res)
  }
}
