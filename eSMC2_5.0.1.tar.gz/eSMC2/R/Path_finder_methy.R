#' Estimates the methylation state of genomic regions
#' @param Os : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param L : Sequence length
#' @param transition_rate : probability of changing methylation state between two position
#' @param NC : Number of scaffold
#' @param P_m : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in methylated regions
#' @param P_d : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in unmethylated regions
#' @return list of size 2, first one containing hidden states (i.e. coalescence time) and second one the sequences of expected hidden state along the genome
Path_finder_methy<-function(Os,L,transition_rate,NC,P_m=c(0.8,0.2),P_d=c(0.2,0.8)){
  test.env <- new.env()
  test.env$L <- L
  test.env$transition_rate <- transition_rate
  test.env$NC<-NC
  s_t=Sys.time()


  start_time <- Sys.time()
  build_meth_matrix<-function(transition_rate){
    Q=matrix((transition_rate/8),9,9)
    diag(Q)=1-transition_rate
    return(Q)
  }
  Q=build_meth_matrix(transition_rate)
  g=matrix(0,nrow=9,ncol=9)
  g[,1]=as.numeric(c(1,0.9375,0.9375)%*%t(c(1,0.9375,0.9375))) #

  g[,2]=as.numeric(c(0,P_m)%*%t(c(0,P_m)))#c(0,0.8,0.2)
  g[,3]=as.numeric(c(0,P_d)%*%t(c(0,P_d)))#c(0,P_d)

  g[,4]=as.numeric(c(0,P_m)%*%t(c(0,P_d))) #
  g[,5]=as.numeric(c(0,P_d)%*%t(c(0,P_m)))#c(0,P_m)

  g[,6]=as.numeric(c(0,P_m)%*%t(c(0,1,1)))#c(0,P_d)
  g[,7]=as.numeric(c(0,P_d)%*%t(c(0,1,1))) #

  g[,8]=as.numeric(c(0,1,1)%*%t(c(0,P_m)))#c(0,0.8,0.2)
  g[,9]=as.numeric(c(0,1,1)%*%t(c(0,P_d)))#c(0,P_d)
#g=g[-c(2,3,4,7),]
  nu=rep(1,dim(Q)[1])/dim(Q)[1]
  Tc=1:dim(Q)[1]
  k=length(Tc)
  if(NC==1){
    test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
    e_t=Sys.time()
   # print("time to build path mat")
  #  print(e_t-s_t)
    Seq_out=list()
    for(i in 1:length(Os)){
      Seq_int=numeric(L)
      s_t <- Sys.time()
      fo=forward_zip_mailund(Os[[i]][[1]],g,nu,test[[1]])
      e_t=Sys.time()
    #  print("time fo")
    #  print(e_t-s_t)
      c=exp(fo[[2]])
      s_t <- Sys.time()
      ba=Backward_zip_mailund(Os[[i]][[1]],test[[3]],length(Tc),c)
      e_t=Sys.time()
     # print("time ba")
    #  print(e_t-s_t)
      s_t <- Sys.time()
      W=list()
      int=t(Q)%*%diag(g[,1])
      int=eigen(int)
      W$P=int$vectors
      W$P_=MASS::ginv(W$P)
      symbol= Os[[i]][[3]][,1]
      count_seq=1
      SAVE=F
      for(ob in 1:length(Os[[i]][[1]])){
        truc_t=(fo[[1]][,ob]*ba[,ob])/c[ob]
        truc_t=truc_t/sum(truc_t)
        Seq_int[count_seq]=max(which(truc_t==max(truc_t))) # to change

        if(SAVE){
          Seq_int[(count_seq-l):(-1+count_seq)]=Seq_int[count_seq]
        }
        count_seq=count_seq+1
        SAVE=F

        if(T){
          if(as.numeric(Os[[i]][[1]][(ob+1)])>2&ob<length(Os[[i]][[1]])){
            l=as.numeric(Os[[i]][[3]][(as.numeric(Os[[i]][[1]][(ob+1)])),2])
            SAVE=T
            count_seq=count_seq-1+l
          }
        }
      }
      e_t=Sys.time()
    #  print("finding hidden state")
    #  print(e_t-s_t)
      s_t <- Sys.time()
    #  print(length(Seq_int))
    #  print(count_seq)
      Tc=1:9
      r_Tc=Tc

      e_t=Sys.time()
   #   print("building output sequence")
  #    print(e_t-s_t)
      s_t <- Sys.time()
      Seq_out[[i]]=round(Seq_int,digits = 0)
      e_t=Sys.time()
   #   print(e_t-s_t)
    }
    res=list()
    res$Tc=Tc
    res$seq=Seq_out

    return(res)
  }
  if(NC>1){
    Q=list()
    nu=list()
    Tc=list()
    g=list()
    M=list()
    N=list()
    MLH=list()
    q_=list()
    Seq_out=list()
    test=Build_zip_Matrix_mailund(Q,g,Os[[1]][[1]][[2]],nu)
    for(chr in 1:NC){
      Seq_out_chr=list()
      for(i in 1:length(Os[[chr]])){
        Seq_int=numeric(L[chr])
        s_t <- Sys.time()
        fo=forward_zip_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
        e_t=Sys.time()
      #  print("time fo")
        #print(e_t-s_t)
        c=exp(fo[[2]])
        s_t <- Sys.time()
        ba=Backward_zip_mailund(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
        e_t=Sys.time()
        #print("time ba")
        #print(e_t-s_t)
        s_t <- Sys.time()
        W=list()
        int=t(Q[[chr]])%*%diag(g[[chr]][,1])
        int=eigen(int)
        W$P=int$vectors
        W$P_=MASS::ginv(W$P)
        symbol= Os[[chr]][[i]][[3]][,1]
        count_seq=1
        SAVE=F
        for(ob in 1:length(Os[[chr]][[i]][[1]])){
          truc_t=(fo[[1]][,ob]*ba[,ob])/c[ob]
          truc_t=truc_t/sum(truc_t)
          Seq_int[count_seq]=Seq_int[count_seq]=max(which(truc_t==max(truc_t)))

          if(SAVE){
            Seq_int[(count_seq-l):(-1+count_seq)]=Seq_int[count_seq]
          }
          count_seq=count_seq+1
          SAVE=F

          if(T){
            if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])>1&ob<length(Os[[chr]][[i]][[1]])){
              l=as.numeric(Os[[chr]][[i]][[3]][(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1),2])
              SAVE=T
              count_seq=count_seq-1+l
            }
          }
        }
        e_t=Sys.time()
        #print("finding hidden state")
        #print(e_t-s_t)
        s_t <- Sys.time()
        #print(length(Seq_int))
        r_Seq_int=numeric(L[chr])
        r_Tc=Tc
        e_t=Sys.time()
        #print("building output sequence")
        #print(e_t-s_t)
        s_t <- Sys.time()
        #print("length pos 1")
        #print(length(pos_1))
        Seq_out_chr[[i]]=round(Seq_int,digits = 0)
        e_t=Sys.time()
        #print(e_t-s_t)
      }
      Seq_out[[chr]]=Seq_out_chr
    }
    res=list()
    res$Tc=Tc
    res$seq=Seq_out
    return(res)
  }
}
