#' Runs the  Sequentially Markovian Coalescent on theoretical markers
#'
#' @param n : Number of hidden states
#' @param rho : numeric vector of prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param mu_marker : list of size equal to the number of theoretical marker, respectively containing the markers rates in generation per position
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param ER : True to estimate recombination rate
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param LH_opt : TRUE to maximize likelihood (not through the Baum-Welch)
#' @param dominant_marker : index of the marker to use for scaling
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @export
#' @return A list containing all estimations (first list contains estimation based on the data second on the pseudo-observed data). List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).

SMC_marker_theo<-function(n=40,rho=1,O,mu_marker=list(c(10^-7),c(10^-8),c(10^-9)),Nb_marker=3,nb_state_marker=list(c(2),c(2),c(2)),Marker_supperposition=T,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,ER=T,NC=1,pop_vect=NA,mu_b=1,sigma=0,beta=1,Big_Window=F,position_removed=NA,LH_opt=F,dominant_marker=NA,window_scaling=c(1,0)){
  Check=F
  FS=F
  EM=F
  BW=F
  SCALED=F

  gamma=rho
  sigma=max(Boxs[1],sigma)
  sigma=min(Boxs[2],sigma)
  beta=min(BoxB[2],beta)
  beta=max(BoxB[1],beta)

  if(SF|SB){
    BaWe=2
  }else{
    BaWe=1
  }
  if(is.na(pop_vect)){
    pop_vect=rep(2,(n*0.5))
  }

  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[dim(O)[1],dim(O)[2]])
    Os=list()
    count=0
    M_o=0
    theta_W=rep(0,Nb_marker)
    s_t=Sys.time()
    for(k in 1:(M-1)){
      for(l in (k+1):M){
        Os_=seq_marker_theo(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,dominant_marker = dominant_marker)

        theta_W=theta_W+as.numeric(Os_$theta)
        M_o=M_o+1
        if(count==0){
          count=count+1

          Mat_symbol=Mat_symbol_create_marker_theo(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker)
          Os[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

        }else{
          count=count+1
          Os[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)
        }
        print(paste("Zipping sequence",count,"over",((M-1)*M*0.5),"",sep=" "))
      }
    }
    e_t=Sys.time()
    print("Time to Zip allsequences")
    print(e_t-s_t)
    rm(O)
    rm(Os_)

    if(length(Os)>=1){
      for(oo in 1:length(Os)){
        Os[[oo]]=symbol2Num_marker_theo(Os[[oo]])
      }
      #browser()

      theta_W=theta_W/M_o


      theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
      print("Observed Theta:")
      print(theta)
      if(Nb_marker>1){
        mu_v=numeric(Nb_marker)
        for(marker in 1:Nb_marker){
          mu_v[marker]=mu_marker[[marker]]
        }

        Not_Na_pos=which(!is.na(mu_v))
        Ne=c()
        for(marker in Not_Na_pos){
          Ne[marker]=(log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
        }
        if(any(is.na(as.numeric(Ne)))){
          Ne[which(is.na(as.numeric(Ne)))]=0
        }
        print("estimated Ne with different marker")
        print(Ne)

        if(any(is.na(as.numeric(theta)))){
          theta[which(is.na(as.numeric(theta)))]=1
        }

        print("Chosen Ne:")
        mu_diff=abs(4+log10(theta/(2*L)))
        choice=min(which(mu_diff==min(mu_diff)))
        Ne=Ne[choice]
        print(Ne)

        Na_pos=which(is.na(mu_v))
        if(length(Na_pos)>0){


          for(marker in Na_pos){
            mu_marker[[marker]]=(1-exp((log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/Ne)))*((nb_state_marker[[marker]]-1))/nb_state_marker[[marker]]
          }

          if(T){
            Ne_test=numeric(Nb_marker)
            for(marker in 1:Nb_marker){
              Ne_test[marker]=(log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
            }
            print(Ne_test)
          }


        }
        if(as.character(Ne)=="NaN"|any(as.character(theta)=="NaN")){
          stop()
        }
        print("Number of the chosen marker:")
        print(choice)
        theta=theta[choice]
        rho=rho*theta
        print("Rho:")
        print(rho)
      }else{
        Ne=(log((1+((log((1-(theta*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
        print("estimated Ne ")
        print(Ne)
        rho=rho*theta
      }
    }else{
      stop("data too poor")
    }
  }

  if(NC>1){

    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=list()
    L_total=vector()


    for(chr in 1:NC){

      M=dim(O[[chr]])[1]-2
      L=as.numeric(O[[chr]][dim(O[[chr]])[1],dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      Ost=list()
      count=0
      M_o=0
      theta_W=c()
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          Os_=seq_marker_theo(O[[chr]][c(k,l,(M+1),(M+2)),],L,position_removed[[1]],Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition)
          theta_W=theta_W+as.numeric(Os_$theta)
          M_o=M_o+1
          if(count==0){
            count=count+1
            Mat_symbol=Mat_symbol_create_marker_theo(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker)
            Ost[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

          }else{
            count=count+1
            Ost[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

          }

        }
      }
      Os[[chr]]=Ost
      theta_W_V[[chr]]=theta_W/M_o


    }


    print(L_total)
    L=L_total
    rm(O)
    rm(Ost)

    if(length(Os)>=1){
      for(oo in 1:length(Os)){
        for(cc in 1:length(Os[[oo]])){

          Os[[oo]][[cc]]=symbol2Num_marker_theo(Os[[oo]][[cc]])


        }
      }

      if(Nb_marker>1){
        Ne=rep(0,Nb_marker)
        for(marker in 1:Nb_marker){
          for(chr in 1:NC){
            Ne[marker]=Ne[marker]+(log((1+((log((1-(theta_W_V[[chr]][marker]*(nb_state_marker[[marker]]/(L_total[chr]*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
          }
          Ne[marker]=Ne[marker]/NC
        }
        print("estimated Ne with different marker")
        print(Ne)
        print("Chosen Ne:")
        mu_diff=abs(4+log10(theta/(2*L)))
        choice=which(mu_diff==min(mu_diff))
        Ne=Ne[choice]
        print(Ne)
        print("Number of the chosen marker:")
        print(choice)
        rho=c()
        for(chr in 1:NC){
          rho[chr]=rho*theta_W_V[[chr]][choice]
        }



      }else{

        Ne=c()
        for(chr in 1:NC){
          Ne=c(Ne,(log((1+((log((1-(theta_W_V[[chr]]*(nb_state_marker[[marker]]/(L_total[chr]*(nb_state_marker[[marker]]-1))))))/2)))) / (log(1-mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))) )
        }
        Ne=mean(Ne)
        for(chr in 1:NC){
          rho[chr]=rho*theta_W_V[[chr]]
        }
      }


      rho=rho*theta
      rm(Os_)
    }else{
      stop("data too poor")
    }
    theta_W=theta_W_V


  }
  if(length(Os)>=1){
    if(BaWe==1){
      results=Baum_Welch_algo_marker_theo(Os=Os, maxIt =maxit,L=L,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,redo_R=F,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,LH_opt=LH_opt,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,theta=theta,window_scaling=window_scaling)
    }
    if(BaWe==2){
      results=Baum_Welch_algo_marker_theo(Os=Os, maxIt =maxit,L=L,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=T,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,LH_opt=LH_opt,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,theta=theta,window_scaling=window_scaling)
      if(SB|SF){
        r=results$rho[1:NC]
        mu_=results$mu
        gamma_=(r*(beta*2*(1-sigma)/(2-sigma)))/mu_
        print(r)
        print(mu_)
        print(gamma_)
        if(mean(gamma_)>1){
          print("Results might not be reliable")
        }
        effect=mean(gamma_/gamma)
        if(SF&!SB){
          sigma=(1-effect)/(1-(effect/2))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
          if(sigma>=Boxs[1]&sigma<=Boxs[2]){
           # Boxs[1]=sigma
          }
        }
        if(SB&!SF){
          beta=effect
          beta=min(BoxB[2],beta)
          beta=max(BoxB[1],beta)
          if(beta>=BoxB[1]&beta<=BoxB[2]){
           # BoxB[2]=beta
          }
        }
        if(SF&SB){
          if(min(BoxB)>(1-max(Boxs))){
            sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
            sigma=max(Boxs[1],sigma)
            sigma=min(Boxs[2],sigma)
            beta=effect*(2-sigma)/(2*(1-sigma))
            beta=max(BoxB[1],beta)
            beta=min(BoxB[2],beta)
          }
          if(min(BoxB)<=(1-max(Boxs))){
            beta=effect*(2-sigma)/(2*(1-sigma))
            beta=max(BoxB[1],beta)
            beta=min(BoxB[2],beta)
            sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
            sigma=max(Boxs[1],sigma)
            sigma=min(Boxs[2],sigma)

          }
          if(gamma_!=(gamma*beta*2*(1-sigma)/(2-sigma))){
            print("Prior might disagree with results.")
          }
        }
      }
      if(NC==1){
        theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        rho=gamma*theta
        Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r*4/3))))
      }else{
        theta=theta_W_V*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        Ne=log((1+((log((1-(theta/(L_total*0.75))))/2))))/(log(1-(mu_r*4/3)))
        rho=gamma*theta
      }
      results=Baum_Welch_algo_marker_theo(Os=Os, maxIt =maxit,L=L,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,LH_opt=LH_opt,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,theta=theta,window_scaling=window_scaling)
      }
  }
  return(results)
}
