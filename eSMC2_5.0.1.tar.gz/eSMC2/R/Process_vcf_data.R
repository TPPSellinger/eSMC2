#' Builds a segregatic matrix from a vcf file
#'
#' @param path : location of the vcf file
#' @export
#' @return The segregating matrix of the vcf file
Process_vcf_data<-function(path){
  data=Get_vcf_data(path)
  M=length(data[[15]][c(10:length(data[[15]]))])*2

  i=0

  for(search_id in 1:length(data)){
    if(data[[search_id]][1]=="#CHROM"){
      start_position=search_id+1
      break()
    }
  }
  if(length(which(as.vector(strsplit(data[[start_position]][9],"")[[1]])==":"))>1){
    not_good=T
  }else{
    not_good=F
  }

  if(length(unique(matrix(as.vector(unlist(data[start_position:length(data)])),nrow=(length(data)-(start_position-1)),ncol=length(data[[start_position]]),byrow = T)[,1]))==1){
    SNP_mat=matrix(0,ncol = length(data),nrow = (M+2))
     for(ii in start_position:length(data)){
      if(nchar(data[[ii]][4])==1&nchar(data[[ii]][5])==1){
        i=i+1
        SNP_mat[(M+2),i]=as.numeric(data[[ii]][2])
        if(i==1){
          SNP_mat[(M+1),i]=as.numeric(data[[ii]][2])
        }else{
          SNP_mat[(M+1),i]=as.numeric(data[[ii]][2])- as.numeric(SNP_mat[(M+2),(i-1)])
        }

        temp_seq=strsplit(paste(data[[ii]][c(10:length(data[[ii]]))],collapse = ""),"")[[1]]
        if(not_good){
          pos=which(temp_seq=="|")
          pos=sort(c((pos+1),(pos-1)))
          SNP_mat[1:M,i]=temp_seq[pos]
        }else{
          SNP_mat[1:M,i]=temp_seq[which(temp_seq!="|")]
        }
        pos_0=which(as.numeric(SNP_mat[1:M,i])==0)
        if(length(pos_0)>0){
          SNP_mat[pos_0,i]=data[[ii]][4]
        }
        pos_1=which(as.numeric(SNP_mat[1:M,i])==1)
        if(length(pos_1)>0){
          SNP_mat[pos_1,i]=data[[ii]][5]
        }

      }
    }
   pos_0=which(as.numeric(SNP_mat[dim(SNP_mat)[1],])==0)
    if(length(pos_0)>1){
      SNP_mat=SNP_mat[,-pos_0]
    }
  }else{
    SNP_mat=list()
    count_chr=0
    for(chr in unique(matrix(as.vector(unlist(data[start_position:length(data)])),nrow=(length(data)-(start_position-1)),ncol=length(data[[start_position]]),byrow = T)[,1])){
      count_chr=count_chr+1
      i=0
      pos_chr=which(matrix(as.vector(unlist(data[start_position:length(data)])),nrow=(length(data)-(start_position-1)),ncol=length(data[[start_position]]),byrow = T)[,1]==chr)
      SNP_mat[[count_chr]]=matrix(0,ncol = length(pos_chr),nrow = (M+2))
      for(ii in sort(pos_chr)){
        ii=start_position+ii-1
        if(nchar(data[[ii]][4])==1&nchar(data[[ii]][5])==1){

          i=i+1

          SNP_mat[[count_chr]][(M+2),i]=as.numeric(data[[ii]][2])
          if(i==1){
            SNP_mat[[count_chr]][(M+1),i]=as.numeric(data[[ii]][2])
          }else{
            SNP_mat[[count_chr]][(M+1),i]=as.numeric(data[[ii]][2])- as.numeric(SNP_mat[[count_chr]][(M+2),(i-1)])
          }

          temp_seq=strsplit(paste(data[[ii]][c(10:length(data[[ii]]))],collapse = ""),"")[[1]]
          if(not_good){
            pos=which(temp_seq=="|")
            pos=sort(c((pos+1),(pos-1)))
            SNP_mat[[count_chr]][1:M,i]=temp_seq[pos]
          }else{
            SNP_mat[[count_chr]][1:M,i]=temp_seq[which(temp_seq!="|")]
          }
          pos_0=which(as.numeric(SNP_mat[[count_chr]][1:M,i])==0)
          if(length(pos_0)>0){
            SNP_mat[[count_chr]][pos_0,i]=data[[ii]][4]
          }
          pos_1=which(as.numeric(SNP_mat[[count_chr]][1:M,i])==1)
          if(length(pos_1)>0){
            SNP_mat[[count_chr]][pos_1,i]=data[[ii]][5]
          }
        }
      }
      pos_0=which(as.numeric(SNP_mat[[count_chr]][dim(SNP_mat[[count_chr]])[1],])==0)
      if(length(pos_0)>1){
        SNP_mat[[count_chr]]=SNP_mat[[count_chr]][,-pos_0]
      }
    }

  }
  return(SNP_mat)
}
