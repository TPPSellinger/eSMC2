#' Runs the baum-welch algorithm to estimate demographic history, germination , self-fertilization  and recombinationn rate
#'
#' @param Os : list containing the signal of all analysis
#' @param maxIt : number of expectation and maximization iteration
#' @param L : Sequence length
#' @param mu : estimated mutation rate given prior
#' @param theta_W : average theta waterson per chromosome
#' @param Rho : vector of estimated recombination rate per sequence
#' @param Popfix : True if population size is assumed constant
#' @param k : number of hidden states
#' @param alpha : parameter of the beta distribution
#' @param Boxa : boundaries of alpha, numeric vector of size 2 indication the minimum and maximum values of alpha (must be bigger than 1 and smaller than 2)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param BoxB : boundaries of beta, numeric vector of size 2 indication the minimum and maximum values rate ( first value must be  bigger than 0)
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop_vect :  vector of hidden states sharing population size parameter (sum must be equal to k).
#' @param window_scaling : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param sigma : self-fertilization rate
#' @param beta : germination rate
#' @param B : True to estimate alpha of the beta distribution
#' @param SF : True to estimate Self-fertilization rate
#' @param ER : True to estimation recombination rate
#' @param SB : True to estimate germination rate
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param M_a : effective number of simultaneously analyzedf sequence
#' @param TS_SNP : estimated external branch length
#' @param TC_SNP : coalescent times used to estimate external branch length
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param LH_opt : TRUE to directly maximize the likelihood (can be very slow)
#' @param ploidy : ploidy level of the organism
#' @return List containing of all model parameters.
BW_MM<-function(Os,maxIt =20,L,mu,theta_W,Rho,Popfix=T,k=20,alpha=1.99,Boxa=c(1.001,1.999),BoxP=c(3,3),Boxr=c(1,1),BoxB=c(0.05,1),Boxs=c(0,0.99),pop_vect=NA,window_scaling=c(1,0),sigma=0,beta=1,B=T,SF=F,ER=F,SB=F,NC=1,M_a=3,TS_SNP,TC_SNP,mu_b=1,Big_Window=F,LH_opt=F,ploidy){
  Xi=NA
  BW=F
  max_count=10
  symbol=list()
  if(NC==1){
    for(i in 1:length(Os)){
      symbol[[i]]= unique(Os[[i]][[1]])
    }
  }
  if(NC>1){
    for(chr in 1:NC){
      symbol[[chr]]=list()
      for(i in 1:length(Os[[chr]])){
        symbol[[chr]][[i]]= unique(Os[[chr]][[i]][[1]])
      }
    }
  }
  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  old_list=list()
  Pop=Popfix
  theta=mu*2*L
  gamma=Rho/theta
  gamma_o=gamma
  print(gamma)
  Alpha=alpha
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- k
  test.env$mu <- mu
  test.env$mu_b <- mu_b
  test.env$Boxa <- Boxa
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$BW<-BW
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$M_a<-M_a
  test.env$TC_SNP<-TC_SNP
  test.env$Alpha<-Alpha
  mb=0
  if(SB){
    BoxB[1]=max(sqrt(0.01),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
    beta=max((BoxB[1]^2),beta)
    beta=min(beta,(BoxB[2]^2))
    Beta=beta
  }

  if(SF){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Sigma=sigma
  }
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=k)){
    Klink=0.5*k
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  maxBit=1
  diff=1
  it <- 0
  if(B){
  oldalpha=(alpha-Boxa[1])/(Boxa[2]-Boxa[1])
  }
  if(!B){
    test.env$alpha <- alpha
  }
  if(!SB){
    Beta=beta
    test.env$beta <- beta
  }
  if(!SF){
    Sigma=sigma
    oldSigma=Sigma
    test.env$sigma <- sigma
  }
  if(!ER){
    oldrho=0
    if(length(unique(round(gamma,digits=3)))>1){
      oldrho=rep(0,NC)
    }
    Boxr=c(0,0)
  }
  if(ER){
    oldrho=(Boxr[1]/sum(Boxr))
    if(length(unique(round(gamma,digits=3)))>1){
      oldrho=rep((Boxr[1]/sum(Boxr)),NC)
    }
  }
  if(SB){
    oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
  }
  if(SF){
    oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
  }
  #print(length(oldrho))
  oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
  oldXi=vector()
  xx=0
  for(ix in 1:Klink){
    x=xx+1
    xx = xx + pop_vect[ix]
    oldXi[x:xx]=oldXi_[ix]
  }
  Do_BW=T
  diff_conv=vector()
  if(!LH_opt){
  while (it<maxIt){
    start_time <- Sys.time()
    it <- it+1;
    if(B){
      alpha=((oldalpha*(Boxa[2]-Boxa[1]))+Boxa[1])
    }
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }

    if(it==1&B){
      print("Searching prior alpha")
      test.env$TS_SNP<-TS_SNP
      lr=length(oldrho)
      test.env$lr<-lr
      B=F
      if(NC==1){



        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$B <- B
        test.env$Os <- Os

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)

        }

        if(SB==1){
          param=c(param,oldbeta)
        }
        if(B==1){
          param=c(param,oldalpha)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }


        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          Boxa=get('Boxa', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Sigma=get('Sigma', envir=test.env)
          Alpha=get('Alpha', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)

          Ts_t=get('TC_SNP', envir=test.env)
          TS_SNP=get('TS_SNP', envir=test.env)



          start_position=0
          if(ER==1){
            #rho_=numeric(1)
            rho=param[(start_position+1):(start_position+1)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+1

          }
          if(ER==0){
            rho=Rho
          }
          if(SF==1){

            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]

          }

          if(SF==0){
            sigma=get('sigma', envir=test.env)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1

          }

          if(SB==0){
            beta=get('beta', envir=test.env)

          }

          if(B==1){
            alpha=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            alpha=alpha*(Boxa[2]-Boxa[1])
            alpha=alpha+Boxa[1]
          }
          if(B==0){
            alpha=get('alpha', envir=test.env)
          }


          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          #browser()
          g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
          #browser()
          test=Build_MMzip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,LH=T)
          MLH=0
          for(i in 1:length(Os)){
            LH_cpp=forward_zipMM_mailund(Os[[i]][[1]],g,nu,test[[1]],TS_SNP[[i]],max_count=10)[[3]]
            MLH=MLH-LH_cpp
          }
          return(MLH)
        }
        Continue=T
        alpha=max(Boxa[2],alpha)+0.1
        LH=0
        while(Continue){
          alpha=max(alpha-0.1,Boxa[1])
          test.env$alpha <- alpha
          new_LH=function_to_minimize(param)
          print(paste("Likelihood with alpha:",alpha,sep=""))
          print(new_LH)
          if(new_LH>LH&LH!=0){
            Continue=F
            alpha=alpha_s
          }else{
            LH=new_LH
            alpha_s=alpha
          }
          if(alpha==Boxa[1]){
            Continue=F
          }
        }

        print("prior alpha:")
        print(alpha)
        Boxa=c(max(1.01,alpha-0.1),min(1.999,alpha+0.1))
        test.env$Boxa <- Boxa
        oldalpha=(alpha-Boxa[1])/(Boxa[2]-Boxa[1])
      }


      if(NC>1){

        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$B <- B
        test.env$Os <- Os





        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)

        }

        if(SB==1){
          param=c(param,oldbeta)
        }
        if(B==1){
          param=c(param,oldalpha)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }

        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          Boxa=get('Boxa', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Sigma=get('Sigma', envir=test.env)
          Alpha=get('Alpha', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          Ts_t=get('TC_SNP', envir=test.env)
          TS_SNP=get('TS_SNP', envir=test.env)
          lr=get('lr', envir=test.env)
          NC=get('NC', envir=test.env)


          start_position=0
          if(ER==1){
            #rho_=numeric(1)
            rho=param[(start_position+1):(start_position+lr)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+lr

          }
          if(ER==0){
            rho=Rho
          }
          if(SF==1){

            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]

          }

          if(SF==0){
            sigma=get('sigma', envir=test.env)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1

          }

          if(SB==0){
            beta=get('beta', envir=test.env)

          }

          if(B==1){
            alpha=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            alpha=alpha*(Boxa[2]-Boxa[1])
            alpha=alpha+Boxa[1]
          }
          if(B==0){
            alpha=get('alpha', envir=test.env)
          }


          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          MLH=0

          for(chr in 1:NC){
            builder=build_SMBC_matrix(n,rho[chr],L=L[chr],Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
            Q = builder[[1]]
            nu= builder[[2]]
            Tc=builder[[3]]
            g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[chr]][[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
            test=Build_MMzip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,LH=T)

            for(i in 1:length(Os[[chr]])){
              LH_cpp=forward_zipMM_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]],TS_SNP[[chr]][[i]],max_count=10)[[3]]
              MLH=MLH-LH_cpp
            }
          }


          return(MLH)
        }

        Continue=T
        alpha=max(Boxa[2],alpha)
        LH=0
        while(Continue){
          alpha=max(alpha-0.1,Boxa[1])
          test.env$alpha <- alpha
          new_LH=function_to_minimize(param)
          if(new_LH>LH&LH!=0){
            Continue=F
          }else{
            LH=new_LH
          }
          if(alpha==Boxa[1]){
            Continue=F
          }
        }

        print("prior alpha:")
        print(alpha)
        Boxa=c(max(1.01,alpha-0.1),min(1.999,alpha+0.1))
        test.env$Boxa <- Boxa
        oldalpha=(alpha-Boxa[1])/(Boxa[2]-Boxa[1])



      }
      B=T
    }
    print(paste("It:",it))
    if(Popfix){
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      print(c("rho/theta:",rho_/theta))
      print(paste("alpha:",alpha,sep=" "))
      Keep_going=F
      if(it==1){
        diff_o=0
      }
      if(NC==1){
        builder=build_SMBC_matrix(n=k,rho=(rho_),L=L,Xi=NA,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
      }
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_SMBC_matrix(k,(rho_[chr]),L=L[chr],Xi=NA,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
        }
      }
    }
    if(!Popfix){
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      Xi_=oldXi*sum(BoxP)
      Xi_=Xi_-(BoxP[1])
      Xi_=10^Xi_
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      print(c("rho/theta:",rho_/theta))
      print(paste("alpha:",alpha,sep=" "))
      Keep_going=F
      if(it==1){
        diff_o=0
      }
      if(NC==1){
        ##print("k,(rho_),L=L,Xi=Xi_,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window :")
        #print(c(k,(rho_),L=L,Xi=Xi_,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window))
        builder=build_SMBC_matrix(k,(rho_),L=L,Xi=Xi_,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
      }
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_SMBC_matrix(k,(rho_[chr]),L=L[chr],Xi=Xi_,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
        }
      }
    }
    if(NC==1){
      Q = builder[[1]]
      nu= builder[[2]]
      Tc= builder[[3]]
      g=build_emi_MM(n=k,mu,alpha,M_a,t=Tc,Ts_t=TC_SNP[[1]],mu_b=mu_b,beta=beta,Beta=Beta,Tc=builder[[4]])
      if(M_a==3){
        M=list()
        for(tt in 1:length(TC_SNP[[1]])){
          M[[tt]]=matrix(0,nrow=(k*4),ncol=5)
        }
        N=matrix(0,(k*4),(k*4))
        q_=rep(0,(k*4))
      }
      if(M_a==4){
        M=list()
        #M
        for(tt in 1:length(TC_SNP[[1]])){
          M[[tt]]=matrix(0,nrow=(k*11),ncol=8)
        }
        N=matrix(0,(k*11),(k*11))
        q_=rep(0,(k*11))
      }
      MLH=0

      s_t=Sys.time()
      test=Build_MMzip_Matrix_mailund(Q,g,Os[[1]][[2]],nu)
      e_t=Sys.time()
      print("Time to build Matrices")
      print(e_t-s_t)
      if(F){
      test_1_cpp=as.matrix(test[[1]][[1]][[1]])
      for(li in 2:length(test[[1]])){
        test_1_cpp=rbind(test_1_cpp,as.matrix(test[[1]][[li]][[1]]))
      }
      test_3_cpp=as.matrix(test[[3]][[1]][[1]])
      for(li in 2:length(test[[3]])){
        test_3_cpp=rbind(test_3_cpp,as.matrix(test[[3]][[li]][[1]]))
      }
      g_cpp=as.matrix(g[[1]])
      for(li in 2:length(g)){
        g_cpp=rbind(g_cpp,as.matrix(g[[li]]))
      }
}

      for(i in 1:length(Os)){
        #browser()
        #fo=forward_MM_cpp(as.numeric(Os[[i]][[1]]),g_cpp,nu,test_1_cpp,TS_SNP[[i]],M_a)
        fo=forward_zipMM_mailund(Os[[i]][[1]],g,nu,test[[1]],TS_SNP[[i]],max_count=10)
        MLH=MLH+fo[[3]]
        c=exp(fo[[2]])
        ba=Backward_zipMM_mailund(as.numeric(Os[[i]][[1]]),test[[3]],length(Tc),c,TS_SNP[[i]],max_count=10,M_a)
        #browser()

        W=list()
        for(xxx in 1:length(g)){
          int=t(Q)%*%diag(g[[xxx]][,1])
          int=eigen(int)
          W[[xxx]]=list()
          W[[xxx]]$P=Re(int$vectors)
          W[[xxx]]$P_=Re(MASS::ginv(W[[xxx]]$P))
          #W[[xxx]]$P_=solve(W[[xxx]]$P)
        }
        count_SNP=0
        if(M_a==3){
          yy=5
        }
        if(M_a==4){
          yy=9
        }
        #browser()
        for(sym in sort(as.numeric(symbol[[i]]))){
          ob=as.numeric(sym)
          pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
          pos=pos+1

          if(ob>9){

            A=Re(t(W[[(ceiling((ob-9)/max_count))]]$P)%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W[[(ceiling((ob-9)/max_count))]]$P_))
            A_=A*test[[2]][[(ceiling((ob-9)/max_count))]][[(-9+yy+ob-((ceiling((ob-9)/max_count)-1)*max_count))]]
            A_=(t(W[[(ceiling((ob-9)/max_count))]]$P_)%*%A_%*%t(W[[(ceiling((ob-9)/max_count))]]$P))
            #if(any(diag(A_)<0)|any(diag(A_)>L)){
             # browser()
            #}

            M[[(ceiling((ob-9)/max_count))]][,1]=M[[(ceiling((ob-9)/max_count))]][,1]+(diag(A_))

            A_=A*test[[4]][[(ceiling((ob-9)/max_count))]][[(-9+yy+ob-((ceiling((ob-9)/max_count)-1)*max_count))]]
            A_=(t(W[[(ceiling((ob-9)/max_count))]]$P_)%*%A_%*%t(W[[(ceiling((ob-9)/max_count))]]$P))
            truc_a=(A_%*%diag(g[[(ceiling((ob-9)/max_count))]][,1]))
            if(sum(truc_a) <= as.numeric(-1)){
              browser()
            }else{
              N=N+ truc_a
            }


          }else{
            if(ob<0){
              ba_t=t(t(ba[,(pos)])/c[(pos)])
              truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[abs(ob)]][[1]]%*%ba_t)))
              truc=(truc/(sum(truc)))*length(pos)
              M[[abs(ob)]][,1]=M[[abs(ob)]][,1]+ truc
              truc_a=(fo[[1]][,(pos-1)]%*%(t(diag(g[[abs(ob)]][,1])%*%ba_t)))
              if(sum(truc_a) <= as.numeric(-1)){
                browser()
              }else{
                N=N+ truc_a
              }
            }
          }

        }

        if(M_a==3){
          ob=c(1,2,3,4)

          pos=sort(which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])%in%ob))
          pos=pos+1

          print("nb SNP:")
          print(length(TS_SNP[[i]]))

            for(ll in pos){
              ob_t=as.numeric(Os[[i]][[1]][(ll)])
              if(ob_t<4){
              count_SNP=count_SNP+1
              ba_t=t(t(ba[,(ll)])/c[(ll)])
              truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[TS_SNP[[i]][count_SNP]]][[(ob_t+1)]]%*%ba_t)))
              truc=(truc/(sum(truc)))
              M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]=M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]+ truc
              N=N+(fo[[1]][,(ll-1)]%*%(t(diag(g[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)])%*%ba_t)))
              }else{
                ba_t=t(t(ba[,(ll)])/c[(ll)])
               truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[1]][[(ob_t+1)]]%*%ba_t)))
               truc=(truc/(sum(truc)))
                N=N+(fo[[1]][,(ll-1)]%*%(t(diag(g[[1]][,(ob_t+1)])%*%ba_t)))
            }
        }
        }
        if(M_a==4){
          ob=c(1,2,3,4,5,6,7,8)
          pos=sort(which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])%in%ob))
          pos=pos+1
            if(length(pos)>0){
            for(ll in pos){

              ob_t=as.numeric(Os[[i]][[1]][ll])
              if(ob_t<8){
              count_SNP=count_SNP+1
              ba_t=t(t(ba[,(ll)])/c[(ll)])
              truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[1]][[(ob_t+1)]]%*%ba_t)))
              truc=(truc/(sum(truc)))
              #M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]=M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]+ truc
              N=N+(fo[[1]][,(ll-1)]%*%(t(diag(g[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)])%*%ba_t)))

          }else{
              ba_t=t(t(ba[,(ll)])/c[(ll)])
              truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[1]][[(ob_t+1)]]%*%ba_t)))
              truc=(truc/(sum(truc)))
              #M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]=M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]+ truc
              N=N+(fo[[1]][,(ll-1)]%*%(t(diag(g[[1]][,(ob_t+1)])%*%ba_t)))
          }
            }
            }
        }
        if(T){
          ob_1=as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])
          if(ob_1>9){
            M[[(ceiling((ob_1-9)/max_count))]][,1]=M[[(ceiling((ob_1-9)/max_count))]][,1]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
          } else {
            if(ob_1<0){
              M[[abs(ob_1)]][,1]=M[[abs(ob_1)]][,1]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
            } else {
              count_SNP=count_SNP+1
              M[[TS_SNP[[i]][count_SNP]]][,(ob_1+1)]=M[[TS_SNP[[i]][count_SNP]]][,(ob_1+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
            }
          }




}
        q_=q_+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
      }

      browser()

      print("nb SNP analyzed:")
      print(count_SNP)
      N=N*t(Q)
      print(sum(N))
      N=Re(N)


      Scale_N=length(Os)*(L-1)/sum(N)
      if(Scale_N<0.99|Scale_N>1.01){
        browser()
      }else{
        N=N*Scale_N
      }

      print(sum(N))
      q_=q_/sum(q_)

    }
    if(NC>1){

      Q=list()
      nu=list()
      Tc=list()
      g=list()
      M=list()
      N=list()
      MLH=list()
      q_=list()
      for(chr in 1:NC){
        Q[[chr]] = builder[[chr]][[1]]
        nu[[chr]]= builder[[chr]][[2]]
        Tc[[chr]]=builder[[chr]][[3]]
        g[[chr]]=build_emi_MM(n=k,mu,alpha,M_a,mu_b=mu_b,t=Tc[[chr]],Ts_t=TC_SNP[[chr]][[1]],beta=beta,Beta=Beta,Tc=builder[[chr]][[4]])
        if(M_a==3){
          M[[chr]]=matrix(0,nrow=(k*4),ncol=5)
          N[[chr]]=matrix(0,nrow=(k*4),ncol=(k*4))
          q_[[chr]]=rep(0,(k*4))
        }
        if(M_a==4){
          M[[chr]]=matrix(0,nrow=(k*11),ncol=9)
          N[[chr]]=matrix(0,nrow=(k*11),ncol=(k*11))
          q_[[chr]]=rep(0,(k*11))
        }
        MLH[[chr]]=0

        s_t=Sys.time()
        test=Build_MMzip_Matrix_mailund(Q[[chr]],g[[chr]],Os[[1]][[1]][[2]],nu[[chr]])
        print("Time to build Matrices")
        e_t=Sys.time()
        print(e_t-s_t)

        for(i in 1:length(Os[[chr]])){


          fo=forward_zipMM_mailund(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]],TS_SNP[[chr]][[i]],max_count=10)
          MLH[[chr]]=MLH[[chr]]+fo[[3]]
          c=exp(fo[[2]])
          ba=Backward_zipMM_mailund(as.numeric(Os[[chr]][[i]][[1]]),test[[3]],length(Tc[[chr]]),c,TS_SNP[[chr]][[i]],max_count=10,M_a)


          W=list()
          for(xxx in 1:length(g[[chr]])){
            int=t(Q[[chr]])%*%diag(g[[chr]][[xxx]][,1])
            int=eigen(int)
            W[[xxx]]=list()
            W[[xxx]]$P=Re(int$vectors)
            W[[xxx]]$P_=Re(MASS::ginv(W[[xxx]]$P))

          }
          count_SNP=0
          if(M_a==3){
            yy=5
          }
          if(M_a==4){
            yy=9
          }
          #browser()
          for(sym in sort(as.numeric(symbol[[chr]][[i]]))){
            ob=as.numeric(sym)
            pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
            pos=pos+1

            if(ob>9){

              A=Re(t(W[[(ceiling((ob-9)/max_count))]]$P)%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W[[(ceiling((ob-9)/max_count))]]$P_))
              #A_=A*test[[2]][[(ceiling((ob-9)/max_count))]][[(-9+yy+ob-((ceiling((ob-9)/max_count)-1)*max_count))]]
              #A_=(t(W[[(ceiling((ob-9)/max_count))]]$P_)%*%A_%*%t(W[[(ceiling((ob-9)/max_count))]]$P))
              #if(any(diag(A_)<0)|any(diag(A_)>L)){
              #browser()
              #}

              #M[[(ceiling((ob-9)/max_count))]][,1]=M[[(ceiling((ob-9)/max_count))]][,1]+(diag(A_))

              A_=A*test[[4]][[(ceiling((ob-9)/max_count))]][[(-9+yy+ob-((ceiling((ob-9)/max_count)-1)*max_count))]]
              A_=(t(W[[(ceiling((ob-9)/max_count))]]$P_)%*%A_%*%t(W[[(ceiling((ob-9)/max_count))]]$P))
              truc_a=(A_%*%diag(g[[chr]][[(ceiling((ob-9)/max_count))]][,1]))
              if(sum(truc_a) <= as.numeric(-1)){
                browser()
              }else{
                N[[chr]]=N[[chr]]+ truc_a
              }


            }else{
              if(ob<0){
                ba_t=t(t(ba[,(pos)])/c[(pos)])
               # truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[abs(ob)]][[1]]%*%ba_t)))
              #  truc=(truc/(sum(truc)))*length(pos)
                #M[[abs(ob)]][,1]=M[[abs(ob)]][,1]+ truc
                truc_a=(fo[[1]][,(pos-1)]%*%(t(diag(g[[chr]][[abs(ob)]][,1])%*%ba_t)))
                if(sum(truc_a) <= as.numeric(-1)){
                  browser()
                }else{
                  N[[chr]]=N[[chr]]+ truc_a
                }
              }
            }

          }

          if(M_a==3){
            ob=c(1,2,3,4)

            pos=sort(which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])%in%ob))
            pos=pos+1

            print("nb SNP:")
            print(length(TS_SNP[[chr]][[i]]))

            for(ll in pos){
              ob_t=as.numeric(Os[[chr]][[i]][[1]][(ll)])
              if(ob_t<4){
                count_SNP=count_SNP+1
                ba_t=t(t(ba[,(ll)])/c[(ll)])
                #truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[TS_SNP[[chr]][[i]][count_SNP]]][[(ob_t+1)]]%*%ba_t)))
                #truc=(truc/(sum(truc)))
               #M[[chr]][[TS_SNP[[chr]][[i]][count_SNP]]][,(ob_t+1)]=M[[chr]][[TS_SNP[[chr]][[i]][count_SNP]]][,(ob_t+1)]+ truc
                N[[chr]]=N[[chr]]+(fo[[1]][,(ll-1)]%*%(t(diag(g[[chr]][[TS_SNP[[chr]][[i]][count_SNP]]][,(ob_t+1)])%*%ba_t)))
              }else{
                ba_t=t(t(ba[,(ll)])/c[(ll)])
                #truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[1]][[(ob_t+1)]]%*%ba_t)))
                #truc=(truc/(sum(truc)))
                N[[chr]]=N[[chr]]+(fo[[1]][,(ll-1)]%*%(t(diag(g[[chr]][[1]][,(ob_t+1)])%*%ba_t)))
              }
            }
          }
          if(M_a==4){
            ob=c(1,2,3,4,5,6,7,8)
            pos=sort(which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])%in%ob))
            pos=pos+1
            if(length(pos)>0){
              for(ll in pos){

                ob_t=as.numeric(Os[[chr]][[i]][[1]][ll])
                if(ob_t<8){
                  count_SNP=count_SNP+1
                  ba_t=t(t(ba[,(ll)])/c[(ll)])
                  #truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[1]][[(ob_t+1)]]%*%ba_t)))
                  #truc=(truc/(sum(truc)))
                  #M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]=M[[TS_SNP[[i]][count_SNP]]][,(ob_t+1)]+ truc
                  N[[chr]]=N[[chr]]+(fo[[1]][,(ll-1)]%*%(t(diag(g[[chr]][[TS_SNP[[chr]][[i]][count_SNP]]][,(ob_t+1)])%*%ba_t)))

                }else{
                  ba_t=t(t(ba[,(ll)])/c[(ll)])
                  #truc=c(rowSums(fo[[1]][,(ll-1)]*(test[[1]][[1]][[(ob_t+1)]]%*%ba_t)))
                  #truc=(truc/(sum(truc)))
                  #M[[chr]][[TS_SNP[[chr]][[i]][count_SNP]]][,(ob_t+1)]=M[[chr]][[TS_SNP[[chr]][[i]][count_SNP]]][,(ob_t+1)]+ truc
                  N[[chr]]=N[[chr]]+(fo[[1]][,(ll-1)]%*%(t(diag(g[[chr]][[1]][,(ob_t+1)])%*%ba_t)))
                }
              }
            }
          }
          if(T){
            ob_1=as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])
            if(ob_1>9){
             # M[[chr]][[(ceiling((ob_1-9)/max_count))]][,1]=M[[(ceiling((ob_1-9)/max_count))]][,1]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
            } else {
              if(ob_1<0){
              #  M[[abs(ob_1)]][,1]=M[[abs(ob_1)]][,1]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
              } else {
                count_SNP=count_SNP+1
               # M[[TS_SNP[[i]][count_SNP]]][,(ob_1+1)]=M[[TS_SNP[[i]][count_SNP]]][,(ob_1+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
              }
            }




          }
          q_[[chr]]=q_[[chr]]+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
        }

        N[[chr]]=N[[chr]]*t(Q[[chr]])
        print("nb SNP analyzed:")
        print(count_SNP)

        print(sum(N[[chr]]))
        N[[chr]]=Re(N[[chr]])


        Scale_N=length(Os[[chr]])*(L[chr]-1)/sum(N[[chr]])
        if(Scale_N<0.99|Scale_N>1.01){
          browser()
        }else{
          N[[chr]]=N[[chr]]*Scale_N
        }
        if(F){
        Scale_M=L[chr]/sum(M[[chr]])
        M[[chr]]=M[[chr]]*Scale_M
        q_[[chr]]=q_[[chr]]/sum(q_[[chr]])
        }
      }
    }
    if(it>1){
      print(paste(" old Likelihood: ",oldMLH))
    }
    if(NC==1){
      print(paste(" New Likelihood: ",MLH))

      if(it>1){
        if(MLH=="NaN"){
          stop("Problem in algorithm, Likelihood not computable.")
        }
        if(oldMLH >=MLH){
          it=maxIt
          MB=maxBit
        }

      }
      oldMLH=MLH
    }
    if(NC>1){
      MLH1=0
      for(chr in 1:length(MLH)){
        MLH1=MLH[[chr]]+MLH1
      }
      print(paste("New Likelihood: ",MLH1))
      if(it>1){
        if(MLH1=="NaN"){
          stop("Problem in algorithm, Likelihood not computable.")
        }
        if(oldMLH >= MLH1){
            it=maxIt
            MB=maxBit
        }

      }
      oldMLH=MLH1
    }

      test.env$Big_Xi <- N
      test.env$Big_M <-M
      test.env$q_ <-q_
      lr=length(oldrho)
      test.env$lr<-lr

    Do_BW=T

    if(!Popfix){
      oldXi_s=oldXi_
    }
    if(ER){
      oldrho_s=oldrho
    }

    if(SB){
      oldbeta_s=oldbeta
    }
    if(SF){
      oldsigma_s=oldsigma
    }
    if(B){
      oldalpha_s=oldalpha
    }

    lr=length(oldrho)
    test.env$lr<-lr
    if(Do_BW){
      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB
      test.env$B <- B
      test.env$Os <- Os

      if(NC==1){





            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              mu=get('mu', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              Klink=get('Klink', envir=test.env)
              Rho=get('Rho', envir=test.env)
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              Boxa=get('Boxa', envir=test.env)
              pop_vect=get('pop_vect', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Sigma=get('Sigma', envir=test.env)
              Alpha=get('Alpha', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Pop=get('Pop', envir=test.env)
              ER=get('ER', envir=test.env)
              SF=get('SF', envir=test.env)
              SB=get('SB', envir=test.env)
              Os=get('Os', envir=test.env)
              q_=get('q_', envir=test.env)
              Big_M=get('Big_M', envir=test.env)
              BW=get('BW', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)


              start_position=0
              if(ER==1){
                #rho_=numeric(1)
                rho=param[(start_position+1):(start_position+1)]
                rho=rho*sum(Boxr)
                rho=rho-(Boxr[1])
                rho=10^(rho)
                rho=rho*Rho
                start_position=start_position+1

              }
              if(ER==0){
                rho=Rho
              }
              if(SF==1){

                sigma=param[(start_position+1):(start_position+1)]
                start_position=start_position+1
                sigma=sigma*(Boxs[2]-Boxs[1])
                sigma=sigma+Boxs[1]

              }

              if(SF==0){
                sigma=get('sigma', envir=test.env)
              }
              if(SB==1){
                beta_=numeric(n)
                beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+1

              }

              if(SB==0){
                beta=get('beta', envir=test.env)

              }

              if(B==1){
                alpha=param[(start_position+1):(start_position+1)]
                start_position=start_position+1
                alpha=alpha*(Boxa[2]-Boxa[1])
                alpha=alpha+Boxa[1]
              }
              if(B==0){
                alpha=get('alpha', envir=test.env)
              }


              if(!Pop){
                Xi=numeric(n)
                Xi_=param[(start_position+1):(start_position+Klink)]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  Xi[x:xx]=Xi_[ix]
                }
                Xi=Xi*sum(BoxP)
                Xi=Xi-(BoxP[1])
                Xi=10^Xi
              }else{
                Xi=rep(1,n)
              }
              builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)

              Q=builder[[1]]
              Q=t(Q)
              A=as.vector(Q)
              keep=which(A>0)
              A=A[keep]
              Big_Xi=as.vector(Big_Xi)
              Big_Xi=Big_Xi[keep]

              if(BW){
                Tc=builder[[3]]
                Ts_t=get('TC_SNP', envir=test.env)
                g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
                Big_M=get('Big_M', envir=test.env)
                q_=get('q_', envir=test.env)
                nu=builder[[2]]

                LH=-sum(log(A)*Big_Xi)-sum(log(nu)*q_)
                for(gg in 1:length(g)){
                  x=as.vector(g[[gg]])
                  keep=which(x>0)
                  x=x[keep]
                  m=as.vector(Big_M[[gg]])
                  m=m[keep]
                  LH=LH-sum(log(x)*m)
                }
              }
              if(!BW){
                LH=-sum(log(A)*Big_Xi)
              }
              return(LH)
            }


            param=c()
            if(ER==1){
              param=c(param,oldrho)

            }

            if(SF==1){
              param=c(param,oldsigma)

            }

            if(SB==1){
              param=c(param,oldbeta)
            }
            if(B==1){
              param=c(param,oldalpha)
            }
            if(!Popfix){
              param=c(param,oldXi_)
            }

            sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(param),M=c(20)))
            sol=as.matrix(sol[[1]])
            start_position=0
            sol=as.numeric(sol[1:length(param),1])

            if(ER==1){
              rho=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              # browser()
              oldrho=rho
            }

            if(SF==1){
              sigma_=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              oldsigma=sigma_
            }



            if(SB==1){
              beta_=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              oldbeta=beta_
            }

            if(B==1){
              alpha_=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              oldalpha=alpha_
            }


            if(!Popfix){
              Xi_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldXi_=Xi_
            }


      }
      if(NC>1){


        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$B <- B
        test.env$Os <- Os

        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          Boxa=get('Boxa', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Sigma=get('Sigma', envir=test.env)
          Alpha=get('Alpha', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          q_=get('q_', envir=test.env)
          Big_M=get('Big_M', envir=test.env)
          BW=get('BW', envir=test.env)
          Big_Xi=get('Big_Xi', envir=test.env)
          lr=get('lr', envir=test.env)
          NC=get('NC', envir=test.env)
          start_position=0
          if(ER==1){
            #rho_=numeric(1)
            rho=param[(start_position+1):(start_position+lr)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+lr

          }
          if(ER==0){
            rho=Rho
          }
          if(SF==1){

            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]

          }

          if(SF==0){
            sigma=get('sigma', envir=test.env)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1

          }

          if(SB==0){
            beta=get('beta', envir=test.env)

          }

          if(B==1){
            alpha=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            alpha=alpha*(Boxa[2]-Boxa[1])
            alpha=alpha+Boxa[1]
          }
          if(B==0){
            alpha=get('alpha', envir=test.env)
          }


          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          LH=0

          for(chr in 1:NC){
            builder=build_SMBC_matrix(n,rho[chr],L=L[chr],Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)

            Q=builder[[1]]
            Q=t(Q)
            A=as.vector(Q)
            keep=which(A>0)
            A=A[keep]
            Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
            Big_Xi[[chr]]=Big_Xi[[chr]][keep]

            if(BW){
              Tc=builder[[3]]
              Ts_t=get('TC_SNP', envir=test.env)
              g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[chr]][[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
              nu=builder[[2]]

              LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(nu)*q_[[chr]])
              for(gg in 1:length(g)){
                x=as.vector(g[[gg]])
                keep=which(x>0)
                x=x[keep]
                m=as.vector(Big_M[[chr]][[gg]])
                m=m[keep]
                LH=LH-sum(log(x)*m)
              }
            }
            if(!BW){
              LH=-sum(log(A)*Big_Xi[[chr]])
            }
          }

          return(LH)
        }

            param=c()
            if(ER==1){
              param=c(param,oldrho)
            }

            if(SF==1){
              param=c(param,oldsigma)
            }

            if(SB==1){
              param=c(param,oldbeta)
            }
            if(B==1){
              param=c(param,oldalpha)
            }
            if(!Popfix){
              param=c(param,oldXi_)
            }

            sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(param),M=c(20)))
            sol=as.matrix(sol[[1]])
            start_position=0
            sol=as.numeric(sol[1:length(param),1])

            if(ER==1){
              rho=sol[(start_position+1):(start_position+lr)]
              start_position=start_position+lr
              # browser()
              oldrho=rho
            }

            if(SF==1){
              sigma_=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              oldsigma=sigma_
            }



            if(SB==1){
              beta_=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              oldbeta=beta_
            }

            if(B==1){
              alpha_=sol[(start_position+1):(start_position+1)]
              start_position=start_position+1
              oldalpha=alpha_
            }


            if(!Popfix){
              Xi_=sol[(start_position+1):(start_position+Klink)]
              start_position=start_position+Klink
              oldXi_=Xi_
            }




      }
    }

    end_time <- Sys.time()
    print("time for BW loop:")
    print(end_time-start_time)
  }
  }else{
    test.env$TS_SNP<-TS_SNP
    lr=length(oldrho)
    test.env$lr<-lr

    if(B){
      print("Searching prior alpha")
      B=F
      if(NC==1){



        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$B <- B
        test.env$Os <- Os

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }
        if(B==1){
          param=c(param,oldalpha)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }


        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          Boxa=get('Boxa', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Sigma=get('Sigma', envir=test.env)
          Alpha=get('Alpha', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          Ts_t=get('TC_SNP', envir=test.env)
          TS_SNP=get('TS_SNP', envir=test.env)



          start_position=0
          if(ER==1){
            #rho_=numeric(1)
            rho=param[(start_position+1):(start_position+1)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+1

          }
          if(ER==0){
            rho=Rho
          }
          if(SF==1){

            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]

          }

          if(SF==0){
            sigma=get('sigma', envir=test.env)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1

          }

          if(SB==0){
            beta=get('beta', envir=test.env)

          }

          if(B==1){
            alpha=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            alpha=alpha*(Boxa[2]-Boxa[1])
            alpha=alpha+Boxa[1]
          }
          if(B==0){
            alpha=get('alpha', envir=test.env)
          }


          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
          test=Build_MMzip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,LH=T)
          MLH=0
          for(i in 1:length(Os)){
            LH_cpp=forward_zipMM_mailund(Os[[i]][[1]],g,nu,test[[1]],TS_SNP[[i]],max_count=10)[[3]]
            MLH=MLH-LH_cpp
          }
          return(MLH)
        }
        Continue=T
        alpha=max(Boxa[2],alpha)+0.1
        LH=0
        while(Continue){
          alpha=max(alpha-0.1,Boxa[1])
          test.env$alpha <- alpha
          new_LH=function_to_minimize(param)
          print(paste("Likelihood with alpha:",alpha,sep=""))
          print(new_LH)
          if(new_LH>LH&LH!=0){
            Continue=F
            alpha=alpha_s
          }else{
            LH=new_LH
            alpha_s=alpha
          }
          if(alpha==Boxa[1]){
            Continue=F
          }
        }
        alpha=alpha_s
        print("prior alpha:")
        print(alpha)
        Boxa=c(max(1.01,alpha-0.1),min(1.999,alpha+0.1))
        test.env$Boxa <- Boxa
        oldalpha=(alpha-Boxa[1])/(Boxa[2]-Boxa[1])
      }


      if(NC>1){

        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$B <- B
        test.env$Os <- Os





        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)

        }

        if(SB==1){
          param=c(param,oldbeta)
        }
        if(B==1){
          param=c(param,oldalpha)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }

        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          mu=get('mu', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          Boxa=get('Boxa', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Sigma=get('Sigma', envir=test.env)
          Alpha=get('Alpha', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          Ts_t=get('TC_SNP', envir=test.env)
          TS_SNP=get('TS_SNP', envir=test.env)
          lr=get('lr', envir=test.env)
          NC=get('NC', envir=test.env)


          start_position=0
          if(ER==1){
            #rho_=numeric(1)
            rho=param[(start_position+1):(start_position+lr)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho=rho*Rho
            start_position=start_position+lr

          }
          if(ER==0){
            rho=Rho
          }
          if(SF==1){

            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]

          }

          if(SF==0){
            sigma=get('sigma', envir=test.env)
          }
          if(SB==1){
            beta_=numeric(n)
            beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1

          }

          if(SB==0){
            beta=get('beta', envir=test.env)

          }

          if(B==1){
            alpha=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            alpha=alpha*(Boxa[2]-Boxa[1])
            alpha=alpha+Boxa[1]
          }
          if(B==0){
            alpha=get('alpha', envir=test.env)
          }


          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          MLH=0
          for(chr in 1:NC){
            builder=build_SMBC_matrix(n,rho[chr],L=L[chr],Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
            Q = builder[[1]]
            nu= builder[[2]]
            Tc=builder[[3]]
            g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[chr]][[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
            test=Build_MMzip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,LH=T)
            for(i in 1:length(Os[[chr]])){
              LH_cpp=forward_zipMM_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]],TS_SNP[[chr]][[i]],max_count=10)[[3]]
              MLH=MLH-LH_cpp
            }
          }


          return(MLH)
        }

        Continue=T
        alpha=max(Boxa[2],alpha)
        LH=0
        while(Continue){
          alpha=max(alpha-0.1,Boxa[1])
          test.env$alpha <- alpha
          new_LH=function_to_minimize(param)
          if(new_LH>LH&LH!=0){
            Continue=F
          }else{
            LH=new_LH
          }
          if(alpha==Boxa[1]){
            Continue=F
          }
        }

        print("prior alpha:")
        print(alpha)
        Boxa=c(max(1.01,alpha-0.1),min(1.999,alpha+0.1))
        test.env$Boxa <- Boxa
        oldalpha=(alpha-Boxa[1])/(Boxa[2]-Boxa[1])



      }
      B=T
    }


    if(NC==1){



      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB
      test.env$B <- B
      test.env$Os <- Os



      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        Boxa=get('Boxa', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Sigma=get('Sigma', envir=test.env)
        Alpha=get('Alpha', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        Os=get('Os', envir=test.env)

        Ts_t=get('TC_SNP', envir=test.env)
        TS_SNP=get('TS_SNP', envir=test.env)



        start_position=0
        if(ER==1){
          #rho_=numeric(1)
          rho=param[(start_position+1):(start_position+1)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+1

        }
        if(ER==0){
          rho=Rho
        }
        if(SF==1){

          sigma=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]

        }

        if(SF==0){
          sigma=get('sigma', envir=test.env)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+1

        }

        if(SB==0){
          beta=get('beta', envir=test.env)

        }

        if(B==1){
          alpha=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          alpha=alpha*(Boxa[2]-Boxa[1])
          alpha=alpha+Boxa[1]
        }
        if(B==0){
          alpha=get('alpha', envir=test.env)
        }


        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }
        builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
        Q = builder[[1]]
        nu= builder[[2]]
        Tc=builder[[3]]
        g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
        test=Build_MMzip_Matrix_mailund(Q,g,Os[[1]][[2]],nu,LH=T)
        MLH=0
        for(i in 1:length(Os)){
          LH_cpp=forward_zipMM_mailund(Os[[i]][[1]],g,nu,test[[1]],TS_SNP[[i]],max_count=10)[[3]]
          MLH=MLH-LH_cpp
        }
        return(MLH)
      }


      param=c()
      if(ER==1){
        param=c(param,oldrho)

      }

      if(SF==1){
        param=c(param,oldsigma)

      }

      if(SB==1){
        param=c(param,oldbeta)
      }
      if(B==1){
        param=c(param,oldalpha)
      }
      if(!Popfix){
        param=c(param,oldXi_)
      }

      sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(param),M=c(20)))
      sol=as.matrix(sol[[1]])
      start_position=0
      sol=as.numeric(sol[1:length(param),1])

      if(ER==1){
        rho=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        # browser()
        oldrho=rho
      }

      if(SF==1){
        sigma_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldsigma=sigma_
      }



      if(SB==1){
        beta_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldbeta=beta_
      }

      if(B==1){
        alpha_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldalpha=alpha_
      }


      if(!Popfix){
        Xi_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldXi_=Xi_
      }




    }


    if(NC>1){

      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB
      test.env$B <- B
      test.env$Os <- Os




      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        Boxa=get('Boxa', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Sigma=get('Sigma', envir=test.env)
        Alpha=get('Alpha', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        Os=get('Os', envir=test.env)
        Ts_t=get('TC_SNP', envir=test.env)
        TS_SNP=get('TS_SNP', envir=test.env)
        lr=get('lr', envir=test.env)
        NC=get('NC', envir=test.env)


        start_position=0
        if(ER==1){
          #rho_=numeric(1)
          rho=param[(start_position+1):(start_position+lr)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+lr

        }
        if(ER==0){
          rho=Rho
        }
        if(SF==1){

          sigma=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]

        }

        if(SF==0){
          sigma=get('sigma', envir=test.env)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+1

        }

        if(SB==0){
          beta=get('beta', envir=test.env)

        }

        if(B==1){
          alpha=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          alpha=alpha*(Boxa[2]-Boxa[1])
          alpha=alpha+Boxa[1]
        }
        if(B==0){
          alpha=get('alpha', envir=test.env)
        }


        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }
        MLH=0

        for(chr in 1:NC){
          builder=build_SMBC_matrix(n,rho[chr],L=L[chr],Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emi_MM(n=n,mu,alpha,M_a,t=Tc,mu_b=mu_b,Ts_t[[chr]][[1]],beta=beta,Beta=Beta,Tc=builder[[4]])
          test=Build_MMzip_Matrix_mailund(Q,g,Os[[chr]][[1]][[2]],nu,LH=T)

          for(i in 1:length(Os[[chr]])){
            LH_cpp=forward_zipMM_mailund(Os[[chr]][[i]][[1]],g,nu,test[[1]],TS_SNP[[chr]][[i]],max_count=10)[[3]]
            MLH=MLH-LH_cpp
          }
        }


        return(MLH)
      }




      param=c()
      if(ER==1){
        param=c(param,oldrho)

      }

      if(SF==1){
        param=c(param,oldsigma)

      }

      if(SB==1){
        param=c(param,oldbeta)
      }
      if(B==1){
        param=c(param,oldalpha)
      }
      if(!Popfix){
        param=c(param,oldXi_)
      }

      sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=15+length(param),M=c(20)))
      sol=as.matrix(sol[[1]])
      start_position=0
      sol=as.numeric(sol[1:length(param),1])

      if(ER==1){
        rho=sol[(start_position+1):(start_position+lr)]
        start_position=start_position+lr
        # browser()
        oldrho=rho
      }

      if(SF==1){
        sigma_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldsigma=sigma_
      }



      if(SB==1){
        beta_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldbeta=beta_
      }

      if(B==1){
        alpha_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldalpha=alpha_
      }


      if(!Popfix){
        Xi_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldXi_=Xi_
      }

    }

  }




  if(NC==1){

    if(B){
      alpha=((oldalpha*(Boxa[2]-Boxa[1]))+Boxa[1])
    }
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }
    if(Popfix){
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      builder=build_SMBC_matrix(n=k,rho=(rho_),L=L,Xi=NA,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
    }
    if(!Popfix){
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      Xi_=oldXi*sum(BoxP)
      Xi_=Xi_-(BoxP[1])
      Xi_=10^Xi_
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      builder=build_SMBC_matrix(k,(rho_),L=L,Xi=Xi_,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)

    }
    Q=builder[[1]]
    Q=t(Q)
    res<-list()
    res$Tc=builder[[4]]
    res$Q<-Q
    res$N<-N
    rho_=rho_/(2*L)
    if(!Popfix){
      res$Xi=Xi_
    }
    res$sigma=sigma
    res$beta=beta
    res$alpha=alpha
    res$mu=mu
    res$L<-L
    res$rho=rho_
    m= 2.0 + exp(alpha * log(2) + (1 - alpha) * log(3) - log(alpha - 1))
    scale_alpha=(alpha*beta(2-alpha,alpha))/(m^alpha)
    res$scale_alpha=scale_alpha

  }
  if(NC>1){

    res <- list();
    Tc=list()
    if(B){
      alpha=((oldalpha*(Boxa[2]-Boxa[1]))+Boxa[1])
    }
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }
    if(Popfix){
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_SMBC_matrix(k,(rho_[chr]),L=L[chr],Xi=NA,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
          Tc[[chr]]=builder[[chr]][[4]]
        }
      }
    }
    if(!Popfix){
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      Xi_=oldXi*sum(BoxP)
      Xi_=Xi_-(BoxP[1])
      Xi_=10^Xi_
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_SMBC_matrix(k,(rho_[chr]),L=L[chr],Xi=Xi_,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,Big_Window=Big_Window,ploidy=ploidy)
          Tc[[chr]]=builder[[chr]][[4]]
        }
      }
    }
    res$Tc=Tc
    res$L<-L
    rho_=rho_/(2*L)
    if(!Popfix){
      res$Xi=Xi_
    }
    res$sigma=sigma
    res$beta=beta
    res$alpha=alpha
    res$rho=rho_
    res$mu=mu
    m= 2.0 + exp(alpha * log(2) + (1 - alpha) * log(3) - log(alpha - 1))
    scale_alpha=(alpha*beta(2-alpha,alpha))/(m^alpha)
    res$scale_alpha=scale_alpha
  }
  return(res)
}
