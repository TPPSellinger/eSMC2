#' Creates a multihetsep file from a Segregating matrix
#'
#' @param O : Segregating matrix
#' @param name : location  and name of the file
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @export
#' @return A file similar to ms output#
create_realinput_marker_theo<-function(O,name,Nb_marker=1,nb_state_marker=list(c(4)),Marker_supperposition=T){
  options(scipen=999)
  O=as.matrix(O)
  output=matrix(NA,nrow=dim(O)[2],ncol = 4)
  count=0
  M=dim(O)[1]-1
  vect_opti=as.numeric(O[M+1,])
  O=O[-(M+1),]
  if(Nb_marker>1){
    if(Marker_supperposition){
      possible_marker=c()
      for(marker in 1:Nb_marker){
        if(marker==1){
          possible_marker=paste(paste("m",marker,sep=""),letters[1:nb_state_marker[[marker]]],sep="_")
        }else{
          possible_marker_o=possible_marker
          possible_marker=c()
          for(ll in possible_marker_o ){
            possible_marker=c(possible_marker,paste(ll,paste("m",marker,sep=""),letters[1:nb_state_marker[[marker]]],sep="_"))
          }

        }

      }
      nucleotide=LETTERS[1:length(possible_marker)]
    }else{
      possible_marker=c()
      for(marker in 1:Nb_marker){
        possible_marker=c(possible_marker,paste(paste("m",marker,sep=""),letters[1:nb_state_marker[[marker]]],sep="_"))
      }
      nucleotide=LETTERS[1:length(possible_marker)]
    }


  }else{
    nucleotide=LETTERS[1:nb_state_marker[[1]]]
    possible_marker=letters[1:nb_state_marker[[1]]]
  }


  for(nu in 1:length(possible_marker)){
    for(m in 1:M){
      pos_mm=which(as.character(O[m,])==as.character(possible_marker[nu]))
      if(length(pos_mm)>0){
        O[m,pos_mm]<-nucleotide[nu]
        rm(pos_mm)
      }

    }
  }
  for(p in 1:dim(O)[2]){
    count=count+1
    output[count,1]=1
    output[count,2]=as.numeric(format(as.numeric(vect_opti[p]),scientific = F))
    if(count==1){
      output[count,3]=as.numeric((as.numeric(format(as.numeric(vect_opti[p]),scientific = F))-1),scientific = F)
    }
    if(count>1){
      output[count,3]=as.numeric(format(as.numeric(vect_opti[p])-as.numeric(output[(count-1),2]),scientific = F))
    }
    output[count,4]=paste(O[,p],collapse="")

  }
  output=output[1:count,]
  write.table(output, file=paste(name,".txt",sep=""), quote = FALSE, row.names=FALSE, col.names=FALSE)
  options(scipen=0)
}
