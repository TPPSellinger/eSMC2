#'  Builds the matrix symbol
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param dominant_marker : index of the marker to use for scaling
#' @return A list of matrix symbol
Mat_symbol_create_marker_theo<-function(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker){
  if(Marker_supperposition){
    max_count=c(9,4)
    zip_symbol=c(0,1)
    symbol_l=list()
    symbol_l[[1]]=c("00","aa","bb","cc","dd","ee","ff","gg","hh")
    symbol_l[[2]]=c("11","jj","kk","ll")
    used_letters=letters[1:13]
    for (marker in 1:Nb_marker) {
      symbol_l[[(marker+2)]]=c(paste(marker+2,marker+2,sep=""))
    }
  }else{
    max_count=rep(5,(Nb_marker+1))
    max_count[dominant_marker]=9
    zip_symbol=c(0:Nb_marker)
    symbol_l=list()
    count_l=1
    MAJ=F
    used_letters=c()
    for (marker in 1:(Nb_marker+1)) {
      if((count_l+(max_count[marker]))>26| MAJ){
        count_l=1
        MAJ=T
        symbol_l[[(marker)]]=c(paste(marker-1,marker-1,sep=""),paste(LETTERS[count_l:(count_l+(max_count[marker]-2))],LETTERS[count_l:(count_l+(max_count[marker]-2))],sep=""))
        used_letters=c(used_letters,LETTERS[count_l:(count_l+(max_count[marker]-1))])
      }else{
        symbol_l[[(marker)]]=c(paste(marker-1,marker-1,sep=""),paste(letters[count_l:(count_l+(max_count[marker]-2))],letters[count_l:(count_l+(max_count[marker]-2))],sep=""))
        used_letters=c(used_letters,letters[count_l:(count_l+(max_count[marker]-1))])
      }
      count_l= count_l+max_count[marker]
    }
  }
  mat_symbol_f=list()
  count_zip=0
  count_l=0
  for(zip_o in zip_symbol){
    count=0
    count_zip=count_zip+1
    criteria=T
    mat_symbol=vector()
    l=vector()
    if(criteria){
      while(criteria){
        count_l=count_l+1
        count=count+1
        new_symbol=used_letters[count_l]
        symbol=symbol_l[[(zip_o+1)]][count]
        if(length(symbol)>0){
          rep_symbol=symbol
          mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
        }
        if(count>=max_count[count_zip]){
          criteria=F
        }
      }
    }
    mat_symbol_f[[(zip_o+1)]]=mat_symbol
  }
  return(mat_symbol_f)
}
