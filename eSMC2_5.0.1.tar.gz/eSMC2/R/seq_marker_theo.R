#' Build signal for theoretical markers
#'
#' @param DNA : matrix of segregating sites for the whole sample with the methylation information
#' @param n : sequence length
#' @param position_removed : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param dominant_marker : index of the marker to use for scaling
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seq_marker_theo<-function(DNA,n,position_removed=NA,Nb_marker=3,nb_state_marker=list(c(2),c(2),c(2)),Marker_supperposition=T,dominant_marker=NA){
  output=list()
  DNA=as.matrix(DNA)

  if(Marker_supperposition){
    marker_matrix=list()
    marker_index=list()
    if(Nb_marker>1){
      possible_marker=c()
      for(marker in 1:Nb_marker){
        if(marker==1){
          possible_marker=paste(paste("m",marker,sep=""),letters[1:nb_state_marker[[marker]]],sep="_")
        }else{
          possible_marker_o=possible_marker
          possible_marker=c()
          for(ll in possible_marker_o ){
            possible_marker=c(possible_marker,paste(ll,paste("m",marker,sep=""),letters[1:nb_state_marker[[marker]]],sep="_"))
          }

        }
      }
      nucleotide=LETTERS[1:length(possible_marker)]
      mut_index=c()
      for(marker in 1:Nb_marker){
        x=4+((marker-1)*5)
        marker_index[[marker]]=c(substr(possible_marker,x,x))
        marker_matrix[[marker]]=cbind(nucleotide,marker_index[[marker]])
        if(marker==1){
          mut_index=c(0,1)
        }else{
          mut_index_o=mut_index
          mut_index=c()
          for(mu_i in  mut_index_o)
            mut_index=c(mut_index,paste(mu_i,c(0,1),sep=""))
        }

      }
      mut_index=mut_index[-1]
      #  print("mut_index")
      #  print(mut_index)
      pos=which(DNA[1,]!=DNA[2,])
      seq=rep(1,n)
      for(p in pos){
        signal=c()
        for(marker in 1:Nb_marker){
          diff=marker_matrix[[marker]][which(marker_matrix[[marker]][,1]==DNA[1,p]),2]!=marker_matrix[[marker]][which(marker_matrix[[marker]][,1]==DNA[2,p]),2]
          signal=paste(signal,as.character(as.numeric(diff)),sep="")
        }
        if(signal==paste(rep(0,Nb_marker),sep="")){
          seq[as.numeric(DNA[4,p])]=0
        }else{
          seq[as.numeric(DNA[4,p])]=1+which(mut_index==signal)
        }

      }

    }else{
      nucleotide=LETTERS[1:nb_state_marker[[1]]]
      possible_marker=letters[1:nb_state_marker[[1]]]
      pos=which(DNA[1,]!=DNA[2,])
      seq=rep(1,n)
      seq[as.numeric(DNA[4,pos])]=2
    }



    mask_pos=c((which((as.numeric(DNA[3,2:(dim(DNA)[2])])+as.numeric(DNA[4,1:(dim(DNA)[2]-1)]))!=as.numeric(DNA[4,2:(dim(DNA)[2])]))))
    mask_pos= mask_pos+1
    if(length(mask_pos)>0){
      for(cc in mask_pos){
        if(cc==1){
          if(as.numeric(DNA[3,cc])>1){
            seq[as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc]))))]=0
          }
        }else{
          if(as.numeric(DNA[3,(cc)])>1){
            seq[as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=0
          }
        }
      }
    }
    good_pos=c(0,(which((as.numeric(DNA[3,2:(dim(DNA)[2])])+as.numeric(DNA[4,1:(dim(DNA)[2]-1)]))==as.numeric(DNA[4,2:(dim(DNA)[2])]))))
    good_pos= good_pos+1
    if(length(good_pos)>0){
      for(cc in good_pos){
        if(cc==1){
          if(as.numeric(DNA[3,cc])>1){
            seq[c(1:(as.numeric(DNA[4,cc])-1))]=0
          }
        }else{
          if(as.numeric(DNA[3,(cc)])>1){
            seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)]=0
          }
        }
      }
    }


    if(!is.na(position_removed)){
      position_to_be_removed=numeric()
      for(ii in 1:length(position_removed)){
        position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
      }
      position_removed=position_to_be_removed
      rm(position_to_be_removed)
    }

    seq=as.numeric(seq)

    if(!is.na(position_removed)){
      seq[as.numeric(c(position_removed))]=1
      rm(position_removed)
    }

  }else{


    if(Nb_marker>1){
      seq=rep(Nb_marker,n)
      possible_marker=list()
      count_l=1
      for(marker in 1:Nb_marker){
        possible_marker[[marker]]=LETTERS[count_l:(count_l+nb_state_marker[[marker]]-1)]
        count_l=count_l+nb_state_marker[[marker]]
      }

      for(marker in 1:Nb_marker){
        pos_marker=which(DNA[1,]%in%possible_marker[[marker]])

        if(length(pos_marker)>0){
          seq[as.numeric(DNA[4,pos_marker])]=marker-1
          pos_diff=which(DNA[1,pos_marker]!=DNA[2,pos_marker])
          if(length(pos_diff)>0){
            seq[as.numeric(DNA[4,pos_marker[pos_diff]])]=Nb_marker+marker
          }
        }
      }



    }else{
      nucleotide=LETTERS[1:nb_state_marker[[1]]]
      possible_marker=letters[1:nb_state_marker[[1]]]
      pos=which(DNA[1,]!=DNA[2,])
      seq=rep(1,n)
      seq[as.numeric(DNA[4,pos])]=2
    }





    mask_pos=c(0,(which((as.numeric(DNA[3,2:(dim(DNA)[2])])+as.numeric(DNA[4,1:(dim(DNA)[2]-1)]))!=as.numeric(DNA[4,2:(dim(DNA)[2])]))))
    mask_pos= mask_pos+1
    if(length(mask_pos)>0){
      for(cc in mask_pos){
        if(cc==1){
          if(as.numeric(DNA[3,cc])>1){
            seq[as.numeric(sample(c(1:(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc]))))]=dominant_marker-1
          }
        }else{
          if(as.numeric(DNA[3,(cc)])>1){
            seq[as.numeric(sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)),(as.numeric(DNA[3,cc])-1)))]=dominant_marker-1
          }
        }
      }
    }
    good_pos=c(0,(which((as.numeric(DNA[3,2:(dim(DNA)[2])])+as.numeric(DNA[4,1:(dim(DNA)[2]-1)]))==as.numeric(DNA[4,2:(dim(DNA)[2])]))))
    good_pos= good_pos+1
    if(length(good_pos)>0){
      for(cc in good_pos){
        if(cc==1){
          if(as.numeric(DNA[3,cc])>1){
            seq[c(1:(as.numeric(DNA[4,cc])-1))]=dominant_marker-1
          }
        }else{
          if(as.numeric(DNA[3,(cc)])>1){
            seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,cc])-1)]=dominant_marker-1
          }
        }
      }
    }



    if(!is.na(position_removed)){
      position_to_be_removed=numeric()
      for(ii in 1:length(position_removed)){
        position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
      }
      position_removed=position_to_be_removed
      rm(position_to_be_removed)
    }

    seq=as.numeric(seq)

    if(Nb_marker==1){
      if(!is.na(position_removed)){
        seq[as.numeric(c(position_removed))]=1
        rm(position_removed)
      }

    }else{
      if(!is.na(position_removed)){
        seq[as.numeric(c(position_removed))]=Nb_marker
        rm(position_removed)
      }

    }

  }


  if(Nb_marker==1){
    n=length(which(as.numeric(seq)!=1))
    theta=length(which(seq==2))/(n/length(seq))
  }else{
    if(Marker_supperposition){
      theta=c()
      n=length(which(as.numeric(seq)!=1))
      for(marker in 1:Nb_marker){
        theta=c(theta,ceiling(length(which(seq%in%c((1+which(substr(mut_index,marker,marker)=="1")))))/(n/length(seq))))
      }
    }else{
      theta=c()
      for(marker in 1:Nb_marker){
        n=length(which(as.numeric(seq)%in%c((marker-1),(Nb_marker+marker))))
        theta=c(theta,(length(which(seq==(Nb_marker+marker)))/(n/length(seq))))

      }
    }
  }
  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)
  return(output)
}
