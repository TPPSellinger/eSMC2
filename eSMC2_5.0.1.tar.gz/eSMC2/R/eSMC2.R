#' Runs the ecological Sequentially Markovian Coalescent 2
#'
#' @param n : Number of hidden states
#' @param rho : prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param Rho : True to estimate recombination rate
#' @param BW : True to use the complete implementation of the Baum-Welch algorithm
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param Share_r : TRUE if all chromosome/scaffold have same recombination rate
#' @param rp : vector of size 2 containing weight for L1 and L2 regularization penalty for population size
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param LH_opt : TRUE tu maximize likelihood and not perform the baum-welch algorithm
#' @param mask_island : number of masked position in a row, 1 will give best results but slow algorithm, 0 to put all missing position in a row (fast and recommanded)
#' @export
#' @return A list containing all estimations. List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate (per bp per 2 Ne) ,mu the mutation rate (per bp per 2 Ne), beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).
eSMC2<-function(n=40,rho=1,O,maxit =20,BoxB=c(0.05,1),BoxP=c(2,2),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,Rho=T,BW=F,NC=1,pop_vect=NA,mu_b=1,sigma=0,beta=1,Big_Window=F,window_scaling=c(1,0),Share_r=T,rp=c(0,0),position_removed=NA,LH_opt=F,mask_island=0){
  SCALED=F
  FS=F
  gamma=rho
  if(is.na(position_removed)&NC>1){
    position_removed=list()
    for(chr in 1:NC){
      position_removed[[chr]]=NA
    }
  }
  sigma=max(Boxs[1],sigma)
  sigma=min(Boxs[2],sigma)
  beta=min(BoxB[2],beta)
  beta=max(BoxB[1],beta)
  if(NC==1){
    Share_r=T
  }
  if(SF|SB){
    BaWe=2
  }else{
    BaWe=1
  }
  if(is.na(pop_vect)){
    pop_vect=rep(2,(n*0.5))
  }

  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    Os=list()
    count=0
    theta_W=0
    s=dim(O)[1]
    for(k in 1:(M-1)){
      for(l in (k+1):M){
        print("Creating seq")
        Os_=seqSNP2_MH(O[c(k,l,(s-1),s),],L,position_removed[[1]])
        if((Os_$theta)>=2){
          print((Os_$theta))
          theta_W=theta_W+((Os_$theta))
          print(count)

          if(count==0){
              print("Finding symbol")
              if(!LH_opt){
                Mat_symbol=Mat_symbol_ID()
              }else{
                temp=Build_zip_2seq(Os_$seq[1:min(10^6,length(Os_$seq))],25)
                Mat_symbol=temp[[2]]
                rm(temp)
              }
                count=count+1
                print("Ziping")
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                rm(Os_)

          }else{
              count=count+1
              print("Ziping")
              Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              rm(Os_)

          }
          print("Symbol to number")
          Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
        }
      }
    }
    if(length(Os)>=1){
      theta_W=theta_W/length(Os)
      theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
      mu=theta/(2*L)
      rho=rho*theta
      rm(O)

    }
    if(length(Os)==0){
      stop("data too poor")
    }


  }
  if(NC>1){
    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=vector(length=NC)
    L_total=vector()
    start_zip=T
    NC_c=vector()
    for(chr in 1:NC){
      theta_W=0
      count=0
      OST_=list()
      M=(dim(O[[chr]])[1]-2)
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          s=dim(O[[chr]])[1]
          Os_=seqSNP2_MH(O[[chr]][c(k,l,(s-1),s),],L,position_removed[[1]])
          if(as.numeric(Os_$theta)>=2){
            count=count+1
            theta_W=theta_W+as.numeric(Os_$theta)
            if(count==1&start_zip){
                if(!LH_opt){

                Mat_symbol=Mat_symbol_ID()
                }else{
                  temp=Build_zip_2seq(Os_$seq[1:min(10^6,length(Os_$seq))],25)
                  Mat_symbol=temp[[2]]
                  rm(temp)
                }
              OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              start_zip=F
            }
            if(count>1|chr>1){
              OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
            }
            OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])
          }
        }
      }
      rm(Os_)
      if(theta_W>=1){
        NC_c=c(NC_c,chr)
        Os[[length(NC_c)]]=OST_
        theta_W=theta_W/length(OST_)
        theta_W_V[chr]=theta_W
      }
      rm(OST_)
    }
    theta_W_V=theta_W_V[NC_c]
    NC=length(NC_c)
    if(length(rho)>1){
      rho=rho[NC_c]
    }

    theta=theta_W_V*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))

    mu=theta/(2*L_total)
    rho=rho*theta
    L=L_total
    rm(O)
    theta_W=theta_W_V
  }
  if(length(Os)>=1){
    print(theta_W)

    if(BaWe==1){

      if(Rho){
        results=Baum_Welch_algo(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=T,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,window_scaling=window_scaling,Share_r=Share_r,rp=rp,LH_opt=LH_opt)
      }else{
        results=Baum_Welch_algo(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,redo_R=F,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,window_scaling=window_scaling,Share_r=Share_r,rp=rp,LH_opt=LH_opt)
        }
    }
    if(BaWe==2){
      rho=theta
      results=Baum_Welch_algo(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=T,SB=F,SF=F,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=T,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,window_scaling=window_scaling,Share_r=Share_r,rp=rp,LH_opt=LH_opt)
      if(SB|SF){
        r=results$rho[1:NC]
        mu_=results$mu
        gamma_=(r*(beta*2*(1-sigma)/(2-sigma)))/mu_
        #print(r)
        #print(mu_)
        print(gamma_)
        if(mean(gamma_)>1){
          print("Results might not be reliable")
        }
        effect=mean(gamma_/gamma)
        if(SF&!SB){
          sigma=(1-effect)/(1-(effect/2))

          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)

        }
        if(SB&!SF){
          beta=effect
          beta=min(BoxB[2],beta)
          beta=max(BoxB[1],beta)

        }
        if(SF&SB){
          if(min(BoxB)>(1-max(Boxs))){
            sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
            sigma=max(Boxs[1],sigma)
            sigma=min(Boxs[2],sigma)
            beta=effect*(2-sigma)/(2*(1-sigma))
            beta=max(BoxB[1],beta)
            beta=min(BoxB[2],beta)
          }
          if(min(BoxB)<=(1-max(Boxs))){
            beta=effect*(2-sigma)/(2*(1-sigma))
            beta=max(BoxB[1],beta)
            beta=min(BoxB[2],beta)
            sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
            sigma=max(Boxs[1],sigma)
            sigma=min(Boxs[2],sigma)

          }
          if(gamma_!=(gamma*beta*2*(1-sigma)/(2-sigma))){
            print("Prior might disagree with results.")
          }
        }
      }
      theta=theta_W*(beta*beta)*2/(2-sigma)
      mu=theta/(2*L)
      rho=gamma*theta
      results=Baum_Welch_algo(Os=Os, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=Rho,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,window_scaling=window_scaling,Share_r=Share_r,rp=rp,LH_opt=LH_opt)
    }
  }
    return(results)
}
