#' Build requirement to define the hidden markov model
#'
#' Build the hidden states, expected coalescent times, equilibrium propabilities,and transition matrices for SMBC
#' @param n : number of  hidden states
#' @param rho : recombination rate per sequence
#' @param L : sequence length
#' @param Xi : vector of scaling value for population size
#' @param scale : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param M_a : number of haplotype used for the model
#' @param alpha : alpha parameter of the Beta value
#' @param Alpha : alpha parameter of the Beta value to build hidden states
#' @param sigma : self-fertilization rate
#' @param Sigma : self-fertilization rate to build hidden states
#' @param beta : germination rate
#' @param Beta : germination rate to build hidden states
#' @param Big_Window : TRUE to use a bigger time window
#' @param ploidy : ploidy level of the organism
#' @return List of size four containing respectively, transition matrix, equilibrium probabilities, expected coalescent time and hidden states.
build_SMBC_matrix<-function(n=20,rho,L,Xi=NA,scale=c(1,0),M_a=3,alpha=1.999999,Alpha=1.999999,sigma=0,Sigma=0,beta=1,Beta=1,Big_Window=F,ploidy=1){
  Vect=0:(n-1)
  if(is.na(Xi)){
    Xi=rep(1,n)
  }
  extra_l=M_a*(M_a-1)*0.5
  Xi=Xi/((beta*beta*2/(2-sigma)))
  Xi=(Xi^(alpha-1))
  Xi_truc=rep(1,n)
  if(M_a==3){
    if(ploidy==1){

      L3_2=3*(beta((2-Alpha), (1+Alpha))/(gamma((2-Alpha))*gamma((Alpha))))
      L3_3=((beta((3-Alpha), (Alpha))/(gamma((2-Alpha))*gamma((Alpha)))))
      L3=L3_2+L3_3
      #L3_3/L3
    }else{
      stop("Not coded")
      nb_box=2*(ploidy)
      #L3_2= (((1-((2-Alpha)/2))/nb_box)  + (3*((2-Alpha)/2)/(nb_box*nb_box)))*3* nb_box# (1/beta((2-Alpha), Alpha))
      #L3_3=(((2-Alpha)/2)/(nb_box*nb_box))*3*nb_box
      L3_2=3*((1-(((2-Alpha)/2)))/(nb_box)) + ((3*(2-Alpha)/2)/(nb_box*nb_box))
      L3_3=(((2-Alpha)/2)/(nb_box*nb_box))
      L3=L3_2+L3_3
    }
    if(as.numeric(Big_Window)==0){
    Tc=  scale[2] -(0.5*(2-Sigma)*log(1-(Vect/n))/(L3*(Beta^2)*scale[1]))
    #print(Tc)
    }
    if(as.numeric(Big_Window)==1){
      Vect=1:(n-1)
      tmax=15
      alpha_t=0.1
      npair=M_a
      alpha_t=alpha_t/(npair)
      tmax=tmax*npair
      Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/(L3*(Beta^2)*scale[1])))
      Vect=0:(n-1)
    }
    if(ploidy==1){
    lambda_M=((beta((2-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha)))))
    lambda=beta((2-alpha), alpha)/(gamma((2-alpha))*gamma((alpha))) # (beta*beta*2/(2-sigma))*

    L3_2=3*(beta((2-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha))))
    L3_3=(beta((3-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha))))
    L3=L3_2+L3_3
    }else{
      nb_box=2*(ploidy)
      lambda_M=((beta((2-alpha), (2+alpha))/(gamma((2-alpha))*gamma((alpha)))))
      lambda=(beta((2-alpha), alpha)/(gamma((2-alpha))*gamma((alpha)))) #  (beta*beta*2/(2-sigma))*
      #L3_2= (((1-((2-alpha)/2))/nb_box)  + (3*((2-alpha)/2)/(nb_box*nb_box)))*3* nb_box
      #L3_3=(((2-alpha)/2)/(nb_box*nb_box))*3*nb_box
      L3_2=3*((1-(((2-alpha)/2)))/(nb_box)) + ((3*(2-alpha)/2)/(nb_box*nb_box))
      L3_3=(((2-alpha)/2)/(nb_box*nb_box))
      p_join=(((2-alpha)/2)/(nb_box))
      L3=L3_2+L3_3
    }
    #lambda_M=lambda
    t=vector()
    q=vector()
    r=rho/(2*(L-1))
    D=Tc[2:n]-Tc[1:(n-1)]
    q[1:(3*n)]= rep(c((L3_2/(3*L3))*exp(-Tc[1:(n-1)]*L3/Xi[1:(n-1)])*(1-exp(-D*L3/Xi[1:(n-1)])),0),3)
    q[((3*n)+1):(4*n)]= c((L3_3/L3)*exp(-Tc[1:(n-1)]*L3/Xi[1:(n-1)])*(1-exp(-D*L3/Xi[1:(n-1)])),exp(-Tc[n]*L3/Xi[n]))

    t[1:(4*n)]= rep(c((((Tc[1:(n-1)]-(Tc[2:(n)]*exp(-D*L3/Xi[1:(n-1)])))/(1-exp(-D*L3/Xi[1:(n-1)])))+(Xi[1:(n-1)]/L3)) ,(Tc[n]+(Xi[n]/L3))),4)
    #browser()
    #t_b=rep(c((((t[1:(n-1)]-(Tc[2:(n)]*exp( - (Tc[2:(n)]-t[1:(n-1)])*lambda/Xi[1:(n-1)])))/(1-exp(-(Tc[2:(n)]-t[1:(n-1)])*lambda/Xi[1:(n-1)])))+(Xi[1:(n-1)])),(t[n]+(Xi[n]/lambda))),3)-t[1:(3*n)]
    #t_b=c(t_b,rep(0,n))
    if(F){
     if(mean(L3_2/Xi)<10^(-4)){
      scale=(10^-4)/mean(L3_2/Xi)
      t[1:(3*n)]= rep(c((((Tc[1:(n-1)]-(Tc[2:(n)]*exp(-D*scale*L3_2/Xi[1:(n-1)])))/(1-exp(-D*scale*L3_2/Xi[1:(n-1)])))+(Xi[1:(n-1)]/(scale*L3_2))) ,(Tc[n]+(Xi[n]/(scale*L3_2)))),3)
    }else{
      t[1:(3*n)]= rep(c((((Tc[1:(n-1)]-(Tc[2:(n)]*exp(-D*L3_2/Xi[1:(n-1)])))/(1-exp(-D*L3_2/Xi[1:(n-1)])))+(Xi[1:(n-1)]/L3_2)) ,(Tc[n]+(Xi[n]/L3_2))),3)
    }

    if(mean(L3_3/Xi)<10^(-4)){
      scale=(10^-4)/mean(L3_3/Xi)
      t[(1+(3*n)):(4*n)]= rep(c((((Tc[1:(n-1)]-(Tc[2:(n)]*exp(-D*scale*L3_3/Xi[1:(n-1)])))/(1-exp(-D*scale*L3_3/Xi[1:(n-1)])))+(Xi[1:(n-1)]/(scale*L3_3))) ,(Tc[n]+(Xi[n]/(scale*L3)))),1)
    }else{
    t[(1+(3*n)):(4*n)]= rep(c((((Tc[1:(n-1)]-(Tc[2:(n)]*exp(-D*L3_3/Xi[1:(n-1)])))/(1-exp(-D*L3_3/Xi[1:(n-1)])))+(Xi[1:(n-1)]/L3_3)) ,(Tc[n]+(Xi[n]/L3))),1)
    }
   }
    #browser()
    t_b=rep(0,4*n)

    Q=matrix(0,nrow=(4*n),ncol=(4*n))
    if(ploidy==1){
      for(i in 1:n){
        if(i==1){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c((i+(n*((0:2)))))
          for(ii in 1:3){
            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))*((D[1]-((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L3_2)/(t[vect_i_moins]*L3*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

          }
          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L3_2/(t[vect_i_plus]*M_a*L3))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))
          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L3_3)/(M_a*t[vect_i_plus]*L3))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2
        }
        if(i==2){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c(i,(i+(n)),(i+(2*n)))
          for(ii in 1:3){
            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*((1-exp(-D[2]*M_a*lambda_M/Xi[2])))/(M_a*lambda_M/Xi[1]))+(D[2]-((1-exp(-D[2]*M_a*lambda_M/Xi[2]))/(M_a*lambda_M/Xi[2]))))

            Q[(i+(n*(ii-1))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3*3))*(1-exp(-D[2]*L3/Xi[2]))*exp(-((Tc[2]-t[c(1,(1+n),(1+(2*n)))])*L3/Xi[1]))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))#*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L3_2)/(t[vect_i_moins]*L3*M_a))*(((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[1]) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))
          }
          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))* (((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*((1-exp(-(t[2]-Tc[2])*M_a*lambda_M/Xi[2])))/(M_a*lambda_M/Xi[1]))+((t[2]-Tc[2])-((1-exp(-(t[2]-Tc[2])*M_a*lambda_M/Xi[2]))/(M_a*lambda_M/Xi[2]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L3_2/(t[vect_i_plus]*M_a*L3))*(1-exp(-(Tc[3]-t[vect_i_plus])*lambda/Xi[2]))* (( (1-exp(-D[1]*M_a*lambda_M/Xi[1]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])/M_a*lambda_M/Xi[1])+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))
          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((L3_3)/(M_a*t[vect_i_plus]*L3))*(((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*(exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[1]) )+((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))+truc_1+truc_2
          bonus=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3))*(1-exp(-D[2]*L3/Xi[2]))*exp(-((Tc[2]-t[c(1,(1+n),(1+(2*n)))])*L3/Xi[1]))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
          Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=((1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(t[c(1,(1+n),(1+(2*n)))]*L3*L3*M_a))*(1-exp(-D[2]*L3/Xi[2]))*exp(-((Tc[2]-t[c(1,(1+n),(1+(2*n)))])*L3/Xi[1]))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))) + bonus

        }
        if(i>2&i<(n-1)){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c(i,(i+(n)),(i+(2*n)))
          truc_eta=vector()
          truc=0
          truc_moins=0
          for(eta in 1:(i-1)){
            if(eta==(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))

            }

            if(eta<(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(i-1)]/Xi[(eta+1):(i-1)]))
            }
            #truc_eta=c(truc_eta,truc)
          }



          for(ii in 1:3){

            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[i]*M_a*lambda_M/Xi[i]))*truc)+(D[i]-((1-exp(-D[i]*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L3_2)/(t[vect_i_moins]*L3*M_a))*((truc*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))) # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))

          }
          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L3_2/(t[vect_i_plus]*M_a*L3))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))
          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((L3_3)/(M_a*t[vect_i_plus]*L3))*((truc*(exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])))+((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))+truc_1+truc_2 #sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))
          for(gamma in 1:(i-1)){
            if(gamma==1){
              for(ii in 1:3){
                Q[(i+(n*(ii-1))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))+bonus
            }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }


              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))  + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])


            }
            if(gamma==(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])

            }
          }
        }
        if(i==(n-1)){
          vect_gamma=c((i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c(i,(i+(n)),(i+(2*n)))
          truc_eta=vector()
          truc=0
          for(eta in 1:(i-1)){
            if(eta==(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
            }
            if(eta<(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(i-1)]/Xi[(eta+1):(i-1)]))
            }
            #truc_eta=c(truc_eta,truc)
          }
          for(ii in 1:3){

            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[i]*M_a*lambda_M/Xi[i]))*truc)+(D[i]-((1-exp(-D[i]*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L3_2)/(t[vect_i_moins]*L3))*((truc*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))) # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))

          }
          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L3_2/(t[vect_i_plus]*M_a*L3))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))
          Q[vect_i_moins,vect_i_plus]=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((L3_3)/(M_a*t[vect_i_plus]*L3))*((truc*(exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))+truc_1+truc_2 # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))
          for(gamma in 1:(i-1)){
            if(gamma==1){
              for(ii in 1:3){
                Q[(i+(n*(ii-1))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))+bonus
            }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])
            }
            if(gamma==(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_2/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*L3_3/(M_a*t[vect_gamma2]*L3*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])

            }
          }
        }
        if(i==n){

          for(gamma in 1:(i-1)){
            if(gamma==1){
              Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma]))
            }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2/(t[vect_gamma2]*L3*M_a))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )
            }
            if(gamma==(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2/(t[vect_gamma2]*L3*M_a))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )
            }
          }
        }
      }
    }else{
      for(i in 1:n){
        if(i==1){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c((i+(n*((0:2)))))
          for(ii in 1:3){
            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))*((D[1]-((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_moins]*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

          }

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))


          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi_truc[1]))/(M_a*lambda_M/Xi_truc[1]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi_truc[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi_truc[1]))/(M_a*lambda_M/Xi_truc[1]))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((p_join)/(M_a*t[vect_i_plus]))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2
        }
        if(i==2){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c(i,(i+(n)),(i+(2*n)))
          for(ii in 1:3){
            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*((1-exp(-D[2]*M_a*lambda_M/Xi[2])))/(M_a*lambda_M/Xi[1]))+(D[2]-((1-exp(-D[2]*M_a*lambda_M/Xi[2]))/(M_a*lambda_M/Xi[2]))))

            Q[(i+(n*(ii-1))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(t[c(1,(1+n),(1+(2*n)))]*L3*M_a*3))*(1-exp(-D[2]*L3/Xi[2]))*exp(-((Tc[2]-t[c(1,(1+n),(1+(2*n)))])*L3/Xi[1]))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))#*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*(((1-p_join))/(t[vect_i_moins]*M_a))*(((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[1]) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))
          }

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))* (((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*((1-exp(-(t[2]-Tc[2])*M_a*lambda_M/Xi[2])))/(M_a*lambda_M/Xi[1]))+((t[2]-Tc[2])-((1-exp(-(t[2]-Tc[2])*M_a*lambda_M/Xi[2]))/(M_a*lambda_M/Xi[2]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[3]-t[vect_i_plus])*lambda/Xi[2]))* (( (1-exp(-D[1]*M_a*lambda_M/Xi[1]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])/M_a*lambda_M/Xi[1])+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))* (((1-exp(-D[1]*M_a*lambda_M/Xi_truc[1]))*((1-exp(-(t[2]-Tc[2])*M_a*lambda_M/Xi_truc[2])))/(M_a*lambda_M/Xi_truc[1]))+((t[2]-Tc[2])-((1-exp(-(t[2]-Tc[2])*M_a*lambda_M/Xi_truc[2]))/(M_a*lambda_M/Xi_truc[2]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[3]-t[vect_i_plus])*lambda/Xi_truc[2]))* (( (1-exp(-D[1]*M_a*lambda_M/Xi_truc[1]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi_truc[i])/M_a*lambda_M/Xi_truc[1])+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((p_join)/(M_a*t[vect_i_plus]))*(((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*(exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[1]) )+((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))+truc_1+truc_2

          bonus=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3))*(1-exp(-D[2]*L3/Xi[2]))*exp(-((Tc[2]-t[c(1,(1+n),(1+(2*n)))])*L3/Xi[1]))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

          Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=((1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(t[c(1,(1+n),(1+(2*n)))]*L3*M_a))*(1-exp(-D[2]*L3/Xi[2]))*exp(-((Tc[2]-t[c(1,(1+n),(1+(2*n)))])*L3/Xi[1]))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))) + bonus

        }
        if(i>2&i<(n-1)){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c(i,(i+(n)),(i+(2*n)))
          truc_eta=vector()
          truc=0
          truc_moins=0
          for(eta in 1:(i-1)){
            if(eta==(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))

            }

            if(eta<(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(i-1)]/Xi[(eta+1):(i-1)]))
            }
            #truc_eta=c(truc_eta,truc)
          }



          for(ii in 1:3){

            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[i]*M_a*lambda_M/Xi[i]))*truc)+(D[i]-((1-exp(-D[i]*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_moins]*M_a))*((truc*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))) # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))

          }

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi_truc[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((p_join)/(M_a*t[vect_i_plus]))*((truc*(exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])))+((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))+truc_1+truc_2 #sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))
          for(gamma in 1:(i-1)){
            if(gamma==1){
              for(ii in 1:3){
                Q[(i+(n*(ii-1))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))+bonus
              #print(bonus/Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))])
              }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }


              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L3_2*(1-p_join)/(M_a*t[vect_gamma2]*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))  + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])

            }
            if(gamma==(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])

            }
          }


        }
        if(i==(n-1)){
          vect_gamma=c((i+1+(3*n)):(n+(3*n)))
          vect_i_moins=c(i+(3*n))
          vect_i_plus=c(i,(i+(n)),(i+(2*n)))
          truc_eta=vector()
          truc=0
          for(eta in 1:(i-1)){
            if(eta==(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
            }
            if(eta<(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(i-1)]/Xi[(eta+1):(i-1)]))
            }
            #truc_eta=c(truc_eta,truc)
          }
          for(ii in 1:3){

            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma])+(2*t_b[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[i]*M_a*lambda_M/Xi[i]))*truc)+(D[i]-((1-exp(-D[i]*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins])+(2*t_b[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*(((1-p_join))/(t[vect_i_moins]))*((truc*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))) # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))

          }
          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((1-p_join)/(t[vect_i_plus]*M_a))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))
          Q[vect_i_moins,vect_i_plus]=(1-exp(-r*( (M_a*t[vect_i_plus])+(2*t_b[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*((p_join)/(M_a*t[vect_i_plus]))*((truc*(exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))+truc_1+truc_2 # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))
          for(gamma in 1:(i-1)){
            if(gamma==1){
              for(ii in 1:3){
                Q[(i+(n*(ii-1))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(t[c(1,(1+n),(1+(2*n)))]*M_a*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))+bonus
            }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*((sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              #print(bonus/Q[(i+(n*(3))),vect_gamma2])
              }
            if(gamma==(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:3){
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3*3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              }
              bonus=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_2/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)*L3_3/(M_a*t[vect_gamma2]*L3))*(1-exp(-D[i]*L3/Xi[i]))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus
              # print(bonus/Q[(i+(n*(3))),vect_gamma2])

            }
          }
        }
        if(i==n){

          for(gamma in 1:(i-1)){
            if(gamma==1){
              Q[(i+(n*(3))),c(1,(1+n),(1+(2*n)))]=(1-exp(-r*( (M_a*t[c(1,(1+n),(1+(2*n)))])+(2*t_b[c(1,(1+n),(1+(2*n)))]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)/(t[c(1,(1+n),(1+(2*n)))]*M_a))*exp(-L3*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[c(1,(1+n),(1+(2*n)))])/Xi[1])))*((1-exp(-t[c(1,(1+n),(1+(2*n)))]*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma]))
            }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)/(t[vect_gamma2]*M_a))*exp(-L3*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )
            }
            if(gamma==(i-1)){
              vect_gamma2=c(gamma,(gamma+n),(gamma+n+n))
              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }
              Q[(i+(n*(3))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2])+(2*t_b[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*(1-p_join)/(t[vect_gamma2]*M_a))*exp(-L3*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )
            }
          }
        }
      }
    }

    if(any(Q<0)){
     # browser()
    }
    diag(Q)=rep(1,(4*n))-apply(Q,2,sum)
    diag(Q)[c(n,(2*n),(3*n))]=0
  }
  if(M_a==4){
    extra_l3=4
    if(ploidy==1){
      L4_2=6*(beta((2-Alpha), (2+Alpha))/(gamma((2-Alpha))*gamma((Alpha))))
      L4_3=4*((beta((3-Alpha), (1+Alpha))/(gamma((2-Alpha))*gamma((Alpha)))))
      L4_4=((beta((4-Alpha), (Alpha))/(gamma((2-Alpha))*gamma((Alpha)))))
      L4=L4_2+L4_3+L4_4

      L3_2=3*(beta((2-Alpha), (1+Alpha))/(gamma((2-Alpha))*gamma((Alpha))))
      L3_3=((beta((3-Alpha), (Alpha))/(gamma((2-Alpha))*gamma((Alpha)))))
      L3=L3_2+L3_3

    }else{
      stop("Not coded")
    }


    if(as.numeric(Big_Window)==0){
      Tc= (scale[2]-(0.5*(2-Sigma)*log(1-(Vect/n)))/(L4*(Beta^2)*scale[1]))
      #print(Tc)
    }
    if(as.numeric(Big_Window)==1){
      Vect=1:(n-1)
      tmax=15
      alpha_t=0.1
      npair=M_a
      alpha_t=alpha_t/(npair)
      tmax=tmax*npair
      Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/(L4*(Beta^2)*scale[1])))
      Vect=0:(n-1)
    }



    if(ploidy==1){
      lambda_M=((beta((2-alpha), (3+alpha))/(gamma((2-alpha))*gamma((alpha)))))
      lambda=beta((2-alpha), alpha)/(gamma((2-alpha))*gamma((alpha)))
      L4_2=6*(beta((2-alpha), (2+alpha))/(gamma((2-alpha))*gamma((alpha))))
      L4_3=4*((beta((3-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha)))))
      L4_4=((beta((4-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
      L4=L4_2+L4_3+L4_4

    }else{

    }

    t=vector()
    q=vector()
    r=rho/(2*(L-1))
    D=Tc[2:n]-Tc[1:(n-1)]
    q[1:(6*n)]= rep(c((L4_2/(6*L4))*exp(-Tc[1:(n-1)]*L4/Xi[1:(n-1)])*(1-exp(-D*L4/Xi[1:(n-1)])),0),6)
    q[((6*n)+1):(10*n)]= rep(c((L4_3/(4*L4/Xi[1:(n-1)]))*exp(-Tc[1:(n-1)]*L4)*(1-exp(-D*L4/Xi[1:(n-1)])),0),4)
    q[((10*n)+1):(11*n)]= c((L4_4/(L4))*exp(-Tc[1:(n-1)]*L4/Xi[n])*(1-exp(-D*L4/Xi[n])),(L4_4/(L4))*exp(-Tc[n]*L4/Xi[n]))
    Q=matrix(0,nrow=(11*n),ncol=(11*n))

    t[1:(11*n)]= rep(c((((Tc[1:(n-1)]-(Tc[2:(n)]*exp(-D*L4/Xi[1:(n-1)])))/(1-exp(-D*L4/Xi[1:(n-1)])))+(Xi[1:(n-1)]/L4)) ,(Tc[n]+(Xi[n]/L4))),11)
    index_2_to_3<-function(i){if(i==1){return(6+c(1,2))};if(i==2){return(6+c(1,3))};if(i==3){return(6+c(2,3))};if(i==4){return(6+c(1,4))};if(i==5){return(6+c(2,4))};if(i==6){return(6+c(3,4))}}
    index_3_to_2<-function(i){if(i==7){return(c(1,2,4))};if(i==8){return(c(1,3,5))};if(i==9){return(c(2,3,6))};if(i==10){return(c(4,5,6))}}



    if(ploidy==1){


      for(i in 1:n){
        if(i==1){
          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n-1+(3*n)),(i+1+(4*n)):(n-1+(4*n)),(i+1+(5*n)):(n-1+(5*n)),(i+1+(6*n)):(n-1+(6*n)),(i+1+(7*n)):(n-1+(7*n)),(i+1+(8*n)):(n-1+(8*n)),(i+1+(9*n)):(n-1+(9*n)),(i+1+(10*n)):(n+(10*n)))


          for(ii in 1:6){
            vect_i_moins=c((i+((index_2_to_3(ii)-1)*n)),(i+(10*n)))
            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))*((D[1]-((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_2)/(t[vect_i_moins]*(L4_3+L4_2)*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

          }

          for(ii in 7:10){
            vect_i_moins=(i+(n*(ii-1)))
            vect_i_plus=c((i+(n*((index_3_to_2(ii))-1))))

            truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))
            truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

            #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi_truc[1]))/(M_a*lambda_M/Xi_truc[1]))))
            #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi_truc[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi_truc[1]))/(M_a*lambda_M/Xi_truc[1]))



            Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_3)/(M_a*t[vect_i_plus]*(L4_3+L4_2)))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2

          }
          vect_i_moins=(i+(n*(10)))
          vect_i_plus=(i+(n*(6:9)))

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*L4))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*((t[vect_i_plus]-((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi_truc[1]))/(M_a*lambda_M/Xi_truc[1]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*L4))*(1-exp(-(Tc[2]-t[vect_i_plus])*lambda/Xi_truc[1]))*((1-exp(-D[1]*M_a*lambda_M/Xi_truc[1]))/(M_a*lambda_M/Xi_truc[1]))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_4)/(M_a*t[vect_i_plus]*(L4_3+L4_4)))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2
          Q[vect_i_plus,vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_3)/(t[vect_i_moins]*(L4_3+L4_4)*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

        }
        if(i==2){

          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n-1+(3*n)),(i+1+(4*n)):(n-1+(4*n)),(i+1+(5*n)):(n-1+(5*n)),(i+1+(6*n)):(n-1+(6*n)),(i+1+(7*n)):(n-1+(7*n)),(i+1+(8*n)):(n-1+(8*n)),(i+1+(9*n)):(n-1+(9*n)),(i+1+(10*n)):(n+(10*n)))


          for(ii in 1:6){

            vect_i_moins=c((i+((index_2_to_3(ii)-1)*n)),(i+(10*n)))
            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[1]*M_a*lambda_M/Xi[1]))*((1-exp(-D[i]*M_a*lambda_M/Xi[i])))/(M_a*lambda_M/Xi[1]))+(D[i]-((1-exp(-D[2]*M_a*lambda_M/Xi[2]))/(M_a*lambda_M/Xi[2]))))

            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_2)/(t[vect_i_moins]*(L4_3+L4_2)*M_a))*((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))

            Q[(i+(n*(ii-1))),c(1+(c(0:5)*n))]=(1-exp(-r*( (M_a*t[c(1+(c(0:5)*n))]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[c(1+(c(0:5)*n))]*extra_l*(L4_3+L4_2)*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[c(1+(c(0:5)*n))])*L4/Xi[1]))*((1-exp(-t[c(1+(c(0:5)*n))]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

          }

          for(ii in 7:10){
            vect_i_moins=(i+(n*(ii-1)))
            vect_i_plus=c((i+(n*((index_3_to_2(ii))-1))))

            truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-D[(i-1)]*M_a*lambda_M/Xi[(i-1)]))*((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i])))/(M_a*lambda_M/Xi[(i-1)]))+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
            truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[vect_i_plus])*lambda/Xi[i]))* (( (1-exp(-D[(i-1)]*M_a*lambda_M/Xi[(i-1)]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])/M_a*lambda_M/Xi[(i-1)])+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

            #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-D[(i-1)]*M_a*lambda_M/Xi_truc[(i-1)]))*((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i])))/(M_a*lambda_M/Xi_truc[(i-1)]))+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
            #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[vect_i_plus])*lambda/Xi_truc[i]))* (( (1-exp(-D[(i-1)]*M_a*lambda_M/Xi_truc[(i-1)]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi_truc[i])/M_a*lambda_M/Xi_truc[(i-1)])+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


            Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_3)/(M_a*t[vect_i_plus]*(L4_3+L4_2)))*((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))+truc_1+truc_2

            vect_i_plus= c((1+(n*((index_3_to_2(ii))-1))))

            bonus=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

            Q[vect_i_moins,vect_i_plus]=((1-exp(-r*((M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(t[vect_i_plus]*extra_l*(L4_3+L4_2)*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])) + bonus

          }
          vect_i_moins=(i+(n*(10)))
          vect_i_plus=(i+(n*(6:9)))

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-D[(i-1)]*M_a*lambda_M/Xi[(i-1)]))*((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i])))/(M_a*lambda_M/Xi[(i-1)]))+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[vect_i_plus])*lambda/Xi[i]))* (( (1-exp(-D[(i-1)]*M_a*lambda_M/Xi[(i-1)]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i])/M_a*lambda_M/Xi[(i-1)])+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-D[(i-1)]*M_a*lambda_M/Xi_truc[(i-1)]))*((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i])))/(M_a*lambda_M/Xi_truc[(i-1)]))+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[vect_i_plus])*lambda/Xi_truc[i]))* (( (1-exp(-D[(i-1)]*M_a*lambda_M/Xi_truc[(i-1)]))*exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi_truc[i])/M_a*lambda_M/Xi_truc[(i-1)])+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_4)/(M_a*t[vect_i_plus]*(L4_3+L4_4)))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2
          Q[vect_i_plus,vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_3)/(t[vect_i_moins]*(L4_3+L4_4)*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

          vect_i_plus=c(1+(c(0:5)*n))
          bonus_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
          bonus_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(t[vect_i_plus]*M_a*(L4_3+L4_2)*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(t[vect_i_plus]*extra_l*(L4_3+L4_2)*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))) + bonus_1+ bonus_2


        }
        if(i>2&i<(n-1)){

          vect_gamma=c((i+1):(n-1),(i+1+(n)):(n+(n-1)),(i+1+(2*n)):(n-1+(2*n)),(i+1+(3*n)):(n-1+(3*n)),(i+1+(4*n)):(n-1+(4*n)),(i+1+(5*n)):(n-1+(5*n)),(i+1+(6*n)):(n-1+(6*n)),(i+1+(7*n)):(n-1+(7*n)),(i+1+(8*n)):(n-1+(8*n)),(i+1+(9*n)):(n-1+(9*n)),(i+1+(10*n)):(n+(10*n)))

          truc_eta=vector()
          truc=0
          truc_moins=0
          for(eta in 1:(i-1)){
            if(eta==(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
            }
            if(eta<(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(i-1)]/Xi[(eta+1):(i-1)]))
            }
          }

          for(ii in 1:6){

            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))* (((1-exp(-D[i]*M_a*lambda_M/Xi[i]))*truc)+(D[i]-((1-exp(-D[i]*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
            vect_i_moins=c((i+((index_2_to_3(ii)-1)*n)),(i+(10*n)))
            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_2)/(t[vect_i_moins]*(L4_3+L4_2)*M_a))*((truc*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))) # sum((1-exp(-D[1:(i-1)]*M_a*lambda_M/Xi[1:(i-1)]))/(M_a*lambda_M/Xi[1:(i-1)]))

          }

          for(ii in 7:10){
            vect_i_moins=(i+(n*(ii-1)))
            vect_i_plus=c((i+(n*((index_3_to_2(ii))-1))))

            truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
            truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

            #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
            #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi_truc[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


            Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_3)/(M_a*t[vect_i_plus]*(L4_3+L4_2)))*((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))+truc_1+truc_2


          }
          vect_i_moins=(i+(n*(10)))
          vect_i_plus=(i+(n*(6:9)))

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))


          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi_truc[i]))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_4)/(M_a*t[vect_i_plus]*(L4_3+L4_4)))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2
          Q[vect_i_plus,vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_3)/(t[vect_i_moins]*(L4_3+L4_4)*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))

          for(gamma in 1:(i-1)){

            if(gamma==1){

              for(ii in 1:6){
                vect_gamma=c(1+(c(0:5)*n))

                Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[vect_gamma]*M_a*(L4_3+L4_2)*L4*extra_l))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[vect_gamma])/Xi[1])))*((1-exp(-t[vect_gamma]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

              }

              for(ii in 7:10){

                vect_i_plus=c((gamma+(n*((index_3_to_2(ii))-1))))
                bonus=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[vect_i_plus]*(L4_3+L4_2)*extra_l*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[vect_i_plus])/Xi[1])))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
                Q[vect_i_moins,vect_i_plus]=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(t[vect_i_plus]*(L4_3+L4_2)*extra_l*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[vect_i_plus])/Xi[1])))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])+bonus

              }

              vect_i_plus=c(1+(c(0:5)*n))
              bonus_1=((1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[vect_i_plus]*(L4_3+L4_2)*extra_l*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
              bonus_2=((1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(t[vect_i_plus]*(L4_3+L4_2)*extra_l*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
              Q[vect_i_moins,vect_gamma]=((1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(t[vect_i_plus]*(L4_3+L4_2)*extra_l*L4*M_a))*(1-exp(-D[i]*L4/Xi[i]))*exp(-((Tc[i]-t[vect_i_plus])*L4/Xi[1]))*((1-exp(-t[vect_i_plus]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))) + bonus_1 + bonus_2

            }
            if(gamma>1&gamma<(i-1)){

              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }




              for(ii in 1:6){

                vect_gamma2=c(gamma+(c(0:5)*n))
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*L4*extra_l))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))  + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

                }

              for(ii in 7:10){

                vect_gamma2=c((gamma+(n*((index_3_to_2(ii))-1))))

                bonus=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]) +bonus

              }

               vect_gamma2=c((gamma+(n*(0:5))))

                bonus_1=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
                bonus_2=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

                Q[(i+(n*10)),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus_1+bonus_2

            }

            if(gamma==(i-1)){

              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:6){

                vect_gamma2=c(gamma+(c(0:5)*n))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*L4*extra_l))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
              }

              for(ii in 7:10){

                vect_gamma2=c((gamma+(n*((index_3_to_2(ii))-1))))

                bonus=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*((sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*((sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]) +bonus

              }



              vect_gamma2=c((gamma+(n*(0:5))))
              bonus_1=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
              bonus_2=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

              Q[(i+(n*(10))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus



            }
          }
        }
        if(i==(n-1)){

          truc_eta=vector()
          truc=0
          for(eta in 1:(i-1)){
            if(eta==(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
            }
            if(eta<(i-1)){
              truc=truc+((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(i-1)]/Xi[(eta+1):(i-1)]))
            }

          }
          for(ii in 1:6){

            vect_gamma=c((n+(10*n)))

            Q[(i+(n*(ii-1))),vect_gamma]=(1-exp(-r*( (M_a*t[vect_gamma]))*beta*2*(1-sigma)/(2-sigma)))*(2/(t[vect_gamma]*M_a*M_a))*(((1-exp(-D[i]*M_a*lambda_M/Xi[i]))*truc)+(D[i]-((1-exp(-D[i]*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))

            vect_i_moins=c((i+((index_2_to_3(ii)-1)*n)),(i+(10*n)))
            Q[(i+(n*(ii-1))),vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_2)/(t[vect_i_moins]*(L4_3+L4_2)))*((truc*(exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i])) )+((1-exp(-(t[vect_i_moins]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

          }
          for(ii in 7:10){
            vect_i_moins=(i+(n*(ii-1)))
            vect_i_plus=c((i+(n*((index_3_to_2(ii))-1))))

            truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
            truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

            #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
            #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


            Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_3)/(M_a*t[vect_i_plus]*(L4_3+L4_2)))*((1-exp(-(t[vect_i_plus]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))+truc_1+truc_2


          }
          vect_i_moins=(i+(n*(10)))
          vect_i_plus=(i+(n*(6:9)))

          truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i]))))
          truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi[i]))/(M_a*lambda_M/Xi[i])))

          #truc_1=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(1/(t[vect_i_plus]*M_a*M_a))*(((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc)+((t[i]-Tc[i])-((1-exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i]))))
          #truc_2=(1-exp(-r*( (M_a*t[vect_i_plus]))*beta*2*(1-sigma)/(2-sigma)))*(L4_2/(t[vect_i_plus]*M_a*(L4_3+L4_2)))*((((exp(-(t[i]-Tc[i])*M_a*lambda_M/Xi_truc[i]))*truc))+((1-exp(-(D[i])*M_a*lambda_M/Xi_truc[i]))/(M_a*lambda_M/Xi_truc[i])))


          Q[vect_i_moins,vect_i_plus]=((1-exp(-r*( (M_a*t[vect_i_plus])*beta*2*(1-sigma)/(2-sigma))))*((L4_4)/(M_a*t[vect_i_plus]*(L4_3+L4_4)))*((1-exp(-(t[vect_i_plus]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1])))+truc_1+truc_2
          Q[vect_i_plus,vect_i_moins]=(1-exp(-r*( (M_a*t[vect_i_moins]))*beta*2*(1-sigma)/(2-sigma)))*((L4_3)/(t[vect_i_moins]*(L4_3+L4_4)*M_a))*((1-exp(-(t[vect_i_moins]-Tc[1])*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[1]))


          for(gamma in 1:(i-1)){

            if(gamma==1){

              for(ii in 1:6){
                vect_gamma2=c(gamma+(c(0:5)*n))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(t[vect_gamma2]*M_a*(L4_3+L4_2)*L4*extra_l))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[vect_gamma2])/Xi[1])))*((1-exp(-t[vect_gamma2]*M_a*lambda_M/Xi[1]))/(M_a*lambda_M/Xi[gamma]))#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
              }

              for(ii in 7:10){

                vect_gamma2=c((gamma+(n*((index_3_to_2(ii))-1))))

                bonus=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])+bonus

              }

              vect_gamma2=c((gamma+(n*(0:5))))


                bonus_1=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
                bonus_2=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

                Q[(i+(n*10)),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus_1+bonus_2
            }
            if(gamma>1&gamma<(i-1)){

              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }


              for(ii in 1:6){

                vect_gamma2=c(gamma+(c(0:5)*n))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*L4*extra_l))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))  + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

              }

              for(ii in 7:10){

                vect_gamma2=c((gamma+(n*((index_3_to_2(ii))-1))))

                bonus=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])+bonus

              }

              vect_gamma2=c((gamma+(n*(0:5))))


                 bonus_1=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
                 bonus_2=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))
                  Q[(i+(n*10)),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus_1+bonus_2

            }

            if(gamma==(i-1)){

              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }

              for(ii in 1:6){

                vect_gamma2=c(gamma+(c(0:5)*n))

                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*L4*extra_l))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )#*(exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
              }

              for(ii in 7:10){

                vect_gamma2=c((gamma+(n*((index_3_to_2(ii))-1))))
                bonus=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*((sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])))*(L3_2/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
                Q[(i+(n*(ii-1))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*((sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i])+bonus

              }

              vect_gamma2=c((gamma+(n*(0:5))))
              bonus_1=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_2/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(L3_3/L3)*(1-exp(-(Tc[(i+1)]-t[i])*L3/Xi[i]))
              bonus_2=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_3/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )*(1-exp(-(Tc[(i+1)]-t[i])*lambda/Xi[i]))

              Q[(i+(n*(10))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2*L4_4/(M_a*t[vect_gamma2]*(L4_3+L4_2)*extra_l*L4))*(1-exp(-D[i]*L4/Xi[i]))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )+bonus_1+bonus_2



            }
          }
        }
        if(i==n){

          for(gamma in 1:(i-1)){
            if(gamma==1){
              vect_gamma2=c((gamma+(n*(0:5))))

              Q[(i+(n*(10))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2/(t[vect_gamma2]*M_a*(L4_3+L4_2)))*exp(-L4*(sum(D[2:(i-1)]/Xi[2:(i-1)])+((Tc[2]-t[vect_gamma2])/Xi[1])))*((1-exp(-t[vect_gamma2]*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma]))
            }
            if(gamma>1&gamma<(i-1)){
              vect_gamma2=c((gamma+(n*(0:5))))

              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }
              Q[(i+(n*(10))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2/(t[vect_gamma2]*(L4_3+L4_2)*M_a))*exp(-L4*(sum(D[(gamma+1):(i-1)]/Xi[(gamma+1):(i-1)])+((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )
            }
            if(gamma==(i-1)){
              vect_gamma2=c((gamma+(n*(0:5))))

              truc_eta=vector()
              for (eta in 1:(gamma-1)) {

                if(eta==(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))
                }
                if(eta<(gamma-1)){
                  truc=((1-exp(-D[eta]*M_a*lambda_M/Xi[eta]))/(M_a*lambda_M/Xi[eta]))*exp(-M_a*lambda_M*sum(D[(eta+1):(gamma-1)]/Xi[(eta+1):(gamma-1)]))
                }
                truc_eta=c( truc_eta,truc)
              }
              Q[(i+(n*(10))),vect_gamma2]=(1-exp(-r*( (M_a*t[vect_gamma2]))*beta*2*(1-sigma)/(2-sigma)))*(2*L4_2/(t[vect_gamma2]*(L4_3+L4_2)*M_a))*exp(-L4*(((Tc[(gamma+1)]-t[vect_gamma2])/Xi[(gamma)])))*( (sum(truc_eta)*exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]) ) + ((1-exp(-(t[vect_gamma2]-Tc[gamma])*M_a*lambda_M/Xi[gamma]))/(M_a*lambda_M/Xi[gamma])) )
            }
          }
        }
      }

    }

    diag(Q)=rep(1,(11*n))-apply(Q,2,sum)
  }
  output=list()
  output[[1]]=Q
  output[[2]]=q
  output[[3]]=t
  output[[4]]=Tc
  return(output)
}
