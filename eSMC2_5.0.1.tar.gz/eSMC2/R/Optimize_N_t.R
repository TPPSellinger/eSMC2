#' Runs the ecological Sequentially Markovian Coalescent 2 on sequence of genealogy
#'
#' @param file : path to the simulated data  ( .txt ), list of path if NC>1
#' @param gamma : ratio of recombination rate over mutation rate
#' @param theta : theta used for simulation (i.e theta=1000 if command line is scrm :  -t 1000 ) or theta waterson of the observed data (if analyzing real data) or mutation rate per generation per bp if simulator is msprime
#' @param L : length of simulated sequence
#' @param n : Number of hidden states
#' @param ER : FALSE to not estimate recombination rate, TRUE to estimate evolution of recombination rate in time with no prior model, 2 to estimate transition of recombination rate time assuming the inputted current and ancestral rates, 3 to estimate current, ancestral and transition time given priors.
#' @param Pop : True  top estimate population size
#' @param SB :  FALSE to not estimate germination/dormancy rate, TRUE to estimate evolution of germination rate in time with no prior model, 2 to estimate transition of germination rate time assuming the inputted current and ancestral rates, 3 to estimate current, ancestral and transition time given priors.
#' @param SF :  FALSE to not estimate selfing rate, TRUE to estimate evolution of selfing rate in time with no prior model, 2 to estimate transition of selfing rate time assuming the inputted current and ancestral rates, 3 to estimate current & ancestral rates as well as transition time given priors.
#' @param BoxB :  For SB=TRUE or FALSE, vector of size 2 seting the boundaries for the germination rate e.g. c(0.1,1). For SB=2, element must be vector of size 2 indicating the current dormancy rate and the ancestral one ,e.g. c(0.1,1) for a current seed bank of 10 generation with ancestral state being absence of dormancy. For model SB=3, element must be a list of size two, with the first element indication the current germination rate boundaries and the second element the ancestral boundaries of the germination rates.
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr :  For ER=TRUE or FALSE, vector of size 2 indicating the logarithmic boundaries in base 10 for the recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value. For model ER=2, element must be vector of size 2 indicating the current ratio of recombination rate over mutation rate followed by the ancestral one ,e.g. c(0.5,1) for a current r/mu=0.5 with ancestral state being r/mu=1. For model ER=3, element must be a list of size two, with the first element indication the current boundaries and the second element the ancestral boundaries of the recombination rate.
#' @param Boxs : For SF=TRUE or FALSE, vector of size 2 seting the boundaries for the selfing rate e.g. c(0,0.99).  For model SF=2, element must be vector of size 2 indicating the current selfing rate and the ancestral one ,e.g. c(0.99,0) for a current selfing rate of 99\% gwith ancestral state being outcrossing. For model SF=3, element must be a list of size two, with the first element indicating the current selfing rate boundaries and the second element the ancestral boundaries of the selfing rates.
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param NC : Number of scaffold to be analyzed
#' @param mu_b : ratio of muration rate in the dormant stage and during reproductive event
#' @param simulator : "msprime" or "scrm" or NA if N is given
#' @param M : sample size of data
#' @param decimal_separator : character use asdecimal separator , "\\." or ","
#' @export
#' @return A list containing all estimations in same format as teSMC.
Optimize_N_t<-function(file,gamma=1,theta,L,n=40,ER=T,Pop=T,SB=FALSE,SF=FALSE,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.97),pop_vect=NA,window_scaling=c(1,0),sigma=0,beta=1,Big_Window=F,NC=1,mu_b=1,simulator,M,decimal_separator="\\."){
  Share=T
  SCALED=F
  FS=F
  npair=2
  BW=F
  M_a=2
  k=n
  scale_T=1
  Correct_window=T
  mut=T
  if(simulator=='msprime'){
    mu_real=theta
  }
  if(ER==2){

    if(Boxr[1]>Boxr[2]){
      gamma=Boxr[1]

      Boxr[1]=log10(Boxr[1]/Boxr[2])
      Boxr[2]=0
      Boxr_s=c(1,0)
    }else{
      gamma=Boxr[2]
      Boxr[2]=log10(Boxr[2]/Boxr[1])
      Boxr[1]=0
      Boxr_s=c(0,1)
    }

  }
  if(SB==2){

    if(BoxB[1]>BoxB[2]){
      BoxB_s=c(1,0)
    }else{
      BoxB_s=c(0,1)
    }
    BoxB=c(min(BoxB),max(BoxB))
    BoxB[1]=max(sqrt(0.0001),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
  }
  if(SF==2){
    if(Boxs[1]>Boxs[2]){
      Boxs_s=c(1,0)
    }else{
      Boxs_s=c(0,1)
    }
    Boxs=c(min(Boxs),max(Boxs))
  }

  if(ER==3){
    Boxr_1=Boxr[[1]]
   # Boxr_1=c(abs(log10(Boxr_1[1]/gamma)),abs(log10(Boxr_1[2]/gamma)))
    Boxr_2=Boxr[[2]]
    #Boxr_2=c(abs(log10(Boxr_2[1]/gamma_2)),abs(log10(Boxr_2[2]/gamma_2)))
    Boxr_s=c((Boxr_1[1]/sum(Boxr_1)),(Boxr_2[1]/sum(Boxr_2)))

  }
  if(SB==3){
    BoxB_1=c(min(BoxB[[1]]),max(BoxB[[1]]))
    BoxB_2=c(min(BoxB[[2]]),max(BoxB[[2]]))
    BoxB_s=c(1,1)
    BoxB_1[1]=max(sqrt(0.0001),sqrt(BoxB_1[1]))
    BoxB_1[2]=min(sqrt(1),sqrt(BoxB_1[2]))
    BoxB_2[1]=max(sqrt(0.0001),sqrt(BoxB_2[1]))
    BoxB_2[2]=min(sqrt(1),sqrt(BoxB_2[2]))
    print(BoxB_s)
    print(BoxB_1)
    print(BoxB_2)
  }
  if(SF==3){

    Boxs_1=c(min(Boxs[[1]]),max(Boxs[[1]]))
    Boxs_2=c(min(Boxs[[2]]),max(Boxs[[2]]))
    Boxs_s=c(0,0)
  }

  if(NC==1){

    if(simulator=="scrm"){
      mu=theta
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M-1))))*L)
      scale_T=mu_/mu
      Ne=NA
    }else{
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M-1))))*L)
      theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
      Ne=mu_/(mu_real)
    }
    mu=mu_

    #b=get_first_coal_time(file,mut)
    Popfix=!Pop
    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5
    if(simulator=="scrm"){
      b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne,decimal_separator=decimal_separator)
    }
    if(simulator=="msprime"){
      b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne,decimal_separator=decimal_separator)
    }

    Rho=gamma*2*L*mu
    Tc= build_Tc(n=n,Beta=beta,scale=window_scaling,Sigma=sigma,Big_Window=Big_Window,npair=npair)
    Tc=Tc*scale_T


    if(M_a<M){
      print("extracting sub genealogies then building N")
      if(M_a==2){
        count_ind=0
        for(i in 1:(M-1)){
          possible_ind=i:M
          if(i>1){
            if(i<(M-1)){
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }else{
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
            }
          }else{
            b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
          }
          for(j in (i+1):M){
            count_ind=count_ind+1
            ind=c(i,j)
            if(length(ind)<length(possible_ind)){
              b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
            }else{
              b_a=b_a_temp1
            }
            #browser()
            if(count_ind==1){
              N=build_N(b_a,Tc)
            }else{
              N=N+build_N(b_a,Tc)
            }
          }
        }
      }

    }else{
      print("building N")
      N=build_N(b,Tc)
    }

    if(BW){
      a=Get_sim_data(file,L,2,1)
      res=build_M(a[[1]],b,Tc)
      print("M is built")
      M=res$M
      print(sum(M))
      q_=res$q
    }
    if(SCALED){
      corrector_N=rowSums(N)
      N=diag(1/corrector_N)%*%N
      if(BW){
        corrector_M=rowSums(M)
        M=diag(1/corrector_M)%*%M
      }
    }
  }else{

    if(length(mu)==1){
      theta=rep(theta,NC)
    }
    if(length(L)==1){
      L=rep(L,NC)
    }


    if(simulator=="scrm"){
      mu=theta
      mu_=c()
      for(chr in 1:NC){
        theta=get_theta(file[[chr]])
        mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
      }
      scale_T=mean(mu_/mu_real)
      Ne=NA
    }else{
      mu_=c()
      for(chr in 1:NC){
        theta=get_theta(file[[chr]])
        mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
      }
      theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
      Ne=mean(mu_/(mu))
    }
    mu=mu_

    #b=get_first_coal_time(file,mut)
    Popfix=!Pop
    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5

    Rho=gamma*2*L*mu
    #print(Rho)
    #print(2*L*mu)
    Tc= build_Tc(n=n,Beta=beta,scale=window_scaling,Sigma=sigma,Big_Window=Big_Window,npair=npair)
    Tc=Tc*scale_T
    N_total=list()
    M_total=list()
    for(chr in 1:NC){

      b=get_genealogy(file[[chr]],M,mut=mut,simulator,Ne=Ne,decimal_separator=decimal_separator)

      if(M_a<M){
        print("extracting sub genealogies then building N")
        if(M_a==2){
          count_ind=0
          for(i in 1:(M-1)){
            possible_ind=i:M
            if(i>1){
              if(i<(M-1)){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
              }
            }else{
              b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }
            for(j in (i+1):M){
              count_ind=count_ind+1
              ind=c(i,j)
              if(length(ind)<length(possible_ind)){
                b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
              }else{
                b_a=b_a_temp1
              }
              if(count_ind==1){
                N=build_N(b_a,Tc)
              }else{
                N=N+build_N(b_a,Tc)
              }
            }
          }
        }

      }else{
        print("building N")
        N=build_N(b,Tc)
      }



      N_total[[chr]]=N
    }
    N=N_total
    M=M_total
  }

  Tc=Tc/scale_T
  scale_T=1
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- n
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$Pop<-!Pop
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$Big_Window <- Big_Window
  test.env$npair <- npair


  test.env$Self <- sigma
  test.env$BoxB <- BoxB
  test.env$Boxs <- Boxs
  test.env$Big_Xi <- N
  test.env$mu_b <- mu
  test.env$BW <- BW

  if(ER==2){
    test.env$Boxr_s <- Boxr_s
  }
  if(SB==2){
    test.env$BoxB_s <- BoxB_s
  }
  if(SF==2){
    test.env$Boxs_s <- Boxs_s
  }

  if(ER==3){
    test.env$Boxr_s <- Boxr_s
    test.env$Boxr_1 <- Boxr_1
    test.env$Boxr_2 <- Boxr_2
    #test.env$correct_R <- correct_R
  }

  if(SB==3){
    test.env$BoxB_s <- BoxB_s
    test.env$BoxB_1 <- BoxB_1
    test.env$BoxB_2 <- BoxB_2
    print(BoxB_s)
    print(BoxB_1)
    print(BoxB_2)
  }

  if(SF==3){
    test.env$Boxs_s <- Boxs_s
    test.env$Boxs_1 <- Boxs_1
    test.env$Boxs_2 <- Boxs_2
  }

  if(BW){
    test.env$Big_M <- M
    test.env$q_ <- q_
  }
  lr=length(Rho)
  test.env$lr<-lr
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=n)){
    Klink=0.5*n
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(SB==1){
      BoxB[1]=max(sqrt(0.0001),sqrt(BoxB[1]))
      BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
      test.env$BoxB <- BoxB
      beta=max((BoxB[1]^2),beta)
      beta=min(beta,(BoxB[2]^2))
      Beta=beta
      beta=rep(beta,length(pop_vect))
  }
  if(SB==2){

    if(BoxB_s[1]==0){
      beta=c(rep(BoxB[(BoxB_s[1]+1)]^2,(length(pop_vect)-1)),BoxB[(BoxB_s[2]+1)]^2)
      oldtb=length(pop_vect)
    }else{
      beta=c(BoxB[(BoxB_s[1]+1)]^2,rep(BoxB[(BoxB_s[2]+1)]^2,(length(pop_vect)-1)))
      oldtb=1
    }

    Beta=max(beta)


  }
  if(SB==3){

    bb=0
    sum_h=0
    while (sum_h<(n/2)){
      bb=bb+1
      sum_h=sum(pop_vect[1:bb])
    }

    oldtb=bb
    test.env$t_b <- oldtb
    beta=c(rep((max(BoxB_1)^2),(bb-1)),rep((max(BoxB_2)^2),Klink-bb+1))
    print(beta)
    Beta=max(beta)
    print(Beta)
  }
  if(SF==1){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Self=sigma
    sigma=rep(sigma,length(pop_vect))
  }
  if(SF==2){
    if(Boxs[(Boxs_s[1]+1)]==0){
      sigma=c(rep(Boxs[(Boxs_s[1]+1)],(length(pop_vect)-1)),Boxs[(Boxs_s[2]+1)])
      oldts=length(pop_vect)
    }else{
      sigma=c(Boxs[(Boxs_s[1]+1)],rep(Boxs[(Boxs_s[2]+1)],(length(pop_vect)-1)))
      oldts=1
    }

    #Self=sigma[1]
    Self=min(Boxs)
  }
  if(SF==3){

    bb=0
    sum_h=0
    while (sum_h<(n/2)){
      bb=bb+1
      sum_h=sum(pop_vect[1:bb])
    }
    oldts=bb
    test.env$t_s <- oldts
    Self=min(Boxs[[1]])
    sigma=c(rep(min(Boxs_1),(bb-1)),rep(min(Boxs_2),Klink-bb+1))
  }
  if(ER==1){
    oldrho=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=rep((Boxr[1]/sum(Boxr)),length(pop_vect))
      }
    }

  }
  if(ER==0){
    Boxr=c(0,0)
  }
  if(ER==2){
    oldrho=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=c(rep(Boxr_s[1],(length(pop_vect)-1)),Boxr_s[2])
      }
    }

  }
  if(ER==3){
    bb=0
    sum_h=0
    while (sum_h<(n/2)){
      bb=bb+1
      sum_h=sum(pop_vect[1:bb])
    }
    oldtr=bb
    test.env$t_r <- oldtr
    oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink-oldtr+1)))
    if(NC>1){
      oldrho=list()
      for(rr in 1:NC){
        oldrho[[rr]]=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink-oldtr+1)))
      }
    }
  }
  if(SB==0){
    Beta=beta
    test.env$beta <- beta
  }
  if(SF==0){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
  }
  if(Pop){
    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }
  if(SB>0&SB<3){
    oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
  }
  if(SB==3){
    if(oldtb>Klink){
      oldbeta=(sqrt(beta)-BoxB_1[1])/(BoxB_1[2]-BoxB_1[1])
    }else{
      if(oldtb>1){
        oldbeta=c((sqrt(beta[1:(oldtb-1)])-BoxB_1[1])/(BoxB_1[2]-BoxB_1[1]),(sqrt(beta[oldtb:Klink])-BoxB_2[1])/(BoxB_2[2]-BoxB_2[1]))
      }else{
        oldbeta=(sqrt(beta)-BoxB_2[1])/(BoxB_2[2]-BoxB_2[1])
      }
    }
  }
  if(SF>0&SF<3){
    oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
  }
  if(SF==3){
    if(oldts>Klink){
      oldsigma=(sigma-Boxs_1[1])/(Boxs_1[2]-Boxs_1[1])
    }else{
      if(oldts>1){
        oldsigma= c( ((sigma[1:(oldts-1)]-Boxs_1[1])/(Boxs_1[2]-Boxs_1[1])), ((sigma[oldts:Klink]-Boxs_2[1])/(Boxs_2[2]-Boxs_2[1])))
      }else{
        oldsigma=(sigma-Boxs_2[1])/(Boxs_2[2]-Boxs_2[1])
      }
    }
   # print(oldsigma)
  }


  if(T){
    if(NC==1){

      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB

      function_to_minimize_prior<-function(param){

        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        npair=get('npair', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        FS=get('FS', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Self=get('Self', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)

        start_position=0
        if(ER==1){
          rho_=numeric(n)
          rho=param[(start_position+1):(start_position+Klink)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+Klink
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]

          }

        }
        if(ER==2){

          Boxr_s=get('Boxr_s', envir=test.env)

          rho_=numeric(n)
          #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_r=get('t_r', envir=test.env)
          if(t_r>Klink){
            rho=rep(Boxr_s[1],Klink)
          }else{
            if(t_r>1){
              rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
            }else{
              rho=rep(Boxr_s[2],Klink)
            }
          }

          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          #start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]

          }
        }
        if(ER==3){
          t_r=get('t_r', envir=test.env)
          Boxr_s=get('Boxr_s', envir=test.env)
          #print(Boxr_s)
          Boxr_1=get('Boxr_1', envir=test.env)
          Boxr_2=get('Boxr_2', envir=test.env)
          #correct_R=get('correct_R', envir=test.env)
          rho_=numeric(n)
          #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


          if(t_r>Klink){

            rho=rep(Boxr_s[1],Klink)
            rho=rho*sum(Boxr_1)
            rho=rho-(Boxr_1[1])
            rho=10^(rho)
            rho=rho*Rho
          }else{
            if(t_r>1){
              rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
              rho=c(rho[1:(t_r-1)]*sum(Boxr_1),rho[t_r:Klink]*sum(Boxr_2))
              rho=c(rho[1:(t_r-1)]-(Boxr_1[1]),rho[t_r:Klink]-(Boxr_2[1]))
              rho=10^(rho)
              rho=rho*Rho
            }else{
              rho=rep(Boxr_s[2],Klink)
              rho=rho*sum(Boxr_2)
              rho=rho-(Boxr_2[1])
              rho=10^(rho)
              rho=rho*Rho
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]
          }
        #  print(rho_)
        }
        if(ER==0){
          rho_=rep(Rho,n)
        }
        if(SF==1){
          sigma_=numeric(n)
          sigma=param[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==2){
          Boxs_s=get('Boxs_s', envir=test.env)
          sigma_=numeric(n)

          #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
          }


          #start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }

        }
        if(SF==3){
          Boxs_s=get('Boxs_s', envir=test.env)
          Boxs_1=get('Boxs_1', envir=test.env)
          Boxs_2=get('Boxs_2', envir=test.env)
          sigma_=numeric(n)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
            sigma=sigma*(Boxs_1[2]-Boxs_1[1])
            sigma=sigma+Boxs_1[1]
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
              sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
            }else{
              sigma=rep(Boxs_s[2],Klink)
              sigma=sigma*(Boxs_2[2]-Boxs_2[1])
              sigma=sigma+Boxs_2[1]
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==0){
          sigma_=rep(sigma,n)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2#^2
          start_position=start_position+(Klink)
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==2){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_b=get('t_b', envir=test.env)

          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }
          }



          beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2#^2
          # start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==3){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          BoxB_1=get('BoxB_1', envir=test.env)
          BoxB_2=get('BoxB_2', envir=test.env)
          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
            beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2#^2
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
              beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1]))^2,(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1]))^2) # ^2
            }else{
              beta=rep(BoxB_s[2],Klink)
              beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2#^2
            }
          }


          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==0){
          beta_=rep(beta,n)
        }
        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }

        builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
        Q=builder[[1]]
        Q=t(Q)
        A=as.vector(Q)
        keep=which(A>0&as.vector(Big_Xi)>0)
        A=A[keep]
        Big_Xi=as.vector(Big_Xi)
        Big_Xi=Big_Xi[keep]



        LH=0




        if(BW){

          q_=get('q_', envir=test.env)
          Big_M=get('Big_M', envir=test.env)

          Tc=builder[[3]]
          g=matrix(0,nrow=length(Tc),ncol=2)
          if(!FS){
            g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
            g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
          }
          if(FS){
            g[,2]= 0.75 - (0.75*exp(-4*mu*(beta+((1-beta)*mu_b))*2*Tc/3))
            g[,1]= 0.25 + (0.75*exp(-4*mu*(beta+((1-beta)*mu_b))*2*Tc/3))
          }

          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(Big_M)
          m=m[keep]
          nu=builder[[2]]

          LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)



        }
        if(!BW){
          LH=-sum(log(A)*Big_Xi)
        }

        return(LH)
      }

      function_to_minimize<-function(param){

        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        npair=get('npair', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        FS=get('FS', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Self=get('Self', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)

        start_position=0
        if(ER==1){
          rho_=numeric(n)
          rho=param[(start_position+1):(start_position+Klink)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+Klink
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]

          }

        }
        if(ER==2){

          Boxr_s=get('Boxr_s', envir=test.env)

          rho_=numeric(n)
          #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_r=get('t_r', envir=test.env)
          if(t_r>Klink){
            rho=rep(Boxr_s[1],Klink)
          }else{
            if(t_r>1){
              rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
            }else{
              rho=rep(Boxr_s[2],Klink)
            }
          }

          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          #start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]

          }
        }
        if(ER==3){
          t_r=get('t_r', envir=test.env)
          Boxr_s=param[(start_position+1):(start_position+2)]
          start_position=start_position+2
          Boxr_1=get('Boxr_1', envir=test.env)
          Boxr_2=get('Boxr_2', envir=test.env)
          #correct_R=get('correct_R', envir=test.env)
          rho_=numeric(n)
          #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)


          if(t_r>Klink){

            rho=rep(Boxr_s[1],Klink)
            rho=rho*sum(Boxr_1)
            rho=rho-(Boxr_1[1])
            rho=10^(rho)
            rho=rho*Rho
          }else{
            if(t_r>1){
              rho=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
              rho=c(rho[1:(t_r-1)]*sum(Boxr_1),rho[t_r:Klink]*sum(Boxr_2))
              rho=c(rho[1:(t_r-1)]-(Boxr_1[1]),rho[t_r:Klink]-(Boxr_2[1]))
              rho=10^(rho)
              rho=rho*Rho
            }else{
              rho=rep(Boxr_s[2],Klink)
              rho=rho*sum(Boxr_2)
              rho=rho-(Boxr_2[1])
              rho=10^(rho)
              rho=rho*Rho
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho_[x:xx]=rho[ix]
          }
        }
        if(ER==0){
          rho_=rep(Rho,n)
        }
        if(SF==1){
          sigma_=numeric(n)
          sigma=param[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==2){
          Boxs_s=get('Boxs_s', envir=test.env)
          sigma_=numeric(n)

          #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
          }


          #start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }

        }
        if(SF==3){
          Boxs_s=param[(start_position+1):(start_position+2)]
          start_position=start_position+2
          Boxs_1=get('Boxs_1', envir=test.env)
          Boxs_2=get('Boxs_2', envir=test.env)
          sigma_=numeric(n)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
            sigma=sigma*(Boxs_1[2]-Boxs_1[1])
            sigma=sigma+Boxs_1[1]
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
              sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
            }else{
              sigma=rep(Boxs_s[2],Klink)
              sigma=sigma*(Boxs_2[2]-Boxs_2[1])
              sigma=sigma+Boxs_2[1]
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==0){
          sigma_=rep(sigma,n)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2#^2
          start_position=start_position+(Klink)
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==2){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_b=get('t_b', envir=test.env)

          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }
          }



          beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2#^2
          # start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==3){
          beta_=numeric(n)
          BoxB_s=param[(start_position+1):(start_position+2)]
          start_position=start_position+2
          BoxB_1=get('BoxB_1', envir=test.env)
          BoxB_2=get('BoxB_2', envir=test.env)
          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
            beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2#^2
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
              beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1]))^2,(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1]))^2)#^2
            }else{
              beta=rep(BoxB_s[2],Klink)
              beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2#^2
            }
          }


          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==0){
          beta_=rep(beta,n)
        }
        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }

        builder=build_HMM_matrix_t(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
        Q=builder[[1]]
        Q=t(Q)
        A=as.vector(Q)
        keep=which(A>0&as.vector(Big_Xi)>0)
        A=A[keep]
        Big_Xi=as.vector(Big_Xi)
        Big_Xi=Big_Xi[keep]



        LH=0




        if(BW){

          q_=get('q_', envir=test.env)
          Big_M=get('Big_M', envir=test.env)

          Tc=builder[[3]]
          g=matrix(0,nrow=length(Tc),ncol=2)
          if(!FS){
            g[,2]=1-exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
            g[,1]=exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)
          }
          if(FS){
            g[,2]= 0.75 - (0.75*exp(-4*mu*(beta+((1-beta)*mu_b))*2*Tc/3))
            g[,1]= 0.25 + (0.75*exp(-4*mu*(beta+((1-beta)*mu_b))*2*Tc/3))
          }

          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(Big_M)
          m=m[keep]
          nu=builder[[2]]

          LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)



        }
        if(!BW){
          LH=-sum(log(A)*Big_Xi)
        }

        return(LH)
      }

      if(max(c(ER,SB,SF))<2){


        # First run for prior

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        test.env$Pop<-T

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0
        sol=as.numeric(sol[1:length(param),1])


        if(ER==1){
          rho=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          # browser()
          oldrho=rho
        }

        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }



        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }
        test.env$Pop<-!Pop
        # Second for real parameters

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }
        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0
        sol=as.numeric(sol[1:length(param),1])


        if(ER==1){
          rho=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          # browser()
          oldrho=rho
        }

        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }



        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }

        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }



      }else{

        if(max(c(ER,SB,SF))==3){
          nloop=3
        }else{
          nloop=1
        }

        for(nnn in 1:nloop){

        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }

        LH_temp=0

        if(ER==3){

      #    print(Boxr_s)
          LH_temp=function_to_minimize_prior(param)
          UP=F
          if((Boxr_s[1]+0.05)<1){
            Boxr_s[1]=Boxr_s[1]+0.05
            test.env$Boxr_s <- Boxr_s
            LH_temp2=function_to_minimize_prior(param)
            if(LH_temp>LH_temp2){
              UP=T
              LH_temp=LH_temp2
            }else{
              Boxr_s[1]=Boxr_s[1]-0.05
              test.env$Boxr_s <- Boxr_s
            }
          }

          if(UP){
            while(UP){
              if((Boxr_s[1]+0.05)<1){
                Boxr_s[1]=Boxr_s[1]+0.05
                test.env$Boxr_s <- Boxr_s
                UP=F
                LH_temp2=function_to_minimize_prior(param)
                if(LH_temp>LH_temp2){
                  UP=T
                  LH_temp=LH_temp2
                }else{
                  Boxr_s[1]=Boxr_s[1]-0.05
                  test.env$Boxr_s <- Boxr_s
                }
              }else{
                UP=F
              }
            }
          }else{
            DOWN=F
            if((Boxr_s[1]-0.05)>0){
              Boxr_s[1]=Boxr_s[1]-0.05
              test.env$Boxr_s <- Boxr_s
              LH_temp2=function_to_minimize_prior(param)
              if(LH_temp>LH_temp2){
                DOWN=T
                LH_temp=LH_temp2
              }else{
                Boxr_s[1]=Boxr_s[1]+0.05
                test.env$Boxr_s <- Boxr_s
              }
            }
            while(DOWN){
              if((Boxr_s[1]-0.05)>0){
                Boxr_s[1]=Boxr_s[1]-0.05
                test.env$Boxr_s <- Boxr_s
                DOWN=F
                LH_temp2=function_to_minimize_prior(param)
                if(LH_temp>LH_temp2){
                  DOWN=T
                  LH_temp=LH_temp2
                }else{
                  Boxr_s[1]=Boxr_s[1]+0.05
                  test.env$Boxr_s <- Boxr_s
                }
              }else{
                DOWN=F
              }
            }
          }


          UP=F
          if((Boxr_s[2]+0.05)<1){
            Boxr_s[2]=Boxr_s[2]+0.05
            test.env$Boxr_s <- Boxr_s
            LH_temp2=function_to_minimize_prior(param)
            if(LH_temp>LH_temp2){
              UP=T
              LH_temp=LH_temp2
            }else{
              Boxr_s[2]=Boxr_s[2]-0.05
              test.env$Boxr_s <- Boxr_s
            }
          }

          if(UP){
            while(UP){
              if((Boxr_s[2]+0.05)<1){
                Boxr_s[2]=Boxr_s[2]+0.05
                test.env$Boxr_s <- Boxr_s
                UP=F
                LH_temp2=function_to_minimize_prior(param)
                if(LH_temp>LH_temp2){
                  UP=T
                  LH_temp=LH_temp2
                }else{
                  Boxr_s[2]=Boxr_s[2]-0.05
                  test.env$Boxr_s <- Boxr_s
                }
              }else{
                UP=F
              }
            }
          }else{
            DOWN=F
            if((Boxr_s[2]-0.05)>0){
              Boxr_s[2]=Boxr_s[2]-0.05
              test.env$Boxr_s <- Boxr_s
              LH_temp2=function_to_minimize_prior(param)
              if(LH_temp>LH_temp2){
                DOWN=T
                LH_temp=LH_temp2
              }else{
                Boxr_s[2]=Boxr_s[2]+0.05
                test.env$Boxr_s <- Boxr_s
              }
            }
            while(DOWN){
              if((Boxr_s[2]-0.05)>0){
                Boxr_s[2]=Boxr_s[2]-0.05
                test.env$Boxr_s <- Boxr_s
                DOWN=F
                LH_temp2=function_to_minimize_prior(param)
                if(LH_temp>LH_temp2){
                  DOWN=T
                  LH_temp=LH_temp2
                }else{
                  Boxr_s[2]=Boxr_s[2]+0.05
                  test.env$Boxr_s <- Boxr_s
                }
              }else{
                DOWN=F
              }
            }
          }


#          print(Boxr_s)
        }

        if(SF==3){
          print(Boxs_s)
          LH_temp=function_to_minimize_prior(param)
          Boxs_s[1]=Boxs_s[1]+0.05
          test.env$Boxs_s <- Boxs_s
          UP=F
          LH_temp2=function_to_minimize_prior(param)
          if(LH_temp>LH_temp2){
            UP=T
            LH_temp=LH_temp2
          }else{
            Boxs_s[1]=Boxs_s[1]-0.05
            test.env$Boxs_s <- Boxs_s
          }
          while(UP){
            if((Boxs_s[1]+0.05)<1){
              Boxs_s[1]=Boxs_s[1]+0.05
              test.env$Boxs_s <- Boxs_s
              UP=F
              LH_temp2=function_to_minimize_prior(param)
              if(LH_temp>LH_temp2){
                UP=T
                LH_temp=LH_temp2
              }else{
                Boxs_s[1]=Boxs_s[1]-0.05
                test.env$Boxs_s <- Boxs_s
              }
            }else{
              UP=F
            }
          }
          Boxs_s[2]=Boxs_s[2]+0.05
          test.env$Boxs_s <- Boxs_s
          UP=F
          LH_temp2=function_to_minimize_prior(param)
          if(LH_temp>LH_temp2){
            UP=T
            LH_temp=LH_temp2
          }else{
            Boxs_s[2]=Boxs_s[2]-0.05
            test.env$Boxs_s <- Boxs_s
          }
          while(UP){
            if((Boxs_s[2]+0.05)<1){
              Boxs_s[2]=Boxs_s[2]+0.05
              test.env$Boxs_s <- Boxs_s
              UP=F
              LH_temp2=function_to_minimize_prior(param)
              if(LH_temp>LH_temp2){
                UP=T
                LH_temp=LH_temp2
              }else{
                Boxs_s[2]=Boxs_s[2]-0.05
                test.env$Boxs_s <- Boxs_s
              }
            }else{
              UP=F
            }
          }

        print(Boxs_s)
        }

        if(SB==3){
          print(BoxB_s)
          LH_temp=function_to_minimize_prior(param)
          BoxB_s[1]=BoxB_s[1]-0.05
          test.env$BoxB_s <- BoxB_s
          DOWN=F
          LH_temp2=function_to_minimize_prior(param)
          if(LH_temp>LH_temp2){
            DOWN=T
            LH_temp=LH_temp2
          }else{
            BoxB_s[1]=BoxB_s[1]+0.05
            test.env$BoxB_s <- BoxB_s
          }
          while(DOWN){
            if((BoxB_s[1]-0.05)>0){
              BoxB_s[1]=BoxB_s[1]-0.05
              test.env$BoxB_s <- BoxB_s
              DOWN=F
              LH_temp2=function_to_minimize_prior(param)
              if(LH_temp>LH_temp2){
                DOWN=T
                LH_temp=LH_temp2
              }else{
                BoxB_s[1]=BoxB_s[1]+0.05
                test.env$BoxB_s <- BoxB_s
              }
            }else{
              DOWN=F
            }
          }
          BoxB_s[2]=BoxB_s[2]-0.05
          test.env$BoxB_s <- BoxB_s
          DOWN=F
          LH_temp2=function_to_minimize_prior(param)
          if(LH_temp>LH_temp2){
            DOWN=T
            LH_temp=LH_temp2
          }else{
            BoxB_s[2]=BoxB_s[2]+0.05
            test.env$BoxB_s <- BoxB_s
          }
          while(DOWN){
            if((BoxB_s[2]-0.05)>0){
              BoxB_s[2]=BoxB_s[2]-0.05
              test.env$BoxB_s <- BoxB_s
              DOWN=F
              LH_temp2=function_to_minimize_prior(param)
              if(LH_temp>LH_temp2){
                DOWN=T
                LH_temp=LH_temp2
              }else{
                BoxB_s[2]=BoxB_s[2]+0.05
                test.env$BoxB_s <- BoxB_s
              }
            }else{
              DOWN=F
            }
          }

          print(BoxB_s)
        }


        if(ER>1){
          for(t_r in 1:(1+Klink)){
            test.env$t_r <- t_r
            if(SB>1){
              for( t_b in 1:(1+Klink)){
                test.env$t_b <- t_b
                if(SF>1){

                  for(t_s in 1:(1+Klink)){
                    test.env$t_s <- t_s

                    sol_temp=function_to_minimize_prior(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtr=t_r
                      oldtb=t_b
                      oldts=t_s

                    }

                  }

                }else{
                  sol_temp=function_to_minimize_prior(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldtb=t_b

                  }
                }
              }

            }else{ # NO  SB
              if(SF==2){
                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize_prior(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize_prior(param)
                print(sol_temp)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){
                  LH_temp=as.numeric(sol_temp)
                  oldtr=t_r

                }
              }
            }
          }
        }else{ # No ER
          if(SB>1){
            #print( oldtb)
            for(t_b in 1:(1+Klink)){
              test.env$t_b <- t_b
              if(SF>1){

                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize_prior(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtb=t_b
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize_prior(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){
                  LH_temp=as.numeric(sol_temp)
                  oldtb=t_b

                }
              }
            }
            #print( oldtb)
          }else{
            if(SF>1){

              for(t_s in 1:(1+Klink)){
                test.env$t_s <- t_s
                sol_temp=function_to_minimize_prior(param)
                print(sol_temp)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){
                  LH_temp=as.numeric(sol_temp)
                  oldts=t_s


                }
              }
            }else{

              stop("How did you get here ?")

            }
          }
        }

        if(ER>1){
          test.env$t_r <- oldtr

          if(oldtr>Klink){
            oldrho=rep(Boxr_s[1],(Klink))
          }else{
            if(oldtr>1){
              oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
            }else{
              oldrho=rep(Boxr_s[2],(Klink))
            }
          }


        }


        if(SF>1){
          # oldts=ceiling(sol[(start_position+1)]*Klink)
          #   start_position=start_position+1
          test.env$t_s <- oldts

          if(oldts>Klink){
            oldsigma=rep(Boxs_s[1],(Klink))
          }else{
            if(oldts>1){
              oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
            }else{
              oldsigma=rep(Boxs_s[2],(Klink))
            }
          }
        }


        if(SB>1){
          #    oldtb=ceiling(sol[(start_position+1)]*Klink)
          #   start_position=start_position+1
          test.env$t_b <- oldtb

          if(oldtb>Klink){
            oldbeta=rep(BoxB_s[1],(Klink))
          }else{
            if(oldtb>1){
              oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
            }else{
              oldbeta=rep(BoxB_s[2],(Klink))
            }
          }


        }

        param=c()
        if(ER==1){
          param=c(param,oldrho)
        }
        if(ER==3){
          param=c(param,Boxr_s)

        }
        if(SF==1){
          param=c(param,oldsigma)

        }
        if(SF==3){
          param=c(param,Boxs_s)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(SB==3){
          param=c(param,BoxB_s)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }

        if(length(param)>0){

            sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=10+length(param),M=c(20)))

            sol=as.matrix(sol[[1]])
            start_position=0
            sol=as.numeric(sol[1:length(param),1])


          if(ER==1){
            rho=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            # browser()
            oldrho=rho
          }
          if(ER==3){
            Boxr_s=sol[(start_position+1):(start_position+2)]
            test.env$Boxr_s <- Boxr_s
            start_position=start_position+2
            if(oldtr>Klink){
              oldrho=rep(Boxr_s[1],(Klink))
            }else{
              if(oldtr>1){
                oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
              }else{
                oldrho=rep(Boxr_s[2],(Klink))
              }
            }
          }
          if(SF==1){
            sigma_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldsigma=sigma_
          }

          if(SF==3){
            Boxs_s=sol[(start_position+1):(start_position+2)]
            test.env$Boxs_s <- Boxs_s
            start_position=start_position+2
            if(oldts>Klink){
              oldsigma=rep(Boxs_s[1],(Klink))
            }else{
              if(oldts>1){
                oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
              }else{
                oldsigma=rep(Boxs_s[2],(Klink))
              }
            }
          }

          if(SB==1){
            beta_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldbeta=beta_
          }

          if(SB==3){
            BoxB_s=sol[(start_position+1):(start_position+2)]
            test.env$BoxB_s <- BoxB_s
            start_position=start_position+2
            if(oldtb>Klink){
              oldbeta=rep(BoxB_s[1],(Klink))
            }else{
              if(oldtb>1){
                oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
              }else{
                oldbeta=rep(BoxB_s[2],(Klink))
              }
            }
          }


          if(!Popfix){
            Xi_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldXi_=Xi_
          }

        }
      }
    }
}

    if(NC>1){

      test.env$ER <- ER
      test.env$SF <- SF
      test.env$SB <- SB

      function_to_minimize_prior<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        npair=get('npair', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        FS=get('FS', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Self=get('Self', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        Os=get('Os_zip', envir=test.env)
        NC=get('NC', envir=test.env)
        start_position=0
        if(ER==1){

          rho=list()
          rho_=list()
          oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
          for(rr in 1:NC){
            rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
            rho[[rr]]=rho[[rr]]-(Boxr[1])
            rho[[rr]]=10^(rho[[rr]])
            rho[[rr]]=rho[[rr]]*Rho[rr]

            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
          start_position=start_position+(Klink*NC)
        }
        if(ER==2){

          Boxr_s=get('Boxr_s', envir=test.env)

          #t_r=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_r=get('t_r', envir=test.env)

          rho=list()
          rho_=list()

          for(rr in 1:NC){

            if(t_r>Klink){
              oldrho_param=rep(Boxr_s[1],Klink)
            }else{
              if(t_r>1){
                oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
              }else{
                oldrho_param=rep(Boxr_s[2],Klink)
              }
            }


            rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
            rho[[rr]]=rho[[rr]]-(Boxr[1])
            rho[[rr]]=10^(rho[[rr]])
            rho[[rr]]=rho[[rr]]*Rho[rr]

            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
        }
        if(ER==0){
          rho_=list()
          for(rr in 1:NC){
            rho_[[rr]]=rep(Rho[rr],n)
          }
        }
        if(ER==3){

          Boxr_s=get('Boxr_s', envir=test.env)
          Boxr_1=get('Boxr_1', envir=test.env)
          Boxr_2=get('Boxr_2', envir=test.env)
          #correct_R=get('correct_R', envir=test.env)
          t_r=get('t_r', envir=test.env)

          rho=list()
          rho_=list()

          for(rr in 1:NC){

            if(t_r>Klink){
              oldrho_param=rep(Boxr_s[1],Klink)
              rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_1)
              rho[[rr]]=rho[[rr]]-(Boxr_1[1])
              rho[[rr]]=10^(rho[[rr]])
              rho[[rr]]=rho[[rr]]*Rho[rr]
            }else{
              if(t_r>1){
                oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                rho[[rr]]=  c(( oldrho_param[(1+((rr-1)*Klink)):((t_r-1)+((rr-1)*Klink))]*sum(Boxr_1))  , ( oldrho_param[((t_r)+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)) )
                rho[[rr]]=c(  rho[[rr]][1:(t_r-1)]-(Boxr_1[1]) ,  rho[[rr]][t_r:Klink]-(Boxr_2[1]) )
                rho[[rr]]=10^(rho[[rr]])
                rho[[rr]]=c(rho[[rr]][1:(t_r-1)]*Rho[rr],rho[[rr]][t_r:Klink]*Rho[rr])
              }else{
                oldrho_param=rep(Boxr_s[2],Klink)
                rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)
                rho[[rr]]=rho[[rr]]-(Boxr_2[1])
                rho[[rr]]=10^(rho[[rr]])
                rho[[rr]]=rho[[rr]]*Rho[rr]
              }
            }




            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
        }
        if(SF==1){
          sigma_=numeric(n)
          sigma=param[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==2){
          Boxs_s=get('Boxs_s', envir=test.env)
          sigma_=numeric(n)

          #t_s=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_s=get('t_s', envir=test.env)
          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
          }
          #start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }

        }
        if(SF==3){
          Boxs_s=get('Boxs_s', envir=test.env)
          Boxs_1=get('Boxs_1', envir=test.env)
          Boxs_2=get('Boxs_2', envir=test.env)
          sigma_=numeric(n)

          t_s=get('t_s', envir=test.env)
          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
            sigma=sigma*(Boxs_1[2]-Boxs_1[1])
            sigma=sigma+Boxs_1[1]
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
              sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
            }else{
              sigma=rep(Boxs_s[2],Klink)
              sigma=sigma*(Boxs_2[2]-Boxs_2[1])
              sigma=sigma+Boxs_2[1]
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==0){
          sigma_=rep(sigma,n)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+Klink)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+(Klink)
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==2){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          #t_b=min(ceiling(param[(start_position+1)]*Klink),Klink)
          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }
          }

          beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          # start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==0){
          beta_=rep(beta,n)
        }
        if(SB==3){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)
          BoxB_1=get('BoxB_1', envir=test.env)
          BoxB_2=get('BoxB_2', envir=test.env)
          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
            beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
              beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
            }else{
              beta=rep(BoxB_s[2],Klink)
              beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
            }
          }


          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }

        MLH=0


        for(chr in 1:NC){
          builder=build_HMM_matrix_t(k,(rho[[chr]]),beta=beta_,L=L[chr],Pop=Pop,Xi,Beta=Beta,scale=window_scaling,sigma =sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta_,FS)




          q_=rep(0,length(Tc))
          test=Build_zip_Matrix_LH_mailund(Q,g,Os[[chr]][[1]][[2]],nu)
          C_test=rep(0,n)
          for(c_test in 1:length(test[[1]])){
            C_test=rbind(C_test,(test[[1]][[c_test]]))
          }
          C_test=C_test[-1,]
          for(i in 1:length(Os[[chr]])){
            LH_cpp=forward_cpp(as.integer(Os[[chr]][[i]][[1]]),g,nu,C_test)
            MLH=MLH-LH_cpp
          }
        }
        return(MLH)
      }

      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        npair=get('npair', envir=test.env)
        Big_Window=get('Big_Window', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        FS=get('FS', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Self=get('Self', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        Os=get('Os', envir=test.env)
        q_=get('q_', envir=test.env)
        Big_M=get('Big_M', envir=test.env)
        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)
        NC=get('NC', envir=test.env)
        a=0
        start_position=0
        if(ER==1){
          rho=list()
          rho_=list()
          oldrho_param=param[(start_position+1):(start_position+(Klink*NC))]
          for(rr in 1:NC){
            rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr)
            rho[[rr]]=rho[[rr]]-(Boxr[1])
            rho[[rr]]=10^(rho[[rr]])
            rho[[rr]]=rho[[rr]]*Rho[rr]

            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
          start_position=start_position+(Klink*NC)
        }
        if(ER==2){

          Boxr_s=get('Boxr_s', envir=test.env)





          rho=list()
          rho_=list()

          t_r=get('t_r', envir=test.env)
          for(rr in 1:NC){

            if(t_r>Klink){
              rho[[rr]]=rep(Boxr_s[1],Klink)
            }else{
              if(t_r>1){
                rho[[rr]]=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
              }else{
                rho[[rr]]=rep(Boxr_s[2],Klink)
              }
            }



            rho[[rr]]= rho[[rr]]*sum(Boxr)
            rho[[rr]]=rho[[rr]]-(Boxr[1])
            rho[[rr]]=10^(rho[[rr]])
            rho[[rr]]=rho[[rr]]*Rho[rr]

            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
          #  start_position=start_position+1
        }
        if(ER==3){

          Boxr_s=param[(start_position+1):(start_position+2)]
          start_position=start_position+2
          Boxr_1=get('Boxr_1', envir=test.env)
          Boxr_2=get('Boxr_2', envir=test.env)
          #correct_R=get('correct_R', envir=test.env)
          t_r=get('t_r', envir=test.env)

          rho=list()
          rho_=list()

          for(rr in 1:NC){

            if(t_r>Klink){
              oldrho_param=rep(Boxr_s[1],Klink)
              rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_1)
              rho[[rr]]=rho[[rr]]-(Boxr_1[1])
              rho[[rr]]=10^(rho[[rr]])
              rho[[rr]]=rho[[rr]]*Rho[rr]
            }else{
              if(t_r>1){
                oldrho_param=c(rep(Boxr_s[1],(t_r-1)),rep(Boxr_s[2],(Klink-t_r+1)))
                rho[[rr]]=  c(( oldrho_param[(1+((rr-1)*Klink)):((t_r-1)+((rr-1)*Klink))]*sum(Boxr_1))  , ( oldrho_param[((t_r)+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)) )
                rho[[rr]]=c(  rho[[rr]][1:(t_r-1)]-(Boxr_1[1]) ,  rho[[rr]][t_r:Klink]-(Boxr_2[1]) )
                rho[[rr]]=10^(rho[[rr]])
                rho[[rr]]=c(rho[[rr]][1:(t_r-1)]*Rho[rr],rho[[rr]][t_r:Klink]*Rho[rr])
              }else{
                oldrho_param=rep(Boxr_s[2],Klink)
                rho[[rr]]= oldrho_param[(1+((rr-1)*Klink)):(rr*Klink)]*sum(Boxr_2)
                rho[[rr]]=rho[[rr]]-(Boxr_2[1])
                rho[[rr]]=10^(rho[[rr]])
                rho[[rr]]=rho[[rr]]*Rho[rr]
              }
            }




            xx=0
            rho_[[rr]]=vector()
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              rho_[[rr]][x:xx]= rho[[rr]][ix]
            }
          }
        }
        if(ER==0){
          rho_=list()
          for(rr in 1:NC){
            rho_[[rr]]=rep(Rho[rr],n)
          }
        }
        if(SF==1){
          sigma_=numeric(n)
          sigma=param[(start_position+1):(start_position+(Klink))]
          start_position=start_position+(Klink)
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }

        }
        if(SF==2){
          Boxs_s=get('Boxs_s', envir=test.env)
          sigma_=numeric(n)

          t_s=get('t_s', envir=test.env)
          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
            }else{
              sigma=rep(Boxs_s[2],Klink)
            }
          }
          # start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==3){
          Boxs_s=param[(start_position+1):(start_position+2)]
          start_position=start_position+2
          Boxs_1=get('Boxs_1', envir=test.env)
          Boxs_2=get('Boxs_2', envir=test.env)
          sigma_=numeric(n)
          t_s=get('t_s', envir=test.env)

          if(t_s>Klink){
            sigma=rep(Boxs_s[1],Klink)
            sigma=sigma*(Boxs_1[2]-Boxs_1[1])
            sigma=sigma+Boxs_1[1]
          }else{
            if(t_s>1){
              sigma=c(rep(Boxs_s[1],(t_s-1)),rep(Boxs_s[2],(Klink-t_s+1)))
              sigma= c(sigma[1:(t_s-1)]*(Boxs_1[2]-Boxs_1[1]),sigma[t_s:Klink]*(Boxs_2[2]-Boxs_2[1]) )
              sigma= c(sigma[1:(t_s-1)]+Boxs_1[1],sigma[t_s:Klink]+Boxs_2[1])
            }else{
              sigma=rep(Boxs_s[2],Klink)
              sigma=sigma*(Boxs_2[2]-Boxs_2[1])
              sigma=sigma+Boxs_2[1]
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            sigma_[x:xx]=sigma[ix]
          }
        }
        if(SF==0){
          sigma_=rep(sigma,n)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+(Klink))]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+(Klink)
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==2){
          beta_=numeric(n)
          BoxB_s=get('BoxB_s', envir=test.env)

          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
            }else{
              beta=rep(BoxB_s[2],Klink)
            }
          }

          beta=((beta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          #   start_position=start_position+1
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==3){
          beta_=numeric(n)
          BoxB_s=param[(start_position+1):(start_position+2)]
          start_position=start_position+2
          BoxB_1=get('BoxB_1', envir=test.env)
          BoxB_2=get('BoxB_2', envir=test.env)
          t_b=get('t_b', envir=test.env)
          if(t_b>Klink){
            beta=rep(BoxB_s[1],Klink)
            beta=((beta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2
          }else{
            if(t_b>1){
              beta=c(rep(BoxB_s[1],(t_b-1)),rep(BoxB_s[2],(Klink-t_b+1)))
              beta=c((((beta[1:(t_b-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1])^2),(((beta[t_b:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2))
            }else{
              beta=rep(BoxB_s[2],Klink)
              beta=((beta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1])^2
            }
          }


          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            beta_[x:xx]=beta[ix]

          }
        }
        if(SB==0){
          beta_=rep(beta,n)
        }

        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }




        LH=0


        for(chr in 1:NC){

          builder=build_HMM_matrix_t(n,(rho_[[chr]]),beta=beta_,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
          Q=builder[[1]]
          Q=t(Q)
          A=as.vector(Q)
          keep=which(as.vector(Big_Xi[[chr]])>0)
          A=A[keep]
          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
          Big_Xi[[chr]]=Big_Xi[[chr]][keep]
          Tc=builder[[3]]
          g=build_emission_matrix(mu[chr],mu_b,Tc=builder[[4]],t=builder[[3]],beta_,FS)
          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(Big_M[[chr]])
          m=m[keep]
          q_=get('q_', envir=test.env)
          nu=builder[[2]]
          if(BW){

            LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
          }
          if(!BW){

            LH=LH-sum(log(A)*Big_Xi[[chr]])
          }




          LH=LH+a


        }

        return(LH)
      }


      if(max(c(ER,SB,SF))<2){


        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }

        if(SF==1){
          param=c(param,oldsigma)
        }

        if(SB==1){
          param=c(param,oldbeta)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0


        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+(Klink*NC))]
          start_position=start_position+(Klink*NC)
          if(ER==1){
            for(rr in 1:NC){
              oldrho[[rr]]=rho[(1+((rr-1)*Klink)):(rr*Klink)]
            }
          }
        }

        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldsigma=sigma_
        }

        if(SB==1){
          beta_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldbeta=beta_
        }


        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }
      }else{


        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }
        if(ER==3){
          param=c(param,Boxr_s)

        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SF==3){
          param=c(param,Boxs_s)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(SB==3){
          param=c(param,BoxB_s)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }

        LH_temp=0

        if(ER==2){
          for(t_r in 1:(1+Klink)){
            test.env$t_r <- t_r
            if(SB==2){
              for( t_b in 1:(1+Klink)){
                test.env$t_b <- t_b
                if(SF==2){

                  for(t_s in 1:(1+Klink)){
                    test.env$t_s <- t_s

                    sol_temp=function_to_minimize(param)
                    if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                      LH_temp=as.numeric(sol_temp)
                      oldtr=t_r
                      oldtb=t_b
                      oldts=t_s

                    }

                  }

                }else{
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldtb=t_b

                  }
                }
              }

            }else{ # NO  SB
              if(SF==2){
                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtr=t_r
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldtr=t_r

                }
              }
            }
          }
        }else{ # No ER
          if(SB==2){
            for( t_b in 1:(1+Klink)){
              test.env$t_b <- t_b
              if(SF==2){

                for(t_s in 1:(1+Klink)){
                  test.env$t_s <- t_s
                  sol_temp=function_to_minimize(param)
                  if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                    LH_temp=as.numeric(sol_temp)
                    oldtb=t_b
                    oldts=t_s

                  }
                }
              }else{
                sol_temp=function_to_minimize(param)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldtb=t_b

                }
              }
            }
          }else{
            if(SF==2){

              for(t_s in 1:(1+Klink)){
                test.env$t_s <- t_s
                sol_temp=function_to_minimize(param)
                print(sol_temp)
                if(LH_temp>as.numeric(sol_temp)|LH_temp==0){

                  LH_temp=as.numeric(sol_temp)
                  oldts=t_s


                }
              }
            }else{

              stop("How did you get here ?")

            }
          }
        }

        if(ER==2){
          test.env$t_r <- oldtr

          if(oldtr>Klink){
            oldrho=rep(Boxr_s[1],(Klink))
          }else{
            if(oldtr>1){
              oldrho=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
            }else{
              oldrho=rep(Boxr_s[2],(Klink))
            }
          }


        }


        if(SF==2){

          test.env$t_s <- oldts
          if(oldts>Klink){
            oldsigma=rep(Boxs_s[1],(Klink))
          }else{
            if(oldts>1){
              oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
            }else{
              oldsigma=rep(Boxs_s[2],(Klink))
            }
          }


        }


        if(SB==2){


          test.env$t_b <- oldtb

          if(oldtb>Klink){
            oldbeta=rep(BoxB_s[1],(Klink))
          }else{
            if(oldtb>1){
              oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
            }else{
              oldbeta=rep(BoxB_s[2],(Klink))
            }
          }


        }



        param=c()
        if(ER==1){
          for(rr in 1:NC){
            param=c(param,oldrho[[rr]])
          }
        }
        if(ER==3){
          param=c(param,Boxr_s)

        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SF==3){
          param=c(param,Boxs_s)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(SB==3){
          param=c(param,BoxB_s)
        }

        if(!Popfix){
          param=c(param,oldXi_)
        }


        if(length(param)>0){

          sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=10+length(param),M=c(20)))
          sol=as.matrix(sol[[1]])
          start_position=0
          sol=as.numeric(sol[1:length(param),1])
          if(ER==1){
            rho=sol[(start_position+1):(start_position+(Klink*NC))]
            start_position=start_position+(Klink*NC)
            if(ER==1){
              for(rr in 1:NC){
                oldrho[[rr]]=rho[(1+((rr-1)*Klink)):(rr*Klink)]
              }
            }
          }
          if(ER==3){

            Boxr_s=sol[(start_position+1):(start_position+2)]
            test.env$Boxr_s <- Boxr_s
            start_position=start_position+2
            for(rr in 1:NC){
              if(oldtr>Klink){
                oldrho[[rr]]=rep(Boxr_s[1],(Klink))
              }else{
                if(oldtr>1){
                  oldrho[[rr]]=c(rep(Boxr_s[1],(oldtr-1)),rep(Boxr_s[2],(Klink+1-oldtr)))
                }else{
                  oldrho[[rr]]=rep(Boxr_s[2],(Klink))
                }
              }
            }

          }
          if(SF==1){
            sigma_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldsigma=sigma_
          }
          if(SF==3){
            Boxs_s=sol[(start_position+1):(start_position+2)]
            test.env$Boxs_s <- Boxs_s
            start_position=start_position+2
            if(oldts>Klink){
              oldsigma=rep(Boxs_s[1],(Klink))
            }else{
              if(oldts>1){
                oldsigma=c(rep(Boxs_s[1],(oldts-1)),rep(Boxs_s[2],(Klink+1-oldts)))
              }else{
                oldsigma=rep(Boxs_s[2],(Klink))
              }
            }
          }
          if(SB==1){
            beta_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldbeta=beta_
          }
          if(SB==3){
            BoxB_s=sol[(start_position+1):(start_position+2)]
            test.env$BoxB_s <- BoxB_s
            start_position=start_position+2
            if(oldtb>Klink){
              oldbeta=rep(BoxB_s[1],(Klink))
            }else{
              if(oldtb>1){
                oldbeta=c(rep(BoxB_s[1],(oldtb-1)),rep(BoxB_s[2],(Klink+1-oldtb)))
              }else{
                oldbeta=rep(BoxB_s[2],(Klink))
              }
            }
          }

          if(!Popfix){
            Xi_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldXi_=Xi_
          }

        }

      }

    }
  }


  if(SB>0){
    if(SB<3){
      beta_=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2#
    }else{
      if(oldtb==1){
        beta_=((oldbeta*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2#
      }else{
        if(oldtb>Klink){
          beta_=((oldbeta*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2#^2
        }else{
          beta_= c( ((oldbeta[1:(oldtb-1)]*(BoxB_1[2]-BoxB_1[1]))+BoxB_1[1] )^2 , ((oldbeta[oldtb:Klink]*(BoxB_2[2]-BoxB_2[1]))+BoxB_2[1] )^2 ) # ^2
        }
      }
    }
    beta=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      beta[x:xx]=beta_[ix]
    }
  }
  if(SF>0){
    if(SF<3){
      sigma_=oldsigma*(Boxs[2]-Boxs[1])
      sigma_=sigma_+Boxs[1]
    }else{
      if(oldts==1){
        sigma_=oldsigma*(Boxs_2[2]-Boxs_2[1])
        sigma_=sigma_+Boxs_2[1]
      }else{
        if(oldts>Klink){
          sigma_=oldsigma*(Boxs_1[2]-Boxs_1[1])
          sigma_=sigma_+Boxs_1[1]
        }else{

          sigma_= c(oldsigma[1:(oldts-1)]*(Boxs_1[2]-Boxs_1[1]) ,oldsigma[oldts:Klink]*(Boxs_2[2]-Boxs_2[1]) )
          sigma_= c( (sigma_[1:(oldts-1)]+Boxs_1[1]) , (sigma_[oldts:Klink]+Boxs_2[1]))
        }
      }
    }
    sigma=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      sigma[x:xx]= sigma_[ix]
    }
  }
  if(NC==1){
    if(ER>0){
      if(ER<3){
        rho_=oldrho*sum(Boxr)
        rho_=rho_-(Boxr[1])
        rho_=10^(rho_)
        rho_=rho_*Rho
        rho=vector()
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          rho[x:xx]=rho_[ix]/(2*L)
        }
      }else{
        if(oldtr==1){

          rho_=oldrho*sum(Boxr_2)
          rho_=rho_-(Boxr_2[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
        }else{
          if(oldtr>Klink){
            rho_=oldrho*sum(Boxr_1)
            rho_=rho_-(Boxr_1[1])
            rho_=10^(rho_)
            rho_=rho_*Rho
          }else{
            rho_=c(oldrho[1:(oldtr-1)]*sum(Boxr_1),oldrho[oldtr:Klink]*sum(Boxr_2))
            rho_=c(rho_[1:(oldtr-1)]-(Boxr_1[1]),rho_[oldtr:Klink]-(Boxr_2[1]))
            rho_=10^(rho_)
            rho_=rho_*Rho
          }
        }
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          rho[x:xx]=rho_[ix]/(2*L)
        }
      }
    }else{
      rho=Rho
      rho_=Rho
    }
  }
  if(NC>1){
    rho_=list()
    rho=list()
    for(chr in 1:NC){
      if(ER>0){
        if(ER<3){
          rho_[[chr]]=oldrho[[chr]]*sum(Boxr)
          rho_[[chr]]=rho_[[chr]]-(Boxr[1])
          rho_[[chr]]=10^(rho_[[chr]])
          rho_[[chr]]=rho_[[chr]]*Rho
          rho[[chr]]=vector()
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho[[chr]][x:xx]=rho_[[chr]][ix]/(2*L)
          }
        }else{
          if(oldtr==1){

            rho_[[chr]]=oldrho[[chr]]*sum(Boxr_2)
            rho_[[chr]]=rho_[[chr]]-(Boxr_2[1])
            rho_[[chr]]=10^(rho_[[chr]])
            rho_[[chr]]=rho_[[chr]]*Rho[chr]
          }else{
            if(oldtr>Klink){
              rho_[[chr]]=oldrho[[chr]]*sum(Boxr_1)
              rho_[[chr]]=rho_[[chr]]-(Boxr_1[1])
              rho_[[chr]]=10^(rho_[[chr]])
              rho_[[chr]]=rho_[[chr]]*Rho[chr]
            }else{
              rho_[[chr]]=c(oldrho[[chr]][1:(oldtr-1)]*sum(Boxr_1),oldrho[[chr]][oldtr:Klink]*sum(Boxr_2))
              rho_[[chr]]=c(rho_[[chr]][1:(oldtr-1)]-(Boxr_1[1]),rho_[[chr]][oldtr:Klink]-(Boxr_2[1]))
              rho_[[chr]]=10^(rho_[[chr]])
              rho_[[chr]]=rho_[[chr]]*Rho[chr]
            }
          }
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            rho[[chr]][x:xx]=rho_[[chr]][ix]/(2*L)
          }
        }


      }else{
        rho[[chr]]=Rho[chr]
        rho_[[chr]]=Rho[chr]
      }
    }
  }

  res<-list()
  res$beta=beta
  res$sigma=sigma


  if(Pop){
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
    res$Xi=Xi_
  }else{
    res$Xi=rep(1,n)
  }
  Beta=get('Beta', envir=test.env)
  Self=get('Self', envir=test.env)
  res$rho=rho
  res$Tc=Tc
  res$mu=mu
  res$N=N
  return(res)
}
