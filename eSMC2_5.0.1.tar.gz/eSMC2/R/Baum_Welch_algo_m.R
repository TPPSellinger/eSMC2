#' Runs the baum-welch algorithm to estimate demographic history, germination , self-fertilization  and recombinationn rate in presence of methylation
#'
#' @param Os : list containing the signal of all analysis
#' @param maxIt : number of expectation and maximization iteration
#' @param L : Sequence length
#' @param mu : estimated mutation rate given prior
#' @param theta_W : average theta waterson per chromosome
#' @param Rho : vector of estimated recombination rate per sequence
#' @param Ne : Estimated effective population size
#' @param beta : germination rate
#' @param Popfix : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param k : number of hidden states
#' @param BoxB : vector of  size two which are bounderies of germination rate
#' @param BoxP : vector of  size two which are bounderies of population size. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param Boxr :  vector of  size two which are bounderies of recombination rate. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param maxBit :  number of run of the  baum-welch algorithm (each time using as prior result from precedent run)
#' @param pop_vect :  vector of hidden states sharing population size parameter (sum must be equal to k).
#' @param window_scaling : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param sigma : self-fertilization rate
#' @param SF : True to estimate Self-fertilization rate
#' @param Boxs : vector of  size two which are bounderies of self-fertilization rate
#' @param ER : True to estimation recombination rate
#' @param BW : True to run complete baum-welch implementation
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param redo_R : True to reestimation recombination rate if no convergence reached
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param SCALED : TRUE to scale estimated matrices
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param methylation : vector of size two of methylation and demethylation rate in -log10 scale
#' @param BoxM : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param BoxU : vector of size two which are bounderies of demethylation rates.  First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param scale_meth : numeric value corresponding to the expected probability to have methylation information at a position
#' @param nb_methylation_context : number of different methylation context
#' @param LH_opt : TRUE to directly maximize the likelihood (can be very slow)
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param region_methylation : vector of size two, respectively containing the absolute values of methylation and demethylation rates at the region level in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @return List containing of all model parameters and estimations
Baum_Welch_algo_m<-function(Os, maxIt =20,L,mu,theta_W,Rho,Ne,beta=1,Popfix=T,SB=F,k=20,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),maxBit=1,pop_vect=NA,window_scaling=c(1,0),sigma=0.00,SF=F,Boxs=c(0,0.97),ER=F,BW=F,NC=1,redo_R=F,mu_b=1,SCALED=F,Big_Window=F,methylation=c(3,4),BoxM=c(1,1),BoxU=c(1,1),scale_meth,nb_methylation_context=1,LH_opt=F,Region,region_methylation){
  Xi=NA
  FS=F
  EM=F
  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  Ne_o=Ne
  Pop=Popfix
  theta=as.numeric(0.75-0.75*exp(-mu*2))*L
  gamma=as.numeric(Rho)/theta
  gamma_o=gamma
  print('rho/theta:')
  print(gamma)
  test.env <- new.env()
  test.env$L <- L
  test.env$Ne <- Ne
  test.env$k <- k
  test.env$mu <- mu
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$BW<-BW
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$mu_b <- mu_b
  test.env$Big_Window <- Big_Window
  test.env$methylation <- methylation
  if(NC>1){
    npair=NC
    test.env$npair <- NC
  }
  if(NC==1){
    npair=1
    test.env$npair <- npair
  }
  mb=0
  if(SB){
    BoxB[1]=max(sqrt(0.01),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
    beta=max((BoxB[1]^2),beta)
    beta=min(beta,(BoxB[2]^2))
    Beta=beta
  }
  if(SF){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Self=sigma
  }
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=k)){
    Klink=0.5*k
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(!SB&!SF){
    maxBit=1
  }
  if(!SB){
    Beta=beta
    test.env$beta <- beta
  }
  if(!SF){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
  }
  if(!ER){
    Boxr=c(0,0)
  }
  if(!EM){
    BoxU=c(0,0)
    BoxM=c(0,0)
    if(nb_methylation_context>1){
      BoxU=matrix(0,nb_methylation_context,2)
      BoxM=matrix(0,nb_methylation_context,2)
    }
  }


    while(mb<maxBit){
      print(paste("Beta:",Beta))
      print(paste("Self:",Self))
      test.env$Beta <- Beta
      test.env$Self <- Self
      test.env$BoxB <- BoxB
      test.env$Boxs <- Boxs
      test.env$BoxM <- BoxM
      test.env$BoxU <- BoxU
      mb=mb+1
      diff=1
      it <- 0
      if(mb==1){
        if(SB){
          oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
        }
        if(SF){
          oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
        }

      }
      if(mb>1){
        if(SB){
          beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
        }
        if(SF){
          sigma=oldsigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
        }
        if(!Popfix){
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            oldXi[x:xx]=oldXi_[ix]
          }
          Xi_=oldXi*sum(BoxP)
          Xi_=Xi_-(BoxP[1])
          Xi_=10^Xi_
        }

        if(NC==1){
          theta=(((theta_W*(beta^2)))*2/((2-sigma)*(beta+((1-beta)*mu_b))))
          # mu=theta/(2*L)
          mu=(-(log((1-(theta/(L*0.75))))/2))
          Rho=gamma*theta
        }
        if(NC>1){
          theta=(((theta_W*(beta^2)))*2/((2-sigma)*(beta+((1-beta)*mu_b))))
          mu=(-(log((1-(theta/(L*0.75))))/2))
          Rho=gamma*theta
        }

        test.env$mu <- mu
        test.env$Rho <- Rho
      }
      if(!ER){
        oldrho=0
        if(length(unique(round(gamma,digits=3)))>1){
          oldrho=rep(0,NC)
        }

      }
      if(ER){
        oldrho=(Boxr[1]/sum(Boxr))
        if(length(unique(round(gamma,digits=3)))>1){
          oldrho=rep((Boxr[1]/sum(Boxr)),NC)
        }

      }
      if(!EM){
        if(nb_methylation_context==1){
          oldU=0
          oldM=0
        }else{
          oldU=rep(0,nb_methylation_context)
          oldM=rep(0,nb_methylation_context)

        }
      }
      if(EM){
        if(nb_methylation_context==1){
          oldU=(BoxU[1]/sum(BoxU))
          oldM=(BoxM[1]/sum(BoxM))
        }else{
          oldU=rep(0,nb_methylation_context)
          oldM=rep(0,nb_methylation_context)
          oldU[1]=(BoxU[1,1]/sum(BoxU[1,]))
          oldM[1]=(BoxM[1,1]/sum(BoxM[1,]))

          oldU[2]=(BoxU[2,1]/sum(BoxU[2,]))
          oldM[2]=(BoxM[2,1]/sum(BoxM[2,]))
        }

      }
      #print(length(oldrho))
      if(!Popfix){
      oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
      oldXi=vector()
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      }
      if(!LH_opt){
      Do_BW=T
      diff_conv=vector()
      while (it<maxIt){
        start_time <- Sys.time()
        if(!Do_BW){
          it=0
          oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
          oldXi=vector()
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            oldXi[x:xx]=oldXi_[ix]
          }
        }
        it <- it+1;
        print(paste("It:",it))
        if(Popfix){
          rho_=oldrho*sum(Boxr)
          rho_=rho_-(Boxr[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
          if(SB){
            beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          }
          if(SF){
            sigma=oldsigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
          }
          print(c("sigma:",sigma,"beta :",beta))
          print(c("rho/theta:",rho_/theta))
          Keep_going=F
          if(it==1){
            diff_o=0
          }
          if(it>1){
            gamma_temp=mean(rho_/theta)
            diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta),abs(gamma_temp_o-gamma_temp))
            count_diff_o=0
            if(diff_o>=0.005){
              if(it==maxIt){
                count_diff_o=count_diff_o+1
                maxIt=maxIt+1
              }
            }
          }
          sigma_o=sigma
          beta_o=beta
          gamma_temp_o=mean(rho_/theta)
          if(NC==1){
            builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
          if(NC>1){
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
          }
        }
        if(!Popfix){
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            oldXi[x:xx]=oldXi_[ix]
          }
          Xi_=oldXi*sum(BoxP)
          Xi_=Xi_-(BoxP[1])
          Xi_=10^Xi_
          rho_=oldrho*sum(Boxr)
          rho_=rho_-(Boxr[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
          if(SB){
            beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          }
          if(SF){
            sigma=oldsigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
          }
          print(c("sigma:",sigma,"beta :",beta))
          print(c("rho/theta:",rho_/theta))
          Keep_going=F
          if(it==1){
            diff_o=0
          }
          if(it>1){
            diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta))
            count_diff_o=0
            if(diff_o>=0.005){
              if(it==maxIt){
                count_diff_o=count_diff_o+1
                maxIt=maxIt+1
              }
            }
          }
          sigma_o=sigma
          beta_o=beta

          if(NC==1){
            builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
          if(NC>1){
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
          }
        }



        if(NC==1){
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]

          if(Region>0){
                      g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
          }else{

            if(nb_methylation_context==1){





            M_=oldM*sum(BoxM)
            M_=M_-(BoxM[1])
            M_=methylation[1]*10^-(M_)
            U_=oldU*sum(BoxU)
            U_=U_-(BoxU[1])
            U_=methylation[2]*10^-(U_)

            mu_m=c(M_,U_)
            g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)


          }else{

            M_=oldM[1]*sum(BoxM[1,])
            M_=M_-(BoxM[1,1])
            M_=methylation[1,1]*10^-(M_)
            U_=oldU[1]*sum(BoxU[1,])
            U_=U_-(BoxU[1])
            U_=methylation[1,2]*10^-(U_)
            U_=U_
            mu_m=c(M_,U_)



            M_=oldM[2]*sum(BoxM[2,])
            M_=M_-(BoxM[2,1])
            M_=methylation[2,1]*10^-(M_)
            U_=oldU[2]*sum(BoxU[2,])
            U_=U_-(BoxU[2])
            U_=methylation[2,2]*10^-(U_)
            U_=U_
            mu_m=rbind(mu_m,c(M_,U_))
            g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
          }
          }




          M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
          N=matrix(0,length(Tc),length(Tc))
          MLH=0
          q_=rep(0,length(Tc))
          #s_t=Sys.time()
          test=Build_zip_Matrix_mailund_m(Q,g,Os[[1]][[2]],nu)
          #e_t=Sys.time()
          #print("Time to build Zip matrices")
          #print(e_t-s_t)
          s_t=Sys.time()
          for(i in 1:length(Os)){

            if(F){
              s_t_temp=Sys.time()
              fo=forward_zip_mailund_m(as.numeric(Os[[i]][[1]]),g,nu,test[[1]])
              e_t_temp=Sys.time()
              print("Time forward algo")
              print(e_t_temp-s_t_temp)
            }
            #s_t_temp=Sys.time()
            fo_cpp=forward_cpp_m(as.numeric(Os[[i]][[1]]),g,nu,test[[6]])
            #e_t_temp=Sys.time()
            #print("Time forward cpp algo")
            #print(e_t_temp-s_t_temp)
            MLH=MLH+fo_cpp[[3]]
            c=exp(fo_cpp[[2]])
            #s_t_temp=Sys.time()
            ba=Backward_zip_mailund_m(as.numeric(Os[[i]][[1]]),test[[3]],length(Tc),c)
            #e_t_temp=Sys.time()
            #print("Time backward algo")
            #print(e_t_temp-s_t_temp)
            if(F){
              s_t_temp=Sys.time()
              ba_cpp=backward_cpp_m(as.numeric(Os[[i]][[1]]),test[[7]],length(Tc),c)
              e_t_temp=Sys.time()
              print("Time backward cpp algo")
              print(e_t_temp-s_t_temp)
            }
            #browser()
            W_P=list()
            W_P_=list()
            #s_t_temp=Sys.time()
            for(oo in 1:dim(g)[2]){
              int=t(Q)%*%diag(g[,oo])
              int=eigen(int)
              W_P[[oo]]=int$vectors
              W_P_[[oo]]=solve(W_P[[oo]])
            }
            symbol=c(0:(dim(g)[2]-1),as.numeric(Os[[i]][[2]][[1]][,1]))
            for(ob in 1){
              truc_M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
              if(as.numeric(Os[[i]][[1]][(ob+1)])<10){
                truc_N=(fo_cpp[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                truc_M[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]=fo_cpp[[1]][,ob]*(test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
              }else{
                truc_N=(t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%fo_cpp[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))%*%diag(g[,(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]))
                truc_M[,(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]=diag(t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%fo_cpp[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))
              }
              N=N+truc_N
              M=M+truc_M
            }
            for(sym in sort(symbol)){
              ob=as.numeric(sym)
              pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
              if(length(pos)>0){
                pos=pos+1
                #print("expected L:")
                #print(Os[[3]][which(Os[[3]][,1]==sym),2]*length(pos))
                #print("ob:")
                #print(ob)
                if(ob<10){
                  # print("expected L:")
                  #  print(length(pos))
                  ba_t=t(t(ba[,(pos)])/c[(pos)])
                  truc=c(rowSums(fo_cpp[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                  truc=(truc/(sum(truc)))*length(pos)
                  M[,(ob+1)]=M[,(ob+1)]+ truc
                  truc_N=(fo_cpp[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                  # print("calculated L:")
                  #  print(sum(truc_N*t(Q)))
                  N=N+truc_N
                }else{
                  A=(t(W_P[[(floor(log10(((ob)))))]])%*%fo_cpp[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[(floor(log10(((ob)))))]]))
                  A_=A*test[[2]][[(ob)]]
                  A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                  M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10(((ob)))))]+(diag(A_))
                  A_=A*test[[4]][[(ob)]]
                  A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                  truc_N=((A_%*%diag(g[,(floor(log10(((ob)))))])))
                  #print("calculated L:")
                  #print(sum(truc_N*t(Q)))
                  N=N+truc_N
                }
              }
            }

            if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<10){
              M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]=M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]+(fo_cpp[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
            }
            if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])>9){
              M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10((as.numeric((ob))))))]+((fo_cpp[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo_cpp[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
            }
            q_=q_+((fo_cpp[[1]][,1]*ba[,(1)])/sum(fo_cpp[[1]][,1]*ba[,(1)]))
            #e_t_temp=Sys.time()
            #print("Time BW algo")
            #print(e_t_temp-s_t_temp)
          }
          e_t=Sys.time()
          print("Time to do a complete Baum-Welch")
          print(e_t-s_t)
          #rm(Os[[i]])
          N=N*t(Q)

          if(is.complex(N)){
            N=Re(N)
          }

          if(is.complex(M)){
            M=Re(M)
          }
          print("Initial:N")
          print(sum(N))
          Scale_N=(L-1)/sum(N)
          N=N*Scale_N
          print("Corrected:N")
          print(sum(N))
          q_=q_/sum(q_)
          print("Initial:M")
          print(sum(M))
          Scale_M=L/sum(M)
          M=M*Scale_M
          print("Corrected:M")
          print(sum(M))

          if(SCALED){
            corrector_N=rowSums(N)
            N=diag(1/corrector_N)%*%N
            corrector_M=rowSums(M)
            M=diag(1/corrector_M)%*%M
          }
        }
        if(NC>1){
          Q=list()
          nu=list()
          Tc=list()
          g=list()
          M=list()
          N=list()
          MLH=list()
          q_=list()
          for(chr in 1:NC){
            Q[[chr]] = builder[[chr]][[1]]
            nu[[chr]] = builder[[chr]][[2]]
            Tc[[chr]]=builder[[chr]][[3]]


            if(Region>0){
              g_=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
            }else{
              if(nb_methylation_context==1){
              g_=matrix(0,nrow=length(Tc[[chr]]),ncol=6)
              M_=oldM*sum(BoxM)
              M_=M_-(BoxM[1])
              M_=methylation[[chr]][1]*10^-(M_)
              U_=oldU*sum(BoxU)
              U_=U_-(BoxU[1])
              U_=methylation[[chr]][2]*10^-(U_)
              U_=U_
              mu_m=c(M_,U_)

              g_=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

            }else{
              g_=matrix(0,nrow=length(Tc[[chr]]),ncol=9)
              M_=oldM*sum(BoxM[1,])
              M_=M_-(BoxM[1,1])
              M_=methylation[[chr]][1,1]*10^-(M_)
              U_=oldU*sum(BoxU[1,])
              U_=U_-(BoxU[1,1])
              U_=methylation[[chr]][1,2]*10^-(U_)
              U_=U_
              mu_m=c(M_,U_)


              M_=oldM[2]*sum(BoxM[2,])
              M_=M_-(BoxM[2,1])
              M_=methylation[[chr]][2,1]*10^-(M_)
              U_=oldU[2]*sum(BoxU[2,])
              U_=U_-(BoxU[2])
              U_=methylation[[chr]][2,2]*10^-(U_)
              U_=U_
              mu_m=rbind(mu_m,c(M_,U_))
              g_=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
            }
            }



            g[[chr]]=g_
            M[[chr]]=matrix(0,nrow=length(Tc[[chr]]),ncol=dim(g_)[2])
            N[[chr]]=matrix(0,length(Tc[[chr]]),length(Tc[[chr]]))
            MLH[[chr]]=0
            q_[[chr]]=rep(0,length(Tc[[chr]]))
            test=Build_zip_Matrix_mailund_m(Q[[chr]],g[[chr]],Os[[1]][[1]][[2]],nu[[chr]])
            for(i in 1:length(Os[[chr]])){
              #fo=forward_zip_mailund_m(Os[[chr]][[i]][[1]],g[[chr]],nu[[chr]],test[[1]])
              fo=forward_cpp_m(as.numeric(Os[[chr]][[i]][[1]]),g[[chr]],nu[[chr]],test[[6]])
              MLH[[chr]]=MLH[[chr]]+fo[[3]]
              c=exp(fo[[2]])
              ba=Backward_zip_mailund_m(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
              W_P=list()
              W_P_=list()
              for(oo in 1:dim(g_)[2]){
                int=t(Q[[chr]])%*%diag(g[[chr]][,oo])
                int=eigen(int)
                W_P[[oo]]=int$vectors
                W_P_[[oo]]=solve(W_P[[oo]])
              }
              symbol=c(0:(dim(g_)[2]-1),as.numeric(Os[[chr]][[i]][[2]][[1]][,1]))
              for(ob in 1){
                truc_M=matrix(0,nrow=length(Tc[[chr]]),ncol=dim(g_)[2])
                if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<10){
                  truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                  truc_M[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
                }else{
                  truc_N=(t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]]))%*%diag(g[[chr]][,(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]))
                  truc_M[,(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]=diag(t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]]))
                }
                N[[chr]]=N[[chr]]+truc_N
                M[[chr]]=M[[chr]]+truc_M
              }
              for(sym in symbol){
                ob=as.numeric(sym)
                pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
                if(length(pos)>0){
                  pos=pos+1
                  if(ob<10){
                    ba_t=t(t(ba[,(pos)])/c[(pos)])
                    truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                    truc=(truc/(sum(truc)))*length(pos)
                    M[[chr]][,(ob+1)]=M[[chr]][,(ob+1)]+ truc
                    N[[chr]]=N[[chr]]+(fo[[1]][,(pos-1)]%*%(t(diag(g[[chr]][,(ob+1)])%*%ba_t)))
                  }else{
                    A=(t(W_P[[(floor(log10(((ob)))))]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[(floor(log10(((ob)))))]]))
                    A_=A*test[[2]][[(ob)]]
                    A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                    M[[chr]][,(floor(log10((as.numeric((ob))))))]=M[[chr]][,(floor(log10(((ob)))))]+(diag(A_))
                    A_=A*test[[4]][[(ob)]]
                    A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                    N[[chr]]=N[[chr]]+((A_%*%diag(g[[chr]][,(floor(log10(((ob)))))])))
                  }
                }
              }
              if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<10){
                M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]=M[[chr]][,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]+(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])
              }
              if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])>9){
                M[[chr]][,(floor(log10((as.numeric((ob))))))]=M[[chr]][,(floor(log10((as.numeric((ob))))))]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))
              }
              q_[[chr]]=q_[[chr]]+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
            }

            N[[chr]]=N[[chr]]*t(Q[[chr]])
            if(is.complex(N[[chr]])){
              N[[chr]]=Re(N[[chr]])
            }

            if(is.complex(M[[chr]])){
              M[[chr]]=Re(M[[chr]])
            }
            Scale_N=(L[chr]-1)/sum(N[[chr]])
            print(sum(N[[chr]]))
            N[[chr]]=N[[chr]]*Scale_N
            print(sum(N[[chr]]))
            Scale_M=L[chr]/sum(M[[chr]])
            print(sum(M[[chr]]))
            M[[chr]]=M[[chr]]*Scale_M
            print(sum(M[[chr]]))
            q_[[chr]]=q_[[chr]]/sum(q_[[chr]])
            if(SCALED){
              corrector_M=rowSums(t(M[[chr]]))
              M[[chr]]=diag(1/corrector_M)%*%M[[chr]]
              corrector_N=rowSums(N[[chr]])
              N[[chr]]=diag(1/corrector_N)%*%N[[chr]]
            }
          }
        }


        if(it>1){
          print(paste(" old Likelihood: ",oldMLH))
        }
        Do_BW=T
        if(NC==1){
          print(paste(" New Likelihood: ",MLH))

          if(it>1){

            if(oldMLH > MLH|MLH=="NaN"){

              if(!Popfix){
                oldXi_=oldXi_s
              }
              if(ER){
                oldrho=oldrho_s
              }
              if(SB){
                oldbeta=oldbeta_s
              }
              if(SF){
                oldsigma=oldsigma_s
              }
              Do_BW=F

            }else{
              Do_BW=T
            }

          }
          oldMLH=MLH
        }
        if(NC>1){
          MLH1=0
          for(chr in 1:length(MLH)){
            MLH1=MLH[[chr]]+MLH1
          }
          print(paste("New Likelihood: ",MLH1))
          if(it>1){
            if(oldMLH > MLH1|MLH1=="NaN"){
              if(it>1){

                if(!Popfix){
                  oldXi_=oldXi_s
                }
                if(ER){
                  oldrho=oldrho_s
                }
                if(SB){
                  oldbeta=oldbeta_s
                }
                if(SF){
                  oldsigma=oldsigma_s
                }
              }
              Do_BW=F
            }else{
              Do_BW=T
            }

          }
          oldMLH=MLH1
        }


        if(NC==1){
          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(M)
          m=m[keep]
          A=as.vector(t(Q))
          keep=which(A>0&as.vector(N)>0)
          A=A[keep]
          Big_Xi=as.vector(N)
          Big_Xi=Big_Xi[keep]
          if(BW){
            LH=Re(sum(log(A)*Big_Xi)+sum(log(x)*m)+sum(log(nu)*q_))
          }
          if(!BW){
            LH=Re(sum(log(A)*Big_Xi))
          }
          print(paste(" old Complete likelihood : ", LH ))
          oldLH=-LH
          test.env$Big_Xi <- N
          test.env$Big_M <-M
          test.env$q_ <-q_
        }
        if(NC>1){
          test.env$Big_Xi <- N
          test.env$Big_M <-M
          test.env$q_ <-q_
        }

        if(!Popfix){
          oldXi_s=oldXi_
        }
        if(ER){
          oldrho_s=oldrho
        }
        if(SB){
          oldbeta_s=oldbeta
        }
        if(SF){
          oldsigma_s=oldsigma
        }
        lr=length(oldrho)
        test.env$lr<-lr
        if(Do_BW){
          if(NC==1){

            if(!EM){ #it==1

              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB




              function_to_minimize<-function(param){
                Boxr=get('Boxr', envir=test.env)
                mu=get('mu', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Big_Xi=get('Big_Xi', envir=test.env)
                start_position=0
                if(ER==1){
                  rho=param[(start_position+1):(start_position+1)]
                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho_=rho*Rho
                  start_position=start_position+1
                }
                if(ER==0){
                  rho_=Rho
                }
                if(SF==1){
                  sigma_=param[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  sigma_=sigma_*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }
                if(SF==0){
                  sigma_=sigma
                }
                if(SB==1){
                  beta_=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+1
                }
                if(SB==0){
                  beta_=beta
                }
                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }

                builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q = builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi)>0)
                A=A[keep]
                Big_Xi=as.vector(Big_Xi)
                Big_Xi=Big_Xi[keep]
                if(BW){
                  nu= builder[[2]]
                  Tc=builder[[3]]
                  Big_M=get('Big_M', envir=test.env)
                  BoxM=get('BoxM', envir=test.env)
                  BoxU=get('BoxU', envir=test.env)
                  methylation=get('methylation', envir=test.env)
                  Ne=get('Ne', envir=test.env)
                  if(Region>0){
                    g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
                  }else{
                    if(nb_methylation_context==1){
                      g_=matrix(0,nrow=length(Tc[[chr]]),ncol=6)
                      M_=oldM*sum(BoxM)
                      M_=M_-(BoxM[1])
                      M_=methylation[1]*10^-(M_)
                      U_=oldU*sum(BoxU)
                      U_=U_-(BoxU[1])
                      U_=methylation[2]*10^-(U_)
                      U_=U_
                      mu_m=c(M_,U_)

                      g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

                    }else{
                      g_=matrix(0,nrow=length(Tc[[chr]]),ncol=9)
                      M_=oldM*sum(BoxM[1,])
                      M_=M_-(BoxM[1,1])
                      M_=methylation[1,1]*10^-(M_)
                      U_=oldU*sum(BoxU[1,])
                      U_=U_-(BoxU[1,1])
                      U_=methylation[1,2]*10^-(U_)
                      U_=U_
                      mu_m=c(M_,U_)


                      M_=oldM[2]*sum(BoxM[2,])
                      M_=M_-(BoxM[2,1])
                      M_=methylation[2,1]*10^-(M_)
                      U_=oldU[2]*sum(BoxU[2,])
                      U_=U_-(BoxU[2])
                      U_=methylation[2,2]*10^-(U_)
                      U_=U_
                      mu_m=rbind(mu_m,c(M_,U_))
                      g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
                    }
                  }
                  x=as.vector(g)
                  keep=which(x>0)
                  x=x[keep]
                  m=as.vector(Big_M)
                  m=m[keep]
                  q_=get('q_', envir=test.env)
                  nu=builder[[2]]

                  LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                }
                if(!BW){
                  LH=-sum(log(A)*Big_Xi)
                }
                return(LH)
              }

              param=c()
              if(ER==1){
                param=c(param,oldrho)
              }

              if(SF==1){
                param=c(param,oldsigma)
              }

              if(SB==1){
                param=c(param,oldbeta)
              }

              if(!Popfix){
                param=c(param,oldXi_)
              }

              if(length(param)>0){
                sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=(length(param)+10),M=c(20)))
                sol=as.matrix(sol[[1]])
                start_position=0
                sol=as.numeric(sol[1:length(param),1])



                if(ER==1){
                  rho=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldrho=rho
                }
                if(SF==1){
                  sigma_=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldsigma=sigma_
                }


                if(SB==1){
                  beta_=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldbeta=beta_
                }


                if(!Popfix){
                  Xi_=sol[(start_position+1):(start_position+Klink)]
                  start_position=start_position+Klink
                  oldXi_=Xi_
                }

              }
            }else{
              stop("To do")
            }


          }
          if(NC>1){

            if(!EM){
              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB




              function_to_minimize<-function(param){
                Boxr=get('Boxr', envir=test.env)
                mu=get('mu', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Big_Xi=get('Big_Xi', envir=test.env)
                lr=get('lr', envir=test.env)
                start_position=0
                if(ER==1){
                  rho=param[(start_position+1):(start_position+lr)]
                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho_=rho*Rho
                  start_position=start_position+lr
                }
                if(ER==0){
                  rho_=Rho
                }
                if(SF==1){
                  sigma_=param[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  sigma_=sigma_*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }
                if(SF==0){
                  sigma_=sigma
                }
                if(SB==1){
                  beta_=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+1
                }
                if(SB==0){
                  beta_=beta
                }
                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }
                LH=0

                for(chr in 1:NC){
                  builder=build_HMM_matrix(n,(rho_[chr]),beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                  Q=builder[[1]]
                  Q=t(Q)
                  A=as.vector(Q)
                  keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                  A=A[keep]
                  Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                  Big_Xi[[chr]]=Big_Xi[[chr]][keep]

                  if(BW){
                    Tc=builder[[3]]
                    BoxM=get('BoxM', envir=test.env)
                    BoxU=get('BoxU', envir=test.env)
                    Big_M=get('Big_M', envir=test.env)
                    methylation=get('methylation', envir=test.env)
                    Ne=get('Ne', envir=test.env)
                    if(Region>0){
                      g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
                    }else{
                      if(nb_methylation_context==1){
                        g_=matrix(0,nrow=length(Tc[[chr]]),ncol=6)
                        M_=oldM*sum(BoxM)
                        M_=M_-(BoxM[1])
                        M_=methylation[[chr]][1]*10^-(M_)
                        U_=oldU*sum(BoxU)
                        U_=U_-(BoxU[1])
                        U_=methylation[[chr]][2]*10^-(U_)
                        U_=U_
                        mu_m=c(M_,U_)

                        g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

                      }else{
                        g_=matrix(0,nrow=length(Tc[[chr]]),ncol=9)
                        M_=oldM*sum(BoxM[1,])
                        M_=M_-(BoxM[1,1])
                        M_=methylation[[chr]][1,1]*10^-(M_)
                        U_=oldU*sum(BoxU[1,])
                        U_=U_-(BoxU[1,1])
                        U_=methylation[[chr]][1,2]*10^-(U_)
                        U_=U_
                        mu_m=c(M_,U_)


                        M_=oldM[2]*sum(BoxM[2,])
                        M_=M_-(BoxM[2,1])
                        M_=methylation[[chr]][2,1]*10^-(M_)
                        U_=oldU[2]*sum(BoxU[2,])
                        U_=U_-(BoxU[2])
                        U_=methylation[[chr]][2,2]*10^-(U_)
                        U_=U_
                        mu_m=rbind(mu_m,c(M_,U_))
                        g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
                      }
                    }
                    x=as.vector(g)
                    keep=which(x>0)
                    x=x[keep]
                    m=as.vector(Big_M[[chr]])
                    m=m[keep]
                    q_=get('q_', envir=test.env)
                    nu=builder[[2]]
                    LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_[[chr]])
                  }
                  if(!BW){
                    LH=LH-sum(log(A)*Big_Xi[[chr]])
                  }
                }

                return(LH)
              }

              param=c()
              if(ER==1){
                param=c(param,oldrho)
              }

              if(SF==1){
                param=c(param,oldsigma)
              }

              if(SB==1){
                param=c(param,oldbeta)
              }

              if(!Popfix){
                param=c(param,oldXi_)
              }

              if(length(param)>0){
                sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=(length(param)+10),M=c(20)))
                sol=as.matrix(sol[[1]])
                start_position=0
                sol=as.numeric(sol[1:length(param),1])



                if(ER==1){
                  rho=sol[(start_position+1):(start_position+lr)]
                  start_position=start_position+lr
                  oldrho=rho
                }
                if(SF==1){
                  sigma_=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldsigma=sigma_
                }


                if(SB==1){
                  beta_=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldbeta=beta_
                }


                if(!Popfix){
                  Xi_=sol[(start_position+1):(start_position+Klink)]
                  start_position=start_position+Klink
                  oldXi_=Xi_
                }

              }



            }else{
              stop("To do")
            }



          }
        }else{
          it=maxIt
        }

        if(diff_o>=0.003){
          diff=(max(diff_o,diff))
        }
        diff_conv=c(diff_conv,diff_o)
        end_time <- Sys.time()
        print(end_time-start_time)
        if(it==maxIt&ER){

          rho_check_s=oldrho_s*sum(Boxr)
          rho_check_s=rho_check_s-(Boxr[1])
          rho_check_s=10^(rho_check_s)
          rho_check_s=rho_check_s*Rho/theta

          rho_check=oldrho*sum(Boxr)
          rho_check=rho_check-(Boxr[1])
          rho_check=10^(rho_check)
          rho_check=rho_check*Rho/theta
          if(any(abs(rho_check_s-rho_check)>0.05)){
            print(rho_check_s)
            print(rho_check)
            print(abs(rho_check_s-rho_check))
            maxIt=maxIt+5
          }
        }
      }
      }else{
        if(NC==1){



          test.env$ER <- ER
          test.env$SF <- SF
          test.env$SB <- SB
          test.env$Os <- Os



          function_to_minimize<-function(param){
            Boxr=get('Boxr', envir=test.env)
            mu=get('mu', envir=test.env)
            npair=get('npair', envir=test.env)
            Big_Window=get('Big_Window', envir=test.env)
            mu_b=get('mu_b', envir=test.env)
            FS=get('FS', envir=test.env)
            Klink=get('Klink', envir=test.env)
            Rho=get('Rho', envir=test.env)
            BoxB=get('BoxB', envir=test.env)
            Boxs=get('Boxs', envir=test.env)
            BoxP=get('BoxP', envir=test.env)
            pop_vect=get('pop_vect', envir=test.env)
            L=get('L', envir=test.env)
            n=get('k', envir=test.env)
            Beta=get('Beta', envir=test.env)
            Self=get('Self', envir=test.env)
            window_scaling=get('window_scaling', envir=test.env)
            Pop=get('Pop', envir=test.env)
            ER=get('ER', envir=test.env)
            SF=get('SF', envir=test.env)
            SB=get('SB', envir=test.env)
            Os=get('Os', envir=test.env)
            start_position=0
            if(ER==1){
              rho=param[(start_position+1):(start_position+1)]
              rho=rho*sum(Boxr)
              rho=rho-(Boxr[1])
              rho=10^(rho)
              rho_=rho*Rho
              start_position=start_position+1

            }
            if(ER==0){
              rho_=Rho
            }
            if(SF==1){
              sigma_=numeric(n)
              sigma=param[(start_position+1):(start_position+1)]
              start_position=start_position+1
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma_=sigma+Boxs[1]
            }
            if(SF==0){
              sigma_=sigma
            }
            if(SB==1){
              beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              start_position=start_position+1
              beta_=beta
            }
            if(SB==0){
              beta_=beta
            }
            if(!Pop){
              Xi=numeric(n)
              Xi_=param[(start_position+1):(start_position+Klink)]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
            }else{
              Xi=rep(1,n)
            }
            builder=build_HMM_matrix(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
            Q = builder[[1]]
            nu= builder[[2]]
            Tc=builder[[3]]
            if(Region>0){
              g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
            }else{
              if(nb_methylation_context==1){
                g_=matrix(0,nrow=length(Tc[[chr]]),ncol=6)
                M_=oldM*sum(BoxM)
                M_=M_-(BoxM[1])
                M_=methylation[1]*10^-(M_)
                U_=oldU*sum(BoxU)
                U_=U_-(BoxU[1])
                U_=methylation[2]*10^-(U_)
                U_=U_
                mu_m=c(M_,U_)

                g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

              }else{
                g_=matrix(0,nrow=length(Tc[[chr]]),ncol=9)
                M_=oldM*sum(BoxM[1,])
                M_=M_-(BoxM[1,1])
                M_=methylation[1,1]*10^-(M_)
                U_=oldU*sum(BoxU[1,])
                U_=U_-(BoxU[1,1])
                U_=methylation[1,2]*10^-(U_)
                U_=U_
                mu_m=c(M_,U_)


                M_=oldM[2]*sum(BoxM[2,])
                M_=M_-(BoxM[2,1])
                M_=methylation[2,1]*10^-(M_)
                U_=oldU[2]*sum(BoxU[2,])
                U_=U_-(BoxU[2])
                U_=methylation[2,2]*10^-(U_)
                U_=U_
                mu_m=rbind(mu_m,c(M_,U_))
                g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
              }
            }

            MLH=0
            test=Build_zip_Matrix_LH_mailund(Q,g,Os[[1]][[2]],nu)
            C_test=rep(0,n)
            for(c_test in 1:length(test[[1]])){
              C_test=rbind(C_test,(test[[1]][[c_test]]))
            }
            C_test=C_test[-1,]
            for(i in 1:length(Os)){
              LH_cpp=forward_cpp(as.integer(Os[[i]][[1]]),g,nu,C_test)
              MLH=MLH-LH_cpp
            }
            return(MLH)
          }



          param=c()
          if(ER==1){
            param=c(param,oldrho)

          }
          if(SF==1){
            param=c(param,oldsigma)
          }
          if(SB==1){
            param=c(param,oldbeta)
          }
          if(!Popfix){
            param=c(param,oldXi_)
          }

          sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=50+length(param),M=c(20)))
          LH=as.numeric(as.matrix(sol[[2]]))
          sol=as.matrix(sol[[1]])
          start_position=0


          sol=as.numeric(sol[1:length(param),1])
          if(ER==1){
            rho=sol[(start_position+1):(start_position+1)]
            start_position=start_position+1
            oldrho=rho
          }
          if(SF==1){
            sigma_=sol[(start_position+1):(start_position+1)]
            start_position=start_position+1
            oldsigma=sigma_
          }
          if(SB==1){
            beta_=sol[(start_position+1):(start_position+1)]
            start_position=start_position+1
            oldbeta=beta_
          }
          if(!Popfix){
            Xi_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldXi_=Xi_
          }







        }


        if(NC>1){

          test.env$ER <- ER
          test.env$SF <- SF
          test.env$SB <- SB
          test.env$Os <- Os



          function_to_minimize<-function(param){
            Boxr=get('Boxr', envir=test.env)
            mu=get('mu', envir=test.env)
            npair=get('npair', envir=test.env)
            Big_Window=get('Big_Window', envir=test.env)
            mu_b=get('mu_b', envir=test.env)
            FS=get('FS', envir=test.env)
            Klink=get('Klink', envir=test.env)
            Rho=get('Rho', envir=test.env)
            BoxB=get('BoxB', envir=test.env)
            Boxs=get('Boxs', envir=test.env)
            BoxP=get('BoxP', envir=test.env)
            pop_vect=get('pop_vect', envir=test.env)
            L=get('L', envir=test.env)
            n=get('k', envir=test.env)
            Beta=get('Beta', envir=test.env)
            Self=get('Self', envir=test.env)
            window_scaling=get('window_scaling', envir=test.env)
            Pop=get('Pop', envir=test.env)
            ER=get('ER', envir=test.env)
            SF=get('SF', envir=test.env)
            SB=get('SB', envir=test.env)
            Os=get('Os', envir=test.env)
            NC=get('NC', envir=test.env)
            start_position=0
            if(ER==1){
              rho=list()
              rho_=list()
              oldrho_param=param[(start_position+1):(start_position+(NC))]
              for(rr in 1:NC){
                rho[[rr]]= oldrho_param[(1+((rr-1))):(rr)]*sum(Boxr)
                rho[[rr]]=rho[[rr]]-(Boxr[1])
                rho[[rr]]=10^(rho[[rr]])
                rho_[[rr]]=rho[[rr]]*Rho[rr]
              }
              start_position=start_position+(NC)
            }


            if(ER==0){
              rho_=list()
              for(rr in 1:NC){
                rho_[[rr]]=Rho[rr]
              }
            }
            if(SF==1){
              sigma=param[(start_position+1):(start_position+1)]
              start_position=start_position+1
              sigma=sigma*(Boxs[2]-Boxs[1])
              sigma_=sigma+Boxs[1]
            }

            if(SF==0){
              sigma_=sigma
            }
            if(SB==1){
              beta_=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
              start_position=start_position+1
            }

            if(SB==0){
              beta_=beta
            }
            if(!Pop){
              Xi=numeric(n)
              Xi_=param[(start_position+1):(start_position+Klink)]
              xx=0
              for(ix in 1:Klink){
                x=xx+1
                xx = xx + pop_vect[ix]
                Xi[x:xx]=Xi_[ix]
              }
              Xi=Xi*sum(BoxP)
              Xi=Xi-(BoxP[1])
              Xi=10^Xi
            }else{
              Xi=rep(1,n)
            }
            MLH=0
            for(chr in 1:NC){

              builder=build_HMM_matrix(n,(rho_[[chr]]),beta=beta_,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
              Q = builder[[1]]
              nu= builder[[2]]
              Tc=builder[[3]]
              if(Region>0){
                g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
              }else{
                if(nb_methylation_context==1){
                  g_=matrix(0,nrow=length(Tc[[chr]]),ncol=6)
                  M_=oldM*sum(BoxM)
                  M_=M_-(BoxM[1])
                  M_=methylation[[chr]][1]*10^-(M_)
                  U_=oldU*sum(BoxU)
                  U_=U_-(BoxU[1])
                  U_=methylation[[chr]][2]*10^-(U_)
                  U_=U_
                  mu_m=c(M_,U_)

                  g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

                }else{
                  g_=matrix(0,nrow=length(Tc[[chr]]),ncol=9)
                  M_=oldM*sum(BoxM[1,])
                  M_=M_-(BoxM[1,1])
                  M_=methylation[[chr]][1,1]*10^-(M_)
                  U_=oldU*sum(BoxU[1,])
                  U_=U_-(BoxU[1,1])
                  U_=methylation[[chr]][1,2]*10^-(U_)
                  U_=U_
                  mu_m=c(M_,U_)


                  M_=oldM[2]*sum(BoxM[2,])
                  M_=M_-(BoxM[2,1])
                  M_=methylation[[chr]][2,1]*10^-(M_)
                  U_=oldU[2]*sum(BoxU[2,])
                  U_=U_-(BoxU[2])
                  U_=methylation[[chr]][2,2]*10^-(U_)
                  U_=U_
                  mu_m=rbind(mu_m,c(M_,U_))
                  g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
                }
              }


              test=Build_zip_Matrix_LH_mailund(Q,g,Os[[chr]][[1]][[2]],nu)
              C_test=rep(0,n)
              for(c_test in 1:length(test[[1]])){
                C_test=rbind(C_test,(test[[1]][[c_test]]))
              }
              C_test=C_test[-1,]
              for(i in 1:length(Os[[chr]])){
                MLH=MLH-forward_cpp(as.integer(Os[[chr]][[i]][[1]]),g,nu,C_test)
              }
            }
            return(MLH)
          }



          param=c()
          if(ER==1){
            for(rr in 1:NC){
              param=c(param,oldrho[[rr]])
            }
          }
          if(SF==1){
            param=c(param,oldsigma)
          }
          if(SB==1){
            param=c(param,oldbeta)
          }
          if(!Popfix){
            param=c(param,oldXi_)
          }

          sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=50+length(param),M=c(20)))
          LH=as.numeric(as.matrix(sol[[2]]))
          sol=as.matrix(sol[[1]])
          start_position=0


          sol=as.numeric(sol[1:length(param),1])
          if(ER==1){
            rho=sol[(start_position+1):(start_position+1)]
            start_position=start_position+1
            if(ER==1){
              for(rr in 1:NC){
                oldrho[[rr]]=rho[(1+((1-rr)*1)):(rr*1)]
              }
            }
          }
          if(SF==1){
            sigma_=sol[(start_position+1):(start_position+1)]
            start_position=start_position+1
            oldsigma=sigma_
          }
          if(SB==1){
            beta_=sol[(start_position+1):(start_position+1)]
            start_position=start_position+1
            oldbeta=beta_
          }
          if(!Popfix){
            Xi_=sol[(start_position+1):(start_position+Klink)]
            start_position=start_position+Klink
            oldXi_=Xi_
          }
        }
      }

      if(Popfix){
        rho_=oldrho*sum(Boxr)
        rho_=rho_-(Boxr[1])
        rho_=10^(rho_)
        rho_=rho_*Rho
        if(SB){
          beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
        }
        if(SF){
          sigma=oldsigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
        }
        if(NC==1){
          builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair )
        }
        if(NC>1){
          builder=list()
          for(chr in 1:NC){
            builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair )
          }
        }
      }
      if(!Popfix){
        xx=0
        for(ix in 1:Klink){
          x=xx+1
          xx = xx + pop_vect[ix]
          oldXi[x:xx]=oldXi_[ix]
        }
        Xi_=oldXi*sum(BoxP)
        Xi_=Xi_-(BoxP[1])
        Xi_=10^Xi_
        rho_=oldrho*sum(Boxr)
        rho_=rho_-(Boxr[1])
        rho_=10^(rho_)
        rho_=rho_*Rho
        if(SB){
          beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
        }
        if(SF){
          sigma=oldsigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]
        }
        if(NC==1){
          builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
        }
        if(NC>1){
          builder=list()
          for(chr in 1:NC){
            builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
        }
      }
      if(NC==1){
        Q = builder[[1]]
        nu= builder[[2]]
        Tc=builder[[3]]
        if(Region>0){
          g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
        }else{
          if(nb_methylation_context==1){
            g_=matrix(0,nrow=length(Tc),ncol=6)
            M_=oldM*sum(BoxM)
            M_=M_-(BoxM[1])
            M_=methylation[1]*10^-(M_)
            U_=oldU*sum(BoxU)
            U_=U_-(BoxU[1])
            U_=methylation[2]*10^-(U_)
            U_=U_
            mu_m=c(M_,U_)

            g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

          }else{

            M_=oldM*sum(BoxM[1,])
            M_=M_-(BoxM[1,1])
            M_=methylation[1,1]*10^-(M_)
            U_=oldU*sum(BoxU[1,])
            U_=U_-(BoxU[1,1])
            U_=methylation[1,2]*10^-(U_)
            U_=U_
            mu_m=c(M_,U_)


            M_=oldM[2]*sum(BoxM[2,])
            M_=M_-(BoxM[2,1])
            M_=methylation[2,1]*10^-(M_)
            U_=oldU[2]*sum(BoxU[2,])
            U_=U_-(BoxU[2])
            U_=methylation[2,2]*10^-(U_)
            U_=U_
            mu_m=rbind(mu_m,c(M_,U_))
            g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
          }
        }


        Tc_r=builder[[4]]
      }
      if(NC>1){
        Q=list()
        nu=list()
        Tc=list()
        Tc_r=list()
        g=list()
        for(chr in 1:NC){
          Q[[chr]] = builder[[chr]][[1]]
          nu[[chr]]= builder[[chr]][[2]]
          Tc[[chr]]=builder[[chr]][[3]]
          Tc_r[[chr]]=builder[[chr]][[4]]


          if(Region>0){
            g_=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
          }else{
            if(nb_methylation_context==1){
              g_=matrix(0,nrow=length(Tc[[chr]]),ncol=6)
              M_=oldM*sum(BoxM)
              M_=M_-(BoxM[1])
              M_=methylation[[chr]][1]*10^-(M_)
              U_=oldU*sum(BoxU)
              U_=U_-(BoxU[1])
              U_=methylation[[chr]][2]*10^-(U_)
              U_=U_
              mu_m=c(M_,U_)

              g_=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)

            }else{
              g_=matrix(0,nrow=length(Tc[[chr]]),ncol=9)
              M_=oldM*sum(BoxM[1,])
              M_=M_-(BoxM[1,1])
              M_=methylation[[chr]][1,1]*10^-(M_)
              U_=oldU*sum(BoxU[1,])
              U_=U_-(BoxU[1,1])
              U_=methylation[[chr]][1,2]*10^-(U_)
              U_=U_
              mu_m=c(M_,U_)


              M_=oldM[2]*sum(BoxM[2,])
              M_=M_-(BoxM[2,1])
              M_=methylation[[chr]][2,1]*10^-(M_)
              U_=oldU[2]*sum(BoxU[2,])
              U_=U_-(BoxU[2])
              U_=methylation[[chr]][2,2]*10^-(U_)
              U_=U_
              mu_m=rbind(mu_m,c(M_,U_))
              g_=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=mu_m,mu_m_reg=region_methylation,Region,scale_meth)
            }
          }
          g[[chr]]=g_

        }
      }

      Tc_or=Tc_r
      Tc_o=Tc
      if(!Popfix){
        Xi_t=oldXi_
        Xit=vector()
        pop_vect=get('pop_vect', envir=test.env)
        xx=0
        for(ix in 1:length(Xi_t)){
          x=xx+1
          xx = xx + pop_vect[ix]
          Xit[x:xx]=Xi_t[ix]
        }
        Xit=Xit*sum(BoxP)
        Xit=Xit-(BoxP[1])
        Xit=10^Xit
      }
      rho_t=oldrho*sum(Boxr)
      rho_t=rho_t-(Boxr[1])
      rho_t=10^(rho_t)
      rho_t=rho_t*Rho
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(EM){
        if(NC==1){
          if(nb_methylation_context==1){
            M_=oldM
            M_=M_-(BoxM[1])
            M_=methylation[1]*10^-(M_)
            M_=M_
            U_=oldU
            U_=U_-(BoxU[1])
            U_=methylation[2]*10^-(U_)
            U_=U_
            mu_m=c(M_,U_)
          }else{
            M_=oldM[1]
            M_=M_-(BoxM[1,1])
            M_=methylation[1,1]*10^-(M_)
            M_=M_
            U_=oldU[1]
            U_=U_-(BoxU[1,1])
            U_=methylation[1,2]*10^-(U_)
            U_=U_
            mu_m=c(M_,U_)
            M_=oldM[2]
            M_=M_-(BoxM[2,1])
            M_=methylation[2,1]*10^-(M_)
            M_=M_
            U_=oldU[2]
            U_=U_-(BoxU[2,1])
            U_=methylation[2,2]*10^-(U_)
            U_=U_
            mu_m=rbind(mu_m,c(M_,U_))
          }
        }else{
          mu_m=list()
          for(chr in 1:NC){
            if(nb_methylation_context==1){
              M_=oldM
              M_=M_-(BoxM[1])
              M_=methylation[1]*10^-(M_)
              M_=M_
              U_=oldU
              U_=U_-(BoxU[1])
              U_=methylation[2]*10^-(U_)
              U_=U_
              mu_m[[chr]]=c(M_,U_)
            }else{
              M_=oldM[1]
              M_=M_-(BoxM[1,1])
              M_=methylation[1,1]*10^-(M_)
              M_=M_
              U_=oldU[1]
              U_=U_-(BoxU[1,1])
              U_=methylation[1,2]*10^-(U_)
              U_=U_
              mu_m[[chr]]=c(M_,U_)
              M_=oldM[2]
              M_=M_-(BoxM[2,1])
              M_=methylation[2,1]*10^-(M_)
              M_=M_
              U_=oldU[2]
              U_=U_-(BoxU[2,1])
              U_=methylation[2,2]*10^-(U_)
              U_=U_
              mu_m[[chr]]=rbind(mu_m[[chr]],c(M_,U_))
            }
          }
        }



      }


      gamma_t=rho_t/theta
      rho_t=rho_t/(2*L)


      if(!SB){
        oldBeta=Beta
      }
      if(SB){
        oldBeta=Beta
        Beta=beta
      }
      if(SF){
        oldSelf=Self
        Self=sigma
      }
      if(!SF){
        oldSelf=Self
      }
      if(Beta==oldBeta&Self==oldSelf){
        mb=maxBit
        print("no need  for more iteration")
      }
    }



  if(NC==1){



      res<-list()
      res$Tc=Tc_or
      Q=t(Q)
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      rho_=rho_/(2*L*Ne)
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(EM){
        if(nb_methylation_context==1){
          M_=oldM
          M_=M_-(BoxM[1])
          M_=methylation[1]*10^-(M_)
          M_=M_
          U_=oldU
          U_=U_-(BoxU[1])
          U_=methylation[2]*10^-(U_)
          U_=U_
          mu_m=c(M_,U_)
        }else{
          M_=oldM[1]
          M_=M_-(BoxM[1,1])
          M_=methylation[1,1]*10^-(M_)
          M_=M_
          U_=oldU[1]
          U_=U_-(BoxU[1,1])
          U_=methylation[1,2]*10^-(U_)
          U_=U_
          mu_m=c(M_,U_)
          M_=oldM[2]
          M_=M_-(BoxM[2,1])
          M_=methylation[2,1]*10^-(M_)
          M_=M_
          U_=oldU[2]
          U_=U_-(BoxU[2,1])
          U_=methylation[2,2]*10^-(U_)
          U_=U_
          mu_m=rbind(mu_m,c(M_,U_))
        }
      }
      if(!Popfix){
        res$Xi=Xi_
      }
      res$mu=(1-exp(log(1-mu)/Ne))*3/4
      res$beta=beta
      res$sigma=sigma
      if(Region>0){
        res$mu_m=methylation
        res$mu_m_reg=region_methylation
      }else{
        res$mu_m=mu_m
      }
      res$rho=rho_
      res$Ne=Ne
      if(!LH_opt){
      res$N=N
      res$M=M
      res$q_=q_
      }


  }
  if(NC>1){

    res <- list();
    res$Tc=Tc_or[[1]]
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho
    rho_=rho_/(2*L*Ne)
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }
    if(EM){
      mu_m=list()
      for(chr in 1:NC){
        if(nb_methylation_context==1){
          M_=oldM
          M_=M_-(BoxM[1])
          M_=methylation[1]*10^-(M_)
          M_=M_
          U_=oldU
          U_=U_-(BoxU[1])
          U_=methylation[2]*10^-(U_)
          U_=U_
          mu_m[[chr]]=c(M_,U_)
        }else{
          M_=oldM[1]
          M_=M_-(BoxM[1,1])
          M_=methylation[1,1]*10^-(M_)
          M_=M_
          U_=oldU[1]
          U_=U_-(BoxU[1,1])
          U_=methylation[1,2]*10^-(U_)
          U_=U_
          mu_m[[chr]]=c(M_,U_)
          M_=oldM[2]
          M_=M_-(BoxM[2,1])
          M_=methylation[2,1]*10^-(M_)
          M_=M_
          U_=oldU[2]
          U_=U_-(BoxU[2,1])
          U_=methylation[2,2]*10^-(U_)
          U_=U_
          mu_m[[chr]]=rbind(mu_m[[chr]],c(M_,U_))
        }
      }
    }
    if(!Popfix){
      res$Xi=Xi_
    }
    res$beta=beta
    res$sigma=sigma
    res$rho=rho_
    if(Region>0){
    res$mu_m=methylation
    res$mu_m_reg=region_methylation
    }else{
      res$mu_m=mu_m
    }
    if(!LH_opt){
      res$N=N
      res$M=M
      res$q_=q_
    }
    res$mu=(1-exp(log(1-mu)/Ne))*3/4
    res$Ne=Ne
  }
  return(res)
}
