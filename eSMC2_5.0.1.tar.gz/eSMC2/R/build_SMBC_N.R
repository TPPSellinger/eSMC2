#' Build the exact transition matrix from sequence of genealogy
#'
#' @param genealogy : Matrix of sequence of genealogy (output of get_first_coal_time)
#' @param Tc : numerical vector containing the discretization of time
#' @param M_a : number of haplotype used for model
#' @param Reg : TRUE to estimate alpha along the sequence
#' @param L_Reg : Sequence length on which to estimate alpha
#' @export
#' @return a square matrix of size TC counting the transition event
build_SMBC_N<-function(genealogy,Tc,M_a=3,Reg=F,L_Reg=10^6){
  vect_k=2:M_a
  nb_state=sum(choose(M_a,vect_k))
  if(!Reg){
    Output=matrix(0,ncol=(length(Tc)*nb_state),nrow=(length(Tc)*nb_state))
    for(i in 1:dim(genealogy)[2]){

      state=genealogy[1,i]
      if(i==1){

        former_state=state
        length_seq=genealogy[2,i]
        if(length_seq>1){
          #Output[former_state,state]=Output[former_state,state]+1

          former_state=state
          Output[former_state,state]=Output[former_state,state]+(length_seq-1)

        }
      }else{
        length_seq=genealogy[2,i]
        if(length_seq>1){
          Output[former_state,state]=Output[former_state,state]+1
          former_state=state
          Output[former_state,state]=Output[former_state,state]+(length_seq-1)

        }else{
          Output[former_state,state]=Output[former_state,state]+1
          former_state=state
        }
      }

    }
  }else{
    Output_final=list()
    Output=matrix(0,ncol=(length(Tc)*nb_state),nrow=(length(Tc)*nb_state))
    L_sca=0
    for(i in 1:dim(genealogy)[2]){
      state=genealogy[1,i]
      if(i==1){
        former_state=state
        length_seq=genealogy[2,i]
        L_sca=L_sca+length_seq
        if(length_seq>1){
          former_state=state
          if(L_sca<L_Reg){
            Output[former_state,state]=Output[former_state,state]+(length_seq-1)
          }else{
            Output[former_state,state]=Output[former_state,state]+(L_Reg-L_sca-length_seq-1)
            Output_final[[(1+length(Output_final))]]=Output
            Output=matrix(0,ncol=(length(Tc)*nb_state),nrow=(length(Tc)*nb_state))
            Output[former_state,state]=Output[former_state,state]+(L_sca-L_Reg)
            L_sca=L_sca-L_Reg
          }
        }
      }else{
        length_seq=genealogy[2,i]
        L_sca=L_sca+length_seq
        if(length_seq>1){
          if(L_sca<L_Reg){
          Output[former_state,state]=Output[former_state,state]+1
          former_state=state
          Output[former_state,state]=Output[former_state,state]+(length_seq-1)
          }else{
            Output[former_state,state]=Output[former_state,state]+1
            former_state=state
            Output[former_state,state]=Output[former_state,state]+(L_Reg-L_sca-length_seq-1)
            Output_final[[(1+length(Output_final))]]=Output
            Output=matrix(0,ncol=(length(Tc)*nb_state),nrow=(length(Tc)*nb_state))
            Output[former_state,state]=Output[former_state,state]+(L_sca-L_Reg)
            L_sca=L_sca-L_Reg
          }


        }else{
          if(L_sca<L_Reg){
          Output[former_state,state]=Output[former_state,state]+1
          former_state=state
          }else{
            Output[former_state,state]=Output[former_state,state]+1
            former_state=state
            Output_final[[(1+length(Output_final))]]=Output
            Output=matrix(0,ncol=(length(Tc)*nb_state),nrow=(length(Tc)*nb_state))
            L_sca=0
          }
        }
      }
    }
    Output=Output_final
    if(sum(Output[[1]]>L_Reg)){
      browser()
    }
  }

  return(Output)
}
