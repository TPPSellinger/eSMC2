#' Runs the ecological Sequentially Markovian Coalescent 2 accounting for methylation
#'
#' @param n : Number of hidden states
#' @param rho : numeric vector of prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param methylation : vector of size two, respectively containing the absolute values of methylation and demethylation rates in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @param region_methylation : vector of size two, respectively containing the absolute values of methylation and demethylation rates at the region level in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @param BoxM : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param BoxU : vector of size two which are bounderies of demethylation rates.  First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param mu_r : numeric value corresponding to real mutation rate (for scaling purposes)
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param BoxB : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param SF : True to estimate Self-fertilization rate
#' @param ER : True to estimate recombination rate
#' @param BW : True to use the complete implementation of the Baum-Welch algorithm
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param LH_opt : TRUE to maximize likelihood (not through the Baum-Welch)
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param window_min : minimum sequence length of a methylated regions
#' @param nb_site_min : list containing vectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param P_m : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in methylated regions , set to NA to theoretically predict those values
#' @param P_d : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in unmethylated regions, set to NA to theoretically predict those values
#' @export
#' @return A list containing all estimations (first list contains estimation based on the data second on the pseudo-observed data). List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).
SMCm<-function(n=40,rho=1,O,methylation=c(5,4),region_methylation=c(5,4),BoxM=c(1,1),BoxU=c(1,1),mu_r,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,ER=T,BW=F,NC=1,pop_vect=NA,mu_b=1,sigma=0,beta=1,Big_Window=F,position_removed=NA,LH_opt=F,Region=F,window_min=100,nb_site_min=4,P_m=c(0.8,0.2),P_d=c(0.2,0.8)){
  nb_methylation_context=1
  Check=F
  FS=F
  EM=F
  SCALED=F
  Free=F
  Region_Free=F
  parallel=1
  Problem_Solvable=T
  if(nb_methylation_context==1){
    mu_m=10^-methylation
    p=(mu_m[2]/(sum(mu_m)))
    #print("Expected probability to be unmethylation")
    #print(p)

  }else{
    mu_m=matrix(0,nb_methylation_context,2)
    p=c()
    for(context in 1:nb_methylation_context){
      mu_m=10^-methylation[context,]
      p=c(p,(mu_m[2]/(sum(mu_m))))
    }
  }




  if(Region>0&!Region_Free){
  mu_m_reg=10^-region_methylation
  p_reg=(mu_m_reg[2]/(sum(mu_m_reg)))
  #print("Expected probability for region to be unmethylation")
  #print(p_reg)
  }

  if(Region){
    if(any(is.na(P_m))){
      p=(mu_m[2]/(sum(mu_m)))
      if((sum(mu_m)/sum(mu_m_reg))<0.5){
        P_m=c(((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))),1-((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))))
      }else{
        print("Warning : Site rate much faster than region rate, region signal most likeli lost")
        P_m=c(0.8,0.2)
      }
    }
    if(any(is.na(P_d))){
      p=(mu_m[2]/(sum(mu_m)))
      if((sum(mu_m)/sum(mu_m_reg))<0.5){
        P_d=c(1-(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))),(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))))
      }else{
        print("Warning : Site rate much faster than region rate, region signal most likeli lost")
        P_d=c(0.2,0.8)
      }
    }
  }

  gamma=rho
  sigma=max(Boxs[1],sigma)
  sigma=min(Boxs[2],sigma)
  beta=min(BoxB[2],beta)
  beta=max(BoxB[1],beta)

  if(SF|SB){
    BaWe=2
  }else{
    BaWe=1
  }
  if(is.na(pop_vect)){
    pop_vect=rep(2,(n*0.5))
  }

    if(NC==1){
      M=dim(O)[1]-2
      L=as.numeric(O[dim(O)[1],dim(O)[2]])
      Redo=T
      while(Redo){
        Redo=F

      Os=list()
      count=0
      M_o=0
      theta_W=0
      theta_M=c()
      theta_reg=c()
      scale_meth=c()
      if(nb_methylation_context==2){
        scale_meth_2=c()
      }
       if(Free|Region_Free>0){
   p_estimated=c()
   ps=c()
   pm=c()
   pm_reg=c()
   if(nb_methylation_context==2){
    p_estimated_2=c()
    ps2=c()
   }
 }
      s_t=Sys.time()
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          Os_=seqMeth(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],nb_meth=nb_methylation_context,Free=Free,Region=Region,Region_Free=Region_Free,window_min=window_min,nb_site_min=nb_site_min,P_m=P_m,P_d=P_d)
          theta_W=theta_W+as.numeric(Os_$theta)
          scale_meth=c(scale_meth,(length(which(Os_$seq<2))/(L-length(which(Os_$seq==2)))))
          if(Region_Free&as.numeric(Region)%in%c(1,2)){
            theta_reg=c(theta_reg,as.numeric(Os_$theta_reg))
            pm_reg=c(pm_reg,Os_$ratio_reg)
            if(Free){
              theta_M=c(theta_M,as.numeric(Os_$theta_M))
              pm=c(pm_reg,Os_$pm)
            }
          }else{

            if(nb_methylation_context==2){
              scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/(L-length(which(Os_$seq==2)))))
              scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])

            }
            if(Free){
              theta_M=c(theta_M,as.numeric(Os_$theta_M))
              p_estimated=c(p_estimated,Os_$ratio_D_over_M)

              if(nb_methylation_context==2){
              p_estimated2=c(p_estimated2,Os_$ratio_O_over_P)
              ps2=c(ps2,Os_$theta_O)}

            }
          }



          M_o=M_o+1
          if(count==0){
            if(length(Os_$seq)>10^6){
              if(!LH_opt){
                Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context,Region=Region)
                Mat_symbol=Os_temporary[[2]]
              }else{
                Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                Mat_symbol=Os_temporary[[2]]

              }

              #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
              #Super_Mat_symbol=Os_temporary[[2]]
              rm(Os_temporary)
              L10=length(Os_$seq)/10^6
                count=count+1
                if(!LH_opt){
                  Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }
                #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                #Os[[count]][[3]]=Mat_symbol
                #Os[[count]][[4]]=length(Os_$seq)


            }else{
              count=count+1
              if(!LH_opt){
                Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context,Region=Region)
                Mat_symbol=Os_temporary[[2]]
                Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
              }else{
                Os[[count]]=Build_zip_2seq_m(Os_$seq,20)
                Mat_symbol=Os[[count]][[2]]
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }




              #Os[[count]][[3]]=Mat_symbol
              #Os[[count]][[4]]=length(Os_$seq)

            }
          }else{
              count=count+1
              if(!LH_opt){
                Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
              }else{
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }


          }
        }
        rm(Os_)
      }
      e_t=Sys.time()
      print("Time to Zip sequences")
      print(e_t-s_t)



      if(length(Os)>=1){
        for(oo in 1:length(Os)){
              Os[[oo]]=symbol2Num_m(Os[[oo]])
        }
        theta_W=theta_W/M_o



        theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r*4/3))))



        mu=(-(log((1-(theta/(L*0.75))))/2))


        scale_meth=mean(scale_meth)
        if(nb_methylation_context==2){
          scale_meth_2=mean(scale_meth_2)
        }

        if(as.numeric(Region)>0){

          if(Free&as.numeric(Region)!=2){
            print("estimated equilibrium probability")
            p=1-mean(pm)
            print(p)
            ps=theta_M#1-mean(pm)
            mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
            if(any(is.na(as.numeric(as.character(mu_m))))){
              print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
              warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

              for(rep in 1:length(Os)){
                pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                if(length(pos)>0){
                Os[[rep]][[1]][pos]=0
                }
              }
              Problem_Solvable=F
              mu_m=c(0.002,0,01)
              }

          }

          if(Region_Free){
            print("estimated region equilibrium probability")
            p=1-mean(pm_reg)
            print(p)
            ps=theta_reg
           #mu_m_reg=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)
            mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
            if(any(is.na(as.numeric(as.character(mu_m_reg))))){
              print("Model cannot explain the Region epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
              warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

              for(rep in 1:length(Os)){
                pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                if(length(pos)>0){
                  Os[[rep]][[1]][pos]=0
                }
              }
              Problem_Solvable=F
              mu_m_reg=c(0.002,0,01)
              }

          }
        }else{

          if(Free){
            print("estimated equilibrium probability")
            p=mean(p_estimated)
            print(p)
            ps=mean(theta_M)

            #mu_m=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)
            mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
            if(any(is.na(as.numeric(as.character(mu_m))))){
              print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
              warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
              for(rep in 1:length(Os)){
                pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                if(length(pos)>0){
                  Os[[rep]][[1]][pos]=0
                }
              }
              Problem_Solvable=F
              mu_m=c(0.002,0,01)
              }


            if(nb_methylation_context==2){
              print("estimated equilibrium probability in second methylation context")
              p=mean(p_estimated2)
              print(p)
              ps=ps2
              #mu_m=rbind(mu_m,c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
              mu_m=rbind(mu_m,c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T))

              if(any(is.na(as.numeric(as.character(mu_m[2,]))))){
                print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
                warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

                for(rep in 1:length(Os)){
                  pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                  if(length(pos)>0){
                    Os[[rep]][[1]][pos]=0
                  }
                }
                Problem_Solvable=F
                mu_m[2,]=c(0.002,0,01)
                }

            }
          }
        }

        if(Problem_Solvable){
        print("mu_m:")
        print(mu_m/Ne)
        if(Region>0){
        print("mu_m_reg:")
        print(mu_m_reg/Ne)
        }
         }
        rho=rho*theta

      }else{
        stop("data too poor")
      }

      if(Free){
        methylation=mu_m
      }else{
        methylation=mu_m*Ne
      }
      if(Region>0){
      if(Region_Free){
        region_methylation=mu_m_reg
      }else{
        region_methylation=mu_m_reg*Ne
      }
      }
      }
      rm(O)
      if(any(is.na(as.numeric(mu_m)))){
        browser()
      }
    }
    if(NC>1){
      if(Free){
      mu_m=list()
      }
      if(length(O)!=NC){
        stop("Not good number of chromosome given")
      }
      Os=list()
      theta_W_V=vector(length=NC)
      L_total=vector()
      scale_meth_v=numeric(NC)
      if(nb_methylation_context==2){
        scale_meth_v_2=c()
      }

      for(chr in 1:NC){
        if(Free){
          p_estimated=c()
          ps=c()
          if(nb_methylation_context==2){
            p_estimated_2=c()
            ps2=c()
          }
        }
        M=dim(O[[chr]])[1]-2
        L=as.numeric(O[[chr]][dim(O[[chr]])[1],dim(O[[chr]])[2]])
        L_total=c(L_total,L)
        Ost=list()
        count=0
        M_o=0
        theta_W=0
        scale_meth=c()
        if(nb_methylation_context==2){
          scale_meth_2=c()
        }
        for(k in 1:(M-1)){
          for(l in (k+1):M){
            Os_=seqMeth(O[[chr]][c(k,l,(M+1),(M+2)),],L,position_removed[[1]],nb_meth=nb_methylation_context,Free=Free,Region=Region,Region_Free=Region_Free,window_min=window_min,nb_site_min=nb_site_min,P_m=P_m,P_d=P_d)
            theta_W=theta_W+as.numeric(Os_$theta)
            scale_meth=c(scale_meth,(length(which(Os_$seq<2))/L))
            if(Free){
              p_estimated=c(p_estimated,Os_$ratio_D_over_M)
              ps=c(ps,Os_$theta_M)
            }

            if(nb_methylation_context==2){
              scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/L))
              scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])
              if(Free){
                p_estimated2=c(p_estimated2,Os_$ratio_O_over_P)
                ps2=c(ps,Os_$theta_O)
              }
            }
            M_o=M_o+1
            if(count==0){
              if(length(Os_$seq)>10^6){

                if(!LH_opt){
                  Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context,Region=Region)
                  Mat_symbol=Os_temporary[[2]]
                }else{
                  Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                  Mat_symbol=Os_temporary[[2]]
                }


                #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
                #Super_Mat_symbol=Os_temporary[[2]]
                rm(Os_temporary)
                L10=length(Os_$seq)/10^6
                  count=count+1


                  if(!LH_opt){
                    Ost[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Ost[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }

                  #Ost[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                  #Ost[[count]][[3]]=Mat_symbol
                  #Ost[[count]][[4]]=length(Os_$seq)


              }else{
                #Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context)
                #Mat_symbol=Os_temporary[[2]]
                count=count+1

                if(!LH_opt){
                  Ost[[count]]=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context,Region=Region)
                  Mat_symbol=Ost[[count]][[2]]
                }else{
                  Ost[[count]]=Build_zip_2seq_m(Os_$seq,20)
                  Mat_symbol=Ost[[count]]
                }
                #Super_Mat_symbol=Ost[[count]][[2]]
                #Ost[[count]][[3]]=Mat_symbol
                #Ost[[count]][[4]]=length(Os_$seq)
                rm(Os_temporary)
              }
            }else{
                count=count+1

                if(!LH_opt){
                  Ost[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Ost[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }


                #Ost[[count]][[3]]=Mat_symbol
                #Ost[[count]][[4]]=length(Os_$seq)


            }
          }
        }
        Os[[chr]]=Ost
        theta_W_V[chr]=theta_W/M_o
        scale_meth_v[chr]=mean(scale_meth)
        if(nb_methylation_context==2){
          scale_meth_v_2[chr]=mean(scale_meth_2)
        }
        if(Free){
          print("estimated equilibrium probability")
          p=mean(p_estimated)
          print(p)
          ps=mean(ps)
          mu_m[[chr]]=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

          if(nb_methylation_context==2){
            print("estimated equilibrium probability in second methylation context")
            p=mean(p_estimated2)
            print(p)
            ps=mean(ps2)
            mu_m[[chr]]=rbind(mu_m[[chr]],c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
          }
        }
      }
      scale_meth=scale_meth_v
      if(nb_methylation_context==2){
        scale_meth_2=scale_meth_v_2
      }

      print(L_total)
      L=L_total
      rm(O)
      rm(Ost)
      rm(scale_meth_v)
      if(length(Os)>=1){
        for(oo in 1:length(Os)){
          for(cc in 1:length(Os[[oo]])){
              Os[[oo]][[cc]]=symbol2Num_m(Os[[oo]][[cc]])
          }
        }

        theta=theta_W_V*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        Ne=log((1+((log((1-(theta/(L_total*0.75))))/2))))/(log(1-(mu_r*4/3)))
        mu=-(log((1-(theta/(L*0.75))))/2)

        rho=rho*theta
        rm(Os_)
      }else{
        stop("data too poor")
      }
      theta_W=theta_W_V
      methylation=list()
      for(chr in 1:NC){
        if(Free){
          methylation[[chr]]=mu_m[[chr]]
        }else{
          methylation[[chr]]=mu_m*Ne[chr]
        }
      }


    }

  if(length(Os)>=1){
    print("Observed theta:")
    print(theta_W)
    print("Estimated effective population size:")
    print(Ne)
    print("Estimated theta:")
    print(theta)
    print("Estimated rho:")
    print(rho)

    if(nb_methylation_context==2){
      scale_meth=rbind(scale_meth,scale_meth_2)
      print(scale_meth)
    }
    if(BaWe==1){
      results=Baum_Welch_algo_m(Os=Os, maxIt =maxit,L=L,mu=mu,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,redo_R=T,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,methylation=methylation,BoxM=BoxM,BoxU=BoxU,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=LH_opt,Region=Region,region_methylation=region_methylation)
    }
    if(BaWe==2){
      results=Baum_Welch_algo_m(Os=Os, maxIt =maxit,L=L,mu=mu,Ne=Ne,theta_W=theta_W,Rho=theta,beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=T,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,methylation=methylation,BoxM=BoxM,BoxU=BoxU,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=LH_opt,Region=Region,region_methylation=region_methylation)
      r=results$rho[1:NC]
      mu_=results$mu
      gamma_=(r*(beta*2*(1-sigma)/(2-sigma)))/mu_
      print(r)
      print(mu_)
      print(gamma_)

      effect=mean(gamma_/gamma)
      if(SF&!SB){
        sigma=(1-effect)/(1-(effect/2))
        sigma=max(Boxs[1],sigma)
        sigma=min(Boxs[2],sigma)
        if(sigma>=Boxs[1]&sigma<=Boxs[2]){
          #Boxs[1]=sigma
        }
      }
      if(SB&!SF){
        beta=effect
        beta=min(BoxB[2],beta)
        beta=max(BoxB[1],beta)
        if(beta>=BoxB[1]&beta<=BoxB[2]){
         # BoxB[2]=beta
        }
      }
      if(SF&SB){
        if(min(BoxB)>(1-max(Boxs))){
          sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)
          beta=effect*(2-sigma)/(2*(1-sigma))
          beta=max(BoxB[1],beta)
          beta=min(BoxB[2],beta)
        }
        if(min(BoxB)<=(1-max(Boxs))){
          beta=effect*(2-sigma)/(2*(1-sigma))
          beta=max(BoxB[1],beta)
          beta=min(BoxB[2],beta)
          sigma=(1-(effect/beta))/(1-(effect/(2*beta)))
          sigma=max(Boxs[1],sigma)
          sigma=min(Boxs[2],sigma)

        }
        if(gamma_!=(gamma*beta*2*(1-sigma)/(2-sigma))){
          print("Prior might disagree with results.")
        }
      }
      if(NC==1){
      theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
      mu=(-(log((1-(theta/(L*0.75))))/2))
      rho=gamma*theta
      old_Ne=Ne
      Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r*4/3))))
      methylation=methylation*Ne/old_Ne
      region_methylation=region_methylation*Ne/old_Ne

      }else{
        theta=theta_W_V*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        old_Ne=Ne
        Ne=log((1+((log((1-(theta/(L_total*0.75))))/2))))/(log(1-(mu_r*4/3)))
        mu=-(log((1-(theta/(L*0.75))))/2)
        methylation=methylation*Ne/old_Ne
        region_methylation=region_methylation*Ne/old_Ne
        rho=gamma*theta
      }
      results=Baum_Welch_algo_m(Os=Os, maxIt =maxit,L=L,mu=mu,Ne=Ne,theta_W =theta_W,Rho=rho,beta=beta,sigma=sigma,Popfix=pop,SB=SB,SF=SF,k=n,BoxB=BoxB,BoxP=BoxP,Boxr=Boxr,Boxs = Boxs,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,methylation=methylation,BoxM=BoxM,BoxU=BoxU,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=LH_opt,Region=Region,region_methylation=region_methylation)
      if(!Problem_Solvable){
        results$mu_m=c(NA,NA)
        results$mu_m_reg=c(NA,NA)
      }
      }
  }
  return(results)
}
