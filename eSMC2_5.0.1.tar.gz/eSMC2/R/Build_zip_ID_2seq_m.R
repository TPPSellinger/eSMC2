#'  Zip the  signal to reduce signal length
#'
#' @param Os : original signal
#' @param nb_context : number of different methylation context
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @return A list with first object the ziped sequence and as second the symbol matrix#
Build_zip_ID_2seq_m<-function(Os,nb_context=1,Region){


  if(as.numeric(Region)==0){
    if(nb_context==1){
      max_count=c(9,9)
      zip_symbol=c(0,2)
      symbol_l=list()
      symbol_l[[1]]=c("00","aa","bb","cc")
      symbol_l[[2]]=c("11")
      symbol_l[[3]]=c("22")
      symbol_l[[4]]=c("33")
      symbol_l[[5]]=c("44")
      symbol_l[[6]]=c("55")
    }
    if(nb_context==2){
      max_count=c(9,9)
      zip_symbol=c(0,2)
      symbol_l=list()
      symbol_l[[1]]=c("00","aa","bb","cc")
      symbol_l[[2]]=c("11")
      symbol_l[[3]]=c("22")
      symbol_l[[4]]=c("33")
      symbol_l[[5]]=c("44")
      symbol_l[[6]]=c("55")
      symbol_l[[7]]=c("66")
      symbol_l[[8]]=c("77")
      symbol_l[[9]]=c("88")
    }
    ini=Os[1]
    Os=Os[-1]
    output=list()
    mat_symbol_f=list()
    count_zip=0
    L=length(Os)
    print("Original length")
    print(L)

    letter_c=0
    count=0

    for(zip_o in zip_symbol){
      count_zip=count_zip+1
      pos_save=which(Os!=zip_o)
      Os_s=Os[pos_save]
      Os[pos_save]<-"+"
      criteria=T
      mat_symbol=vector()
      l=vector()
      if(count>=max_count[count_zip]){
        criteria=F
      }
      if(criteria){
        while(criteria){


          L=length(Os)
          count=count+1
          new_symbol=letters[(letter_c+count)]

          if(count>length(symbol_l[[(zip_o+1)]])){
            L=length(Os)
            impair=cbind(seq(1,(L-1),2),seq(2,L,2))
            pair=cbind(seq(2,(L-1),2),seq(3,L,2))
            tot_pair=rbind(impair,pair)
            rm(impair)
            rm(pair)
            pattern=rbind(as.vector(as.matrix(paste(Os[tot_pair[,1]],Os[tot_pair[,2]],sep=""))),tot_pair[,1],tot_pair[,2])
            rm(tot_pair)
            symbol=unique(pattern[1,])
            real_symb=vector()
            nb_symbol=length(symbol)
            for(k in 1:nb_symbol){
              sym_dec=strsplit(symbol[k],"")[[1]]
              if(!any(as.character(sym_dec)%in%c("+"))){
                real_symb=c(real_symb,symbol[k])
              }
            }
            symbol=real_symb
            if(length(symbol)==0){
              criteria=F
            }
            if(length(symbol)>0){
              nb_symbol=length(symbol)
              count_symbol=rep(0,nb_symbol)
              pos_s=vector()
              for(k in 1:nb_symbol){
                test=as.numeric(as.matrix(pattern[2,which(pattern[1,]==symbol[k])]))
                x=length(test)
                test=c(test,c(test+1))
                coef=length(unique(test))/length(test)
                count_symbol[k]=x*coef
              }
              rm(pattern)
              rm(test)
              rep_symbol=as.vector(symbol[which(count_symbol==max(count_symbol))])[1]
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
              Os[pos_s]=new_symbol
              pos_s=pos_s+1
              Os=Os[-pos_s]
            }
          }else{
            symbol=symbol_l[[(zip_o+1)]][count]
            if(length(symbol)>0){
              pos_s=vector()
              rep_symbol=symbol
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              if(length(pos_s)>1){
                mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
                Os[pos_s]=new_symbol
                pos_s=pos_s+1
                Os=Os[-pos_s]
                n_L=length(Os)
                if(n_L>=L){
                  stop("zip problem")
                }
              }
            }
          }

          if(count>=max_count[count_zip]){
            criteria=F
          }
        }

      }
      letter_c=letter_c+count
      if(length(which(Os=="+"))!=length(Os_s)){
        browser()
      }else{
        Os[which(Os=="+")]<-Os_s
      }

      mat_symbol_f[[(zip_o+1)]]=mat_symbol
    }

  }

  if(as.numeric(Region)==1){
    max_count=c(9,3)
    zip_symbol=c(0,2)
    symbol_l=list()
    symbol_l[[1]]=c("00","aa","bb","cc","dd","ee","ff","gg","hh")
    symbol_l[[2]]=c("11")
    symbol_l[[3]]=c("22")
    symbol_l[[4]]=c("33")
    symbol_l[[5]]=c("44")
    symbol_l[[6]]=c("55")
    symbol_l[[7]]=c("66")
    symbol_l[[8]]=c("77")
    symbol_l[[9]]=c("88")
    symbol_l[[10]]=c("99")
    ini=Os[1]
    Os=Os[-1]
    output=list()
    mat_symbol_f=list()
    count_zip=0
    L=length(Os)
    print("Original length")
    print(L)

    letter_c=0
    count=0

    for(zip_o in zip_symbol){
      count_zip=count_zip+1
      pos_save=which(Os!=zip_o)
      Os_s=Os[pos_save]
      Os[pos_save]<-"+"
      criteria=T
      mat_symbol=vector()
      l=vector()
      if(count>=max_count[count_zip]){
        criteria=F
      }
      if(criteria){
        while(criteria){


          L=length(Os)
          count=count+1
          new_symbol=letters[(letter_c+count)]

          if(count>length(symbol_l[[(zip_o+1)]])){
            L=length(Os)
            impair=cbind(seq(1,(L-1),2),seq(2,L,2))
            pair=cbind(seq(2,(L-1),2),seq(3,L,2))
            tot_pair=rbind(impair,pair)
            rm(impair)
            rm(pair)
            pattern=rbind(as.vector(as.matrix(paste(Os[tot_pair[,1]],Os[tot_pair[,2]],sep=""))),tot_pair[,1],tot_pair[,2])
            rm(tot_pair)
            symbol=unique(pattern[1,])
            real_symb=vector()
            nb_symbol=length(symbol)
            for(k in 1:nb_symbol){
              sym_dec=strsplit(symbol[k],"")[[1]]
              if(!any(as.character(sym_dec)%in%c("+"))){
                real_symb=c(real_symb,symbol[k])
              }
            }
            symbol=real_symb
            if(length(symbol)==0){
              criteria=F
            }
            if(length(symbol)>0){
              nb_symbol=length(symbol)
              count_symbol=rep(0,nb_symbol)
              pos_s=vector()
              for(k in 1:nb_symbol){
                test=as.numeric(as.matrix(pattern[2,which(pattern[1,]==symbol[k])]))
                x=length(test)
                test=c(test,c(test+1))
                coef=length(unique(test))/length(test)
                count_symbol[k]=x*coef
              }
              rm(pattern)
              rm(test)
              rep_symbol=as.vector(symbol[which(count_symbol==max(count_symbol))])[1]
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
              Os[pos_s]=new_symbol
              pos_s=pos_s+1
              Os=Os[-pos_s]
            }
          }else{
            symbol=symbol_l[[(zip_o+1)]][count]
            if(length(symbol)>0){
              pos_s=vector()
              rep_symbol=symbol
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              if(length(pos_s)>1){
                mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
                Os[pos_s]=new_symbol
                pos_s=pos_s+1
                Os=Os[-pos_s]
                n_L=length(Os)
                if(n_L>=L){
                  stop("zip problem")
                }
              }
            }
          }

          if(count>=max_count[count_zip]){
            criteria=F
          }
        }

      }
      letter_c=letter_c+count
      if(length(which(Os=="+"))!=length(Os_s)){
        browser()
      }else{
        Os[which(Os=="+")]<-Os_s
      }

      mat_symbol_f[[(zip_o+1)]]=mat_symbol
    }

  }

  if(as.numeric(Region)==2){
    max_count=c(9,3)
    zip_symbol=c(0,2)
    symbol_l=list()
    symbol_l[[1]]=c("00","aa","bb","cc","dd","ee","ff","gg","hh")
    symbol_l[[2]]=c("11")
    symbol_l[[3]]=c("22")
    symbol_l[[4]]=c("33")
    symbol_l[[5]]=c("44")
    symbol_l[[6]]=c("55")

    ini=Os[1]
    Os=Os[-1]
    output=list()
    mat_symbol_f=list()
    count_zip=0
    L=length(Os)
    print("Original length")
    print(L)

    letter_c=0
    count=0

    for(zip_o in zip_symbol){
      count_zip=count_zip+1
      pos_save=which(Os!=zip_o)
      Os_s=Os[pos_save]
      Os[pos_save]<-"+"
      criteria=T
      mat_symbol=vector()
      l=vector()
      if(count>=max_count[count_zip]){
        criteria=F
      }
      if(criteria){
        while(criteria){


          L=length(Os)
          count=count+1
          new_symbol=letters[(letter_c+count)]

          if(count>length(symbol_l[[(zip_o+1)]])){
            L=length(Os)
            impair=cbind(seq(1,(L-1),2),seq(2,L,2))
            pair=cbind(seq(2,(L-1),2),seq(3,L,2))
            tot_pair=rbind(impair,pair)
            rm(impair)
            rm(pair)
            pattern=rbind(as.vector(as.matrix(paste(Os[tot_pair[,1]],Os[tot_pair[,2]],sep=""))),tot_pair[,1],tot_pair[,2])
            rm(tot_pair)
            symbol=unique(pattern[1,])
            real_symb=vector()
            nb_symbol=length(symbol)
            for(k in 1:nb_symbol){
              sym_dec=strsplit(symbol[k],"")[[1]]
              if(!any(as.character(sym_dec)%in%c("+"))){
                real_symb=c(real_symb,symbol[k])
              }
            }
            symbol=real_symb
            if(length(symbol)==0){
              criteria=F
            }
            if(length(symbol)>0){
              nb_symbol=length(symbol)
              count_symbol=rep(0,nb_symbol)
              pos_s=vector()
              for(k in 1:nb_symbol){
                test=as.numeric(as.matrix(pattern[2,which(pattern[1,]==symbol[k])]))
                x=length(test)
                test=c(test,c(test+1))
                coef=length(unique(test))/length(test)
                count_symbol[k]=x*coef
              }
              rm(pattern)
              rm(test)
              rep_symbol=as.vector(symbol[which(count_symbol==max(count_symbol))])[1]
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
              Os[pos_s]=new_symbol
              pos_s=pos_s+1
              Os=Os[-pos_s]
            }
          }else{
            symbol=symbol_l[[(zip_o+1)]][count]
            if(length(symbol)>0){
              pos_s=vector()
              rep_symbol=symbol
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              if(length(pos_s)>1){
                mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
                Os[pos_s]=new_symbol
                pos_s=pos_s+1
                Os=Os[-pos_s]
                n_L=length(Os)
                if(n_L>=L){
                  stop("zip problem")
                }
              }
            }
          }

          if(count>=max_count[count_zip]){
            criteria=F
          }
        }

      }
      letter_c=letter_c+count
      if(length(which(Os=="+"))!=length(Os_s)){
        browser()
      }else{
        Os[which(Os=="+")]<-Os_s
      }

      mat_symbol_f[[(zip_o+1)]]=mat_symbol
    }


  }

  if(as.numeric(Region)==3){
    max_count=c(9,3)
    zip_symbol=c(0,2)
    symbol_l=list()
    symbol_l[[1]]=c("00","aa","bb","cc","dd","ee","ff","gg","hh")
    symbol_l[[2]]=c("11")
    symbol_l[[3]]=c("22")
    symbol_l[[4]]=c("33")
    symbol_l[[5]]=c("44")
    symbol_l[[6]]=c("55")
    symbol_l[[7]]=c("66")
    symbol_l[[8]]=c("77")
    symbol_l[[9]]=c("88")
    ini=Os[1]
    Os=Os[-1]
    output=list()
    mat_symbol_f=list()
    count_zip=0
    L=length(Os)
    print("Original length")
    print(L)

    letter_c=0
    count=0

    for(zip_o in zip_symbol){
      count_zip=count_zip+1
      pos_save=which(Os!=zip_o)
      Os_s=Os[pos_save]
      Os[pos_save]<-"+"
      criteria=T
      mat_symbol=vector()
      l=vector()
      if(count>=max_count[count_zip]){
        criteria=F
      }
      if(criteria){
        while(criteria){


          L=length(Os)
          count=count+1
          new_symbol=letters[(letter_c+count)]

          if(count>length(symbol_l[[(zip_o+1)]])){
            L=length(Os)
            impair=cbind(seq(1,(L-1),2),seq(2,L,2))
            pair=cbind(seq(2,(L-1),2),seq(3,L,2))
            tot_pair=rbind(impair,pair)
            rm(impair)
            rm(pair)
            pattern=rbind(as.vector(as.matrix(paste(Os[tot_pair[,1]],Os[tot_pair[,2]],sep=""))),tot_pair[,1],tot_pair[,2])
            rm(tot_pair)
            symbol=unique(pattern[1,])
            real_symb=vector()
            nb_symbol=length(symbol)
            for(k in 1:nb_symbol){
              sym_dec=strsplit(symbol[k],"")[[1]]
              if(!any(as.character(sym_dec)%in%c("+"))){
                real_symb=c(real_symb,symbol[k])
              }
            }
            symbol=real_symb
            if(length(symbol)==0){
              criteria=F
            }
            if(length(symbol)>0){
              nb_symbol=length(symbol)
              count_symbol=rep(0,nb_symbol)
              pos_s=vector()
              for(k in 1:nb_symbol){
                test=as.numeric(as.matrix(pattern[2,which(pattern[1,]==symbol[k])]))
                x=length(test)
                test=c(test,c(test+1))
                coef=length(unique(test))/length(test)
                count_symbol[k]=x*coef
              }
              rm(pattern)
              rm(test)
              rep_symbol=as.vector(symbol[which(count_symbol==max(count_symbol))])[1]
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
              Os[pos_s]=new_symbol
              pos_s=pos_s+1
              Os=Os[-pos_s]
            }
          }else{
            symbol=symbol_l[[(zip_o+1)]][count]
            if(length(symbol)>0){
              pos_s=vector()
              rep_symbol=symbol
              pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
              pos_s=as.vector(as.matrix(pos_s[[1]]))
              if(length(pos_s)>1){
                mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
                Os[pos_s]=new_symbol
                pos_s=pos_s+1
                Os=Os[-pos_s]
                n_L=length(Os)
                if(n_L>=L){
                  stop("zip problem")
                }
              }
            }
          }

          if(count>=max_count[count_zip]){
            criteria=F
          }
        }

      }
      letter_c=letter_c+count
      if(length(which(Os=="+"))!=length(Os_s)){
        browser()
      }else{
        Os[which(Os=="+")]<-Os_s
      }

      mat_symbol_f[[(zip_o+1)]]=mat_symbol
    }
  }

  Os=c(ini,Os)
  print("Final length")
  n_L=length(Os)
  print(n_L)
  output[[1]]=Os
  output[[2]]=mat_symbol_f

  return(output)
}
