#' Builds the expected transition matrix from expected coalescent time
#'
#' @param DNA : the sequence of number segregating sites per time window
#' @param Tc_SNP : numeric vector indicating the expected number of segregatings sites per coalescence time
#' @return  A square matrix of dimension equal to Tc_SNP counting the number of transitions
build_X_star<-function(DNA,Tc_SNP){
  pos_check=which(!is.na(DNA[1:(length(DNA)-1)])&(!is.na(DNA[2:(length(DNA))])) )
  transi=sapply(pos_check, function(x){return(c(max(which(Tc_SNP<=DNA[x])),max(which(Tc_SNP<=DNA[(x+1)]))))})
  output=matrix(0,length(Tc_SNP),length(Tc_SNP))
  for(cc in 1:dim(transi)[2]){
    output[transi[1,cc],transi[2,cc]]=output[transi[1,cc],transi[2,cc]]+1
  }
  return(output)
}
