#' Plot the average SNP density along the genome to detect any issue
#'
#' @param O : segrating matrix, or list of segrgating matrix
#' @param NC : number of scaffolds
#' @param window : window size in kb on which to calculate the number of SNPs
#' @param print : character string corresponding to the plot name in pdf, e.g. "My_plot.pdf". if NA, plots are not printed in pdf but only displayed
#' @export
#' @return Plots of SNP density along the genome
check_SNP_distribution<-function(O,NC,window=50,print=NA){
  window=window*10^3
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    s=dim(O)[1]
    count=0
    vect_SNP=numeric(floor(L/window))
    for(k in 1:(M-1)){
      for(l in (k+1):M){
        count=count+1
        Os_=seqSNP2_MH(O[c(k,l,(s-1),s),],L,mask_island=10000)
        Os_=as.numeric(Os_$seq)
        vect_SNP= vect_SNP+sapply(1:floor(L/window), function(x){length(which(as.numeric(Os_[(1+((x-1)*window)):(x*window)])==1))/(1-(length(which(as.numeric(Os_[(1+((x-1)*window)):(x*window)])==2))/L) )})
        rm(Os_)
      }
    }
    vect_SNP=vect_SNP/count
    if(!is.na(print)){
      grDevices::pdf(print)
    }
    x=(1:floor(L/window))*window
    graphics::plot(x,vect_SNP,xlab = "Position",ylab = "Nb SNPs per window",type = "l")
    if(!is.na(print)){
      grDevices::dev.off()
    }
  }
  if(NC>1){
    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    if(!is.na(print)){
      grDevices::pdf(print)
    }
    for(chr in 1:NC){

      count=0

      M=(dim(O[[chr]])[1]-2)
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      vect_SNP=numeric(floor(L/window))
      s=dim(O[[chr]])[1]
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          count=count+1
          Os_=seqSNP2_MH(O[[chr]][c(k,l,(s-1),s),],L,mask_island=10000)
          Os_=Os_$seq
          vect_SNP= vect_SNP+sapply(1:floor(L/window),function(x){length(which(as.numeric(Os_[(1+((x-1)*window)):(x*window)])==1))/(1-(length(which(as.numeric(Os_[(1+((x-1)*window)):(x*window)])==2))/L) )})
          rm(Os_)

        }
      }
      vect_SNP=vect_SNP/count
      x=(1:floor(L/window))*window
      graphics::plot(x,vect_SNP,xlab = "Position",ylab = "Nb SNPs per window",type = "l")
    }
    if(!is.na(print)){
      grDevices::dev.off()
    }
  }

}
