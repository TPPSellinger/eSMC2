#' get the genealogy of a subsample from the output of get_genealogy
#'
#' @param genealogy : output of get_genealogy
#' @param ind : index of individual to extract the genealogy
#' @param update_index : TRUE to update index to sample size
#' @return list of size 3 containing matrices describing genealogy. First and second list object contain index of coalescing individual, first coalescent event being in last line and  each column is a different genealogy. Last object sequence length of genealogy on last line and coalescent times on others lines (starting at line M-1)
get_sub_genealogy<-function(genealogy,ind,update_index=T){
  ind=sort(ind)
  old_ind=ind
  M=dim(genealogy$Coal_time)[1]
  good_index=1:length(ind)

  sub_gen=list()
  total_ind=as.numeric(unique(c(genealogy$id_split[,1],genealogy$id_create[,1])))
  rm_ind=total_ind[which(!total_ind%in%ind)]
  if(length(rm_ind)>0){
    for(ind in rm_ind){

      Coal_time=matrix(0,ncol=dim(genealogy$Coal_time)[2],nrow=(M-1))
      id_split=matrix(0,ncol=dim(genealogy$Coal_time)[2],nrow=((M-2)))
      id_create=matrix(0,ncol=dim(genealogy$Coal_time)[2],nrow=(M-2))



      for(cc in 1:dim(genealogy$Coal_time)[2]){
        rm_l_split=which(as.numeric(genealogy$id_split[,cc])==ind)
        if(length(rm_l_split)>0){
          rm_l_split=max(rm_l_split)
        }else{
          rm_l_split=0
        }
        rm_l_create=which(as.numeric(genealogy$id_create[,cc])==ind)
        if(length(rm_l_create)>0){
          rm_l_create=max(rm_l_create)
        }else{
          rm_l_create=0
        }
        if(rm_l_create>rm_l_split){
          rep=as.numeric(genealogy$id_split[rm_l_create,cc])
          rm_ligne= rm_l_create
        }else{
          rep=as.numeric(genealogy$id_create[rm_l_split,cc])
          rm_ligne= rm_l_split
        }
        id_split[,cc]=genealogy$id_split[-rm_ligne,cc]
        id_split[which(id_split[,cc]==ind),cc]<-rep

        id_create[,cc]=genealogy$id_create[-rm_ligne,cc]
        id_create[which(id_create[,cc]==ind),cc]<-rep
        Coal_time[,cc]=genealogy$Coal_time[-rm_ligne,cc]
      }

      genealogy=list()
      genealogy$Coal_time=Coal_time
      genealogy$id_split=id_split
      genealogy$id_create=id_create
      M=dim(genealogy$Coal_time)[1]
    }
  }else{
    Coal_time=genealogy$Coal_time
    id_split=genealogy$id_split
    id_create=genealogy$id_create
  }
  rm(genealogy)
  if(update_index){
  for(m in 1:(length(old_ind)-1)){
    for(rep_ind in 1:length(good_index)){
     pos_rep=which(as.character(id_create[m,])==as.character(old_ind[rep_ind]))
     if(length(pos_rep)>0){
       id_create[m,pos_rep]=letters[rep_ind]
     }
     pos_rep=which(as.character(id_split[m,])==as.character(old_ind[rep_ind]))
     if(length(pos_rep)>0){
       id_split[m,pos_rep]=letters[rep_ind]
     }

    }
    for(rep_ind in 1:length(good_index)){
      pos_rep=which(as.character(id_create[m,])==letters[rep_ind])
      if(length(pos_rep)>0){
        id_create[m,pos_rep]=good_index[rep_ind]
      }
      pos_rep=which(as.character(id_split[m,])==letters[rep_ind])
      if(length(pos_rep)>0){
        id_split[m,pos_rep]=good_index[rep_ind]
      }

    }
  }
  }

  sub_gen$Coal_time=Coal_time
  rm(Coal_time)
  sub_gen$id_split=id_split
  rm(id_split)
  sub_gen$id_create=id_create
  rm(id_create)
  return(sub_gen)
}
















