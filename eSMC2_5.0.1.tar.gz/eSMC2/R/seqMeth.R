#' Build signal for SMCm
#'
#' @param DNA : matrix of segregating and "episegregating" sites of the sample
#' @param n : sequence length
#' @param position_removed : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param mask_island : number of masked position in a row, 1 will give best results but slow algorithm
#' @param nb_meth : number of methylation context
#' @param Free : TRUE to estimate methylation rates from the data (i.e. ignoring what has been inputed)
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param Region_Free : TRUE to estimate region methylation rates from the data (i.e. ignoring what has been inputed)
#' @param window_min : minimum sequence length of a methylated regions
#' @param nb_site_min : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param find_rate : True to find best transition rate
#' @param transition_rate : transition rate to be used to find regions
#' @param P_m : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in methylated regions
#' @param P_d : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in unmethylated regions
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seqMeth<-function(DNA,n,position_removed=NA,mask_island=10000,nb_meth=1,Free=F,Region,Region_Free,window_min=200,nb_site_min=5,find_rate=T,transition_rate=NA,P_m=c(0.8,0.2),P_d=c(0.2,0.8)){
  output=list()
  DNA=as.matrix(DNA)
  good_transition_rate=NA
  if(as.numeric(Region)>0){
    Reg=Seq_Methy(O= DNA,window_min=window_min,nb_site_min=nb_site_min,find_rate=find_rate,transition_rate=transition_rate,P_m=P_m,P_d=P_d)
    good_transition_rate=Reg$good_transition_rate
    if(Region_Free){
      meth_reg_long=Reg$seq[[1]]
      L=length(meth_reg_long)
      transition=which(meth_reg_long[1:(L-1)]!=meth_reg_long[2:(L)])
      meth_reg_long_zip=matrix(0,ncol=length(transition),nrow=3)
      meth_reg_long_zip[1,]=meth_reg_long[transition]
      meth_reg_long_zip[2,]=1+c(0,transition[-length(transition)])
      meth_reg_long_zip[3,]=c(transition -c(0,transition[-length(transition)]))
        number_removed=
        for(sca in 1:2){
          Pos_MD=as.numeric(DNA[4,which(DNA[sca,]%in%c("M","D"))])
          for(reg_id in 1:dim(meth_reg_long_zip)[2]){
            pos_temp=which(Pos_MD[1:min(1000,length(Pos_MD))]>=meth_reg_long_zip[2,reg_id]&Pos_MD[1:min(1000,length(Pos_MD))]<=(meth_reg_long_zip[2,reg_id]-1+meth_reg_long_zip[3,reg_id]))
            if(length(pos_temp)>0){
              Pos_MD_temp=Pos_MD[pos_temp]
              Pos_MD=Pos_MD[-pos_temp]
              if(length(which(Pos_MD_temp%in%c(meth_reg_long_zip[2,reg_id]:(meth_reg_long_zip[2,reg_id]-1+meth_reg_long_zip[3,reg_id]))))<nb_site_min){
                meth_reg_long_zip[1,reg_id]=1
              }
            }else{meth_reg_long_zip[1,reg_id]=1}
        }
      }

      meth_reg_long_zip[1,which(meth_reg_long_zip[3,]< window_min)]=1
      for(reg_id in 1:dim(meth_reg_long_zip)[2]){
        Reg[[2]][[1]][c(meth_reg_long_zip[2,reg_id]:(meth_reg_long_zip[2,reg_id]-1+meth_reg_long_zip[3,reg_id]))]=meth_reg_long_zip[1,reg_id]
      }
      scaling=1
      #scaling=mean(meth_reg_long_zip[3,which(meth_reg_long_zip[1,]%in%c(5,9))])/mean(meth_reg_long_zip[3,which(meth_reg_long_zip[1,]%in%c(6,8))])
      #theta_reg=(length(which(meth_reg_long_zip[1,]%in%c(6,8)))*mean(meth_reg_long_zip[3,which(meth_reg_long_zip[1,]%in%c(6,8))]))/(length(which(meth_reg_long_zip[1,]%in%c(5,6,8,9)))*mean(meth_reg_long_zip[3,which(meth_reg_long_zip[1,]%in%c(5,6,8,9))]))
      theta_reg=(length(which(meth_reg_long_zip[1,]%in%c(6,8))))/(length(which(meth_reg_long_zip[1,]%in%c(5,6,8,9))))

      if(is.na(as.numeric(theta_reg))){
        theta_reg=0
      }
      output$theta_reg=as.numeric(theta_reg)/2
      scaling=1
      pm_reg=(length(which(meth_reg_long_zip[1,]%in%c(5))) + 0.5*(length(which(meth_reg_long_zip[1,]%in%c(6,8)))) )  / (length(which(meth_reg_long_zip[1,]%in%c(9,5,6,8))))
      if(is.na(as.numeric(pm_reg))){
        pm_reg=0
      }
      output$ratio_reg=as.numeric(pm_reg)
    }
    Reg=Reg[[2]][[1]]
    pos=which(DNA[1,]!=DNA[2,])
    seq=rep(0,n)
    seq[as.numeric(DNA[4,pos])]=1
    rm(pos)
    pos_1_M=which(DNA[1,]=="M")
    DNA[1,pos_1_M[which(as.numeric(Reg[as.numeric(DNA[4,pos_1_M])])%in%c(7,8,9))]]="O"
    DNA[1,pos_1_M[which(as.numeric(Reg[as.numeric(DNA[4,pos_1_M])])%in%c(1,2,3))]]="C"
    pos_1_D=which(DNA[1,]=="D")
    DNA[1,pos_1_D[which(as.numeric(Reg[as.numeric(DNA[4,pos_1_D])])%in%c(7,8,9))]]="P"
    DNA[1,pos_1_D[which(as.numeric(Reg[as.numeric(DNA[4,pos_1_D])])%in%c(1,2,3))]]="C"
    pos_2_M=which(DNA[2,]=="M")
    DNA[2,pos_2_M[which(as.numeric(Reg[as.numeric(DNA[4,pos_2_M])])%in%c(3,6,9))]]="O"
    DNA[2,pos_2_M[which(as.numeric(Reg[as.numeric(DNA[4,pos_2_M])])%in%c(1,4,7))]]="C"
    pos_2_D=which(DNA[2,]=="D")
    DNA[2,pos_2_D[which(as.numeric(Reg[as.numeric(DNA[4,pos_2_D])])%in%c(3,6,9))]]="P"
    DNA[2,pos_2_D[which(as.numeric(Reg[as.numeric(DNA[4,pos_2_D])])%in%c(1,4,7))]]="C"
    pos_1_M=which(DNA[1,]=="M")
    pos_1_D=which(DNA[1,]=="D")
    pos_2_M=which(DNA[2,]=="M")
    pos_2_D=which(DNA[2,]=="D")
    pos_1_O=which(DNA[1,]=="O")
    pos_1_P=which(DNA[1,]=="P")
    pos_2_O=which(DNA[2,]=="O")
    pos_2_P=which(DNA[2,]=="P")
    pos_1_C=which(DNA[1,]=="C")
    pos_2_C=which(DNA[2,]=="C")

    pm=(length(pos_1_M)+length(pos_2_M)+(length(pos_1_O)+length(pos_2_O)))/(length(pos_1_M)+length(pos_2_M)+length(pos_1_D)+length(pos_2_D)+(length(pos_1_O)+length(pos_2_O)+length(pos_1_P)+length(pos_2_P)))
    output$pm=pm
    total_1_pos_C=c(pos_1_M,pos_1_D,pos_1_O,pos_1_P,pos_1_C)
    total_2_pos_C=c(pos_2_M,pos_2_D,pos_2_O,pos_2_P,pos_2_C)
    correct_pos=total_1_pos_C[which(total_1_pos_C%in%total_2_pos_C)]
    if(length(correct_pos)>0){
      seq[as.numeric(DNA[4,correct_pos])]=0
    }

    rm(correct_pos)
    rm(total_1_pos_C)
    rm(total_2_pos_C)
    if(as.numeric(Region)==1){

    pos_D=which(pos_1_D%in%pos_2_D)
    seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=3
    pos_M=which(pos_1_M%in%pos_2_M)
    seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=4
    rm(pos_D)
    rm(pos_M)
    pos_MD=which(pos_1_D%in%pos_2_M)
    pos_DM=which(pos_1_M%in%pos_2_D)
    if(length(pos_MD)>0){
      seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=5
    }
    if(length(pos_DM)>0){
      seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=5
    }
    rm(pos_MD)
    rm(pos_DM)
    pos_P=which(pos_1_P%in%pos_2_P)
    seq[as.numeric(DNA[4,pos_1_P[pos_P]])]=6
    pos_O=which(pos_1_O%in%pos_2_O)
    seq[as.numeric(DNA[4,pos_1_O[pos_O]])]=7
    rm(pos_P)
    rm(pos_O)
    pos_OP=which(pos_1_P%in%pos_2_O)
    pos_PO=which(pos_1_O%in%pos_2_P)
    if(length(pos_OP)>0){
      seq[as.numeric(DNA[4,pos_1_P[pos_OP]])]=8
    }
    if(length(pos_PO)>0){
      seq[as.numeric(DNA[4,pos_1_O[pos_PO]])]=8
    }
    rm(pos_PO)
    rm(pos_OP)
    total_1_pos_M=c(pos_1_M,pos_1_D)
    total_1_pos_U=c(pos_1_O,pos_1_P)

    total_2_pos_M=c(pos_2_M,pos_2_D)
    total_2_pos_U=c(pos_2_O,pos_2_P)

    pos_UM=which(total_1_pos_U%in%total_2_pos_M)
    pos_MU=which(total_1_pos_M%in%total_2_pos_U)
    if(length(pos_UM)>0){
      seq[as.numeric(DNA[4,total_1_pos_U[pos_UM]])]=9
    }
    if(length(pos_MU)>0){
      seq[as.numeric(DNA[4,total_1_pos_M[pos_MU]])]=9
    }
    rm(pos_MU)
    rm(pos_UM)
    rm(total_1_pos_M)
    rm(total_2_pos_M)
    rm(total_1_pos_U)
    rm(total_2_pos_U)
    if(Free){
    theta_M=(((length(which(seq%in%c(5,8)))))/length(which(seq%in%c(3,4,5,6,7,8))))
    output$theta_M=as.numeric(theta_M)/2
    output$theta_D=(length(pos_1_D)+length(pos_2_D))/(length(pos_1_D)+length(pos_2_D)+length(pos_1_M)+length(pos_2_M))
    output$theta_O=(length(pos_1_O)+length(pos_2_O))/(length(pos_1_O)+length(pos_2_O)+length(pos_1_P)+length(pos_2_P))

    }

    }
    if(as.numeric(Region)==2){

      total_1_pos_M=c(pos_1_M,pos_1_D)
      total_1_pos_U=c(pos_1_O,pos_1_P)

      total_2_pos_M=c(pos_2_M,pos_2_D)
      total_2_pos_U=c(pos_2_O,pos_2_P)

      pos_UU=which(total_1_pos_U%in%total_2_pos_U)
      if(length(pos_UU)>0){
        seq[as.numeric(DNA[4,total_1_pos_U[pos_UU]])]=3
      }
      rm(pos_UU)
      pos_MM=which(total_1_pos_M%in%total_2_pos_M)
      if(length(pos_MM)>0){
        seq[as.numeric(DNA[4,total_1_pos_M[pos_MM]])]=4
      }
      rm(pos_MM)


      pos_UM=which(total_1_pos_U%in%total_2_pos_M)
      pos_MU=which(total_1_pos_M%in%total_2_pos_U)
      if(length(pos_UM)>0){
        seq[as.numeric(DNA[4,total_1_pos_U[pos_UM]])]=5
      }
      if(length(pos_MU)>0){
        seq[as.numeric(DNA[4,total_1_pos_M[pos_MU]])]=5
      }
      output$theta_M=0


      rm(pos_MU)
      rm(pos_UM)
      rm(total_1_pos_M)
      rm(total_2_pos_M)
      rm(total_1_pos_U)
      rm(total_2_pos_U)

    }
    if(as.numeric(Region)==3){

      pos_D=which(pos_1_D%in%pos_2_D)
      seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=3
      pos_M=which(pos_1_M%in%pos_2_M)
      seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=4
      rm(pos_D)
      rm(pos_M)
      pos_MD=which(pos_1_D%in%pos_2_M)
      pos_DM=which(pos_1_M%in%pos_2_D)
      if(length(pos_MD)>0){
        seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=5
      }
      if(length(pos_DM)>0){
        seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=5
      }
      rm(pos_MD)
      rm(pos_DM)
      pos_P=which(pos_1_P%in%pos_2_P)
      seq[as.numeric(DNA[4,pos_1_P[pos_P]])]=6
      pos_O=which(pos_1_O%in%pos_2_O)
      seq[as.numeric(DNA[4,pos_1_O[pos_O]])]=7
      rm(pos_P)
      rm(pos_O)
      pos_OP=which(pos_1_P%in%pos_2_O)
      pos_PO=which(pos_1_O%in%pos_2_P)
      if(length(pos_OP)>0){
        seq[as.numeric(DNA[4,pos_1_P[pos_OP]])]=8
      }
      if(length(pos_PO)>0){
        seq[as.numeric(DNA[4,pos_1_O[pos_PO]])]=8
      }
      rm(pos_PO)
      rm(pos_OP)
      if(Free){
      theta_M=(((length(which(seq%in%c(5,8)))))/length(which(seq%in%c(3,4,5,6,7,8))))

      output$theta_M=as.numeric(theta_M)/2
      }
    }



    if(!is.na(position_removed)){
      position_to_be_removed=numeric()
      for(ii in 1:length(position_removed)){
        position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
      }
      position_removed=position_to_be_removed
      rm(position_to_be_removed)
    }
    if(any(is.na(seq))){
      browser()
    }
    mask_vector=(as.numeric(DNA[4,-1])-as.numeric(DNA[4,-dim(DNA)[2]]))-as.numeric(DNA[3,-1])
    masked_pos=which(mask_vector>0)+1
    if(length(masked_pos)>0){
      print("Masking sequence")
      for(cc in c(1,masked_pos)){
        if(cc==1){
          if(as.numeric(DNA[3,cc])<(as.numeric(DNA[4,cc])-1)){
            masked_number=as.numeric(DNA[4,cc])-as.numeric(DNA[3,cc])
            if(mask_island==1){
              seq[sample(c(1:(as.numeric(DNA[4,1])-1)),masked_number)]=2
            }else{

              if(masked_number>mask_island){
                nb_island=floor(masked_number/mask_island)
                pos_island=sample(1:floor((as.numeric(DNA[4,1])-1)/mask_island),nb_island)
                for(ppp in pos_island){
                  seq[(1+((ppp-1)*mask_island)):(ppp*mask_island)]=2
                }
              }else{
                seq[1:masked_number]=2
              }
            }
          }
          if(any(is.na(seq))){
            browser()
          }
        }else{
          masked_number=mask_vector[(cc-1)]
          if(mask_island==1){
            seq[sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc)])-1)),masked_number)]=2
          }else{
            if(masked_number>mask_island){
              nb_island=floor(masked_number/mask_island)
              pos_island=sample(1:floor(((as.numeric(DNA[4,cc])-1)-(as.numeric(DNA[4,(cc-1)])+1))/mask_island),nb_island)
              for(ppp in pos_island){
                seq[((as.numeric(DNA[4,(cc-1)])+1)+((ppp-1)*mask_island)):((as.numeric(DNA[4,(cc-1)]))+(ppp*mask_island))]=2
              }
            }else{
              seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc-1)])+masked_number)]=2
            }

          }

          if(any(is.na(seq))){
            browser()
          }
        }

      }
    }

    if(!is.na(position_removed)){
      seq[c(position_removed)]=2
      rm(position_removed)
    }
    if(any(is.na(seq))){
      browser()
    }
    n=length(which(as.numeric(seq)!=2))
    theta=length(which(seq==1))/(n/length(seq))

    print("signal build")
    output$seq=as.numeric(seq)
    output$theta=as.numeric(theta)




  }else{

  pos=which(DNA[1,]!=DNA[2,])
  seq=rep(0,n)

  seq[as.numeric(DNA[4,pos])]=1
  rm(pos)
  pos_1_M=which(DNA[1,]=="M")
  pos_1_D=which(DNA[1,]=="D")

  pos_2_M=which(DNA[2,]=="M")
  pos_2_D=which(DNA[2,]=="D")

  pos_1_C=which(DNA[1,]=="C")
  pos_2_C=which(DNA[2,]=="C")

  correct_pos=unique(c(pos_1_M[which(pos_1_M%in%pos_2_C)],pos_2_M[which(pos_2_M%in%pos_1_C)],pos_1_D[which(pos_1_D%in%pos_2_C)],pos_2_D[which(pos_2_D%in%pos_1_C)]))
  if(length(correct_pos)>0){
    seq[as.numeric(DNA[4,correct_pos])]=0
  }
  pos_M=which(pos_1_M%in%pos_2_M)
  seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=4

  pos_D=which(pos_1_D%in%pos_2_D)
  seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=3
  rm(pos_D)
  rm(pos_M)
  pos_MD=which(pos_1_D%in%pos_2_M)
  pos_DM=which(pos_1_M%in%pos_2_D)

  if(length(pos_MD)>0){
  seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=5
  }
  if(length(pos_DM)>0){
  seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=5
  }


  if(nb_meth==2){
    rm(pos_1_M)
    rm(pos_2_M)
    rm(pos_1_D)
    rm(pos_2_D)
    rm(pos_MD)
    rm(pos_DM)

    pos_1_M=which(DNA[1,]=="O")
    pos_1_D=which(DNA[1,]=="P")

    pos_2_M=which(DNA[2,]=="O")
    pos_2_D=which(DNA[2,]=="P")

    #pos_1_C=which(DNA[1,]=="C")
    #pos_2_C=which(DNA[2,]=="C")

    correct_pos=unique(c(pos_1_M[which(pos_1_M%in%pos_2_C)],pos_2_M[which(pos_2_M%in%pos_1_C)],pos_1_D[which(pos_1_D%in%pos_2_C)],pos_2_D[which(pos_2_D%in%pos_1_C)]))
    if(length(correct_pos)>0){
      seq[as.numeric(DNA[4,correct_pos])]=0
    }
    pos_M=which(pos_1_M%in%pos_2_M)
    seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=7

    pos_D=which(pos_1_D%in%pos_2_D)
    seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=6
    rm(pos_D)
    rm(pos_M)
    pos_MD=which(pos_1_D%in%pos_2_M)
    pos_DM=which(pos_1_M%in%pos_2_D)

    if(length(pos_MD)>0){
      seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=8
    }
    if(length(pos_DM)>0){
      seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=8
    }

  }


  rm(pos_1_M)
  rm(pos_2_M)
  rm(pos_1_D)
  rm(pos_2_D)
  rm(pos_MD)
  rm(pos_DM)
  rm(pos_1_C)
  rm(pos_2_C)


  if(!is.na(position_removed)){
    position_to_be_removed=numeric()
    for(ii in 1:length(position_removed)){
      position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
    }
    position_removed=position_to_be_removed
    rm(position_to_be_removed)
  }
  if(any(is.na(seq))){
    browser()
  }
  mask_vector=(as.numeric(DNA[4,-1])-as.numeric(DNA[4,-dim(DNA)[2]]))-as.numeric(DNA[3,-1])
  masked_pos=which(mask_vector>0)+1
  if(length(masked_pos)>0){
    print("Masking sequence")
  for(cc in c(1,masked_pos)){
    if(cc==1){
      if(as.numeric(DNA[3,cc])<(as.numeric(DNA[4,cc])-1)){
        masked_number=as.numeric(DNA[4,cc])-as.numeric(DNA[3,cc])
         if(mask_island==1){
           seq[sample(c(1:(as.numeric(DNA[4,1])-1)),masked_number)]=2
         }else{

         if(masked_number>mask_island){
           nb_island=floor(masked_number/mask_island)
           pos_island=sample(1:floor((as.numeric(DNA[4,1])-1)/mask_island),nb_island)
           for(ppp in pos_island){
             seq[(1+((ppp-1)*mask_island)):(ppp*mask_island)]=2
           }
         }else{
           seq[1:masked_number]=2
         }
         }
     }
      if(any(is.na(seq))){
        browser()
      }
    }else{
      masked_number=mask_vector[(cc-1)]
      if(mask_island==1){
        seq[sample(c((as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc)])-1)),masked_number)]=2
      }else{
        if(masked_number>mask_island){
          nb_island=floor(masked_number/mask_island)
          pos_island=sample(1:floor(((as.numeric(DNA[4,cc])-1)-(as.numeric(DNA[4,(cc-1)])+1))/mask_island),nb_island)
          for(ppp in pos_island){
            seq[((as.numeric(DNA[4,(cc-1)])+1)+((ppp-1)*mask_island)):((as.numeric(DNA[4,(cc-1)]))+(ppp*mask_island))]=2
          }
        }else{
          seq[(as.numeric(DNA[4,(cc-1)])+1):(as.numeric(DNA[4,(cc-1)])+masked_number)]=2
        }

      }

      if(any(is.na(seq))){
        browser()
      }
    }

  }
  }

  if(!is.na(position_removed)){
    seq[c(position_removed)]=2
    #print('Length of removed sequence:')
    #print(length(position_removed))
    rm(position_removed)
  }
  if(any(is.na(seq))){
    browser()
  }
  n=length(which(as.numeric(seq)!=2))
  theta=length(which(seq==1))/(n/length(seq))

  print("signal build")
  output$seq=as.numeric(seq)
  output$theta=as.numeric(theta)

  if(Free){
    ratio_D_over_M=(length(which(seq==3))+(0.5*length(which(seq==5))))/length(which(seq%in%c(3,4,5)))
    theta_M=((length(which(seq==5))))/length(which(seq%in%c(3,4,5)))
    output$ratio_D_over_M=ratio_D_over_M
    output$theta_M=as.numeric(theta_M)
    if(nb_meth==2){
      ratio_O_over_P=(length(which(seq==6))+(0.5*length(which(seq==8))))/length(which(seq%in%c(6,7,8)))
      theta_O=((length(which(seq==8))))/length(which(seq%in%c(6,7,8)))
      output$ratio_O_over_P=as.numeric(ratio_O_over_P)
      output$theta_O=as.numeric(theta_O)
    }
    output$good_transition_rate=good_transition_rate
  }
  }

  #print("Propotion of sites with methylation information:")
  #print(length(which(output$seq>2))/length(output$seq))

  return(output)
}

