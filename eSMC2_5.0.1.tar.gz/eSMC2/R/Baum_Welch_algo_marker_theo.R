#' Runs the baum-welch algorithm to estimate demographic history, germination , self-fertilization  and recombinationn rate in presence of methylation
#'
#' @param Os : list containing the signal of all analysis
#' @param maxIt : number of expectation and maximization iteration
#' @param L : Sequence length
#' @param theta_W : average theta waterson per chromosome
#' @param Rho : vector of estimated recombination rate per sequence
#' @param Ne : Estimated effective population size
#' @param beta : germination rate
#' @param Popfix : True if population size is assumed constant
#' @param SB : True to estimate germination rate
#' @param k : number of hidden states
#' @param BoxB : vector of  size two which are bounderies of germination rate
#' @param BoxP : vector of  size two which are bounderies of population size. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param Boxr :  vector of  size two which are bounderies of recombination rate. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param maxBit :  number of run of the  baum-welch algorithm (each time using as prior result from precedent run)
#' @param pop_vect :  vector of hidden states sharing population size parameter (sum must be equal to k).
#' @param window_scaling : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param sigma : self-fertilization rate
#' @param SF : True to estimate Self-fertilization rate
#' @param Boxs : vector of  size two which are bounderies of self-fertilization rate
#' @param ER : True to estimation recombination rate
#' @param BW : True to run complete baum-welch implementation
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param redo_R : True to reestimation recombination rate if no convergence reached
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param SCALED : TRUE to scale estimated matrices
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param LH_opt : TRUE to maximize likelihood (not through the Baum-Welch)
#' @param mu_marker : list of size equal to the number of theoretical marker, respectively containing the markers rates in generation per position
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param BoxM :  vector of  size two which are bounderies of theoretical markers. First value gives the -log10 of lower bondery and second value the log10 of upper bondery
#' @param theta : Average rescaled theta per chromosome
#' @return List containing of all model parameters and estimations

Baum_Welch_algo_marker_theo<-function(Os, maxIt =20,L,theta_W,Rho,Ne,beta=1,Popfix=T,SB=F,k=20,BoxB=c(0.1,1),BoxP=c(3,3),Boxr=c(1,1),maxBit=1,pop_vect=NA,window_scaling=c(1,0),sigma=0.00,SF=F,Boxs=c(0,0.97),ER=F,BW=F,NC=1,redo_R=F,mu_b=1,SCALED=F,Big_Window=F,LH_opt=F,mu_marker=list(c(10^-7),c(10^-8),c(10^-9)),Nb_marker=3,nb_state_marker=list(c(2),c(2),c(2)),Marker_supperposition=T,BoxM=c(1,1),theta){
  Xi=NA
  FS=F
  EM=F
  symbol=c()
  if(NC>1){
    for(chr in 1:NC){
      for(i in 1:length(Os[[chr]])){
        symbol=sort(as.numeric(unique(c(symbol,Os[[chr]][[i]][[1]]))))
      }
    }
  }else{
    for(i in 1:length(Os)){
      symbol=sort(as.numeric(unique(c(symbol,Os[[i]][[1]]))))
    }
  }


  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  Ne_o=Ne
  Pop=Popfix
  test.env <- new.env()
  test.env$L <- L
  test.env$Ne <- Ne
  test.env$k <- k
  test.env$mu_marker <- mu_marker
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$BW<-BW
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$mu_b <- mu_b
  test.env$Nb_marker <- Nb_marker
  test.env$Big_Window <- Big_Window
  test.env$nb_state_marker <- nb_state_marker
  test.env$Marker_supperposition <- Marker_supperposition
  if(NC>1){
    npair=NC
    test.env$npair <- NC
    test.env$NC <- NC
  }
  if(NC==1){
    npair=length(Os)
    test.env$npair <- npair
  }
  mb=0
  if(SB){
    BoxB[1]=max(sqrt(0.01),sqrt(BoxB[1]))
    BoxB[2]=min(sqrt(1),sqrt(BoxB[2]))
    beta=max((BoxB[1]^2),beta)
    beta=min(beta,(BoxB[2]^2))
    Beta=beta
  }
  if(SF){
    sigma=min(Boxs[2],sigma)
    sigma=max(sigma,Boxs[1])
    Self=sigma
  }
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=k)){
    Klink=0.5*k
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(!SB&!SF){
    maxBit=1
  }
  if(!SB){
    Beta=beta
    test.env$beta <- beta
  }
  if(!SF){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
  }
  if(!ER){
    Boxr=c(0,0)
  }
  if(!EM){
    BoxM=c(0,0)
  }


  while(mb<maxBit){
    print(paste("Beta:",Beta))
    print(paste("Self:",Self))
    test.env$Beta <- Beta
    test.env$Self <- Self
    test.env$BoxB <- BoxB
    test.env$Boxs <- Boxs
    test.env$BoxM <- BoxM
    mb=mb+1
    diff=1
    it <- 0
    if(SB){
      oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
    }
    if(SF){
      oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
    }



    if(!ER){
      oldrho=0


    }
    if(ER){
      oldrho=(Boxr[1]/sum(Boxr))

    }
    if(!EM){
      oldM=0
    }
    if(EM){
      oldM=(BoxM[1]/sum(BoxM))
    }

    oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
    oldXi=vector()
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    if(!LH_opt){
      Do_BW=T
      diff_conv=vector()
      while (it<maxIt){
        start_time <- Sys.time()
        if(!Do_BW){
          it=0
          oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
          oldXi=vector()
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            oldXi[x:xx]=oldXi_[ix]
          }
        }
        it <- it+1;
        print(paste("It:",it))
        if(Popfix){
          rho_=oldrho*sum(Boxr)
          rho_=rho_-(Boxr[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
          if(SB){
            beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          }
          if(SF){
            sigma=oldsigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
          }
          print(c("sigma:",sigma,"beta :",beta))
          print(c("rho/theta:",rho_/theta))
          Keep_going=F
          if(it==1){
            diff_o=0
          }
          if(it>1){
            gamma_temp=mean(rho_/theta)
            diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta),abs(gamma_temp_o-gamma_temp))
            count_diff_o=0
            if(diff_o>=0.005){
              if(it==maxIt){
                count_diff_o=count_diff_o+1
                maxIt=maxIt+1
              }
            }
          }
          sigma_o=sigma
          beta_o=beta
          gamma_temp_o=mean(rho_/theta)
          if(NC==1){
            builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
          if(NC>1){
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
          }
        }
        if(!Popfix){
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            oldXi[x:xx]=oldXi_[ix]
          }
          Xi_=oldXi*sum(BoxP)
          Xi_=Xi_-(BoxP[1])
          Xi_=10^Xi_
          rho_=oldrho*sum(Boxr)
          rho_=rho_-(Boxr[1])
          rho_=10^(rho_)
          rho_=rho_*Rho
          if(SB){
            beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          }
          if(SF){
            sigma=oldsigma*(Boxs[2]-Boxs[1])
            sigma=sigma+Boxs[1]
          }
          print(c("sigma:",sigma,"beta :",beta))
          print(c("rho/theta:",rho_/theta))
          Keep_going=F
          if(it==1){
            diff_o=0
          }
          if(it>1){
            diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta))
            count_diff_o=0
            if(diff_o>=0.005){
              if(it==maxIt){
                count_diff_o=count_diff_o+1
                maxIt=maxIt+1
              }
            }
          }
          sigma_o=sigma
          beta_o=beta

          if(NC==1){
            builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
          }
          if(NC>1){
            builder=list()
            for(chr in 1:NC){
              builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
            }
          }
        }



        if(NC==1){
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)
          M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
          N=matrix(0,length(Tc),length(Tc))
          MLH=0
          q_=rep(0,length(Tc))
          test=Build_zip_Matrix_mailund_marker_theo(Q,g,Os[[1]][[2]],nu)

          for(i in 1:length(Os)){
            fo=forward_zip_mailund_marker_theo(as.numeric(Os[[i]][[1]]),g,nu,test[[1]])
            MLH=MLH+fo[[3]]
            c=exp(fo[[2]])
            ba=Backward_zip_mailund_marker_theo(as.numeric(Os[[i]][[1]]),test[[3]],length(Tc),c)
            W_P=list()
            W_P_=list()
            for(oo in 1:dim(g)[2]){
              int=t(Q)%*%diag(g[,oo])
              int=eigen(int)
              W_P[[oo]]=int$vectors
              W_P_[[oo]]=solve(W_P[[oo]])
            }


            #print( symbol)
            for(ob in 1){
              truc_M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
              if(as.numeric(Os[[i]][[1]][(ob+1)])<10){
                truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                truc_M[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
              }else{
                truc_N=(t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))%*%diag(g[,(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]))
                truc_M[,(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]=diag(t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))
              }
              N=N+truc_N
              M=M+truc_M
            }
            for(sym in sort(as.numeric(symbol))){
              ob=as.numeric(sym)
              pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
              if(length(pos)>0){
                pos=pos+1

                if(ob<10){
                  ba_t=t(t(ba[,(pos)])/c[(pos)])
                  truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                  truc=(truc/(sum(truc)))*length(pos)
                  M[,(ob+1)]=M[,(ob+1)]+ truc
                  truc_N=(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                  N=N+truc_N
                }else{
                  A=(t(W_P[[(floor(log10(((ob)))))]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[(floor(log10(((ob)))))]]))
                  A_=A*test[[2]][[(ob)]]
                  A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                  M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10(((ob)))))]+(diag(A_))
                  A_=A*test[[4]][[(ob)]]
                  A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                  truc_N=((A_%*%diag(g[,(floor(log10(((ob)))))])))
                  N=N+truc_N
                }
              }
            }

            if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<10){
              M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]=M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
            }
            if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])>9){
              M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10((as.numeric((ob))))))]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
            }
            q_=q_+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
          }

          N=N*t(Q)

          if(is.complex(N)){
            N=Re(N)
          }

          if(is.complex(M)){
            M=Re(M)
          }
          print("Initial:N")
          print(sum(N))
          Scale_N=(L-1)/sum(N)
          N=N*Scale_N
          print("Corrected:N")
          print(sum(N))
          q_=q_/sum(q_)
          print("Initial:M")
          print(sum(M))
          Scale_M=L/sum(M)
          M=M*Scale_M
          print("Corrected:M")
          print(sum(M))
          # browser()

          if(SCALED){
            corrector_N=rowSums(N)
            N=diag(1/corrector_N)%*%N
            corrector_M=rowSums(M)
            M=diag(1/corrector_M)%*%M
          }
        }
        if(NC>1){
          M_all=list()
          N_all=list()
          q_all=list()
          MLH=0
          for(chr in 1:NC){

          Q = builder[[chr]][[1]]
          nu= builder[[chr]][[2]]
          Tc=builder[[chr]][[3]]
          g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[chr]][[4]],builder[[chr]][[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)
          M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
          N=matrix(0,length(Tc),length(Tc))

          q_=rep(0,length(Tc))
          test=Build_zip_Matrix_mailund_marker_theo(Q,g,Os[[chr]][[1]][[2]],nu)

          for(i in 1:length(Os[[chr]])){
            fo=forward_zip_mailund_marker_theo(as.numeric(Os[[chr]][[i]][[1]]),g,nu,test[[1]])
            MLH=MLH+fo[[3]]
            c=exp(fo[[2]])
            ba=Backward_zip_mailund_marker_theo(as.numeric(Os[[chr]][[i]][[1]]),test[[3]],length(Tc),c)
            W_P=list()
            W_P_=list()
            for(oo in 1:dim(g)[2]){
              int=t(Q)%*%diag(g[,oo])
              int=eigen(int)
              W_P[[oo]]=int$vectors
              W_P_[[oo]]=solve(W_P[[oo]])
            }


            #print( symbol)
            for(ob in 1){
              truc_M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
              if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])<10){
                truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
                truc_M[,(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
              }else{
                truc_N=(t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])*test[[4]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]]))%*%diag(g[,(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]))
                truc_M[,(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]=diag(t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]]))*test[[2]][[(as.numeric(Os[[chr]][[i]][[1]][(ob+1)]))]]%*%t(W_P[[(floor(log10((as.numeric(Os[[chr]][[i]][[1]][(ob+1)])))))]]))
              }
              N=N+truc_N
              M=M+truc_M
            }
            for(sym in sort(as.numeric(symbol))){
              ob=as.numeric(sym)
              pos=which(as.numeric(Os[[chr]][[i]][[1]][-c(1,length(Os[[chr]][[i]][[1]]))])==ob)
              if(length(pos)>0){
                pos=pos+1

                if(ob<10){
                  ba_t=t(t(ba[,(pos)])/c[(pos)])
                  truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
                  truc=(truc/(sum(truc)))*length(pos)
                  M[,(ob+1)]=M[,(ob+1)]+ truc
                  truc_N=(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
                  N=N+truc_N
                }else{
                  A=(t(W_P[[(floor(log10(((ob)))))]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[(floor(log10(((ob)))))]]))
                  A_=A*test[[2]][[(ob)]]
                  A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                  M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10(((ob)))))]+(diag(A_))
                  A_=A*test[[4]][[(ob)]]
                  A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
                  truc_N=((A_%*%diag(g[,(floor(log10(((ob)))))])))
                  N=N+truc_N
                }
              }
            }

            if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])<10){
              M[,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]=M[,(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])+1)]+(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])
            }
            if(as.numeric(Os[[chr]][[i]][[1]][length(Os[[chr]][[i]][[1]])])>9){
              M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10((as.numeric((ob))))))]+((fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])])/sum(fo[[1]][,length(Os[[chr]][[i]][[1]])]*ba[,length(Os[[chr]][[i]][[1]])]))
            }
            q_=q_+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
          }

          N=N*t(Q)

          if(is.complex(N)){
            N=Re(N)
          }

          if(is.complex(M)){
            M=Re(M)
          }
          print("Initial:N")
          print(sum(N))
          Scale_N=(L-1)/sum(N)
          N=N*Scale_N
          print("Corrected:N")
          print(sum(N))
          q_=q_/sum(q_)
          print("Initial:M")
          print(sum(M))
          Scale_M=L/sum(M)
          M=M*Scale_M
          print("Corrected:M")
          print(sum(M))
          # browser()

          if(SCALED){
            corrector_N=rowSums(N)
            N=diag(1/corrector_N)%*%N
            corrector_M=rowSums(M)
            M=diag(1/corrector_M)%*%M
          }
          M_all[[chr]]=M
          N_all[[chr]]=N
          q_all[[chr]]=q_
          }

        }


        if(it>1){
          print(paste(" old Likelihood: ",oldMLH))
        }
        Do_BW=T
        if(NC==1){
          print(paste(" New Likelihood: ",MLH))

          if(it>1){

            if(oldMLH > MLH|MLH=="NaN"){

              if(!Popfix){
                oldXi_=oldXi_s
              }
              if(ER){
                oldrho=oldrho_s
              }
              if(SB){
                oldbeta=oldbeta_s
              }
              if(SF){
                oldsigma=oldsigma_s
              }
              Do_BW=F

            }else{
              Do_BW=T
            }

          }
          oldMLH=MLH
        }
        if(NC>1){

          print(paste("New Likelihood: ",MLH))
          if(it>1){
            if(oldMLH > MLH|MLH=="NaN"){
              if(it>1){

                if(!Popfix){
                  oldXi_=oldXi_s
                }
                if(ER){
                  oldrho=oldrho_s
                }
                if(SB){
                  oldbeta=oldbeta_s
                }
                if(SF){
                  oldsigma=oldsigma_s
                }
              }
              Do_BW=F
            }else{
              Do_BW=T
            }

          }
          oldMLH=MLH
        }


        if(NC==1){
          test.env$Big_Xi <- N
          test.env$Big_M <-M
          test.env$q_ <-q_
        }
        if(NC>1){
          test.env$Big_Xi <- N_all
          test.env$Big_M <-M_all
          test.env$q_ <-q_all
        }

        if(!Popfix){
          oldXi_s=oldXi_
        }
        if(ER){
          oldrho_s=oldrho
        }
        if(SB){
          oldbeta_s=oldbeta
        }
        if(SF){
          oldsigma_s=oldsigma
        }
        lr=length(oldrho)
        test.env$lr<-lr
        if(Do_BW){
          if(NC==1){

           #it==1

              test.env$ER <- ER
              test.env$SF <- SF
              test.env$SB <- SB




              function_to_minimize<-function(param){
                Boxr=get('Boxr', envir=test.env)
                npair=get('npair', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                FS=get('FS', envir=test.env)
                Klink=get('Klink', envir=test.env)
                Rho=get('Rho', envir=test.env)
                BoxB=get('BoxB', envir=test.env)
                Boxs=get('Boxs', envir=test.env)
                BoxP=get('BoxP', envir=test.env)
                pop_vect=get('pop_vect', envir=test.env)
                L=get('L', envir=test.env)
                n=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                window_scaling=get('window_scaling', envir=test.env)
                Pop=get('Pop', envir=test.env)
                ER=get('ER', envir=test.env)
                SF=get('SF', envir=test.env)
                SB=get('SB', envir=test.env)
                Big_Xi=get('Big_Xi', envir=test.env)
                nb_state_marker=get('nb_state_marker', envir=test.env)
                Nb_marker=get('Nb_marker', envir=test.env)
                mu_marker=get('mu_marker', envir=test.env)
                Marker_supperposition=get('Marker_supperposition', envir=test.env)
                start_position=0
                if(ER==1){
                  rho=param[(start_position+1):(start_position+1)]
                  rho=rho*sum(Boxr)
                  rho=rho-(Boxr[1])
                  rho=10^(rho)
                  rho_=rho*Rho
                  start_position=start_position+1
                }
                if(ER==0){
                  rho_=Rho
                }
                if(SF==1){
                  sigma_=param[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  sigma_=sigma_*(Boxs[2]-Boxs[1])
                  sigma_=sigma_+Boxs[1]
                }
                if(SF==0){
                  sigma_=sigma
                }
                if(SB==1){
                  beta_=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                  start_position=start_position+1
                }
                if(SB==0){
                  beta_=beta
                }
                if(!Pop){
                  Xi=numeric(n)
                  Xi_=param[(start_position+1):(start_position+Klink)]
                  xx=0
                  for(ix in 1:Klink){
                    x=xx+1
                    xx = xx + pop_vect[ix]
                    Xi[x:xx]=Xi_[ix]
                  }
                  Xi=Xi*sum(BoxP)
                  Xi=Xi-(BoxP[1])
                  Xi=10^Xi
                }else{
                  Xi=rep(1,n)
                }

                builder=build_HMM_matrix(n,rho_,beta,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q = builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi)>0)
                A=A[keep]
                Big_Xi=as.vector(Big_Xi)
                Big_Xi=Big_Xi[keep]
                if(BW){
                  nu= builder[[2]]
                  Tc=builder[[3]]
                  Big_M=get('Big_M', envir=test.env)
                  Ne=get('Ne', envir=test.env)
                  g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)
                  x=as.vector(g)
                  keep=which(x>0)
                  x=x[keep]
                  m=as.vector(Big_M)
                  m=m[keep]
                  q_=get('q_', envir=test.env)
                  nu=builder[[2]]

                  LH=-sum(log(A)*Big_Xi)-sum(log(x)*m)-sum(log(nu)*q_)
                }
                if(!BW){
                  LH=-sum(log(A)*Big_Xi)
                }
                return(LH)
              }

              param=c()
              if(ER==1){
                param=c(param,oldrho)
              }

              if(SF==1){
                param=c(param,oldsigma)
              }

              if(SB==1){
                param=c(param,oldbeta)
              }

              if(!Popfix){
                param=c(param,oldXi_)
              }

              if(length(param)>0){
                sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=(length(param)+10),M=c(20)))
                sol=as.matrix(sol[[1]])
                start_position=0
                sol=as.numeric(sol[1:length(param),1])



                if(ER==1){
                  rho=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldrho=rho
                }
                if(SF==1){
                  sigma_=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldsigma=sigma_
                }


                if(SB==1){
                  beta_=sol[(start_position+1):(start_position+1)]
                  start_position=start_position+1
                  oldbeta=beta_
                }


                if(!Popfix){
                  Xi_=sol[(start_position+1):(start_position+Klink)]
                  start_position=start_position+Klink
                  oldXi_=Xi_
                }

              }





          }
          if(NC>1){


            test.env$ER <- ER
            test.env$SF <- SF
            test.env$SB <- SB




            function_to_minimize<-function(param){
              Boxr=get('Boxr', envir=test.env)
              npair=get('npair', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              FS=get('FS', envir=test.env)
              Klink=get('Klink', envir=test.env)
              Rho=get('Rho', envir=test.env)
              BoxB=get('BoxB', envir=test.env)
              Boxs=get('Boxs', envir=test.env)
              BoxP=get('BoxP', envir=test.env)
              pop_vect=get('pop_vect', envir=test.env)
              L=get('L', envir=test.env)
              n=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              window_scaling=get('window_scaling', envir=test.env)
              Pop=get('Pop', envir=test.env)
              ER=get('ER', envir=test.env)
              SF=get('SF', envir=test.env)
              SB=get('SB', envir=test.env)
              Big_Xi=get('Big_Xi', envir=test.env)
              nb_state_marker=get('nb_state_marker', envir=test.env)
              Nb_marker=get('Nb_marker', envir=test.env)
              mu_marker=get('mu_marker', envir=test.env)
              NC=get('NC', envir=test.env)
              Marker_supperposition=get('Marker_supperposition', envir=test.env)
              start_position=0
              if(ER==1){
                rho=param[(start_position+1):(start_position+NC)]
                rho=rho*sum(Boxr)
                rho=rho-(Boxr[1])
                rho=10^(rho)
                rho_=rho*Rho
                start_position=start_position+NC
              }
              if(ER==0){
                rho_=Rho
              }
              if(SF==1){
                sigma_=param[(start_position+1):(start_position+1)]
                start_position=start_position+1
                sigma_=sigma_*(Boxs[2]-Boxs[1])
                sigma_=sigma_+Boxs[1]
              }
              if(SF==0){
                sigma_=sigma
              }
              if(SB==1){
                beta_=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
                start_position=start_position+1
              }
              if(SB==0){
                beta_=beta
              }
              if(!Pop){
                Xi=numeric(n)
                Xi_=param[(start_position+1):(start_position+Klink)]
                xx=0
                for(ix in 1:Klink){
                  x=xx+1
                  xx = xx + pop_vect[ix]
                  Xi[x:xx]=Xi_[ix]
                }
                Xi=Xi*sum(BoxP)
                Xi=Xi-(BoxP[1])
                Xi=10^Xi
              }else{
                Xi=rep(1,n)
              }

              LH=0
              for(chr in 1:NC){
                builder=build_HMM_matrix(n,rho_[chr],beta,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
                Q = builder[[1]]
                Q=t(Q)
                A=as.vector(Q)
                keep=which(A>0&as.vector(Big_Xi[[chr]])>0)
                A=A[keep]
                Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
                Big_Xi[[chr]]=Big_Xi[[chr]][keep]
                if(BW){
                  nu= builder[[2]]
                  Tc=builder[[3]]
                  Big_M=get('Big_M', envir=test.env)
                  Ne=get('Ne', envir=test.env)
                  g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)
                  x=as.vector(g)
                  keep=which(x>0)
                  x=x[keep]
                  m=as.vector(Big_M[[chr]])
                  m=m[keep]
                  q_=get('q_', envir=test.env)
                  nu=builder[[2]]

                  LH=LH-sum(log(A)*Big_Xi[[chr]])-sum(log(x)*m)-sum(log(nu)*q_)
                }
                if(!BW){
                  LH=LH-sum(log(A)*Big_Xi[[chr]])
                }
              }


              return(LH)
            }

            param=c()
            if(ER==1){
              param=c(param,oldrho)
            }

            if(SF==1){
              param=c(param,oldsigma)
            }

            if(SB==1){
              param=c(param,oldbeta)
            }

            if(!Popfix){
              param=c(param,oldXi_)
            }

            if(length(param)>0){
              sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=(length(param)+10),M=c(20)))
              sol=as.matrix(sol[[1]])
              start_position=0
              sol=as.numeric(sol[1:length(param),1])



              if(ER==1){
                rho=sol[(start_position+1):(start_position+NC)]
                start_position=start_position+NC
                oldrho=rho
              }
              if(SF==1){
                sigma_=sol[(start_position+1):(start_position+1)]
                start_position=start_position+1
                oldsigma=sigma_
              }


              if(SB==1){
                beta_=sol[(start_position+1):(start_position+1)]
                start_position=start_position+1
                oldbeta=beta_
              }
              if(!Popfix){
                Xi_=sol[(start_position+1):(start_position+Klink)]
                start_position=start_position+Klink
                oldXi_=Xi_
              }

            }


          }
        }else{
          it=maxIt
        }

        if(diff_o>=0.003){
          diff=(max(diff_o,diff))
        }
        diff_conv=c(diff_conv,diff_o)
        end_time <- Sys.time()
        print(end_time-start_time)
        if(it==maxIt&ER){
          if(any(abs(oldrho-oldrho_s)>0.1)){
            maxIt=maxIt+5
          }
        }
      }
    }else{
      if(NC==1){



        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$Os <- Os



        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          npair=get('npair', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          FS=get('FS', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Self=get('Self', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          nb_state_marker=get('nb_state_marker', envir=test.env)
          Nb_marker=get('Nb_marker', envir=test.env)
          mu_marker=get('mu_marker', envir=test.env)
          Marker_supperposition=get('Marker_supperposition', envir=test.env)
          start_position=0
          if(ER==1){
            rho=param[(start_position+1):(start_position+1)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho_=rho*Rho
            start_position=start_position+1

          }
          if(ER==0){
            rho_=Rho
          }
          if(SF==1){
            sigma_=numeric(n)
            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma_=sigma+Boxs[1]
          }
          if(SF==0){
            sigma_=sigma
          }
          if(SB==1){
            beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1
            beta_=beta
          }
          if(SB==0){
            beta_=beta
          }
          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          builder=build_HMM_matrix(n,rho_,beta=beta_,Pop = Pop,Xi=Xi,L=L,Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
          Q = builder[[1]]
          nu= builder[[2]]
          Tc=builder[[3]]
          g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)
          MLH=0
          test=Build_zip_Matrix_mailund_marker_theo(Q,g,Os[[1]][[2]],nu,do_all=F)
          for(i in 1:length(Os)){
            fo=forward_zip_mailund_marker_theo(as.numeric(Os[[i]][[1]]),g,nu,test[[1]])
            MLH=MLH-fo[[3]]
          }
          return(MLH)
        }



        param=c()
        if(ER==1){
          param=c(param,oldrho)

        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=50+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0


        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+1)]
          start_position=start_position+1
          oldrho=rho
        }
        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+1)]
          start_position=start_position+1
          oldsigma=sigma_
        }
        if(SB==1){
          beta_=sol[(start_position+1):(start_position+1)]
          start_position=start_position+1
          oldbeta=beta_
        }
        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }



      }


      if(NC>1){

        test.env$ER <- ER
        test.env$SF <- SF
        test.env$SB <- SB
        test.env$Os <- Os
        test.env$NC <- NC


        function_to_minimize<-function(param){
          Boxr=get('Boxr', envir=test.env)
          npair=get('npair', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          FS=get('FS', envir=test.env)
          Klink=get('Klink', envir=test.env)
          Rho=get('Rho', envir=test.env)
          BoxB=get('BoxB', envir=test.env)
          Boxs=get('Boxs', envir=test.env)
          BoxP=get('BoxP', envir=test.env)
          pop_vect=get('pop_vect', envir=test.env)
          L=get('L', envir=test.env)
          n=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Self=get('Self', envir=test.env)
          window_scaling=get('window_scaling', envir=test.env)
          Pop=get('Pop', envir=test.env)
          ER=get('ER', envir=test.env)
          SF=get('SF', envir=test.env)
          SB=get('SB', envir=test.env)
          Os=get('Os', envir=test.env)
          NC=get('NC', envir=test.env)
          start_position=0
          if(ER==1){
            rho=param[(start_position+1):(start_position+NC)]
            rho=rho*sum(Boxr)
            rho=rho-(Boxr[1])
            rho=10^(rho)
            rho_=rho*Rho
            start_position=start_position+NC
          }


          if(ER==0){
            rho_=Rho
          }
          if(SF==1){
            sigma=param[(start_position+1):(start_position+1)]
            start_position=start_position+1
            sigma=sigma*(Boxs[2]-Boxs[1])
            sigma_=sigma+Boxs[1]
          }

          if(SF==0){
            sigma_=sigma
          }
          if(SB==1){
            beta_=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
            start_position=start_position+1
          }

          if(SB==0){
            beta_=beta
          }
          if(!Pop){
            Xi=numeric(n)
            Xi_=param[(start_position+1):(start_position+Klink)]
            xx=0
            for(ix in 1:Klink){
              x=xx+1
              xx = xx + pop_vect[ix]
              Xi[x:xx]=Xi_[ix]
            }
            Xi=Xi*sum(BoxP)
            Xi=Xi-(BoxP[1])
            Xi=10^Xi
          }else{
            Xi=rep(1,n)
          }
          MLH=0
          for(chr in 1:NC){
            builder=build_HMM_matrix(n,rho_[chr],beta=beta_,Pop = Pop,Xi=Xi,L=L[chr],Beta=Beta,scale=window_scaling,sigma = sigma_,Sigma = Self,Big_Window=Big_Window,npair=npair)
            Q = builder[[1]]
            nu= builder[[2]]
            Tc=builder[[3]]
            g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)
            test=Build_zip_Matrix_mailund_marker_theo(Q,g,Os[[chr]][[1]][[2]],nu,do_all=F)
            for(i in 1:length(Os[[chr]])){
              fo=forward_zip_mailund_marker_theo(as.numeric(Os[[chr]][[i]][[1]]),g,nu,test[[1]])
              MLH=MLH-fo[[3]]
            }
          }
          return(MLH)
        }



        param=c()
        if(ER==1){
            param=c(param,oldrho)
        }
        if(SF==1){
          param=c(param,oldsigma)
        }
        if(SB==1){
          param=c(param,oldbeta)
        }
        if(!Popfix){
          param=c(param,oldXi_)
        }


        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=50+length(param),M=c(20)))
        LH=as.numeric(as.matrix(sol[[2]]))
        sol=as.matrix(sol[[1]])
        start_position=0


        sol=as.numeric(sol[1:length(param),1])
        if(ER==1){
          rho=sol[(start_position+1):(start_position+NC)]
          start_position=start_position+NC
          oldrho=rho
        }
        if(SF==1){
          sigma_=sol[(start_position+1):(start_position+1)]
          start_position=start_position+1
          oldsigma=sigma_
        }
        if(SB==1){
          beta_=sol[(start_position+1):(start_position+1)]
          start_position=start_position+1
          oldbeta=beta_
        }
        if(!Popfix){
          Xi_=sol[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          oldXi_=Xi_
        }
      }
    }

    if(Popfix){
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(NC==1){
        builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair )
      }
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair )
        }
      }
    }
    if(!Popfix){
      xx=0
      for(ix in 1:Klink){
        x=xx+1
        xx = xx + pop_vect[ix]
        oldXi[x:xx]=oldXi_[ix]
      }
      Xi_=oldXi*sum(BoxP)
      Xi_=Xi_-(BoxP[1])
      Xi_=10^Xi_
      rho_=oldrho*sum(Boxr)
      rho_=rho_-(Boxr[1])
      rho_=10^(rho_)
      rho_=rho_*Rho
      if(SB){
        beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
      }
      if(SF){
        sigma=oldsigma*(Boxs[2]-Boxs[1])
        sigma=sigma+Boxs[1]
      }
      if(NC==1){
        builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
      }
      if(NC>1){
        builder=list()
        for(chr in 1:NC){
          builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
        }
      }
    }
    if(NC==1){
      Q = builder[[1]]
      nu= builder[[2]]
      Tc=builder[[3]]
      g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)

      Tc_r=builder[[4]]
    }
    if(NC>1){
      Q=list()
      nu=list()
      Tc=list()
      Tc_r=list()
      g=list()
      for(chr in 1:NC){
        Q[[chr]] = builder[[chr]][[1]]
        nu[[chr]]= builder[[chr]][[2]]
        Tc[[chr]]=builder[[chr]][[3]]
        Tc_r[[chr]]=builder[[chr]][[4]]
        g[[chr]]=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[chr]][[4]],builder[[chr]][[3]],beta,nb_state_marker,Nb_marker,Marker_supperposition)

      }
    }

    Tc_or=Tc_r
    Tc_o=Tc
    if(!Popfix){
      Xi_t=oldXi_
      Xit=vector()
      pop_vect=get('pop_vect', envir=test.env)
      xx=0
      for(ix in 1:length(Xi_t)){
        x=xx+1
        xx = xx + pop_vect[ix]
        Xit[x:xx]=Xi_t[ix]
      }
      Xit=Xit*sum(BoxP)
      Xit=Xit-(BoxP[1])
      Xit=10^Xit
    }
    rho_t=oldrho*sum(Boxr)
    rho_t=rho_t-(Boxr[1])
    rho_t=10^(rho_t)
    rho_t=rho_t*Rho
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }



    gamma_t=rho_t/theta
    rho_t=rho_t/(2*L)


    if(!SB){
      oldBeta=Beta
    }
    if(SB){
      oldBeta=Beta
      Beta=beta
    }
    if(SF){
      oldSelf=Self
      Self=sigma
    }
    if(!SF){
      oldSelf=Self
    }
    if(Beta==oldBeta&Self==oldSelf){
      mb=maxBit
      print("no need  for more iteration")
    }
  }



  if(NC==1){



    res<-list()
    res$Tc=Tc_or
    Q=t(Q)
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho
    rho_=rho_/(2*L*Ne)
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }

    if(!Popfix){
      res$Xi=Xi_
    }
    res$mu_marker=mu_marker
    res$mu=theta/(2*L*Ne)
    res$beta=beta
    res$sigma=sigma
    res$rho=rho_
    res$Ne=Ne
    if(!LH_opt){
      res$N=N
      res$M=M
      res$q_=q_
    }


  }
  if(NC>1){

    res <- list();
    res$mu_marker=mu_marker
    res$Tc=Tc_or[[1]]
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho
    rho_=rho_/(2*L*Ne)
    if(SB){
      beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1] )^2
    }
    if(SF){
      sigma=oldsigma*(Boxs[2]-Boxs[1])
      sigma=sigma+Boxs[1]
    }

    if(!Popfix){
      res$Xi=Xi_
    }
    res$beta=beta
    res$sigma=sigma
    res$rho=rho_
    if(!LH_opt){
      res$N=N_all
      res$M=M_all
      res$q_=q_all
    }
    res$Ne=Ne
    res$mu=theta/(2*L*Ne)
  }
  return(res)
}

