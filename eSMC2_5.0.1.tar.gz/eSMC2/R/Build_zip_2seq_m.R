#' Zip the  signal to reduce signal length
#'
#' @param  Os : original signal
#' @param max_count : maximum number of symbol
#' @return A list containing the zip sequence and the symbol matrix
Build_zip_2seq_m<-function(Os,max_count=20){
  ini=Os[1]
  Os=Os[-1]
  count=0
  output=list()
  criteria=T
  mat_symbol=vector()
  l=vector()
  L=length(Os)
  print("Original length")
  print(L)
  while(criteria){
    count=count+1
    new_symbol=LETTERS[count]
    L=length(Os)
    impair=cbind(seq(1,(L-1),2),seq(2,L,2))
    pair=cbind(seq(2,(L-1),2),seq(3,L,2))
    tot_pair=rbind(impair,pair)
    rm(impair)
    rm(pair)
    pattern=rbind(as.vector(as.matrix(paste(Os[tot_pair[,1]],Os[tot_pair[,2]],sep=""))),tot_pair[,1],tot_pair[,2])
    rm(tot_pair)
    symbol=unique(pattern[1,])
    nb_symbol=length(symbol)
    count_symbol=rep(0,nb_symbol)
    pos_s=vector()
    for(k in 1:nb_symbol){
      test=as.numeric(as.matrix(pattern[2,which(pattern[1,]==symbol[k])]))
      x=length(test)
      test=c(test,c(test+1))
      coef=length(unique(test))/length(test)
      count_symbol[k]=x*coef
    }
    rm(pattern)
    rm(test)
    rep_symbol=as.vector(symbol[which(count_symbol==max(count_symbol))])[1]
    pos_s=gregexpr(rep_symbol,paste(as.character(Os),collapse = ""))
    pos_s=as.vector(as.matrix(pos_s[[1]]))

    mat_symbol=rbind(mat_symbol,c(new_symbol,rep_symbol),l[length(l)])
    Os[pos_s]=new_symbol
    pos_s=pos_s+1
    Os=Os[-pos_s]

    if(count>=max_count)
    {
      criteria=F
    }

  }
  Os=c(ini,Os)
  L=length(Os)
  print("final length")
  print(L)
  output[[1]]=Os
  output[[2]]=mat_symbol
  return(output)
}
