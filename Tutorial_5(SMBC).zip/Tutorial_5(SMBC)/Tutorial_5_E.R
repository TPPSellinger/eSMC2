###################
# Source function #
###################
library(eSMC2)
########
#Script#
########
M=10 # sample size 
nsim=3 # number of replicate
Pop=10^6 # population size used for simulation
mu_v <-c(10^-6,10^-7,10^-8,10^-8)
L=10^7 # sequence length
rho=1 # recombination rate / mutation rate
  n=40 # number of hidden state
  Pop_size=vector()
  x_ab=c(seq(0,1000,1),seq(1001,10^5,10),seq((1+10^5),10^7,10^3))
    count_a=0
    mu_ex=matrix(0,4,nsim)
    alpha_ex=matrix(0,4,nsim)
    r_ex=matrix(0,4,nsim)
    Ne_ex=matrix(0,4,nsim)
    mat_save_p=matrix(0,4*nsim,n)
    mat_save_t=matrix(0,4*nsim,n)
    alpha_v=c(1.3,1.5,1.7,1.9)
    alpha_s=numeric(length = (nsim*4))
    setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
    theta_file=read.table("Tutorial_5_E_SNPs.txt",sep = " ")$V1
    theta_counter=0
    for(alpha in c(1.3,1.5,1.7,1.9)){ # 
      count_a=which(alpha_v==alpha)
      mu=mu_v[count_a]
      print(mu)
      total=list()
      Tc=list()
      Os=list()
      
      
      for(x in 1:nsim){
          theta_counter=theta_counter+1
          setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
          name=paste("Tutortial_5_E_",alpha,"_arg-sample_r",mu,"m",mu,"_1-10000000_",(x-1),".1000.txt",sep ="" )
          theta=theta_file[theta_counter]
          test=Optimize_SMBC_N(file=name,ploidy = 1,mu=mu,simulator="argweaver",gamma=1,L=L,n=n,alpha=1.99,Boxa=c(1.01,1.9999),BoxP=c(3,3),Boxr=c(1,1),pop=T,B=T,ER=T,NC=1,window_scaling = c(1,0),M=M,M_a=3,decimal_separator = "\\.",Reg=F,pop_vect = rep(4,10),theta=theta)
          mat_save_p[(((count_a-1)*nsim)+x),]=as.numeric(test$Xi)*test$Ne
          mat_save_t[(((count_a-1)*nsim)+x),]=test$Tc*(test$mu/(mu))
          alpha_ex[count_a,x]=(test$alpha)
          mu_ex[count_a,x]=(test$mu)
          r_ex[count_a,x]=(test$rho/test$mu)
          Ne_ex[count_a,x]=(test$Ne)
      }
      
    
    }
    print("Estimated alpha: ")
    print(alpha_ex)
    
    if(F){
    write.csv(Ne_ex,file = paste("Tutorial_5_E_Ne.csv",sep="_"))
    write.csv(mu_ex,file = paste("Tutorial_5_E_mu.csv",sep="_"))
    write.csv(r_ex,file = paste("Tutorial_5_E_rho.csv",sep="_"))
    write.csv(alpha_ex,file = paste("Tutorial_5_E_alpha.csv",sep="_"))
    write.csv(mat_save_p,file = paste("Tutorial_5_E_pop.csv",sep="_"))
    write.csv(mat_save_t,file = paste("Tutorial_5_E_Tc.csv",sep="_"))
    }
  

    

    
