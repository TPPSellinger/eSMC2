###################
# Source function #
###################
library(eSMC2)
########
#Script#
########
beta=1
sigma=0
M=10
nsim=2
Pop=10^6
mu <-10^-8#theta/(4*Pop*L)
total_r=list()
Tc_r=list()
mu_r=list()
alpha_r=list()
r_r=list()
Ne_r=list()
L=10^8
theta=mu*4*Pop*L
theta_o=theta
rho=1
rho_o=rho*theta
total_m=list()
Tc_m=list()
mu_m=list()
alpha_m=list()
r_m=list()
Ne_m=list()
sa_m=list()
n=40
Pop_size=vector()
x_ab=c(seq(0,1000,1),seq(1001,10^5,10),seq((1+10^5),10^7,10^3))
if(T){
  sum=0
  count=0
  mat_t=vector()
  for(i in seq(1,6,1)){
    if((i %% 2) == 0) {
      time_e=(10^i)/(2*10^4)
      time_e_1=((10^i)+0.5*(10^i))/(2*10^4)
      v_t=c(time_e,log(0.2)/abs(time_e-time_e_1))
      
      mat_t=rbind(mat_t,v_t)
      time_e=((10^i)+0.5*(10^i))/(2*10^4)
      time_e_1=((10^(i+1)))/(2*10^4)
      v_t=c(time_e,log(5)/abs(time_e-time_e_1))
      mat_t=rbind(mat_t, v_t)
    } else {
      time_e=(10^i)/(2*10^4)
      time_e_1=((10^i)+0.5*(10^i))/(2*10^4)
      v_t=c(time_e,log(5)/abs(time_e-time_e_1))
      
      mat_t=rbind(mat_t,v_t)
      time_e=((10^i)+0.5*(10^i))/(2*10^4)
      time_e_1=((10^(i+1)))/(2*10^4)
      v_t=c(time_e,log(0.2)/abs(time_e-time_e_1))
      mat_t=rbind(mat_t, v_t)
    }
    
    
  }
  v_t=c((10^(i+1))/(2*10^4),1)
  mat_t=rbind(mat_t, v_t)
  for(t in x_ab){
    t=t/(2*10^4)
    count=0
    if(t<=mat_t[dim(mat_t)[1],1]){
      Pop_t=Pop
      if(t>mat_t[1,1]){
        l=which(mat_t[1:(dim(mat_t)[1]-1),1]<t)
        for(x in 1:length(l)){
          if(x<length(l)){
            Pop_t=Pop_t*exp(-(mat_t[x+1,1]-mat_t[x,1])*mat_t[x,2])
          }
          if(x==length(l)){
            Pop_t=Pop_t*exp(-(t-mat_t[x,1])*mat_t[x,2])
          }
        }
      }
      Pop_size=c(Pop_size,Pop_t)
      count=count+1
    }
    if(t>mat_t[dim(mat_t)[1],1]){
      Pop_size=c(Pop_size,Pop)
      count=count+1
    }
    
    if(count>1|length(Pop_t)>1|count==0){
      sef
    }
  }
}
count_a=0
mu_ex=matrix(0,4,nsim)
alpha_ex=matrix(0,nsim,100)
# sa_ex=matrix(0,4,nsim)
r_ex=matrix(0,4,nsim)
Ne_ex=matrix(0,4,nsim)
mat_save_p=matrix(0,4*nsim,n)
mat_save_t=matrix(0,4*nsim,n)
for(alpha in c(1.9)){
  count_a=count_a+1
  total=list()
  Tc=list()
  for(x in 1:nsim){
    setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
    NC=1
    rho=1
    test=Optimize_SMBC_N(file=paste("Tutorial_5_A_alpha",alpha,"x",x,".txt",sep ="" ),ploidy = 1,mu=mu,simulator="msprime",gamma= 1,L=L,n=n,alpha=1.99,Boxa=c(1.01,1.9999),BoxP=c(2,2),Boxr=c(2,2),pop=T,B=T,ER=T,NC=NC,window_scaling = c(1,0),M=M,M_a=3,decimal_separator = ",",pop_vect = rep(4,10),Reg = T)
    mat_save_p[(((count_a-1)*nsim)+x),]=as.numeric(test$Xi)*test$Ne
    mat_save_t[(((count_a-1)*nsim)+x),]=test$Tc*(test$mu/(2*mu))
    alpha_ex[x,]=(test$alpha)
    mu_ex[count_a,x]=(test$mu)
    r_ex[count_a,x]=(test$rho/test$mu)
    Ne_ex[count_a,x]=(test$Ne)
  }
}


gen=1
par(mfrow=c(1,2),pty="s")
for(count_a in 1){
  
  plot(c(1,100),c(1,2), ylim =c(1,2) ,xlim = c(0,100)  , type="n", xlab= "Position on the sequence in Mb", ylab="alpha")

  for(x in 1:nsim){
    lines(seq(1,100,1), alpha_ex[x,], type="s", col="red")
  }
  
  lines(x_ab,log10(Pop_size), type="s", col="black")
  if(count_a==1){
    legend("topright",legend=c("SMBC","True"), col=c("red","black"), lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
  }
  abline(h=1.9,col="black")
  
  plot(c(1,10^7),c(1,1), log=c("x"), ylim =c(4,8) , type="n", xlab= "Generations ago", ylab="population size (log10)")

  
  for(x in 1:nsim){
    lines(mat_save_t[(((count_a-1)*nsim)+x),], log10(mat_save_p[(((count_a-1)*nsim)+x),]), type="s", col="red")
  }
  
  lines(x_ab,log10(Pop_size), type="s", col="black")
  if(count_a==1){
    legend("topright",legend=c("SMBC","True"), col=c("red","black"), lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
  }
  
}  

# dev.off()
