###################
# Source function #
###################
library(eSMC2)
########
#Script#
########
M=10 # sample size 
nsim=3 # number of replicate
Pop=10^6 # population size used for simulation
mu_v <-c(10^-8,10^-8,10^-7,10^-6) # vector of mutation rate used
L=10^7 # sequence length
rho=1 # recombination rate / mutation rate
n=40 # number of hidden state
    count_a=0
    mu_ex=matrix(0,4,nsim)
    alpha_ex=matrix(0,4,nsim)
    r_ex=matrix(0,4,nsim)
    Ne_ex=matrix(0,4,nsim)
    mat_save_p=matrix(0,4*nsim,n)
    mat_save_t=matrix(0,4*nsim,n)
    alpha_v=c(1.9,1.7,1.5,1.3)
    alpha_s=numeric(length = (nsim*4))
    for(alpha in c(1.3,1.5,1.7,1.9)){ # ,1.7,1.5,1.3
      count_a=which(alpha_v==alpha)
      mu=mu_v[count_a]
      for(x in 1:nsim){
        setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
          Os=read_msprime_data(paste("Tutorial_5_D_alpha",alpha,"mu",mu,"r",rho*mu,"x",x,"L",as.integer(L),".txt",sep ="" ),M)
          Os=Os[c(1,2,3,4,5,11,12),1:5000] # Uncomment if > 50G of memory is available
          results=SMBC(n=40,rho=1,O=Os,BoxP=c(2,2),alpha =1.9,pop =T,B=T,ER=T,LH_opt = F,ploidy=1,mu_real=mu,pop_vect = rep(4,10))
          mat_save_p[(((count_a-1)*nsim)+x),]=as.numeric(results$Xi)*results$Ne
          mat_save_t[(((count_a-1)*nsim)+x),]=results$Tc*(results$mu/(mu))
          alpha_ex[count_a,x]=(results$alpha)
          mu_ex[count_a,x]=(results$mu)
          r_ex[count_a,x]=(results$rho/results$mu)
          Ne_ex[count_a,x]=(results$Ne)
        
      }

      
      #print(res)
      
        for(x in 1:nsim){
          test=res[[x]]
          mat_save_p[(((count_a-1)*nsim)+x),]=as.numeric(test$Xi)*test$Ne
          mat_save_t[(((count_a-1)*nsim)+x),]=test$Tc*(test$mu/(mu))
          alpha_ex[count_a,x]=(test$alpha)
          mu_ex[count_a,x]=(test$mu)
          r_ex[count_a,x]=(test$rho/test$mu)
          Ne_ex[count_a,x]=(test$Ne)
        }

      #print(prior_alpha)
    }
    
    
    
    print(alpha_ex)

    if(F){
      write.csv(Ne_ex,file = paste("Tutorial_5_D_Ne.csv",sep="_"))
      write.csv(mu_ex,file = paste("Tutorial_5_D_mu.csv",sep="_"))
      write.csv(r_ex,file = paste("Tutorial_5_D_rho.csv",sep="_"))
      write.csv(alpha_ex,file = paste("Tutorial_5_D_alpha.csv",sep="_"))
      write.csv(mat_save_p,file = paste("Tutorial_5_D_pop.csv",sep="_"))
      write.csv(mat_save_t,file = paste("Tutorial_5_D_Tc.csv",sep="_"))
    }


