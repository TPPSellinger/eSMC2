###################
# Source function #
###################
library(MASS)
library(readr)
library(rlist)
library(expm)
library(BB)
library(parallel)
library(combinat)
library(GenomicRanges)
library(data.table)
library(eSMC2, lib.loc="~/R/x86_64-redhat-linux-gnu-library/3.6")
################################

########
#Script#
########



for(M in c(10)){
  Tc_esmc=list()
  Tc_smcm=list()
  total_esmc=list()
  total_smcm=list()
  nchr=1
  mu <- 6.95*10^-9
  r=c(3.4*10^(-8),3.6*10^(-8),3.5*10^(-8),3.8*10^(-8),3.6*10^(-8))
  rho=r/mu
  mu_ex=matrix(0,ncol = 1,nrow=4)
  rm_ex=matrix(0,ncol = 1,nrow=4)
  Ne_t=matrix(0,nrow=3,ncol=1)
  SB=F
  SF=T
  ER=F
  
  total=list()
  total_=list()
  total__=list()
  total___=list()
  Tc=list()
  Tc_=list()
  Tc__=list()
  Tc___=list()
  
  # esmc
  setwd("~/Documents/eSMC2_tutorial/Tutorial_7(SMCm)") # Path to data
  file_SNP=paste("intersection_",c(9783,9794,9808,9809,9810,9811,9812,9816,9813,9814),".vcf",sep="")
  file_methylation=paste("methylome_",c(9783,9794,9808,9809,9810,9811,9812,9816,9813,9814),".txt",sep="")

  Os_=Get_real_methylation_data(file_SNP,file_methylation,hap=T)
  Os_=Os_[[1]]
  #stop()
  #
  for(chr in 1:length(Os_)){
    for(kk in 1:M){
      pos_U=which(Os_[[chr]][kk,]=="U")
      if(length(pos_U)>0){
        Os_[[chr]][kk,pos_U]<-"P"
      }
      rm(pos_U)
      pos_M=which(Os_[[chr]][kk,]=="M")
      if(length(pos_M)>0){
        Os_[[chr]][kk,pos_M]<-"O"
      }
      rm(pos_M)
    }
    if(T){
      genes <- fread("TAIR10_genes.bed")
      genes=subset(genes,genes$V1==chr)
      genes=subset(genes,genes$V6=="+")
      gene_pos=c()
      for(ii in 1:length(genes$V2)){
        gene_pos=c(gene_pos,genes$V2[ii]:genes$V3[ii])
      }
      pos_m=which(as.numeric(Os_[[chr]][dim(Os_[[chr]])[1],])%in%gene_pos)
    }else{
      pos_m=1:dim(Os_[[chr]])[2]
    }
    
    
    for(kk in 1:M){
      pos_o=which(Os_[[chr]][kk,]=="O")
      pos_p=which(Os_[[chr]][kk,]=="P")
      pos_mm=pos_o[which(pos_o%in%pos_m)]
      pos_md=pos_p[which(pos_p%in%pos_m)]
      rm(pos_o)
      rm(pos_p)
      if(length(pos_mm)>0){
        Os_[[chr]][kk,pos_mm]="M"
      }
      rm(pos_mm)
      if(length(pos_md)>0){
        Os_[[chr]][kk,pos_md]="D"
      }
      rm(pos_md)
      pos_O=which(Os_[[chr]][kk,]=="O")
      if(length(pos_O)>0){
        Os_[[chr]][kk,pos_O]<-"C"
      }
      rm(pos_O)
      pos_P=which(Os_[[chr]][kk,]=="P")
      if(length(pos_P)>0){
        Os_[[chr]][kk,pos_P]<-"C"
      }
      rm(pos_P)
    }
    
    for(nucl in c("A","T","C","G")){
      for(m in 1:M){
        pos=as.numeric(which(Os_[[chr]][m,]%in%c(nucl)))
        if(m==1){
          rm_pos=pos
        }else{
          rm_pos=rm_pos[which(rm_pos%in%pos)]
        }
        if(m==M){
          if(length(rm_pos)>0){
            Os_[[chr]]=Os_[[chr]][,-rm_pos]
          }
          Os_[[chr]][(M+1),]=as.numeric(Os_[[chr]][(M+2),])-as.numeric(c(1,Os_[[chr]][(M+2),-dim(Os_[[chr]])[2]]))
        }
      }
    }
    
    create_realinput_meth_msmc2(Os_[[chr]],paste("Input_Tutorial_7_D",chr,sep ="" ))
  }
}

