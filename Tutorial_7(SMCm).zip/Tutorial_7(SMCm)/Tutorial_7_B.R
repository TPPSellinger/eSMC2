###################
# Source function #
###################
library(eSMC2, lib.loc="~/R/x86_64-redhat-linux-gnu-library/3.6")
################################

########
#Script#
########
nsim=2
M=10
M_s=M
mu <- 10^-8
r=10^-8
rho=r/mu
p_meth=0.01
  mu_ex=matrix(0,ncol = 3,nrow=8)
  rm_ex=matrix(0,ncol = 3,nrow=8)
  Ne_t=matrix(0,nrow=8,ncol=1)
  SB=F
  SF=F
  ER=T
  rate_m=3.5*10^(-4)
  rate_d=1.5*10^(-3)
  rate_m_reg=2*10^(-4)
  rate_d_reg=10^(-3)
  Pop=10^3
  Pop_size=vector()
  x_ab=c(seq(0,Pop,0.00001*Pop),seq((Pop+0.0001*Pop),10*Pop,0.0001*Pop),seq(((10*Pop)+(0.01*Pop)),100*Pop,0.01*Pop),seq(((100*Pop)+(0.01*Pop)),1000*Pop,5*Pop))
  mat_t=vector()
  time_e=0
  time_e_1=400
  v_t=c(time_e,log(10)/abs(time_e-time_e_1))
  mat_t=rbind(mat_t,v_t)
  for(t in x_ab){
    count=0
    if(t<=400){
      Pop_t=Pop*exp(-(t-v_t[1])*v_t[2])
    }
    if(t>400){
      Pop_t=Pop*100
    }
    Pop_size=c(Pop_size,Pop_t)
  }
  for(model in 1:3){
    if(model==1){
      results_site=list()
      for(x in 1:nsim){
        M=M_s
        O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_site_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,11,12),]
        results_site[[x]]=SMCm(n=40,rho= rho,methylation=c(abs(log10(rate_m)),abs(log10(rate_d))),O,mu_r=(mu),maxit =20,pop=F,SB=F,SF=F,ER=T,NC=1,mu_b=1,Region=F,Big_Window = 4,window_scaling=c(2,0))
        }
    }

    if(model==2){
      results_region=list()
      for(x in 1:nsim){
        M=M_s
        O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_region_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,11,12),]
        results_region[[x]]=SMCm(n=40,rho= rho,O,mu_r=(mu),BoxP=c(3,3),Boxr=c(1,1),nb_site_min=4,window_min=100,pop=F,SB=F,ER=T,SF=F,NC=1,Big_Window = 4,Region=2,region_methylation = c(abs(log10(rate_m_reg)),abs(log10(rate_d_reg))),window_scaling=c(2,0))
        
      }
    }
    
    
    if(model==3){
      results_site_and_region=list()
      for(x in 1:nsim){
        M=M_s
        O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_site_and_region_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,11,12),]
        results_site_and_region[[x]]=SMCm(n=40,rho= rho,methylation=c(abs(log10(rate_m)),abs(log10(rate_d))),O,mu_r=(mu),BoxP=c(3,3),Boxr=c(1,1),nb_site_min=4,window_min=100,pop=F,SB=F,ER=T,SF=F,NC=1,Big_Window = 4,Region=T,region_methylation = c(abs(log10(rate_m_reg)),abs(log10(rate_d_reg))),window_scaling=c(2,0))
        
      }
    }
    
    
  }
  results_eSMC2=list()
  for(x in 1:nsim){
    M=M_s
    O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_site_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,11,12),]
    M=dim(O)[1]-2
    for(m in 1:M){
      pos=as.numeric(which(O[m,]%in%c("M","D","C")))
      O[m,pos]="C"
    }
    results_eSMC2[[x]]=eSMC2(n=40,rho=rho,O,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,Rho=T,NC=1,mu_b=1,sigma=0,beta=1,Big_Window = 4,LH_opt = F,window_scaling=c(2,0))
  }
  

  

    gen <- 1
    col_u=c("red","orange","green","blue","purple")
    mat_save_p=matrix(NA,nrow=(nsim*4),ncol=40)
    mat_save_t=matrix(NA,nrow=(nsim*4),ncol=40)
    mat_save_r=matrix(NA,nrow=(nsim*4),ncol=1)
    count_p=0
    count_t=0
    count_r=0

    plot(c(1,2*10^6),c(1,1), log=c("x"), ylim =c(1,7) ,
         type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")
    for(x in 1:nsim){
      
      lines((results_site[[x]]$Tc*results_site[[x]]$Ne), log10(results_site[[x]]$Xi*0.5*results_site[[x]]$Ne), type="s", col=col_u[1])
      count_p=count_p+1
      count_t=count_t+1
      count_r=count_r+1
      mat_save_p[count_p,]=log10(results_site[[x]]$Xi*0.5*results_site[[x]]$Ne)
      mat_save_t[count_t,]=(results_site[[x]]$Tc*results_site[[x]]$Ne)
      mat_save_r[count_r,]=results_site[[x]]$rho/results_site[[x]]$mu
      
      
      lines((results_region[[x]]$Tc*results_region[[x]]$Ne), log10(results_region[[x]]$Xi*0.5*results_region[[x]]$Ne), type="s", col=col_u[2])
      count_p=count_p+1
      count_t=count_t+1
      count_r=count_r+1
      mat_save_p[count_p,]=log10(results_region[[x]]$Xi*0.5*results_region[[x]]$Ne)
      mat_save_t[count_t,]=(results_region[[x]]$Tc*results_region[[x]]$Ne)
      mat_save_r[count_r,]=results_region[[x]]$rho/results_region[[x]]$mu
      
      
      lines((results_site_and_region[[x]]$Tc*results_site_and_region[[x]]$Ne), log10(results_site_and_region[[x]]$Xi*0.5*results_site_and_region[[x]]$Ne), type="s", col=col_u[3])
      count_p=count_p+1
      count_t=count_t+1
      count_r=count_r+1
      mat_save_p[count_p,]=log10(results_site_and_region[[x]]$Xi*0.5*results_site_and_region[[x]]$Ne)
      mat_save_t[count_t,]=(results_site_and_region[[x]]$Tc*results_site_and_region[[x]]$Ne)
      mat_save_r[count_r,]=results_site_and_region[[x]]$rho/results_site_and_region[[x]]$mu

      
      Pop=results_eSMC2[[x]]$mu/mu
      lines((results_eSMC2[[x]]$Tc*Pop), log10(results_eSMC2[[x]]$Xi*0.5*Pop), type="s", col=col_u[4])
      count_p=count_p+1
      count_t=count_t+1
      count_r=count_r+1
      mat_save_p[count_p,]=log10(results_eSMC2[[x]]$Xi*0.5*Pop)
      mat_save_t[count_t,]=(results_eSMC2[[x]]$Tc*Pop)
      mat_save_r[count_r,]=results_eSMC2[[x]]$rho/results_eSMC2[[x]]$mu
      
    }
    legend("topright",legend=c("SMCm_site","SMCm_region","SMCm_site_and_region","eSMC2"), col=col_u[1:4], lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
    lines(x_ab,log10(Pop_size), type="s", col="black")
    write.csv(mat_save_p,file = paste("Tutorial_7_B_mat_save_p_real.csv",sep="_"))
    write.csv(mat_save_t,file = paste("Tutorial_7_B_mat_save_t_real.csv",sep="_"))
    write.csv(mat_save_r,file = paste("Tutorial_7_B_mat_save_r_real.csv",sep="_"))
  
