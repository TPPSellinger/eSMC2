###################
# Source function #
###################
library(eSMC2, lib.loc="~/R/x86_64-redhat-linux-gnu-library/3.6")
################################

########
#Script#
########
nsim=2
M=10
M_s=M
mu <- 10^-8
r=10^-8
rho=r/mu
p_meth=0.01
mu_ex=matrix(0,ncol = 3,nrow=8)
rm_ex=matrix(0,ncol = 3,nrow=8)
Ne_t=matrix(0,nrow=8,ncol=1)
SB=F
SF=F
ER=T
rate_m=3.5*10^(-4)
rate_d=1.5*10^(-3)
rate_m_reg=2*10^(-4)
rate_d_reg=10^(-3)
# esmc
for(model in 1:3){
  if(model==1){
    results_site=list()
    for(x in nsim){
      M=M_s
      O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_site_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,3,4,5,6,11,12),]
      M=dim(O)[1]-2
    # Testing for region effect 
      test_results=Test_region_effect(O)
      print(test_results)
    # Estimating rates
      Estimation_results=Methylation_rate_estimation(n=40,rho= rho,methylation=c(abs(log10(rate_m)),abs(log10(rate_d))),O,mu_r=(mu),NC=1,mu_b=1,Region=F,Free = T)
      print(Estimation_results$mu_m)
    # Calculation LDdecay for epimutations
      Os=O
      rm_pos=c()
      nb_methy=0
      pos_M=c()
      pos_D=c()
      for(m in 1:M){
        
        pos_M_temp=as.numeric(which(Os[m,]%in%c("M")))
        pos_D_temp=as.numeric(which(Os[m,]%in%c("D")))
        pos_D=as.numeric(unique(c(pos_D,pos_D_temp)))
        pos_M=as.numeric(unique(c(pos_M,pos_M_temp)))
      }
      keep_methy=pos_M[which(pos_M%in%pos_D)]
      print(length(keep_methy))
      remove_M=pos_M[which(!(pos_M%in%pos_D))]
      remove_D=pos_D[which(!(pos_D%in%pos_M))]
      remove_methy=sort(as.numeric(unique(c(remove_M,remove_D))))
      for(m in 1:M){
        pos_M_temp=as.numeric(which(Os[m,]%in%c("M")))
        pos_D_temp=as.numeric(which(Os[m,]%in%c("D")))
        pos_MC=pos_M_temp[which(pos_M_temp%in%remove_methy)]
        pos_DC=pos_D_temp[which(pos_D_temp%in%remove_methy)]
        pos_C=as.numeric(unique(c(pos_MC,pos_DC)))
        Os[m,pos_C]="C"
      }
      Ld_methylation=LD_methy(Os,NC=1,D_max = 1000)
      plot_mat=rbind(Ld_methylation[1,],Ld_methylation[2,])
      to_plot=matrix(0, nrow = 2, ncol = 14)
      count_d=0
      for(dd in seq(0.4,3,0.2)){
        count_d=count_d+1
        good_pos=which( plot_mat[2,]<=10^dd)
        if(length(good_pos)>0){
          to_plot[1,count_d]=mean(plot_mat[1,good_pos])
          to_plot[2,count_d]=10^dd  
          plot_mat=plot_mat[,-good_pos]
        }
      }
      plot(c(1,10),c(0,0.5), ylim =c(0,1) ,xlim=c(1,10^3),
           type="n", xlab= paste("Distance in bp",sep=" "), ylab="Average r² ",main = "r² decay of epimutations")
      lines(to_plot[2,], to_plot[1,], type="s", col="black")
      
      
      
      # Calculation LD decay for  mutations
      
      Os=O
      rm_pos=c()
      nb_methy=0
      pos_M=c()
      pos_D=c()
      for(m in 1:M){
        
        pos_MD=as.numeric(which(Os[m,]%in%c("M","D")))
        Os[m,pos_MD]="C"
        
      }
      Ld_mutation=LD_mut(Os,NC=1,D_max = 10000000)
      plot_mat=rbind(Ld_mutation[1,],Ld_mutation[2,])
      plot(c(1,10),c(0,0.5), ylim =c(0,1) ,xlim=c(10,10^7),
           type="n", xlab= paste("Distance in bp",sep=" "), ylab="Average r² ",main = "r² decay of mutations",log=c("x"))
      to_plot=matrix(0, nrow = 2, ncol = length(seq(1,7,0.2)))
      count_d=0
      for(dd in seq(1,6,0.2)){
        count_d=count_d+1
        good_pos=which( plot_mat[2,]<=10^dd)
        if(length(good_pos)>0){
          to_plot[1,count_d]=mean(plot_mat[1,good_pos])
          to_plot[2,count_d]=10^dd  
          plot_mat=plot_mat[,-good_pos]
        }
      }
      lines(to_plot[2,], to_plot[1,], type="s", col="black")
      
      }
  }
  
  if(model==2){
    results_region=list()
    for(x in nsim){
      M=M_s
      O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_region_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,3,4,5,6,11,12),]
      M=dim(O)[1]-2
      # Testing for region effect 
      test_results=Test_region_effect(O)
      print(test_results)
      # Estimating rates
      Estimation_results=Methylation_rate_estimation(n=40,rho= rho,methylation=c(abs(log10(rate_m)),abs(log10(rate_d))),O,mu_r=(mu),NC=1,mu_b=1,Region=T,Free = F,Region_Free=T)
      print(Estimation_results$mu_m)
      # Calculation LDdecay for epimutations
      Os=O
      rm_pos=c()
      nb_methy=0
      pos_M=c()
      pos_D=c()
      for(m in 1:M){
        
        pos_M_temp=as.numeric(which(Os[m,]%in%c("M")))
        pos_D_temp=as.numeric(which(Os[m,]%in%c("D")))
        pos_D=as.numeric(unique(c(pos_D,pos_D_temp)))
        pos_M=as.numeric(unique(c(pos_M,pos_M_temp)))
      }
      keep_methy=pos_M[which(pos_M%in%pos_D)]
      print(length(keep_methy))
      remove_M=pos_M[which(!(pos_M%in%pos_D))]
      remove_D=pos_D[which(!(pos_D%in%pos_M))]
      remove_methy=sort(as.numeric(unique(c(remove_M,remove_D))))
      for(m in 1:M){
        pos_M_temp=as.numeric(which(Os[m,]%in%c("M")))
        pos_D_temp=as.numeric(which(Os[m,]%in%c("D")))
        pos_MC=pos_M_temp[which(pos_M_temp%in%remove_methy)]
        pos_DC=pos_D_temp[which(pos_D_temp%in%remove_methy)]
        pos_C=as.numeric(unique(c(pos_MC,pos_DC)))
        Os[m,pos_C]="C"
      }
      Ld_methylation=LD_methy(Os,NC=1,D_max = 1000)
      plot_mat=rbind(Ld_methylation[1,],Ld_methylation[2,])
      to_plot=matrix(0, nrow = 2, ncol = 14)
      count_d=0
      for(dd in seq(0.4,3,0.2)){
        count_d=count_d+1
        good_pos=which( plot_mat[2,]<=10^dd)
        if(length(good_pos)>0){
          to_plot[1,count_d]=mean(plot_mat[1,good_pos])
          to_plot[2,count_d]=10^dd  
          plot_mat=plot_mat[,-good_pos]
        }
      }
      plot(c(1,10),c(0,0.5), ylim =c(0,1) ,xlim=c(1,10^3),
           type="n", xlab= paste("Distance in bp",sep=" "), ylab="Average r² ",main = "r² decay of epimutations")
      lines(to_plot[2,], to_plot[1,], type="s", col="black")
      
      
      
      # Calculation LD decay for  mutations
      
      Os=O
      rm_pos=c()
      nb_methy=0
      pos_M=c()
      pos_D=c()
      for(m in 1:M){
        
        pos_MD=as.numeric(which(Os[m,]%in%c("M","D")))
        Os[m,pos_MD]="C"
        
      }
      Ld_mutation=LD_mut(Os,NC=1,D_max = 10000000)
      plot_mat=rbind(Ld_mutation[1,],Ld_mutation[2,])
      plot(c(1,10),c(0,0.5), ylim =c(0,1) ,xlim=c(10,10^7),
           type="n", xlab= paste("Distance in bp",sep=" "), ylab="Average r² ",main = "r² decay of mutations",log=c("x"))
      to_plot=matrix(0, nrow = 2, ncol = length(seq(1,7,0.2)))
      count_d=0
      for(dd in seq(1,6,0.2)){
        count_d=count_d+1
        good_pos=which( plot_mat[2,]<=10^dd)
        if(length(good_pos)>0){
          to_plot[1,count_d]=mean(plot_mat[1,good_pos])
          to_plot[2,count_d]=10^dd  
          plot_mat=plot_mat[,-good_pos]
        }
      }
      lines(to_plot[2,], to_plot[1,], type="s", col="black")
    }
  }
  
  
  if(model==3){
    results_site_and_region=list()
    for(x in nsim){
      M=M_s
      O=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M=M,paste("Tutorial_7_B_site_and_region_x",x,"_pmeth_",p_meth,".txt",sep ="" )))[c(1,2,3,4,5,6,11,12),]
      M=dim(O)[1]-2
      # Testing for region effect 
      test_results=Test_region_effect(O)
      print(test_results)
      # Estimating rates
      Estimation_results=Methylation_rate_estimation(n=40,rho= rho,methylation=c(abs(log10(rate_m)),abs(log10(rate_d))),O,mu_r=(mu),NC=1,mu_b=1,Region=T,Free = T,Region_Free=T)
      print(Estimation_results$mu_m)
      # Calculation LDdecay for epimutations
      Os=O
      rm_pos=c()
      nb_methy=0
      pos_M=c()
      pos_D=c()
      for(m in 1:M){
        
        pos_M_temp=as.numeric(which(Os[m,]%in%c("M")))
        pos_D_temp=as.numeric(which(Os[m,]%in%c("D")))
        pos_D=as.numeric(unique(c(pos_D,pos_D_temp)))
        pos_M=as.numeric(unique(c(pos_M,pos_M_temp)))
      }
      keep_methy=pos_M[which(pos_M%in%pos_D)]
      print(length(keep_methy))
      remove_M=pos_M[which(!(pos_M%in%pos_D))]
      remove_D=pos_D[which(!(pos_D%in%pos_M))]
      remove_methy=sort(as.numeric(unique(c(remove_M,remove_D))))
      for(m in 1:M){
        pos_M_temp=as.numeric(which(Os[m,]%in%c("M")))
        pos_D_temp=as.numeric(which(Os[m,]%in%c("D")))
        pos_MC=pos_M_temp[which(pos_M_temp%in%remove_methy)]
        pos_DC=pos_D_temp[which(pos_D_temp%in%remove_methy)]
        pos_C=as.numeric(unique(c(pos_MC,pos_DC)))
        Os[m,pos_C]="C"
      }
      Ld_methylation=LD_methy(Os,NC=1,D_max = 1000)
      plot_mat=rbind(Ld_methylation[1,],Ld_methylation[2,])
      to_plot=matrix(0, nrow = 2, ncol = 14)
      count_d=0
      for(dd in seq(0.4,3,0.2)){
        count_d=count_d+1
        good_pos=which( plot_mat[2,]<=10^dd)
        if(length(good_pos)>0){
          to_plot[1,count_d]=mean(plot_mat[1,good_pos])
          to_plot[2,count_d]=10^dd  
          plot_mat=plot_mat[,-good_pos]
        }
      }
      plot(c(1,10),c(0,0.5), ylim =c(0,1) ,xlim=c(1,10^3),
           type="n", xlab= paste("Distance in bp",sep=" "), ylab="Average r² ",main = "r² decay of epimutations")
      lines(to_plot[2,], to_plot[1,], type="s", col="black")
      
      
      
      # Calculation LD decay for  mutations
      
      Os=O
      rm_pos=c()
      nb_methy=0
      pos_M=c()
      pos_D=c()
      for(m in 1:M){
        
        pos_MD=as.numeric(which(Os[m,]%in%c("M","D")))
        Os[m,pos_MD]="C"
        
      }
      Ld_mutation=LD_mut(Os,NC=1,D_max = 10000000)
      plot_mat=rbind(Ld_mutation[1,],Ld_mutation[2,])
      plot(c(1,10),c(0,0.5), ylim =c(0,1) ,xlim=c(10,10^7),
           type="n", xlab= paste("Distance in bp",sep=" "), ylab="Average r² ",main = "r² decay of mutations",log=c("x"))
      to_plot=matrix(0, nrow = 2, ncol = length(seq(1,7,0.2)))
      count_d=0
      for(dd in seq(1,6,0.2)){
        count_d=count_d+1
        good_pos=which( plot_mat[2,]<=10^dd)
        if(length(good_pos)>0){
          to_plot[1,count_d]=mean(plot_mat[1,good_pos])
          to_plot[2,count_d]=10^dd  
          plot_mat=plot_mat[,-good_pos]
        }
      }
      lines(to_plot[2,], to_plot[1,], type="s", col="black")
    }
  }
  
  
}


