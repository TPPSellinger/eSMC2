
###################
# Source function #
###################
library(MASS)
library(readr)
library(rlist)
library(Matrix)
library(expm)
library(BB)
library(parallel)
library(combinat)
library(eSMC2)
################################

########
#Script#
########


L=10^7
M=10
nsim=1
Pop=10^4
rho=10

      sigma=0
      beta=1
      count_b=0
      mu_ex=matrix(0,ncol = nsim,nrow=4)
      rm_ex=matrix(0,ncol = 3*nsim,nrow=4)
      Ne_t=matrix(0,nrow=4,ncol=nsim)
      r_ex=list()
      Pop_sizel=list()
      totall=list()
      total_l=list()
      total__l=list()
      total___l=list()
      Tcl=list()
      SB=F
      SF=F
      ER=T
      Pop_size=vector()
      x_ab=c(seq(0,1000,1),seq(1001,10^5,10),seq((1+10^5),10^7,10^3))
      LH=vector()
      total=list()
      total_=list()
      total__=list()
      total___=list()
      Tc=list()
      Tc_=list()
      Tc__=list()
      Tc___=list()
      
      strength=10
      for(t in x_ab){
        t=t/(4*Pop)
        Pop_t=Pop
        count=0
        if(t<=(500/(4*Pop))){
          Pop_t=Pop
        }
        if(t>(500/(4*Pop))){
          Pop_t=Pop/strength
        }
        if(t>(5000/(4*Pop))){
          Pop_t=Pop
        }
        Pop_size=c(Pop_size,Pop_t)
        count=count+1
        if(count>1|length(Pop_t)>1|count==0){
          stop("Error in building plot line")
        }
      }
      results_Nb_marker_2_known=list()
      results_Nb_marker_2_unknown=list()
      results_Nb_marker_1=list()
      for(Nb_marker in c(1,2)){
        mu=c(c(10^-8),c(10^-4)) # Transition rate of Marker 1 and  2
        nb_state=c(2,2) # Number of state of each marker
        nb_state_marker=list()
        mu_list=list()
        for(marker in 1:Nb_marker){
          nb_state_marker[[marker]]=nb_state[marker]
          mu_list[[marker]]=mu[marker]
        }
        for(x in 1:nsim){
          # esmc
          Os=as.matrix(Get_real_data("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)",M,file=paste("Tutorial_6_A_marker_",Nb_marker,"_theo_x",x,".txt",sep ="" )))[c(1,2,3,4,5,6,11,12),]

          if(Nb_marker>1){
            if(T){
              
                # If rates are known
              
                results_Nb_marker_2_known[[x]]=SMC_marker_theo(n=40,rho=1,O=Os,mu_marker=mu_list,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,ER=T,NC=1,mu_b=1,sigma=0,beta=1,dominant_marker=1)

                # If rate of second marker is unknown
                
                mu_list[[2]]=NA
                # Estimating the rates
                mu_list_temp=Estimate_marker_rate(n=40,rho=1,O=Os,mu_marker=mu_list,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,BoxMarker=c(2,8),NC=1,mu_b=1,sigma=0,beta=1,Big_Window=F,position_removed=NA,dominant_marker=1,window_scaling=c(1,0))

                 # Estimated rates 
                mu_list_temp=mu_list_temp$mu_marker
                print(mu_list_temp)
                # Using estimated rates
                results_Nb_marker_2_unknown[[x]]=SMC_marker_theo(n=40,rho=1,O=Os,mu_marker=mu_list_temp,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,ER=T,NC=1,mu_b=1,sigma=0,beta=1,dominant_marker=1)
                
                
            }

          }else{
            if(T){
               results_Nb_marker_1[[x]]=SMC_marker_theo(n=40,rho=1,O=Os,mu_marker=mu_list,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,maxit =20,BoxB=c(0.05,1),BoxP=c(3,3),Boxr=c(1,1),Boxs=c(0,0.99),pop=F,SB=F,SF=F,ER=T,NC=1,mu_b=1,sigma=0,beta=1,dominant_marker=1)
            }
          }
        }
      }
      gen <- 1
      col_u=c("red","green","blue")
      
      mat_save_p=matrix(NA,nrow=(3*nsim),ncol=40)
      mat_save_t=matrix(NA,nrow=(3*nsim),ncol=40)
      mat_save_r=matrix(NA,nrow=(3),ncol=nsim)
      count_p=0
      count_t=0

      #eSMC
      
      plot(c(10,10^5),c(1,1), log=c("x"), ylim =c(2,6) ,
           type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")
      for(marker in 1:Nb_marker){
      for(x in 1:nsim){

          if(marker==1){
            test_=results_Nb_marker_1[[x]]$Xi
            Pop_=results_Nb_marker_1[[x]]$Ne
            Tc=results_Nb_marker_1[[x]]$Tc
            count_p=count_p+1
            count_t=count_t+1
            mat_save_r[marker,x]=mean(results_Nb_marker_1[[x]]$rho/results_Nb_marker_1[[x]]$mu)
            mat_save_p[count_p,]=(log10((test_)*0.5*Pop_))
            mat_save_t[count_t,]=(Tc*Pop_)
            lines((Tc*Pop_), log10((test_)*0.5*Pop_), type="s", col=col_u[marker])
          }
        
          if(marker==2){
            
            test_=results_Nb_marker_2_known[[x]]$Xi
            Pop_=results_Nb_marker_2_known[[x]]$Ne
            Tc=results_Nb_marker_2_known[[x]]$Tc
            count_p=count_p+1
            count_t=count_t+1
            mat_save_r[marker,x]=mean(results_Nb_marker_2_known[[x]]$rho/results_Nb_marker_2_known[[x]]$mu)
            mat_save_p[count_p,]=(log10((test_)*0.5*Pop_))
            mat_save_t[count_t,]=(Tc*Pop_)
            lines((Tc*Pop_), log10((test_)*0.5*Pop_), type="s", col=col_u[marker])
            
            
            test_=results_Nb_marker_2_unknown[[x]]$Xi
            Pop_=results_Nb_marker_2_unknown[[x]]$Ne
            Tc=results_Nb_marker_2_unknown[[x]]$Tc
            count_p=count_p+1
            count_t=count_t+1
            mat_save_r[(marker+1),x]=mean(results_Nb_marker_2_unknown[[x]]$rho/results_Nb_marker_2_unknown[[x]]$mu)
            mat_save_p[count_p,]=(log10((test_)*0.5*Pop_))
            mat_save_t[count_t,]=(Tc*Pop_)
            lines((Tc*Pop_), log10((test_)*0.5*Pop_), type="s", col=col_u[(marker+1)])
          }
          


          

        }
      }
      lines(x_ab,log10(Pop_size), type="s", col="black")
      #dev.off()
      legend("topright",legend=c("Nb marker:1","Nb marker:2&known","Nb marker:2&unknown"), col=col_u, lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
      

      
      write.csv(mat_save_p,file = paste("Tutorial_6_A_mat_save_p_real.csv",sep="_"))
      write.csv(mat_save_t,file = paste("Tutorial_6_A_mat_save_t_real.csv",sep="_"))
      write.csv(mat_save_r,file = paste("Tutorial_6_A_mat_save_r_real.csv",sep="_"))
      
      
    
