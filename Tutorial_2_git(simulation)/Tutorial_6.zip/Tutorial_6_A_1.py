import matplotlib
import numpy as np
import pandas as pd
import scipy.special
import scipy.stats
from matplotlib import lines as mlines
from matplotlib import pyplot

import msprime
import msprime.cli as cli
sample_size=5
Ne=10**4
r=1e-7
m=1*1e-8
L=10 ** 7
population_configurations=[msprime.PopulationConfiguration(initial_size=Ne,sample_size=sample_size)]
demography=msprime.Demography()
demography.add_population(initial_size=(Ne))
demography.add_population_parameters_change(time=500, population=None, initial_size=0.1*Ne)
demography.add_population_parameters_change(time=5000, population=None, initial_size=Ne)
for x in range(1,3):
    ts=msprime.sim_ancestry(samples=sample_size,recombination_rate=r,sequence_length=L,demography=demography ,model=[msprime.DiscreteTimeWrightFisher(duration=1000),msprime.StandardCoalescent()]) # 
    f = open("Tutorial_6_A_Newick_x"+str(x)+".txt","w")
    f.write("//"+'\n')
    for tree in ts.trees():
        f.write("["+str(tree.span)+"]"+str(tree.newick())+'\n')
    f.close()





