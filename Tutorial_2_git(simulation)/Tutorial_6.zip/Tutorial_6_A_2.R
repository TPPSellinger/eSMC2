
###################
# Source function #
###################
library(MASS)
library(readr)
library(rlist)
library(expm)
library(BB)
library(combinat)
library(eSMC2)
################################

########
#Script#
########


L=10*10^6 # Sequence length of  10Mb
M=10 # Number of haploid genomes (5*2 because of diploidy)
nsim=2 # Number of simulation
r=10^(-7) # recombination rate
sigma=0 # selfing
beta=1 # dormancy rate
Pop=10^4 # Population size used for scaling 
for(Nb_marker in c(1,2)){ # number of marker to use for simulation
          
          for(xx in 1:nsim){
            # esmc
            setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)") # Path to simlulated Newick files
            gen=get_genealogy(file=paste("Tutorial_6_A_Newick_x",xx,".txt",sep ="" ),M=M,mut=F,simulator="msprime",Ne=Pop,decimal_separator = ",") # check decimal separator used. It can take some time
            mu=c(c(10^-8),c(10^-4)) # Rates of the first and second marker
            nb_state=c(2)
            nb_state_marker=list()
            mu_list=list()
            proportion=c()
            for(marker in 1:Nb_marker){
              if(Nb_marker>1){
                nb_state_marker[[marker]]=nb_state
                mu_list[[marker]]=mu[marker]
              }else{
                nb_state_marker=nb_state
                mu_list=mu[marker]
              }

            }
            if(Nb_marker==2){
              proportion=c(0.99,0.01) # Proportion of the first and second marker in the sequence
              seq=Create_multiple_marker_theo(gen,mu_marker=mu_list,Nb_marker=Nb_marker,Ne=Pop,Nb_region_type=1,Region_pos=NA,nb_state_marker=nb_state_marker,Marker_supperposition=F,initial_marker_proportion=proportion)
              create_realinput_marker_theo(seq,paste("Tutorial_6_A_marker_",Nb_marker,"_theo_x",xx,sep ="" ),Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F)
            }else{
              proportion=NA
              seq=Create_multiple_marker_theo(gen,mu_marker=mu_list,Nb_marker=Nb_marker,Ne=Pop,Nb_region_type=1,Region_pos=NA,nb_state_marker=nb_state_marker,Marker_supperposition=F,initial_marker_proportion=proportion)
              create_realinput_marker_theo(seq,paste("Tutorial_6_A_marker_",Nb_marker,"_theo_x",xx,sep ="" ),Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F)
            }
           }
        }
      
  

