################################
# Tutorial 1 : Simulating data #
################################
##################
# Requirements   #  
##################
import matplotlib #Very important (make decimal separator "," and not a ".")
import numpy 
from matplotlib import lines as mlines
from matplotlib import pyplot
import msprime

##############
# Parameters #
##############
sample_size=3 # Number of sampled (diploid) individuals 
Ne=10**4 # Effective population size 
m=1*1e-8 # mutation rate
L=10 ** 7 # Sequence length
strength=10
for r in [1e-9,1e-8,1e-7]: # rec
    demography=msprime.Demography()
    demography.add_population(initial_size=Ne) # Setting initial population size 
    demography.add_population_parameters_change(time=1000, population=None, initial_size=Ne/strength)
    demography.add_population_parameters_change(time=10000, population=None, initial_size=Ne)
    for x in range(1,3):
        ts=msprime.sim_ancestry(samples=sample_size,recombination_rate=r,sequence_length=L,demography=demography ,model=[msprime.DiscreteTimeWrightFisher(duration=1000),msprime.StandardCoalescent()]) # Simulating ancestry
        mts = msprime.sim_mutations(ts, rate=m) # Adding mutations  
        f = open("Scenario_4_x"+str(x)+"_Strength_"+str(strength)+"_Length_"+str(int(numpy.log10(L)))+"_rec_"+str(-int(numpy.log10(r)))+"_m_"+str(-int(numpy.log10(m)))+".txt","w") # writing file
        for variant in mts.variants():
            f.write(str(variant.site.position)+str(variant.genotypes)+'\n')
        f.close()
