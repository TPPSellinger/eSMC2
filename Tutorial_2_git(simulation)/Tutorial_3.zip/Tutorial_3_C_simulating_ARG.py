################################
# Tutorial 1 : Simulating data #
################################
##################
# Requirements   #  
##################
import numpy
import msprime

##############
# Parameters #
##############
sample_size=2 # Number of sampled (diploid) individuals 
Ne=10**4 # Effective population size 
r=1*1e-8 # Recombination rate
m=1*1e-8 # mutation rate
strength=10
for L in [10 ** 6,10 ** 7,10 ** 8,10 ** 9]:  # Sequence length
    demography=msprime.Demography()
    demography.add_population(initial_size=Ne) # Setting initial population size 
    demography.add_population_parameters_change(time=1000, population=None, initial_size=Ne/strength)
    demography.add_population_parameters_change(time=10000, population=None, initial_size=Ne)
    for x in range(1,3):
        ts=msprime.sim_ancestry(samples=sample_size,recombination_rate=r,sequence_length=L,demography=demography ,model=[msprime.DiscreteTimeWrightFisher(duration=1000),msprime.StandardCoalescent()]) # Simulating ancestry
        mts = msprime.sim_mutations(ts, rate=m) # Adding mutations  
        f = open("Scenario_3_x"+str(x)+"_Strength_"+str(strength)+"_Length_"+str(int(numpy.log10(L)))+"_rec_"+str(int(-numpy.log10(r)))+"_m_"+str(-int(numpy.log10(m)))+".txt","w") # writing file
        f.write("segsites: "+str(mts.get_num_sites())+'\n')
        f.write("//"+'\n')
        for tree in ts.trees():
            f.write("["+str(tree.span)+"]"+str(tree.newick())+'\n')
        f.close()
