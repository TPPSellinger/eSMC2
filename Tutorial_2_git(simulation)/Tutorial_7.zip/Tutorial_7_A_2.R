
###################
# Source function #
###################
library(MASS)
library(readr)
library(rlist)
library(expm)
library(BB)
library(combinat)
library(eSMC2)
################################

########
#Script#
########
p_meth=0.01 # Proportion of CG with methylation state annotated
mu <- 10^-8 # mutation rate
L=10^7 # sequence length
M=10 # number of haploid sequences
nsim=2 # number of repetition
Pop=10^5 # population size for scaling simulator

setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)") # Path to simlulated Newick files
          Meth_pos=list()
          region_size=1000
          nb_reg=L*p_meth/region_size
          for(pp in 1:nb_reg){
            x=1+(((L/nb_reg))*(pp-1))
            y=x+region_size
            Meth_pos[[pp]]=c(x,y)
          }
        
        for(xx in 1:nsim){ 
          
          name=paste("Tutorial_7_A_Newick_x",xx,".txt",sep ="" )
          gen=get_genealogy(file=name,M=M,mut=F,simulator="msprime",Ne=Pop,decimal_separator = ",")
          seq=Create_multiple_meth_regions_seq(gen,mu=mu,Gbm_rates=c(3.5*10^(-4),1.5*10^(-3)),cryptic_Gbm_rates=c(2*10^(-4),(10^-3)),Ne=Pop,Gbm_pos=Meth_pos,symbol=c("CG"),c_pos=c(1))
          create_realinput_meth_msmc2(seq,paste("Tutorial_7_A_x",xx,"_pmeth_",p_meth,sep ="" ))
          }
          
      
    


