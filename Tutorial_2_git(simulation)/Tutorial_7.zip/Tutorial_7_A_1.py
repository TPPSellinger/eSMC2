import matplotlib
import numpy as np
import pandas as pd
import scipy.special as sc
import scipy.stats
from matplotlib import lines as mlines
from matplotlib import pyplot

import msprime
import msprime.cli as cli
sample_size=5
Ne=10**5
r=1e-8
m=1e-8
L=10 ** 7
population_configurations=[msprime.PopulationConfiguration(initial_size=Ne,sample_size=sample_size)]
demography=msprime.Demography()
demography.add_population(initial_size=(0.01*Ne))
demography.add_population_parameters_change(time=0, population=None, growth_rate=2.302585/400)
demography.add_population_parameters_change(time=400, population=None, initial_size=Ne,growth_rate=0)
for x in range(1,3):
    #ts=msprime.DemographyDebugger(demography=demography)
    #ts.print_history()
    ts=msprime.sim_ancestry(samples=sample_size,recombination_rate=r,sequence_length=L,demography=demography ,model=[msprime.DiscreteTimeWrightFisher(duration=1000),msprime.StandardCoalescent()]) # 
    mts = msprime.sim_mutations(ts, rate=m) 
    print("segsites: "+str(mts.get_num_sites())+'\n')   
    f = open("Tutorial_7_A_Newick_x"+str(x)+".txt","w")  
    f.write("//"+'\n')
    for tree in ts.trees():
        f.write("["+str(tree.span)+"]"+str(tree.newick())+'\n')
    f.close()





