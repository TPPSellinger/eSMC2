#' estimates prior for alpha based on diversity
#'
#' @param Os : sample size
#' @param max_dist : max sample size to account for alpha estimation
#' @param start_dist : min sample size to account for alpha estimation
#' @param Xi : vector of relative population size through time compare to Ne
#' @param Tc : Coalescent times used for binning
#' @export
#' @return numerical value corresponding to the estimated alpha
Estimate_prior_alpha<-function(Os,max_dist=NA,start_dist=3,Xi=NA,Tc=NA){
  n=dim(Os)[1]-2
  alpha_v=c(seq(1.1,1.95,0.05),1.999)
  distance=numeric(length = length(alpha_v))
  counter=0
  diversity=c()

  for( k in 1:(n-1)){
    for(l in (k+1):n){
      counter=counter+1
      diversity[counter]=length(which(Os[k,]!=Os[l,]))
    }
  }
  L2=mean(diversity)
  L_diversity=numeric((n-1))
  L_diversity[1]=L2
  for(m in 3:n){
    diversity=c()
    combination_possible=utils::combn(n,m)
    for(cc in 1:dim(combination_possible)[2]){
      Os_temp=Os[combination_possible[,cc],]
      diversity_temp=0
      for(temp_col in 1:dim(Os_temp)[2]){
        if(length(unique(Os_temp[,temp_col]))>1){
          diversity_temp=diversity_temp+1
        }
      }
      diversity[cc]=diversity_temp
    }
   L_diversity[(m-1)]=mean(diversity)
  }
  if(all(!is.na(max_dist))){
    if(max_dist<=(n-1)){
      n_lim=max_dist
    }else{
      n_lim=(n-1)
    }

  }else{
    n_lim=(n-1)
  }
  if(start_dist>(n_lim)){
    start_dist=n_lim
  }
  counter=0
  for(alpha in alpha_v){
    counter=counter+1
    Expected_Bl=Get_total_branch_length_SMBC((n_lim+1),alpha,Xi=Xi,Tc=Tc)
   # if(any((Expected_Bl[2:length(Expected_Bl)] -Expected_Bl[1:(length(Expected_Bl)-1)])<0)){
    #
    #}

    distance[counter]=sum((((Expected_Bl[start_dist:n_lim]-Expected_Bl[c(c(start_dist:n_lim)-1)])/Expected_Bl[c(c(start_dist:n_lim))])-((L_diversity[c(start_dist:n_lim)]-L_diversity[c(c(start_dist:n_lim)-1)])/L_diversity[c(c(start_dist:n_lim))]))^2) # start_dist:
  }
  return(list(alpha_v[which(distance==min(distance))],distance))
  }



