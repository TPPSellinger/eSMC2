#' Runs SMBC on sequence of genealogy
#'
#' @param file : path to the simulated data  ( .txt )
#' @param L : length of simulated sequence (or vector of these values if NC>1)
#' @param mu : mutation rate per generation per bp if simulator is msprime, inputted theta if using scrm (or vector of these values if NC>1)
#' @param n : Number of hidden states
#' @param gamma : initial ration of recombination over mutation
#' @param alpha : initial value for the beta distribution (multiple merger parameter)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination/dormancy rate
#' @param Boxa : boundaries of alpha, numeric vector of size 2 indication the minimum and maximum values of alpha (must be bigger than 1 and smaller than 2)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param BoxB : boundaries of beta, numeric vector of size 2 indication the minimum and maximum values rate ( first value must be  bigger than 0)
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param B : True to estimate alpha (multiple merger parameters)
#' @param ER : True to estimate recombination rate
#' @param SB : True to estimate beta (dormancy)
#' @param SF : True to estimate selfing rates
#' @param NC : Number of scaffold
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param M : Number of sequences simulated
#' @param M_a : Number of simultaneously analyzed sequences
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param simulator : "msprime" ,"scrm" or argweaver
#' @param ploidy : ploidy of the studied genome
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param decimal_separator : character use as decimal separator , "\\." or ","
#' @param Reg : TRUE to estimate alpha along the sequence
#' @param L_Reg : Sequence length on which to estimate alpha
#' @param theta : total number of segregating sites if not in the input file.
#' @export
#' @return A list containing model parameter:
#' \itemize{
#' \item{ scale_T : Scaling constant to switch from generations to coalescence rate}
#' \item{ Tc : the expected coalescent time}
#' \item{ Xi : the vector of population size in unite of Ne at each hidden state (population size at time t =  Xi[t] x  Ne/ploidy)}
#' \item{ mu : the mutation rate (per bp per 2 Ne)}
#' \item{ beta : the germination/dormancy rate}
#' \item{ sigma : the self-fertilization rate}
#' \item{ alpha : alpha parameter of the beta distribution}
#' \item{ rho : the recombination rate (per bp per 2 Ne)}
#' \item{ N : the estimated transition matrix}
#' \item{ M : the estimated emission matrix}
#' \item{ q : the estimated inital density}
#' \item{ Ne : the estimated effective population size for scaling under the beta coalescent}
#' \item{ Q : the theoretical transition matrix}
#' \item{ G : the estimated effective population size for haploid population under Kingman coalescence}
#' \item{ L : sequence length}
#' \item{scale_Alpha: Prior scaling constant to transform population size under kingman into Beta coalescent}
#' \item{scale_alpha: scaling constant from the estimated alpha to transform population size under kingman into Beta coalescent}
#' }
Optimize_SMBC_N<-function(file,L,mu,n=40,gamma=1,alpha=1.99,sigma=0,beta=1,Boxa=c(1.001,1.999),BoxP=c(3,3),Boxr=c(1,1),BoxB=c(0.05,1),Boxs=c(0,0.99),pop=T,B=T,ER=T,SB=F,SF=F,NC=1,pop_vect=NA,M,M_a=3,window_scaling=c(1,0),simulator,ploidy=1,mu_b=1,decimal_separator="\\.",Reg=F,L_Reg=10^6,theta=NA){
  cut_edge=F
  cor=T
  Popfix=!pop
  Beta=beta
  Sigma=sigma
  Pop=pop
  Vect=0:(n-1)
  BW=F
  SCALED=F
  Penalty=F
  Alpha=alpha
  if(F){
  if(Reg){
    ER=F
    SF=F
    SB=F
    pop=F
    B=T
  }
  }
  Ne_Beta_founder<-function(theta,L,M_a=3,mu_real,alpha,ploidy=1){
    mu_estimated=(theta/((2*sum(1/(1:(M_a-1))))*L))
    if(ploidy==2){
      m=2+((2^alpha)/((3^(alpha-1))*(alpha-1)))
      scale=4*(m^alpha)/(alpha*beta(2-alpha,alpha))
      Ne=2*(((mu_estimated/mu_real)/scale)^(1/(alpha-1)))
      G=(mu_estimated/mu_real)
    }
    if(ploidy==1){
      m=1+(1/((2^(alpha-1))*(alpha-1)))
      scale=(m^alpha)/(alpha*beta(2-alpha,alpha))
      Ne=(((mu_estimated/mu_real)/scale)^(1/(alpha-1)))
      G=(mu_estimated/mu_real)
    }
    res=list()
    res$Ne=Ne
    res$G=G
    res$mu=mu_estimated
    return(res)
  }


 if(simulator=='msprime'|simulator=='argweaver'){
   mu_real=mu
 }

    #print(mu)
    scale_T=1

    if(NC==1){

    if(cor){
      if(simulator!='argweaver'){
        theta=get_theta(file)
      }




      if(simulator=="scrm"|simulator=="msms"){
        mu_=theta/((2*sum(1/(1:(M-1))))*L)
        scale_T=mu_/mu
        Ne=NA
        mu_real=NA
      }

      if(simulator=="msprime"|simulator=='argweaver'){
        mu_=theta/((2*sum(1/(1:(M-1))))*L)
        theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
        #res=Ne_Beta_founder(theta=theta,L=L,M_a=3,mu_real=mu_real,alpha=alpha,ploidy=ploidy)
        #mu_=res$mu
        Ne=mu_/(mu)#res$G##
      }
      mu=mu_
    }

    #print('scaling:')
    #print(scale_T)
    print('mutation rate:')
    print(mu)
    Rho=mu*gamma*L*2
    if(M_a==3){
      if(ploidy==1){
      lambda=beta((2-alpha), alpha)/(gamma((2-alpha))*gamma((alpha)))
      L3_2=3*(beta((2-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha))))
      L3_3=((beta((3-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
      L3=L3_2+L3_3
      }else{
        nb_box=2*(ploidy)
        #L3_2=(((1-((2-alpha)/2))/nb_box)  + (3*((2-alpha)/2)/(nb_box*nb_box)))*3*nb_box
        #L3_3=(((2-alpha)/2)/(nb_box*nb_box))*3*nb_box
        L3_2=3*((1-(((2-alpha)/2)))/(nb_box)) + ((3*(2-alpha)/2)/(nb_box*nb_box))
        L3_3=3*(((2-alpha)/2)/(nb_box*nb_box))
        L3=L3_2+L3_3

        L3=L3_2+L3_3
      }
      Tc=  window_scaling[2] -(0.5*(2-Sigma)*log(1-(Vect/n))/(L3*(Beta^2)*window_scaling[1]))
    }

    if(M_a==4){
      if(ploidy==1){
        L4_2=6*(beta((2-alpha), (2+alpha))/(gamma((2-alpha))*gamma((alpha))))
        L4_3=4*((beta((3-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha)))))
        L4_4=((beta((4-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
        L4=L4_2+L4_3+L4_4

      }else{
        stop("Not coded")
      }
      Tc= (window_scaling[2]-(0.5*(2-Sigma)*log(1-(Vect/n)))/(L4*(Beta^2)*window_scaling[1]))
    }

    if(all(!is.na(scale_T))){
      Tc=Tc*scale_T
    }
    print("reading genealogy")
    if(simulator!="argweaver"){
      b=get_genealogy(file,M,mut=cor,simulator,Ne=Ne,decimal_separator=decimal_separator)
    }
     if(simulator=="argweaver"){
       b=get_genealogy_Argweaver(file,M,Ne=Ne,decimal_separator=decimal_separator)


     }


      if(!Reg){

      if(M_a<M){
         print("extracting sub genealogies then building N")
          if(M_a==3){
            count_ind=0


            for(i in 1:(M-2)){
              possible_ind=i:M
              if(i>1){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }
              possible_ind1=possible_ind
              for(j in (i+1):(M-1)){
                possible_ind=c(i,j:M)
                if(length(possible_ind)<length(possible_ind1)){
                  if(length(possible_ind)>M_a){
                    b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                  }else{
                    b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                  }

                }else{
                  b_a_temp2=b_a_temp1
                  }
                for(k in (j+1):M){
                  count_ind=count_ind+1
                  ind=c(i,j,k)
                  #print(count_ind)
                  if(length(ind)<length(possible_ind)){
                    #browser()
                    b_a_i=get_sub_genealogy(b_a_temp2,ind,update_index=T)
                  }
                  #scale_T=mean(as.numeric(b_a$Coal_time[(M_a-1),]))/Tc[floor(n/2)]
                  #print('scaling:')
                  #print(scale_T)
                  #browser()
                  #Tc=Tc*scale_T

                  b_a=build_seq_id(b_a_i,Tc)
                  #browser()
                  if(count_ind==1){
                    N=build_SMBC_N(b_a,Tc,M_a=M_a)

                  }else{
                    N=N+build_SMBC_N(b_a,Tc,M_a=M_a)

                  }
                  if(sum(N)>=(count_ind*1.05*(L-1))|sum(N)<=(count_ind*0.95*(L-1))){
                    #browser()
                  }
                  #print(sum(N))
                  #print(sum(N)/(count_ind*(L-1)))
                  Tc=Tc/scale_T
                  scale_T=1
                }
              }
            }
          }
          if(M_a==4){
          count_ind=0
          for(i in 1:(M-3)){
            possible_ind=i:M
            if(i>1){
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }else{
              b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }
            possible_ind1=possible_ind
            for(j in (i+1):(M-2)){
              possible_ind=c(i,j:M)
              if(length(possible_ind)<length(possible_ind1)){
                if(length(possible_ind)>M_a){
                  b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                }else{
                  b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                }

              }else{
                b_a_temp2=b_a_temp1
              }
              for(k in (j+1):(M-1)){
                possible_ind=c(i,j,k:M)

                if(length(possible_ind)<length(possible_ind1)){
                  if(length(possible_ind)>M_a){
                    b_a_temp3=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=F)
                  }else{
                    b_a_i=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=T)
                  }

                }else{
                  b_a_temp3=b_a_temp2
                }
                for(l in (k+1):M){
                count_ind=count_ind+1
                ind=c(i,j,k,l)
                #print(count_ind)
                if(length(ind)<length(possible_ind)){
                  #browser()
                  b_a_i=get_sub_genealogy(b_a_temp3,ind,update_index=T)
                }


                b_a=build_seq_id(b_a_i,Tc)
                #browser()
                if(count_ind==1){
                  N=build_SMBC_N(b_a,Tc,M_a=M_a)

                }else{
                  N=N+build_SMBC_N(b_a,Tc,M_a=M_a)

                }
                }

                Tc=Tc/scale_T
                scale_T=1
              }
            }
          }
        }
      }else{
        print("building N")
        #scale_T=mean(as.numeric(b$Coal_time[(M_a-1),]))/Tc[floor(n/2)]
        #print("potential scale T:")
        #print(mean(as.numeric(b$Coal_time[(M_a-1),]))/Tc[floor(n/2)])
        #Tc=Tc*scale_T
        b=build_seq_id(b,Tc)
        N=build_SMBC_N(b,Tc,M_a=M_a)
        #Tc=Tc/scale_T
        scale_T=1
        if(sum(N)>=(1.01*L)|sum(N)<=(0.99*L)){
          #browser()
        }
      }
      }else{

        if(M_a<M){
          print("extracting sub genealogies then building N")
          if(M_a==3){
            count_ind=0
            for(i in 1:(M-2)){
              possible_ind=i:M
              if(i>1){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }
              possible_ind1=possible_ind
              for(j in (i+1):(M-1)){
                possible_ind=c(i,j:M)
                if(length(possible_ind)<length(possible_ind1)){
                  if(length(possible_ind)>M_a){
                    b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                  }else{
                    b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                  }

                }else{
                  b_a_temp2=b_a_temp1
                }
                for(k in (j+1):M){
                  count_ind=count_ind+1
                  ind=c(i,j,k)
                  #print(count_ind)
                  if(length(ind)<length(possible_ind)){
                    #browser()
                    b_a_i=get_sub_genealogy(b_a_temp2,ind,update_index=T)
                  }
                  #scale_T=mean(as.numeric(b_a$Coal_time[(M_a-1),]))/Tc[floor(n/2)]
                  #print('scaling:')
                  #print(scale_T)
                  #browser()
                  #Tc=Tc*scale_T

                  b_a=build_seq_id(b_a_i,Tc)
                  #browser()
                  if(count_ind==1){
                    N=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)

                  }else{
                    N_temp=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)
                    for(nnn in 1:length(N_temp)){
                      N[[nnn]]=N[[nnn]]+N_temp[[nnn]]
                    }
                  }
                  Tc=Tc/scale_T
                  scale_T=1
                }
              }
            }
          }
          if(M_a==4){
            count_ind=0
            for(i in 1:(M-3)){
              possible_ind=i:M
              if(i>1){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }
              possible_ind1=possible_ind
              for(j in (i+1):(M-2)){
                possible_ind=c(i,j:M)
                if(length(possible_ind)<length(possible_ind1)){
                  if(length(possible_ind)>M_a){
                    b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                  }else{
                    b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                  }

                }else{
                  b_a_temp2=b_a_temp1
                }
                for(k in (j+1):(M-1)){
                  possible_ind=c(i,j,k:M)

                  if(length(possible_ind)<length(possible_ind1)){
                    if(length(possible_ind)>M_a){
                      b_a_temp3=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=F)
                    }else{
                      b_a_i=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=T)
                    }

                  }else{
                    b_a_temp3=b_a_temp2
                  }
                  for(l in (k+1):M){
                    count_ind=count_ind+1
                    ind=c(i,j,k,l)
                    #print(count_ind)
                    if(length(ind)<length(possible_ind)){
                      #browser()
                      b_a_i=get_sub_genealogy(b_a_temp3,ind,update_index=T)
                    }


                    b_a=build_seq_id(b_a_i,Tc)
                    #browser()
                    if(count_ind==1){
                      N=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)

                    }else{
                      N_temp=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)
                      for(nnn in 1:length(N_temp)){
                        N[[nnn]]=N[[nnn]]+N_temp[[nnn]]
                      }
                    }
                  }

                  Tc=Tc/scale_T
                  scale_T=1
                }
              }
            }
          }
        }else{
          print("building N")
          b=build_seq_id(b,Tc)
          N=build_SMBC_N(b,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)
          scale_T=1

        }
        full_N=N[[1]]
        for(sca in 2:length(N)){
          full_N=full_N+N[[sca]]
        }

      }
    }
    if(NC>1){
      if(length(mu)==1){
        mu=rep(mu,NC)
      }
      if(length(L)==1){
        L=rep(L,NC)
      }
      if(cor){
        mu_=c()
        for(chr in 1:NC){
          theta=get_theta(file[chr])
          mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
        }


        if(simulator=="scrm"|simulator=="msms"){
          scale_T=mean(mu_/mu)
          Ne=NA
        }else{
          #mu_=theta/((2*sum(1/(1:(M-1))))*L)
          theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
          #res=Ne_Beta_founder(theta=sum(theta),L=sum(L),M_a=3,mu_real=mu_real,alpha=alpha,ploidy=ploidy)
          #mu_=res$mu
          Ne=mean(mu_/(mu))
        }

        mu=mean(mu_)
      }

      print('scaling:')
      print(scale_T)
      print('mutation rate:')
      print(mu)
      Rho=mu*gamma*L*2
      if(M_a==3){
        if(ploidy==1){
          L3_2=3*(beta((2-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha))))
          L3_3=((beta((3-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
          L3=L3_2+L3_3
        }else{
          nb_box=2*(ploidy)
         # L3_2=(((1-((2-alpha)/2))/nb_box)  + (3*((2-alpha)/2)/(nb_box*nb_box)))*3* nb_box
        #  L3_3=(((2-alpha)/2)/(nb_box*nb_box))*3* nb_box
          L3_2=3*((1-(((2-alpha)/2)))/(nb_box)) + ((3*(2-alpha)/2)/(nb_box*nb_box))
          L3_3=(((2-alpha)/2)/(nb_box*nb_box))
          L3=L3_2+L3_3
        }
        Tc=  window_scaling[2] -(0.5*(2-Sigma)*log(1-(Vect/n))/(L3*(Beta^2)*window_scaling[1]))
      }


      if(M_a==4){
        if(ploidy==1){
          L4_2=6*(beta((2-alpha), (2+alpha))/(gamma((2-alpha))*gamma((alpha))))
          L4_3=4*((beta((3-alpha), (1+alpha))/(gamma((2-alpha))*gamma((alpha)))))
          L4_4=((beta((4-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
          L4=L4_2+L4_3+L4_4

        }else{
          stop("Not coded")
        }
        Tc= (window_scaling[2]-(0.5*(2-Sigma)*log(1-(Vect/n)))/(L4*(Beta^2)*window_scaling[1]))
      }


      if(all(!is.na(scale_T))){
        Tc=Tc*scale_T
      }



      N_total=list()

      if(!Reg){
        for(chr in 1:NC){
          print("reading genealogy")
          if(simulator!="argweaver"){
            b=get_genealogy(file[chr],M,mut=cor,simulator,Ne=Ne,decimal_separator=decimal_separator)
          }
          if(simulator=="argweaver"){
            b=get_genealogy_Argweaver(file[chr],M,Ne=Ne,decimal_separator=decimal_separator)
          }

          if(M_a<M){
            print("extracting sub genealogies then building N")
            if(M_a==3){
              count_ind=0
              for(i in 1:(M-2)){
                possible_ind=i:M
                if(i>1){
                  b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }else{
                  b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }
                possible_ind1=possible_ind
                for(j in (i+1):(M-1)){
                  possible_ind=c(i,j:M)
                  if(length(possible_ind)<length(possible_ind1)){
                    if(length(possible_ind)>M_a){
                      b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                    }else{
                      b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                    }

                  }else{
                    b_a_temp2=b_a_temp1
                  }
                  for(k in (j+1):M){
                    count_ind=count_ind+1
                    ind=c(i,j,k)
                    #print(count_ind)
                    if(length(ind)<length(possible_ind)){
                      #browser()
                      b_a_i=get_sub_genealogy(b_a_temp2,ind,update_index=T)
                    }
                    #scale_T=mean(as.numeric(b_a$Coal_time[(M_a-1),]))/Tc[floor(n/2)]
                    #print('scaling:')
                    #print(scale_T)
                    #browser()
                    #Tc=Tc*scale_T

                    b_a=build_seq_id(b_a_i,Tc)

                    if(count_ind==1){
                      N=build_SMBC_N(b_a,Tc,M_a=M_a)

                    }else{
                      N=N+build_SMBC_N(b_a,Tc,M_a=M_a)

                    }
                    if(sum(N)>=(count_ind*1.05*(L-1))|sum(N)<=(count_ind*0.95*(L-1))){
                      #browser()
                    }
                    #print(sum(N))
                    #print(sum(N)/(count_ind*(L-1)))
                    Tc=Tc/scale_T
                    scale_T=1
                  }
                }
              }
            }
            if(M_a==4){
              count_ind=0
              for(i in 1:(M-3)){
                possible_ind=i:M
                if(i>1){
                  b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }else{
                  b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }
                possible_ind1=possible_ind
                for(j in (i+1):(M-2)){
                  possible_ind=c(i,j:M)
                  if(length(possible_ind)<length(possible_ind1)){
                    if(length(possible_ind)>M_a){
                      b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                    }else{
                      b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                    }

                  }else{
                    b_a_temp2=b_a_temp1
                  }
                  for(k in (j+1):(M-1)){
                    possible_ind=c(i,j,k:M)

                    if(length(possible_ind)<length(possible_ind1)){
                      if(length(possible_ind)>M_a){
                        b_a_temp3=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=F)
                      }else{
                        b_a_i=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=T)
                      }

                    }else{
                      b_a_temp3=b_a_temp2
                    }
                    for(l in (k+1):M){
                      count_ind=count_ind+1
                      ind=c(i,j,k,l)
                      #print(count_ind)
                      if(length(ind)<length(possible_ind)){
                        b_a_i=get_sub_genealogy(b_a_temp3,ind,update_index=T)
                      }
                      b_a=build_seq_id(b_a_i,Tc)
                      #browser()
                      if(count_ind==1){
                        N=build_SMBC_N(b_a,Tc,M_a=M_a)

                      }else{
                        N=N+build_SMBC_N(b_a,Tc,M_a=M_a)
                      }
                    }

                    if(sum(N)>=(count_ind*1.05*(L-1))|sum(N)<=(count_ind*0.95*(L-1))){
                      #browser()
                    }
                    #print(sum(N))
                    #print(sum(N)/(count_ind*(L-1)))
                    Tc=Tc/scale_T
                    scale_T=1
                  }
                }
              }
            }
          }else{
            print("building N")
            b=build_seq_id(b,Tc)

            N=build_SMBC_N(b,Tc,M_a=M_a)
            if(sum(N)>=(1.01*L)|sum(N)<=(0.99*L)){
              #browser()
            }
          }
          N_total[[chr]]=N
        }
      }else{
        for(chr in 1:NC){
          print("reading genealogy")
          if(simulator!="argweaver"){
            b=get_genealogy(file[chr],M,mut=cor,simulator,Ne=Ne,decimal_separator=decimal_separator)
          }
          if(simulator=="argweaver"){
            b=get_genealogy_Argweaver(file[chr],M,Ne=Ne,decimal_separator=decimal_separator)
          }
          if(M_a<M){
            print("extracting sub genealogies then building N")
            if(M_a==3){
              count_ind=0
              for(i in 1:(M-2)){
                possible_ind=i:M
                if(i>1){
                  b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }else{
                  b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }
                possible_ind1=possible_ind
                for(j in (i+1):(M-1)){
                  possible_ind=c(i,j:M)
                  if(length(possible_ind)<length(possible_ind1)){
                    if(length(possible_ind)>M_a){
                      b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                    }else{
                      b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                    }

                  }else{
                    b_a_temp2=b_a_temp1
                  }
                  for(k in (j+1):M){
                    count_ind=count_ind+1
                    ind=c(i,j,k)
                    #print(count_ind)
                    if(length(ind)<length(possible_ind)){
                      #browser()
                      b_a_i=get_sub_genealogy(b_a_temp2,ind,update_index=T)
                    }


                    b_a=build_seq_id(b_a_i,Tc)
                    #browser()
                    if(count_ind==1){
                      N=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)

                    }else{
                      N_temp=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)
                      for(nnn in 1:length(N_temp)){
                        N[[nnn]]=N[[nnn]]+N_temp[[nnn]]
                      }
                    }

                    Tc=Tc/scale_T
                    scale_T=1
                  }
                }
              }
            }
            if(M_a==4){
              count_ind=0
              for(i in 1:(M-3)){
                possible_ind=i:M
                if(i>1){
                  b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }else{
                  b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
                }
                possible_ind1=possible_ind
                for(j in (i+1):(M-2)){
                  possible_ind=c(i,j:M)
                  if(length(possible_ind)<length(possible_ind1)){
                    if(length(possible_ind)>M_a){
                      b_a_temp2=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=F)
                    }else{
                      b_a_i=get_sub_genealogy(b_a_temp1,ind=c(possible_ind),update_index=T)
                    }

                  }else{
                    b_a_temp2=b_a_temp1
                  }
                  for(k in (j+1):(M-1)){
                    possible_ind=c(i,j,k:M)

                    if(length(possible_ind)<length(possible_ind1)){
                      if(length(possible_ind)>M_a){
                        b_a_temp3=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=F)
                      }else{
                        b_a_i=get_sub_genealogy(b_a_temp2,ind=c(possible_ind),update_index=T)
                      }

                    }else{
                      b_a_temp3=b_a_temp2
                    }
                    for(l in (k+1):M){
                      count_ind=count_ind+1
                      ind=c(i,j,k,l)
                      #print(count_ind)
                      if(length(ind)<length(possible_ind)){
                        b_a_i=get_sub_genealogy(b_a_temp3,ind,update_index=T)
                      }
                      b_a=build_seq_id(b_a_i,Tc)
                      #browser()
                      if(count_ind==1){
                        N=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)

                      }else{
                        N_temp=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)
                        for(nnn in 1:length(N_temp)){
                          N[[nnn]]=N[[nnn]]+N_temp[[nnn]]
                        }
                      }
                    }

                    Tc=Tc/scale_T
                    scale_T=1
                  }
                }
              }
            }
          }else{
            print("building N")
            b=build_seq_id(b,Tc)
              N=build_SMBC_N(b_a,Tc,M_a=M_a,Reg=Reg,L_Reg=L_Reg)
          }
          N_total[[chr]]=N
        }
      }

      N=N_total
}

print("starting optimization")
  if(SCALED){
    corrector_N=rowSums(N)
    N=diag(1/corrector_N)%*%N
  }
  Tc=Tc/scale_T
  #window_scaling=c((1/scale_T),0)

  test.env <- new.env()
  test.env$L <- L
  test.env$k <- n
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$alpha<-alpha
  test.env$Alpha<-Alpha
  test.env$Beta <-Beta
  test.env$Sigma <-Sigma
  test.env$BoxP <- BoxP
  test.env$Boxa <- Boxa
  test.env$Boxs <- Boxs
  test.env$BoxB <- BoxB
  test.env$Big_Xi <- N
  if(Reg){
    test.env$full_Big_Xi <- full_N
  }
  test.env$M_a<-M_a
  test.env$mu_b <- mu_b
  test.env$Penalty <- Penalty
  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=n)){
    Klink=0.5*n
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(B){
    oldalpha=(alpha-Boxa[1])/(Boxa[2]-Boxa[1])
  }
  if(!B){
    test.env$alpha <- alpha
  }
  if(!SB){
    Beta=beta
    test.env$beta <- beta
  }
  if(!SF){
    Sigma=sigma
    oldSigma=Sigma
    test.env$sigma <- sigma
  }
  if(!ER){
    oldrho=0
    if(length(unique(round(gamma,digits=3)))>1){
      oldrho=rep(0,NC)
    }
    Boxr=c(0,0)
  }
  if(ER){
    oldrho=(Boxr[1]/sum(Boxr))
    if(length(unique(round(gamma,digits=3)))>1){
      oldrho=rep((Boxr[1]/sum(Boxr)),NC)
    }
  }
  if(SB){
    oldbeta=(sqrt(beta)-BoxB[1])/(BoxB[2]-BoxB[1])
  }
  if(SF){
    oldsigma=(sigma-Boxs[1])/(Boxs[2]-Boxs[1])
  }

  oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
  oldXi=vector()
  xx=0
  for(ix in 1:Klink){
    x=xx+1
    xx = xx + pop_vect[ix]
    oldXi[x:xx]=oldXi_[ix]
  }

  test.env$Boxr <- Boxr
  test.env$ER <- ER
  test.env$SF <- SF
  test.env$SB <- SB
  test.env$B <- B
  test.env$Boxr <- Boxr

  lr=length(oldrho)
  test.env$lr<-lr
  if(!Reg){
    if(NC==1){





      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        Boxa=get('Boxa', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Sigma=get('Sigma', envir=test.env)
        Alpha=get('Alpha', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)


        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)


        start_position=0
        if(ER==1){
          #rho_=numeric(1)
          rho=param[(start_position+1):(start_position+1)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+1

        }
        if(ER==0){
          rho=Rho
        }
        if(SF==1){

          sigma=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]

        }

        if(SF==0){
          sigma=get('sigma', envir=test.env)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+1

        }

        if(SB==0){
          beta=get('beta', envir=test.env)

        }

        if(B==1){
          alpha=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          alpha=alpha*(Boxa[2]-Boxa[1])
          alpha=alpha+Boxa[1]
        }
        if(B==0){
          alpha=get('alpha', envir=test.env)
        }


        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }
        builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy)

        Q=builder[[1]]
        Q=t(Q)
        A=as.vector(Q)
        keep=which(A>0)
        A=A[keep]
        Big_Xi=as.vector(Big_Xi)
        Big_Xi=Big_Xi[keep]

        if(BW){
          q_=get('q_', envir=test.env)
          Big_M=get('Big_M', envir=test.env)
          Tc=builder[[3]]
          Ts_t=get('TC_SNP', envir=test.env)
          g=build_emi_MM(n=n,mu,alpha,M_a,Tc=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta)
          Big_M=get('Big_M', envir=test.env)
          q_=get('q_', envir=test.env)
          nu=builder[[2]]

          LH=-sum(log(A)*Big_Xi)-sum(log(nu)*q_)
          for(gg in 1:length(g)){
            x=as.vector(g[[gg]])
            keep=which(x>0)
            x=x[keep]
            m=as.vector(Big_M[[gg]])
            m=m[keep]
            LH=LH-sum(log(x)*m)
          }
        }
        if(!BW){
          LH=-sum(log(A)*Big_Xi)
        }
        Penalty=get('Penalty', envir=test.env)
        if(Penalty){
          Xi_rp=as.numeric(Xi[1:(length(Xi)-1)]-Xi[2:(length(Xi))])
          LH=LH+((sum((Xi_rp)^2))*(0.001*-sum(log(A)*Big_Xi)))
        }
        return(LH)
      }


      for(loop in c(1,2)){

      param=c()
      if(ER==1){
        param=c(param,oldrho)

      }

      if(SF==1){
        param=c(param,oldsigma)

      }

      if(SB==1){
        param=c(param,oldbeta)
      }
      if(B==1){
        param=c(param,oldalpha)
      }
      if(!Popfix){
        param=c(param,oldXi_)
      }

      sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
      sol=as.matrix(sol[[1]])
      start_position=0
      sol=as.numeric(sol[1:length(param),1])

      if(ER==1){
        rho=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        #
        oldrho=rho
      }

      if(loop==2){

      if(SF==1){
        sigma_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldsigma=sigma_
      }



      if(SB==1){
        beta_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldbeta=beta_
      }

      if(B==1){
        alpha_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldalpha=alpha_
      }


      if(!Popfix){
        Xi_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldXi_=Xi_
      }
      }
      }
    }
    if(NC>1){




      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        Boxa=get('Boxa', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Sigma=get('Sigma', envir=test.env)
        Alpha=get('Alpha', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)
        lr=get('lr', envir=test.env)
        NC=get('NC', envir=test.env)
        start_position=0
        if(ER==1){
          #rho_=numeric(1)
          rho=param[(start_position+1):(start_position+lr)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+lr

        }
        if(ER==0){
          rho=Rho
        }
        if(SF==1){

          sigma=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]

        }

        if(SF==0){
          sigma=get('sigma', envir=test.env)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+1

        }

        if(SB==0){
          beta=get('beta', envir=test.env)

        }

        if(B==1){
          alpha=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          alpha=alpha*(Boxa[2]-Boxa[1])
          alpha=alpha+Boxa[1]
        }
        if(B==0){
          alpha=get('alpha', envir=test.env)
        }


        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }
        LH=0

        for(chr in 1:NC){

          builder=build_SMBC_matrix(n,rho[chr],L=L[chr],Xi=Xi,scale=window_scaling,alpha=alpha,beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy)
          Q=builder[[1]]
          Q=t(Q)
          A=as.vector(Q)
          keep=which(A>0)
          A=A[keep]
          Big_Xi[[chr]]=as.vector(Big_Xi[[chr]])
          Big_Xi[[chr]]=Big_Xi[[chr]][keep]

          if(BW){
            q_=get('q_', envir=test.env)
            Big_M=get('Big_M', envir=test.env)
            Tc=builder[[3]]
            Ts_t=get('TC_SNP', envir=test.env)
            g=build_emi_MM(n=n,mu,alpha,M_a,Tc=Tc,mu_b=mu_b,Ts_t[[chr]][[1]],beta=beta,Beta=Beta)
            nu=builder[[2]]

            LH=-sum(log(A)*Big_Xi[[chr]])-sum(log(nu)*q_[[chr]])
            for(gg in 1:length(g)){
              x=as.vector(g[[gg]])
              keep=which(x>0)
              x=x[keep]
              m=as.vector(Big_M[[chr]][[gg]])
              m=m[keep]
              LH=LH-sum(log(x)*m)
            }
          }
          if(!BW){
            LH=-sum(log(A)*Big_Xi[[chr]])
          }
        }

        return(LH)
      }

      param=c()
      if(ER==1){
        param=c(param,oldrho)
      }

      if(SF==1){
        param=c(param,oldsigma)
      }

      if(SB==1){
        param=c(param,oldbeta)
      }
      if(B==1){
        param=c(param,oldalpha)
      }
      if(!Popfix){
        param=c(param,oldXi_)
      }

      sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
      sol=as.matrix(sol[[1]])
      start_position=0
      sol=as.numeric(sol[1:length(param),1])

      if(ER==1){
        rho=sol[(start_position+1):(start_position+lr)]
        start_position=start_position+lr
        #
        oldrho=rho
      }

      if(SF==1){
        sigma_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldsigma=sigma_
      }



      if(SB==1){
        beta_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldbeta=beta_
      }

      if(B==1){
        alpha_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldalpha=alpha_
      }


      if(!Popfix){
        Xi_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldXi_=Xi_
      }




    }
  }else{
    if(NC==1){

      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        Boxa=get('Boxa', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Sigma=get('Sigma', envir=test.env)
        Alpha=get('Alpha', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        B=get('B', envir=test.env)
        n_sca=get('n_sca', envir=test.env)

        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)


        start_position=0
        if(ER==1){
          #rho_=numeric(1)
          rho=param[(start_position+1):(start_position+1)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+1

        }
        if(ER==0){
          rho=Rho
        }
        if(SF==1){

          sigma=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]

        }

        if(SF==0){
          sigma=get('sigma', envir=test.env)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+1

        }

        if(SB==0){
          beta=get('beta', envir=test.env)

        }




        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          start_position=start_position+Klink
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }

        if(B==1){
          alpha=param[(start_position+1):(start_position+n_sca)]
          start_position=start_position+n_sca
          alpha=alpha*(Boxa[2]-Boxa[1])
          alpha=alpha+Boxa[1]
        }
        if(B==0){
          alpha=rep(get('alpha', envir=test.env),n_sca)
        }

        LH=0
        sca=get('sca', envir=test.env)
        #for(sca in 1:n_sca){
        if(B){
          builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha[sca],beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy)
          Q=builder[[1]]
          Q=t(Q)
          A=as.vector(Q)
          keep=which(A>0)
          A=A[keep]
          Big_Xi[[sca]]=as.vector(Big_Xi[[sca]])
          Big_Xi[[sca]]=Big_Xi[[sca]][keep]

          if(BW){
            q_=get('q_', envir=test.env)
            Big_M=get('Big_M', envir=test.env)
            Tc=builder[[3]]
            Ts_t=get('TC_SNP', envir=test.env)
            g=build_emi_MM(n=n,mu,alpha[[sca]],M_a,Tc=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta)
            Big_M=get('Big_M', envir=test.env)
            nu=builder[[2]]
            LH=LH-sum(log(A)*Big_Xi[[sca]])-sum(log(nu)*q_)
            for(gg in 1:length(g)){
              x=as.vector(g[[gg]])
              keep=which(x>0)
              x=x[keep]
              m=as.vector(Big_M[[sca]][[gg]])
              m=m[keep]
              LH=LH-sum(log(x)*m)
            }
          }
          if(!BW){
            LH=LH-sum(log(A)*Big_Xi[[sca]])
          }
        }else{
          builder=build_SMBC_matrix(n,rho,L=L,Xi=Xi,scale=window_scaling,alpha=alpha[1],beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy)
          Q=builder[[1]]
          Q=t(Q)
          A=as.vector(Q)
          keep=which(A>0)
          A=A[keep]
          Big_Xi_real=get('full_Big_Xi', envir=test.env)
          Big_Xi_real=as.numeric(Big_Xi_real)
          Big_Xi_real=Big_Xi_real[keep]

          if(BW){
            stop("To code!")
            q_=get('q_', envir=test.env)
            Big_M=get('Big_M', envir=test.env)
            Tc=builder[[3]]
            Ts_t=get('TC_SNP', envir=test.env)
            g=build_emi_MM(n=n,mu,alpha[1],M_a,Tc=Tc,mu_b=mu_b,Ts_t[[1]],beta=beta,Beta=Beta)
            Big_M=get('Big_M', envir=test.env)
            nu=builder[[2]]
            LH=LH-sum(log(A)*Big_Xi[[sca]])-sum(log(nu)*q_)
            for(gg in 1:length(g)){
              x=as.vector(g[[gg]])
              keep=which(x>0)
              x=x[keep]
              m=as.vector(Big_M[[sca]][[gg]])
              m=m[keep]
              LH=LH-sum(log(x)*m)
            }
          }
          if(!BW){
            LH=LH-sum(log(A)*Big_Xi_real)
          }
        }

        #}
        return(LH)
      }
      n_sca=0
        for(sca in 1:length(N)){
          n_sca=n_sca+1
      }
      test.env$n_sca <- n_sca
      param=c()
      if(ER==1){
        param=c(param,oldrho)

      }

      if(SF==1){
        param=c(param,oldsigma)

      }

      if(SB==1){
        param=c(param,oldbeta)
      }

      if(!Popfix){
        param=c(param,oldXi_)
      }


      if(length(param)>0){
        test.env$B <- F

        sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
        sol=as.matrix(sol[[1]])
        sol=as.numeric(sol[1:length(param),1])
        test.env$B=B
      }
      if(B){
        l_param=length(param)
        if(l_param>0){
        param=c(sol,rep(oldalpha,n_sca))
        }
        for(sca in 1:n_sca){
          LH=0
          for(value in seq(0,1,0.02)){
            value_s=param[(l_param+sca)]
            param[(l_param+sca)]=value
            test.env$sca <-sca
            LH_temp=function_to_minimize(param)
            if(LH==0|LH_temp<LH){
              LH=LH_temp
            }else{
              param[(l_param+sca)]=value_s
            }
          }
        }
      }

      start_position=0
      if(ER==1){
        rho=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldrho=rho
      }

      if(SF==1){
        sigma_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldsigma=sigma_
      }



      if(SB==1){
        beta_=sol[(start_position+1):(start_position+1)]
        start_position=start_position+1
        oldbeta=beta_
      }




      if(!Popfix){
        Xi_=sol[(start_position+1):(start_position+Klink)]
        start_position=start_position+Klink
        oldXi_=Xi_
      }

      if(B==1){
        alpha_=param[(start_position+1):(start_position+n_sca)]
        start_position=start_position+n_sca
        oldalpha=alpha_
      }
    }
    if(NC>1){
      function_to_minimize<-function(param){
        Boxr=get('Boxr', envir=test.env)
        mu=get('mu', envir=test.env)
        mu_b=get('mu_b', envir=test.env)
        Klink=get('Klink', envir=test.env)
        Rho=get('Rho', envir=test.env)
        BoxB=get('BoxB', envir=test.env)
        Boxs=get('Boxs', envir=test.env)
        BoxP=get('BoxP', envir=test.env)
        Boxa=get('Boxa', envir=test.env)
        pop_vect=get('pop_vect', envir=test.env)
        L=get('L', envir=test.env)
        n=get('k', envir=test.env)
        Beta=get('Beta', envir=test.env)
        Sigma=get('Sigma', envir=test.env)
        Alpha=get('Alpha', envir=test.env)
        window_scaling=get('window_scaling', envir=test.env)
        Pop=get('Pop', envir=test.env)
        ER=get('ER', envir=test.env)
        SF=get('SF', envir=test.env)
        SB=get('SB', envir=test.env)
        BW=get('BW', envir=test.env)
        Big_Xi=get('Big_Xi', envir=test.env)
        lr=get('lr', envir=test.env)
        NC=get('NC', envir=test.env)
        n_sca=get('n_sca', envir=test.env)
        start_position=0
        if(ER==1){
          #rho_=numeric(1)
          rho=param[(start_position+1):(start_position+lr)]
          rho=rho*sum(Boxr)
          rho=rho-(Boxr[1])
          rho=10^(rho)
          rho=rho*Rho
          start_position=start_position+lr

        }
        if(ER==0){
          rho=Rho
        }
        if(SF==1){

          sigma=param[(start_position+1):(start_position+1)]
          start_position=start_position+1
          sigma=sigma*(Boxs[2]-Boxs[1])
          sigma=sigma+Boxs[1]

        }

        if(SF==0){
          sigma=get('sigma', envir=test.env)
        }
        if(SB==1){
          beta_=numeric(n)
          beta=((param[(start_position+1):(start_position+1)]*(BoxB[2]-BoxB[1]))+BoxB[1])^2
          start_position=start_position+1

        }

        if(SB==0){
          beta=get('beta', envir=test.env)

        }

        if(B==1){
          alpha=param[(start_position+1):(start_position+n_sca)]
          start_position=start_position+n_sca
          alpha=alpha*(Boxa[2]-Boxa[1])
          alpha=alpha+Boxa[1]
        }
        if(B==0){
          alpha=get('alpha', envir=test.env)
        }


        if(!Pop){
          Xi=numeric(n)
          Xi_=param[(start_position+1):(start_position+Klink)]
          xx=0
          for(ix in 1:Klink){
            x=xx+1
            xx = xx + pop_vect[ix]
            Xi[x:xx]=Xi_[ix]
          }
          Xi=Xi*sum(BoxP)
          Xi=Xi-(BoxP[1])
          Xi=10^Xi
        }else{
          Xi=rep(1,n)
        }
        LH=0
        c_sca=0
        for(chr in 1:NC){
           for(sca in 1:length(Big_Xi[[chr]])){
             c_sca=c_sca+1
          builder=build_SMBC_matrix(n,rho[chr],L=L[chr],Xi=Xi,scale=window_scaling,alpha=alpha[c_sca],beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy)
          Q=builder[[1]]
          Q=t(Q)
          A=as.vector(Q)
          keep=which(A>0)
          A=A[keep]
          Big_Xi[[chr]][[sca]]=as.vector(Big_Xi[[chr]][[sca]])
          Big_Xi[[chr]][[sca]]=Big_Xi[[chr]][[sca]][keep]

          if(BW){
            q_=get('q_', envir=test.env)
            Big_M=get('Big_M', envir=test.env)
            Tc=builder[[3]]
            Ts_t=get('TC_SNP', envir=test.env)
            g=build_emi_MM(n=n,mu,alpha[c_sca],M_a,Tc=Tc,mu_b=mu_b,Ts_t[[chr]][[1]],beta=beta,Beta=Beta)
            nu=builder[[2]]

            LH=-sum(log(A)*Big_Xi[[chr]][[sca]])-sum(log(nu)*q_[[chr]])
            for(gg in 1:length(g)){
              x=as.vector(g[[gg]])
              keep=which(x>0)
              x=x[keep]
              m=as.vector(Big_M[[chr]][[sca]][[gg]])
              m=m[keep]
              LH=LH-sum(log(x)*m)
            }
          }
          if(!BW){
            LH=-sum(log(A)*Big_Xi[[chr]][[sca]])
          }
        }
       }
        return(LH)
      }
      n_sca=0
      for(chr in 1:length(N)){
        for(sca in 1:length(N[[chr]])){
          n_sca=n_sca+1
        }
      }
      test.env$ncs <- n_sca
      param=c()

      if(B==1){
        param=c(param,rep(oldalpha,n_sca))
      }


      sol= BB::BBoptim(param,function_to_minimize,lower=0,upper=1,method=c(2),control = list(maxit=35+length(param),M=c(20)))
      sol=as.matrix(sol[[1]])
      start_position=0
      sol=as.numeric(sol[1:length(param),1])


      if(B==1){
        alpha_=sol[(start_position+1):(start_position+n_sca)]
        start_position=start_position+n_sca
        oldalpha=alpha_
      }





    }
  }


  if(B){
    alpha=((oldalpha*(Boxa[2]-Boxa[1]))+Boxa[1])
    print("alpha:")
    print(alpha)
  }
  if(SB){
    beta=((oldbeta*(BoxB[2]-BoxB[1]))+BoxB[1])^2
  }
  if(SF){
    sigma=oldsigma*(Boxs[2]-Boxs[1])
    sigma=sigma+Boxs[1]
  }
  if(ER){
  rho_=oldrho*sum(Boxr)
  rho_=rho_-(Boxr[1])
  rho_=10^(rho_)
  rho_=rho_*Rho
  rho_=rho_/(2*L)
  }else{
    rho_=gamma*mu
  }
  if(Pop){
    xx=0
    for(ix in 1:Klink){
      x=xx+1
      xx = xx + pop_vect[ix]
      oldXi[x:xx]=oldXi_[ix]
    }
    Xi_=oldXi*sum(BoxP)
    Xi_=Xi_-(BoxP[1])
    Xi_=10^Xi_
  }else{
    Xi_=NA
  }
  res<-list()

  if(ploidy==1){
    m=1+(1/((2^(Alpha-1))*(Alpha-1)))
    scale_Alpha=(m^Alpha)/(Alpha*beta(2-Alpha,Alpha))
  }
  if(ploidy==2){
    m= 2.0 + exp(Alpha * log(2) + (1 - Alpha) * log(3) - log(Alpha - 1))
    scale_Alpha=4*(m^Alpha)/(Alpha*beta(2-Alpha,Alpha))
  }
  res$scale_Alpha=scale_Alpha
  if(ploidy==1){
    m=1+(1/((2^(mean(alpha)-1))*(mean(alpha)-1)))
    scale_alpha=(m^mean(alpha))/(mean(alpha)*beta(2-mean(alpha),mean(alpha)))
  }
  if(ploidy==2){
    m= 2.0 + exp(mean(alpha) * log(2) + (1 - mean(alpha)) * log(3) - log(mean(alpha) - 1))
    scale_alpha=4*(m^mean(alpha))/(mean(alpha)*beta(2-mean(alpha),mean(alpha)))
  }
  res$scale_alpha=scale_alpha
  res$rho=rho_
  if(Pop){
    res$Xi=Xi_
  }else{
    res$Xi=rep(1,n)
  }


  if(NC==1){
    builder=build_SMBC_matrix(n,rho_*(2*L),L=L,Xi=Xi_,scale=window_scaling,alpha=mean(alpha),beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy) # (n=20,rho,beta=1,L,Pop=T,Xi=NA,Beta=1,scale=c(1,0),sigma=0,Sigma=0,FS=F,Big_Window=F,tmax=15,alpha_t=0.1,npair=2,cut_edge=F)
    Tc=builder[[4]]
  }
  if(NC>1){
    Tc=list()
    for(chr in 1){
      builder=build_SMBC_matrix(n,rho_[chr]*(2*L[chr]),L=L[chr],Xi=Xi_,scale=window_scaling,alpha=mean(alpha),beta=beta,sigma=sigma,Beta=Beta,Alpha=Alpha,Sigma=Sigma,M_a=M_a,ploidy=ploidy)
      Tc=builder[[4]]
    }
  }
  res$sigma=sigma
  res$beta=beta
  res$alpha=alpha
  res$L<-L
  res$rho=rho_
  res$scale_T=scale_T
  res$Tc=Tc
  res$mu=mu
  res$theta=theta
  res$N=N
  res$Q=builder[[1]]
  #if(NC==1&simulator=="msprime"){
  if(all(!is.na(mu_real))){
  out=Ne_Beta_founder(theta=sum(theta),L=sum(L),M_a=3,mu_real=mu_real,alpha=min(1.9,mean(alpha)),ploidy=ploidy)

  res$Ne=out$Ne
  }else{
  res$Ne=Ne
  }
  #}
  return(res)
}
