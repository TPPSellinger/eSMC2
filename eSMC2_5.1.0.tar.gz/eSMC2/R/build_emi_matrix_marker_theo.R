#' Builds the emission matrix of the Sequentially Markovian Coalescent with methylation
#'
#' @param mu : estimated mutation rate given prior
#' @param Ne : estimated effective population size
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Tc : coalescent times to discretize time
#' @param t : expected  coalescent times of hidden states
#' @param beta : germination rate of vector of germination rates
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @return The emission matrix
build_emi_matrix_marker_theo<-function(mu,Ne,mu_b,Tc,t,beta,Nb_marker,nb_state_marker=list(c(2),c(2),c(2)),Marker_supperposition){
  Nb_marker=as.numeric(Nb_marker)
  n=length(t)
  Delta=Tc[2:n]-Tc[1:(n-1)]
  if(length(beta)==1){
    beta=rep(beta,length(t))
  }
  if(Marker_supperposition){

    mut_index=c()
    for(marker in 1:Nb_marker){
      if(marker==1){
        mut_index=c(0,1)
      }else{
        mut_index_o=mut_index
        mut_index=c()
        for(mu_i in  mut_index_o)
          mut_index=c(mut_index,paste(mu_i,c(0,1),sep=""))
      }
    }
    #print("mut_index:")
    #print(mut_index)
    nb_observation=1+(2^Nb_marker)
    g=matrix(0,length(t),nb_observation)
    g[,2]=1

    g_0=list()
    g_1=list()
    for(marker in 1:Nb_marker){
      g_0[[marker]]=numeric(n)
      for(k in 1:n){
        if(k>1){
          g_0[[marker]][k]= (1/nb_state_marker[[marker]])  + ((nb_state_marker[[marker]]-1)/nb_state_marker[[marker]] )*exp(-Ne*nb_state_marker[[marker]] *mu[[marker]]*((sum((beta[1:(k-1)]+((1-beta[1:(k-1)])*mu_b))*2*Delta[1:(k-1)]))+(beta[k]+((1-beta[k])*mu_b))*2*(t[k]-Tc[k]))/(nb_state_marker[[marker]]-1))
        }else{
          g_0[[marker]][k]=(1/nb_state_marker[[marker]])  + ((nb_state_marker[[marker]]-1)/nb_state_marker[[marker]] )*exp(-Ne*nb_state_marker[[marker]] *mu[[marker]]*((beta[k]+((1-beta[k])*mu_b))*(2*t[k]))/(nb_state_marker[[marker]]-1))
        }
      }
      g_1[[marker]]=1-g_0[[marker]]
    }
    count=0
    for(ob in mut_index){
      count=count+1
      if(count==2){
        count=count+1
      }
      for(car in 1:nchar(ob)){

        if(car==1){
          if(substr(ob,car,car)=="1"){
            g[,count]=g_1[[car]]
          }else{
            g[,count]=g_0[[car]]
          }
        }else{
          if(substr(ob,car,car)=="1"){
            g[,count]=g[,count]*g_1[[car]]
          }else{
            g[,count]=g[,count]*g_0[[car]]
          }
        }

      }


    }


  }else{

    nb_observation=(Nb_marker*2)+1
    g=matrix(0,length(t),nb_observation)
    g[,(Nb_marker+1)]=1
    for(marker in 1:Nb_marker){

      for(k in 1:n){
        if(k>1){
          g[k,marker]= (1/nb_state_marker[[marker]])  + ((nb_state_marker[[marker]]-1)/nb_state_marker[[marker]] )*exp(-Ne*nb_state_marker[[marker]] *mu[[marker]]*((sum((beta[1:(k-1)]+((1-beta[1:(k-1)])*mu_b))*2*Delta[1:(k-1)]))+(beta[k]+((1-beta[k])*mu_b))*2*(t[k]-Tc[k]))/(nb_state_marker[[marker]]-1))
        }else{
          g[k,marker]=(1/nb_state_marker[[marker]])  + ((nb_state_marker[[marker]]-1)/nb_state_marker[[marker]] )*exp(-Ne*nb_state_marker[[marker]] *mu[[marker]]*((beta[k]+((1-beta[k])*mu_b))*2*(t[k]))/(nb_state_marker[[marker]]-1))
        }
      }
      g[,((Nb_marker+1)+marker)]=1-g[,marker]


      if(marker==1){
        p=1
        g[,marker]=g[,marker]*p
        g[,((Nb_marker+1)+marker)]=g[,((Nb_marker+1)+marker)]*p
      }else{
        p=1
        g[,marker]=g[,marker]*p
        g[,((Nb_marker+1)+marker)]=g[,((Nb_marker+1)+marker)]*p
      }
    }
  }
  return(g)
}
