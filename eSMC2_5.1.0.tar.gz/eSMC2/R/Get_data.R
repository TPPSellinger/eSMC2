#' Read text file
#'
#' Read a text file
#' @param path : location of the file
#' @param heavy : TRUE to read simulated sequence
#' @param simulator : scrm ,msprime , msms, argweaver
#' @return A ms output file
Get_data<-function(path, heavy=F,simulator="scrm"){
  DNAseqfile=list()
  count_DNA=0
  con = file(path, "r")
  while ( TRUE ) {

    line = readLines(con, n = 1)
    if ( length(line) == 0  ){
      break
    }
    if(simulator!="argweaver"){
      count_DNA= count_DNA+1
      DNAseqfile[[count_DNA]]=as.vector(unlist(strsplit(as.vector(line)," ")))
      if (heavy&substr(line,1,3)=="seg"){
        if(simulator=="scrm"|simulator=="msms"){
          break
        }
      }
    }else{

      if (substr(line,1,4)=="TREE"){
        count_DNA= count_DNA+1
        DNAseqfile[[count_DNA]]=as.vector(unlist(strsplit(substr(as.vector(line),6,nchar(line)),"\t")))
        DNAseqfile[[count_DNA]][2]=(as.numeric(DNAseqfile[[count_DNA]][2])-as.numeric(DNAseqfile[[count_DNA]][1]))+1
        DNAseqfile[[count_DNA]]=DNAseqfile[[count_DNA]][-1]
        DNAseqfile[[count_DNA]][2]=gsub("\\[[^][]*]", "",as.character(DNAseqfile[[count_DNA]][2]))
      }
    }

  }
  close(con)
  return(DNAseqfile)
}
