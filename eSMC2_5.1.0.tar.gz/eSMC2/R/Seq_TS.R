#' Estimates coalescent time at each position under the SMC
#'
#' @param n : Number of hidden states
#' @param rho : prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param symbol_number : number of zipping step
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param M_a : effective number of simultaneously analyzedf sequence
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @export
#' @return list of size 2, first one containing hidden states (i.e. coalescence time) and second one the sequences of expected hidden state along the genome
Seq_TS<-function(n=40,rho=1,O,symbol_number=20,NC=1,M_a=3,position_removed=NA){
  M_a=max(2,M_a)
  M_a=min(4,M_a)
  gamma=rho
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    Os=list()
    count=0
    theta_W=0
    s=dim(O)[1]
    if(M_a==2){
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          print("Creating seq")
          Os_=seqSNP2_MH(O[c(k,l,(s-1),s),],L,position_removed[[1]])
          if((Os_$theta)>=2){
            print((Os_$theta))
            theta_W=theta_W+((Os_$theta))
            print(count)

            count=count+1
            print(count)
            if(count==1){
               Mat_symbol=Mat_symbol_ID()
            }
              print("Ziping")
              Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              rm(Os_)

            print("Symbol to number")
            Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
          }
        }
      }
    }
    if(M_a==3){

      for(k in 1:(M-2)){
        for(l in (k+1):(M-1)){
          for(m in (l+1):M){
            Os_=seqSNP2_MM(O[c(k,l,m,(s-1),s),],L,M_a)
            theta_W=theta_W+Os_$theta
            print("Nb SNPs")
            print(Os_$theta)
            Os_=as.numeric(Os_$seq)
            Os_[which(Os_%in%c(1,2,3))]<-1
            if(any(Os_==4)){
              Os_[Os_==4]<-2
            }
            #print(unique(Os_))
            count=count+1
            print(count)
            if(count==1){
              Os[[count]]=Build_zip_ID_2seq(Os_)
              Mat_symbol=Os[[count]][[2]]
            }
            if(count>1){
              Os[[count]]=Zip_seq(Os_,Mat_symbol)
            }

            Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
          }
        }
      }
    }
    if(M_a==4){
      for(k in 1:(M-3)){
        for(l in (k+1):(M-2)){
          for(m in (l+1):(M-1)){
            for(mm in (m+1):M){
              Os_=seqSNP2_MM(O[c(k,l,m,mm,(s-1),s),],L,M_a)
              theta_W=theta_W+Os_$theta
              Os_=Os_$seq
              Os_[Os_>4&Os_<8]<-0
              Os_[Os_>0&Os_<5]<-1
              Os_[Os_==8]<-2
              count=count+1
              print(count)
              if(count==1){
                Os[[count]]=Build_zip_ID_2seq(Os_)
                Mat_symbol=Os[[count]][[2]]
              }
              if(count>1){
                Os[[count]]=Zip_seq(Os_,Mat_symbol)
              }
              Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
            }
          }
        }
      }
    }
    if(length(Os)>=1){
      theta_W=theta_W/length(Os)
      theta=theta_W
      mu=theta/(2*L)
      rho=rho*theta
      rm(Os_)
    }
    if(length(Os)==0){
      stop("data too poor")
    }

  }
  if(NC>1){
    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=vector(length=NC)
    L_total=vector()
    for(chr in 1:NC){
      theta_W=0
      count=0
      OST_=list()
      M=(dim(O[[chr]])[1]-2)
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      s=dim(O[[chr]])[1]
      if(M_a==2){
        for(k in 1:(M-1)){
          for(l in (k+1):M){
            print("Creating seq")
            Os_=seqSNP2_MH(O[[chr]][c(k,l,(s-1),s),],L,position_removed[[1]])
            if((Os_$theta)>=2){
              print((Os_$theta))
              theta_W=theta_W+((Os_$theta))
              print(count)

              count=count+1
              print(count)
              if(count==1){
                OST_[[count]]=Build_zip_ID_2seq(Os_)
                Mat_symbol=OST_[[count]][[2]]
              }else{
                count=count+1
                print("Ziping")
                OST_[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                rm(Os_)

              }
              print("Symbol to number")
              OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])
            }
          }
        }
      }
      if(M_a==3){
        for(k in 1:(M-2)){
          for(l in (k+1):(M-1)){
            for(m in (l+1):M){
              Os_=seqSNP2_MM(O[[chr]][c(k,l,m,(s-1),s),],L,M_a)
              theta_W=theta_W+Os_$theta
              Os_=Os_$seq
              Os_[Os_>0&Os_<4]<-1
              Os_[Os_==4]<-2
              count=count+1
              print(count)
              if(count==1){
                OST_[[count]]=Build_zip_ID_2seq(Os_)
                Mat_symbol=OST_[[count]][[2]]
              }
              if(count>1){
                OST_[[count]]=Zip_seq(Os_,Mat_symbol)
              }

              OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])



            }
          }
        }
      }
      if(M_a==4){
        for(k in 1:(M-3)){
          for(l in (k+1):(M-2)){
            for(m in (l+1):(M-1)){
              for(mm in (m+1):M){
                Os_=seqSNP2_MM(O[[chr]][c(k,l,m,mm,(s-1),s),],L,M_a)
                theta_W=theta_W+Os_$theta
                Os_=Os_$seq
                Os_[Os_>4&Os_<8]<-0
                Os_[Os_>0&Os_<5]<-1
                Os_[Os_==8]<-2
                count=count+1
                print(count)
                if(count==1){
                  OST_[[count]]=Build_zip_ID_2seq(Os_)
                  Mat_symbol=OST_[[count]][[2]]
                }
                if(count>1){
                  OST_[[count]]=Zip_seq(Os_,Mat_symbol)
                }
                OST_[[count]]=symbol2Num(OST_[[count]][[1]],OST_[[count]][[2]])
              }
            }
          }
        }
      }
      rm(Os_)
      Os[[chr]]=OST_
      theta_W=theta_W/length(OST_)
      theta_W_V[chr]=theta_W
      rm(OST_)
    }
    theta=theta_W_V
    mu=sum(theta)/(2*sum(L_total))
    rho=rho*theta
    L=L_total
    theta_W=theta_W_V
  }
  if(length(Os)>=1){
    results=Path_finder(Os=Os,L=L,mu=mu,theta_W =theta_W,Rho=rho,k=n,NC=NC,M_a=M_a)
  }
  return(results)


}
