#'  Builds the matrix symbol
#'
#' @param n : number of hidden state
#' @return A list of matrix symbol
Mat_symbol_ID_MM<-function(n=40){
  max_count=10
  output=list()
  mat_symbol=list()
  Mat_symbol=list()
  for(iii in 1:n){
    mat_symbol[[iii]]=vector()
    count=0
      default_symbol=c("00","aa","bb","cc","dd","ee","ff","gg","hh","ii")
      while(count<max_count){
        count=count+1
        new_symbol=letters[count]
        symbol=default_symbol[count]
        real_symb=vector()
        if(length(symbol)>0){
            rep_symbol=symbol
            mat_symbol[[iii]]=rbind(mat_symbol[[iii]],c(new_symbol,rep_symbol))
        }
      }
  }
  return(mat_symbol)
}
