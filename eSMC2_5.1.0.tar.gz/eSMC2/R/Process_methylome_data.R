#' Builds epimutation matrix
#'
#' @param path : path to methylation file
#' @param hap : TRUE if haploid
#' @param counts : minimum number of reads
#' @return : epimutation matrix
Process_methylome_data<-function(path,hap=T,counts=3){
  data=Get_vcf_data(path)

  size_vect=as.numeric(as.vector(unlist(lapply(1:length(data),function(x){length(data[[x]])}))))
  good_size=length(data[[2]])
  pos_rm=which(size_vect!=good_size)
  if(length(pos_rm)>0){
    data=data[-pos_rm]
  }

  data=matrix(unlist(data),ncol=length(data[[2]]),nrow=length(data),byrow = T)
  data=data[which(data[,4]=="CG"),]
  data=data[which(data[,3]=="+"),]
  data=data[which(as.numeric(data[,6])>counts),]
  #data=data[which(as.numeric(data[,5])<=1|as.numeric(data[,5])>=(as.numeric(data[,6])-1) ),]
  #data=data[which(as.numeric(data[,5])==0|as.numeric(data[,5])==(as.numeric(data[,6]))),]
  data=data[which(as.numeric(data[,7])>=0.999),]
  rm_pos=which(is.na(as.numeric(data[,1])))
  if(length(rm_pos)>1){
    data=data[-rm_pos,]
  }
  print("Nb chromosome:")
  nchr=length(unique(data[,1]))

  print(nchr)
if(hap){
  if(nchr>1){
    SNP_mat=list()
    count_chr=0
    for(chr in as.numeric(sort(unique(data[,1]))) ){
      M=1
      count_chr=count_chr+1
      data_temp=data[which( as.numeric(data[,1])==as.numeric(chr)),]

      SNP_mat[[count_chr]]=matrix(0,ncol = dim(data_temp)[1],nrow = (M+1))
      SNP_mat[[count_chr]][1,]=data_temp[,8]
      SNP_mat[[count_chr]][2,]=data_temp[,2]
      rm(data_temp)
      pos_0=which(as.numeric(SNP_mat[[count_chr]][dim(SNP_mat)[1],])==0)
      if(length(pos_0)>1){
        SNP_mat[[count_chr]]=SNP_mat[[count_chr]][,-pos_0]
      }
    }
  }else{
    M=1
    SNP_mat=matrix(0,ncol = dim(data)[1],nrow = (M+1))
    SNP_mat[1,]=data[,8]
    SNP_mat[2,]=data[,2]
    pos_0=which(as.numeric(SNP_mat[dim(SNP_mat)[1],])==0)
    if(length(pos_0)>1){
      SNP_mat=SNP_mat[,-pos_0]
    }
    #SNP_mat=list(SNP_mat)
  }
}else{

}
  return(SNP_mat)
}
