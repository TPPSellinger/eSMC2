#' Builds the time window of eSMC2 from parameters
#'
#' @param n : number of  hidden states
#' @param Beta : germination rate to build hidden states
#' @param scale : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param Sigma : self-fertilization rate to build hidden states
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param tmax : numerical value parametrizing the time window, the bigger it is, the further in time goes the time window
#' @param alpha_t : numerical value parametrizing the time window, the smaller it is, the more recent in time is defined the time window
#' @param npair : number of pairewise analysis
#' @export
#' @return  A numeric vector indicating the bins to discretize time in unit of coalescence time.
build_Tc<-function(n=20,Beta=1,scale=c(1,0),Sigma=0,Big_Window=F,tmax=15,alpha_t=0.1,npair=1){

  if(as.numeric(Big_Window)==0){
    Vect=0:(n-1)
    Tc= scale[2] -(0.5*(2-Sigma)*log(1-(Vect/n))/((Beta^2)*scale[1]))
  }
  if(as.numeric(Big_Window)==1){
    Vect=1:(n-1)
    alpha_t=alpha_t/(npair)
    tmax=tmax*npair
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])))

  }
  if(as.numeric(Big_Window)==2){
    tmax=50
    Vect=1:(n-1)
    alpha_t=0.001
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])) )
  }
  if(as.numeric(Big_Window)==3){
    tmax=20
    Vect=1:(n-1)
    alpha_t=0.1
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])) )
  }

  if(as.numeric(Big_Window)==4){
    tmax=20
    alpha_t=0.005
    Vect=1:(n-1)
    Tc= c(0,scale[2] + (0.5*(2-Sigma)*(alpha_t*exp((Vect/n)*log(1+(tmax/alpha_t))-1))/((Beta^2)*scale[1])) )
  }

  return(Tc)
}

