#'  Zip the  signal to reduce signal length
#'
#' @param Os : original signal (sequence of 0 and 1)
#' @param mat_symbol : list of matrix symbol containing symbol to zip the sequence
#' @param n : number of hidden state
#' @return A list with first object the ziped sequence and as second the symbol matrix#
Zip_seq_MM<-function(Os,mat_symbol,n=40){
  max_count=10
  Mat_symbol=list()
  output=list()
  symbol_v=c(letters[12:26],LETTERS,strsplit(intToUtf8(35:43),split = "")[[1]])
  Os=paste(as.character(Os),collapse = ".")
  for(iii in 1:n){
    Mat_symbol_t=mat_symbol[[iii]]
    if(iii==1){
      start_symbol=9
    }
    if(iii>1){
      start_symbol=start_symbol+max_count
    }
      for(count in dim(mat_symbol[[iii]])[1]:1){
            symbol=paste(rep(paste(".",symbol_v[iii],sep=""),2^count),collapse ="")
            x=count

            Os=gsub(symbol,paste(".",(start_symbol+x),sep=""),Os,fixed = T)

            Mat_symbol_t[x,1]=(start_symbol+x)
            sym=paste((start_symbol+x-1),(start_symbol+x-1),sep=" ")
            Mat_symbol_t[x,2]=sym
      }
    Mat_symbol_t[1,2]="0 0"
    Mat_symbol[[iii]]=Mat_symbol_t
  }
  for(iii in 1:n){
    symbol=symbol_v[iii]
    Os=gsub(symbol,as.character(-iii),Os,fixed = T)
  }
  Os=as.numeric(unlist(strsplit(Os,".",fixed = T)))
  if(any(is.na(Os))){
    browser()
  }
  output[[1]]=Os
  output[[2]]=Mat_symbol
  output[[3]]=mat_symbol
  return(output)
}
