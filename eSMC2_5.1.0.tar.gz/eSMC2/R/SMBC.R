#' Runs the Sequentially Markovian Beta Coalescent
#'
#' @param n : Number of hidden states
#' @param rho : prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param maxit : maximum number of iteration for the baum_welch algorithm
#' @param alpha : initial value for the beta distribution (multiple merger parameter)
#' @param Boxa : boundaries of alpha, numeric vector of size 2 indication the minimum and maximum values of alpha (must be bigger than 1 and smaller than 2)
#' @param BoxP : logarithmic boundaries in base 10 for the  demography e.g. c(3,3) means the  population size can grow up to a thousand time  and decrease up to a thousand time
#' @param Boxr : logarithmic boundaries in base 10 for the  recombination rate e.g. c(1,1) means the recombination rate can be up to ten times smaller or bigger than the initial given value
#' @param BoxB : boundaries of beta, numeric vector of size 2 indication the minimum and maximum values rate ( first value must be  bigger than 0)
#' @param Boxs : boundaries for the self-fertilization rate e.g. c(0.5,0.9) means the selfing rate is between 0.5 and 0.9
#' @param pop : True if population size is assumed constant
#' @param B : True to estimate alpha (multiple merger parameters)
#' @param ER : True to estimate recombination rate
#' @param SB : True to estimate beta (dormancy)
#' @param SF : True to estimate selfing rates
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param pop_vect : vector of hidden state sharing their population size parameter. Sum must be equal to hidden state number
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination/dormancy rate
#' @param M_a : effective number of simultaneously analyzed sequences ( currently only 3 is available)
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_MM_matrix.R
#' @param LH_opt : TRUE tu maximize likelihood and not perform the baum-welch algorithm
#' @param ploidy : ploidy level of the organism
#' @param mu_real : mutation rate
#' @export
#' @return List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, alpha the parameter of the beta distribution,  Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).
SMBC<-function(n=40,rho=1,O,maxit =20,alpha=1.99,Boxa=c(1.001,1.999),BoxP=c(3,3),Boxr=c(1,1),BoxB=c(0.05,1),Boxs=c(0,0.99),pop=T,B=T,ER=T,SB=F,SF=F,NC=1,pop_vect=NA,sigma=0,beta=1,M_a=3,Big_Window=F,LH_opt=F,ploidy,mu_real){
  M_a=max(3,M_a)
  M_a=min(4,M_a)
  if(n>50){
    print("the number of hidden state has to be smaller than 50 to zip the sequence, hence it will be set back to 50")
  }
  n=min(50,n)
  gamma=rho
  if(Boxa[2]>=2){
    Boxa[2]=1.999
  }
  if(Boxa[1]<1.001){
    Boxa[1]=1.001
  }
  alpha=min(Boxa[2],alpha)
  alpha=max(Boxa[1],alpha)
  sigma=max(Boxs[1],sigma)
  sigma=min(Boxs[2],sigma)
  beta=min(BoxB[2],beta)
  beta=max(BoxB[1],beta)

  if(any(is.na(pop_vect))){
    pop_vect=rep(2,(n*0.5))
  }
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    Os=list()
    count=0
    theta_W=0
    s=dim(O)[1]
    TC_SNP=list()
    TS=Seq_TS(n,rho,O,symbol_number=20,NC,M_a)
    #browser()
    TS_SNP=list()
    print("Sequence length:")
    print(L)
    if(M_a==3){
      print(L)
      start_time <- Sys.time()
      for(k in 1:(M-2)){
        for(l in (k+1):(M-1)){
          for(m in (l+1):M){
            #print("After SNP")
            Os_=seqSNP2_MM(O[c(k,l,m,(s-1),s),],L,M_a)
            theta_W=theta_W+Os_$theta
            Os_=Os_$seq
            count=count+1
            TC_SNP[[count]]=2*TS$Tc
            pos=which(as.numeric(Os_)==0)
            pos_SNP=which(as.numeric(Os_)%in%c(1,2,3))
            TS_SNP[[count]]=TS$seq[[count]][pos_SNP]
            #print(TS$Tc[floor(mean(as.numeric(TS_SNP[[count]])))])
            #browser()
            symbol_v=c(letters[12:26],LETTERS,strsplit(intToUtf8(35:43),split = "")[[1]])
            #Os_[pos]=(-1)*as.numeric(TS$seq[[count]][pos])
            Os_[pos]=symbol_v[as.numeric(TS$seq[[count]][pos])]
            if(count==1){
              Mat_symbol=Mat_symbol_ID_MM(n=n)
            }
            Os[[count]]=Zip_seq_MM(Os_,Mat_symbol,n=n)
            print(count)
            print("Zipped Sequence length:")
            print(length(Os[[count]][[1]]))
       }
      }
      }
      end_time <- Sys.time()
      print("Time to zip all sequences:")
      print(end_time-start_time)
    }
    if(M_a==4){
      for(k in 1:(M-3)){
        for(l in (k+1):(M-2)){
          for(m in (l+1):(M-1)){
            for(mm in (m+1):M){
              Os_=seqSNP2_MM(O[c(k,l,m,mm,(s-1),s),],L,M_a)
              theta_W=theta_W+Os_$theta
              Os_=Os_$seq
              count=count+1
              TC_SNP[[count]]=2*TS$Tc
              pos=which(as.numeric(Os_)==0)
              pos_SNP=which(as.numeric(Os_)%in%c(1,2,3,4,5,6,7))
              TS_SNP[[count]]=TS$seq[[count]][pos_SNP]
              print(TS$Tc[floor(mean(as.numeric(TS_SNP[[count]])))])
              Os_[pos]=(-1)*as.numeric(TS$seq[[count]][pos])
              if(count==1){
                Os_temporary=Build_zip_ID_MMseq(Os_[1:min(1000000,length(Os_))],n=n)
                Mat_symbol=Os_temporary[[3]]
                rm(Os_temporary)
              }
              Os[[count]]=Zip_seq_MM(Os_,Mat_symbol,n=n)
              print(count)
            }
          }
        }
      }
    }
    if(length(Os)>=1){
      theta_W=theta_W/length(Os)
      theta=theta_W
      mu=theta/(2*L)
      print("Theta waterson:")
      print(theta)
      rho=rho*theta
      O=Os
      rm(Os_)
    }
    if(length(Os)==0){
      stop("data too poor")
    }
    rm(Os)
    rm(TS)
  }
  if(NC>1){

    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=vector(length=NC)
    L_total=vector()
    TC_SNP_total=list()
    TS_SNP_total=list()
    print("Estimating external branch length")
    TS=Seq_TS(n,rho,O,symbol_number=20,NC,M_a)
    print("Zipping sequences")
    for(chr in 1:NC){
      theta_W=0
      count=0
      OST_=list()
      M=(dim(O[[chr]])[1]-2)
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      s=dim(O[[chr]])[1]
      TC_SNP=list()
      TS_SNP=list()
      if(M_a==3){
        for(k in 1:(M-2)){
          for(l in (k+1):(M-1)){
            for(m in (l+1):M){
              Os_=seqSNP2_MM(O[[chr]][c(k,l,m,(s-1),s),],L,M_a)
              theta_W=theta_W+Os_$theta
              Os_=Os_$seq
              count=count+1
              TC_SNP[[count]]=2*TS$Tc[[chr]]
              pos=which(as.numeric(Os_)==0)

              pos_SNP=which(as.numeric(Os_)%in%c(1,2,3))
              #Os_[pos]=(-1)*as.numeric(TS$seq[[chr]][[count]][pos])
              symbol_v=c(letters[12:26],LETTERS,strsplit(intToUtf8(35:43),split = "")[[1]])
              Os_[pos]=symbol_v[as.numeric(TS$seq[[count]][pos])]
              TS_SNP[[count]]=TS$seq[[chr]][[count]][pos_SNP]
              print(count)
              if(count==1){
                Mat_symbol=Mat_symbol_ID_MM(n=n)
              }

              OST_[[count]]=Zip_seq_MM(Os_,Mat_symbol,n=n)
            }
          }
        }
      }
      if(M_a==4){
        for(k in 1:(M-3)){
          for(l in (k+1):(M-2)){
            for(m in (l+1):(M-1)){
              for(mm in (m+1):M){
                Os_=seqSNP2_MM(O[[chr]][c(k,l,m,mm,(s-1),s),],L,M_a)
                theta_W=theta_W+Os_$theta
                Os_=Os_$seq
                count=count+1
                TC_SNP[[count]]=2*TS$Tc[[chr]]
                pos=which(as.numeric(Os_)==0)
                Os_[pos]=(-1)*as.numeric(TS$seq[[chr]][[count]][pos])
                pos_SNP=which(as.numeric(Os_)%in%c(1,2,3,4,5,6,7))
                TS_SNP[[count]]=TS$seq[[chr]][[count]][pos_SNP]
                print(count)
                if(count==1&chr==1){
                  Os_temporary=Build_zip_ID_MMseq(Os_[1:min(1000000,length(Os_))],n=n)
                  Mat_symbol=Os_temporary[[3]]
                  rm(Os_temporary)
                }
                OST_[[count]]=Zip_seq_MM(Os_,Mat_symbol,n=n)
              }
            }
          }
        }
      }

      rm(Os_)
      Os[[chr]]=OST_
      TC_SNP_total[[chr]]=TC_SNP
      TS_SNP_total[[chr]]=TS_SNP
      theta_W=theta_W/length(OST_)
      theta_W_V[chr]=theta_W
      rm(OST_)
    }
    rm(TS)
    theta=theta_W_V
    mu=theta/(2*L_total)
    rho=rho*theta
    O=Os
    L=L_total
    rm(Os)
    theta_W=theta_W_V
    TC_SNP=TC_SNP_total
    rm(TC_SNP_total)
    TS_SNP=TS_SNP_total
    rm(TS_SNP_total)

  }
  if(B==T){
    test=eSMC2(O=Os,n=30,BoxP=c(2,2),NC=NC)
    prior_alpha=Estimate_prior_alpha(Os=Os,Xi=test$Xi,Tc=test$Tc)
    prior_alpha=prior_alpha[[1]]
    B=F
  }
  results=BW_MM(Os=O, maxIt =maxit,L=L,mu=mu,theta_W =theta_W,Rho=rho,alpha=prior_alpha,Popfix=pop,k=n,Boxa=Boxa,beta=beta,sigma=sigma,BoxP=BoxP,Boxr=Boxr,BoxB=BoxB,Boxs=Boxs,pop_vect=pop_vect,ER=ER,NC=NC,B=B,SB=SB,SF=SF,M_a=M_a,TS_SNP=TS_SNP,TC_SNP=TC_SNP,Big_Window=Big_Window,LH_opt=LH_opt,ploidy=ploidy)
  Ne_Beta_founder<-function(theta,L,M_a=3,mu_real,alpha,ploidy=1){
    mu_estimated=(theta/(2*L))
    if(ploidy==2){
      m=2+((2^alpha)/((3^(alpha-1))*(alpha-1)))
      scale=4*(m^alpha)/(alpha*beta(2-alpha,alpha))
      Ne=2*(((mu_estimated/mu_real)/scale)^(1/(alpha-1)))
      G=(mu_estimated/mu_real)
    }
    if(ploidy==1){
      m=1+(1/((2^(alpha-1))*(alpha-1)))
      scale=(m^alpha)/(alpha*beta(2-alpha,alpha))
      Ne=(((mu_estimated/mu_real)/scale)^(1/(alpha-1)))
      G=(mu_estimated/mu_real)
    }
    res=list()
    res$Ne=Ne
    res$G=G
    res$mu=mu_estimated
    return(res)
  }
  #browser()
  out=Ne_Beta_founder(theta=sum(theta),L=sum(L),M_a=3,mu_real=mu_real,alpha=min(c(1.9,results$alpha)),ploidy=ploidy)
  results$Ne=out$Ne
  results$G=out$G
  return(results)
}
