#' Get position of cytosine from VCF file
#'
#' @param path : path to the VCF file
#' @return : numeric vector of cytosine position on the sequence
Get_C_pos<-function(path){
  data=Get_vcf_data(path)
  for(search_id in 1:length(data)){
    if(data[[search_id]][1]=="#CHROM"){
      start_position=search_id+1
      break()
    }
  }
  data=matrix(as.vector(unlist(data[start_position:length(data)])),nrow=(length(data)-(start_position-1)),ncol=length(data[[start_position]]),byrow = T)[,c(1,4)]
  data=data[which(as.character(data[,2])=="C"),]
  return(data)
}
