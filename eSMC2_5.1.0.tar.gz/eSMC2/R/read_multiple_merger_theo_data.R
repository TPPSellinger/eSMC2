#' builds segregating matrix from msprime output file
#'
#' @param path : path to the output of msprime
#' @param mut : TRUE if mutations have been simulated
#' @return A segregating matrix
read_multiple_merger_msprime_data<-function(path,mut=T){
  DNAfile=Get_data(path)
  theta=NA
  DNA=matrix(0,ncol=length(DNAfile),nrow=4)
  start=1
  if(mut==T){
    start=2
    theta=as.numeric(substr(DNAfile[[1]][2],6,nchar(DNAfile[[1]][2])))
  }

  #browser()
  for(i in start:length(DNAfile)){
    data=DNAfile[[i]][1]
    pos_state=which(strsplit(data, "")[[1]]=="s")
    pos_time=which(strsplit(data, "")[[1]]=="m")
    pos_end=which(strsplit(data, "")[[1]]=="d")
    DNA[1,i]=as.numeric(substr(data,pos_time+2,pos_end-3))
    DNA[2,i]=as.numeric(substr(data,pos_time-3,pos_time-3))
    DNA[3,i]=floor(as.numeric(substr(data,1,pos_state-1)))
    DNA[4,i]=as.numeric(substr(data,pos_end+1,nchar(data)))
  }
  DNA=DNA[,-1]
  output=list()
  output$DNA=DNA
  output$theta=theta
  return(output)
}
