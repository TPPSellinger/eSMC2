#'  Zip the  signal to reduce signal length
#'
#' @param Os : original signal (sequence of 0 and 1)
#' @param n : number of hidden state
#' @return A list with first object the ziped sequence and as second the symbol matrix#
Build_zip_ID_MMseq<-function(Os,n=40){
  max_count=10
  output=list()
  mat_symbol=list()
  Mat_symbol=list()
  for(iii in 1:n){
    mat_symbol[[iii]]=vector()
    count=0
    ini=Os[1]
    Os=Os[-1]
    pos_t=which(as.numeric(Os)==(-iii))
    if(length(pos_t)>0){
      Os[pos_t]<-0
      pos_save=which(as.numeric(Os)!=0)
      Os_save=Os[pos_save]
      Os[pos_save]<-1
      default_symbol=c("00","aa","bb","cc","dd","ee","ff","gg","hh","jj")
      while(count<max_count){
        count=count+1
        new_symbol=letters[count]
        L=length(Os)

          if(count==1){
            symbol_base=c("0")
          }
          symbol=vector()
          if(count>length(default_symbol)){
          for(sb1 in 1:length(symbol_base)){
            for(sb2 in 1:length(symbol_base)){

                symbol=c(symbol,paste(symbol_base[sb1],symbol_base[sb2],sep=""))


            }
          }
          symbol=unique(symbol)
          }else{
            symbol=default_symbol[count]
          }


        real_symb=vector()
        if(length(symbol)>0){
          nb_symbol=length(symbol)
          pos_s=vector()
          test=list()
          x=vector()
          for(k in 1:nb_symbol){
            test[[k]]=gregexpr(symbol[k],paste(as.character(Os),collapse = ""))
            x[k]=length(test[[k]][[1]])
          }
          if(any(x>1)){
            pos_k=min(which(x==max(x)))
            #  print(length(pos_k))
            rep_symbol=symbol[pos_k]
            pos_s=as.vector(as.matrix(test[[pos_k]][[1]]))

              mat_symbol[[iii]]=rbind(mat_symbol[[iii]],c(new_symbol,rep_symbol))
              symbol_base=c(symbol_base,as.character(new_symbol))

            pos_s=pos_s[which(pos_s<=length(Os))]
            #  print(length(pos_s))
            Os[pos_s]=new_symbol
            pos_s=pos_s+1
            pos_s=pos_s[which(pos_s<=length(Os))]
            Os=Os[-pos_s]
            #  print("After zip")
            #  print(length(Os))
            if(L<length(Os)){
              browser()
            }

            rm(test)
          }
        }
      }

      pos_rep=which(as.numeric(Os)==1)
      if(length(pos_rep)>0){
        Os[pos_rep]<-Os_save
      }
      Os=c(ini,Os)
      pos_rep=which(as.numeric(Os)==0)
      if(length(pos_rep)>0){
        Os[pos_rep]<-(-iii)
      }
    }
    if(iii==1){
      start_symbol=9
    }
    if(iii>1){
      start_symbol=start_symbol+max_count
    }
    #  print("starting to zip sequence")
    #  print(start_symbol)
    Os_int=symbol2NumMM(Os,mat_symbol[[iii]],start_symbol)
    Os=Os_int[[1]]
    Mat_symbol[[iii]]=Os_int[[2]]
  }
  output[[1]]=Os
  output[[2]]=Mat_symbol
  output[[3]]=mat_symbol
  return(output)
}
