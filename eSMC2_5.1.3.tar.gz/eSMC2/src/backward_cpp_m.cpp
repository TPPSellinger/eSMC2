#include <Rcpp.h>


using namespace Rcpp;
//' Forward Algorithm to compute likelihood
//'
//' @param xx :  pointers of the zip signal
//' @param yy :  pointers of the matrix for the zip signal
//' @param n : number of  hidden states
//' @param zz :  pointers of the vector of rescaling outputed by the forward algorihtm
// [[Rcpp::export]]


Rcpp::NumericMatrix backward_cpp_m( SEXP xx, SEXP yy, int const& n, SEXP zz){
  Rcpp::NumericVector y(xx);
  Rcpp::NumericVector c(zz);
  Rcpp::NumericMatrix TO(yy);
  int seq_length = y.size();
  Rcpp::NumericMatrix beta(n, seq_length);
  Rcpp::NumericVector v_b (n) ;
  // Rcpp::NumericVector value_v (n) ;
  double value;
  int x,xxx;
  double sca;
  for(int l = 0; l < n; ++l){
    beta(l,(seq_length-1))=1;
  }

  for(int t = (seq_length-2); t >= 0 ; t--){
    sca = c(t+1) ;
    v_b = beta(_,(t+1));
    x=(y(t+1)*n);
    for(int l = 0; l < n; l++){
      xxx=x+l;
      value=0;
      for(int k = 0; k < n ; k++){
        value +=(TO(xxx,k)*v_b(k))/sca;
      }
      //value_v(l)=value;
      beta(l,t)=value;
    }
  }
  return beta ;
}
