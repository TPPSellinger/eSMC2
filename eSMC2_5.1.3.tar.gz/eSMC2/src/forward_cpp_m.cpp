#include <Rcpp.h>


using namespace Rcpp;
//' Forward Algorithm to compute likelihood
//'
//' @param xx : pointers of the integer vector of observation
//' @param E : Emission matrix
//' @param q : equilibrium probability
//' @param yy :  pointers of tge Numeric Matrix containing all pre calbulated probabilities from zipped observation
// [[Rcpp::export]]


Rcpp::List forward_cpp_m(SEXP xx, Rcpp::NumericMatrix const& E, Rcpp::NumericVector const& q, SEXP yy) {
  Rcpp::IntegerVector Os(xx);
  int T_prime = Os.size();
  Rcpp::NumericMatrix C(yy);
  int n = q.size();
  Rcpp::NumericMatrix alpha(n, T_prime);
  Rcpp::List out(3);
  double LH  = 0.0 ;
  double dn  = 0.0;
  Rcpp::NumericVector d(T_prime);
  int i=0;
  for(int l = 0; l < n; l++){
    alpha(l,i) = E(l,Os(i))*q[l];
    dn+=alpha(l,i);
  }
  d(i)=log(dn);
  LH+=log(dn);
  for(int l = 0; l < n; l++){
    alpha(l,i)=(alpha(l,i)/dn);
  }
  int x;
  for(int i = 1; i < T_prime; i++){
    dn=0.0;
    for(int l = 0; l < n; l++){
      x=(Os(i)*n)+l;
      for(int k = 0; k < n ; k++){
        alpha(l,i) +=(C(x,k)*alpha(k,(i-1)));
      }
      dn+=alpha(l,i);
    }
    d(i)=log(dn);
    LH+=log(dn);
    for(int l = 0; l < n; l++){
      alpha(l,i)=(alpha(l,i)/dn);
    }
  }
  out(0)=alpha;
  out(1)=d;
  out(2)=LH;

  return out ;
}
