#' Runs the  Sequentially Markovian Coalescent on theoretical markers to test heritability
#'
#' @param n : Number of hidden states
#' @param rho : numeric vector of prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param mu_marker : list of size equal to the number of theoretical marker, respectively containing the markers rates in generation per position. If heritability of a marker need to be tested, simply put NA
#' @param Nb_marker : vector of size two which are boundaries of methylation rates. First value gives the -log10 of lower boundary and second value the log10 of upper boynderi.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param BoxMarker : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param mu_b : ratio of mutation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param dominant_marker : index of the marker to use for scaling
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param niveau : Power of the statistical test
#' @param estimate_Pop : TRUE to estimate population size before Test
#' @param estimate_R : TRUE to estimate the recombination rate before the Test
#' @export
Test_heritability_marker_theo<-function(n=40,rho=1,O,mu_marker=list(c(10^-8),c(NA)),Nb_marker=2,nb_state_marker=list(c(2),c(2)),Marker_supperposition=F,BoxMarker=c(2,10),NC=1,mu_b=1,sigma=0,beta=1,Big_Window=F,position_removed=NA,dominant_marker=1,window_scaling=c(1,0),niveau=0.05,estimate_Pop=F,estimate_R=F){
  Check=F
  FS=F
  EM=F
  BW=F
  SF=F
  SB=F
  ER=F
  pop=F
  pop_vect=NA
  check_tree=T
  SCALED=F
  gamma=rho
  Xi=NA
  if(any(is.na(pop_vect))){
    pop_vect=rep(2,(n*0.5))
  }

  to_estimate=c()
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[dim(O)[1],dim(O)[2]])
    Os=list()
    count=0
    M_o=0
    theta_W=rep(0,Nb_marker)
    s_t=Sys.time()
    for(k in 1:(M-1)){
      for(l in (k+1):M){
        Os_=seq_marker_theo(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,dominant_marker = dominant_marker)
        theta_W=theta_W+as.numeric(Os_$theta)
        M_o=M_o+1
        if(count==0){
          count=count+1

          Mat_symbol=Mat_symbol_create_marker_theo(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker)
          Os[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

        }else{
          count=count+1
          Os[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)
        }
        print(paste("Zipping sequence",count,"over",((M-1)*M*0.5),"",sep=" "))
      }
    }
    e_t=Sys.time()
    print("Time to Zip allsequences")
    print(e_t-s_t)
    rm(O)
    rm(Os_)

    if(length(Os)>=1){
      for(oo in 1:length(Os)){
        Os[[oo]]=symbol2Num_marker_theo(Os[[oo]])
      }

      theta_W=theta_W/M_o


      theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
      print("Observed Theta:")
      print(theta)
      mu_v=numeric(Nb_marker)
      for(marker in 1:Nb_marker){
        mu_v[marker]=mu_marker[[marker]]
      }

      Not_Na_pos=which(!is.na(mu_v))
      Ne=c()
      for(marker in Not_Na_pos){
        Ne[marker]=(log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
      }
      if(any(is.na(as.numeric(Ne)))){
        Ne[which(is.na(as.numeric(Ne)))]=0
      }
      print("estimated Ne with different marker")
      print(Ne)

      if(any(is.na(as.numeric(theta)))){
        theta[which(is.na(as.numeric(theta)))]=1
      }

      Na_pos=which(is.na(mu_v))
      if(length(Na_pos)>0){


        for(marker in Na_pos){
          mu_marker[[marker]]=(1-exp((log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/Ne)))*((nb_state_marker[[marker]]-1))/nb_state_marker[[marker]]
          to_estimate=c(to_estimate,marker)

        }

      }
      if(as.character(Ne)=="NaN"|any(as.character(theta)=="NaN")){
        stop()
      }

      if(check_tree){
        test.env <- new.env()
        Rho <- rho*theta[dominant_marker]

        if(estimate_Pop|estimate_R){
          if(estimate_Pop){
            pop=F
          }
          if(estimate_R){
            ER=T
          }
          temp_res=Baum_Welch_algo_marker_theo(Os=Os,L=L,Ne=Ne,theta_W =theta_W,Rho=Rho,beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,theta=theta[dominant_marker],window_scaling=window_scaling,to_remove=to_estimate)
          if(estimate_Pop){
            Xi=temp_res$Xi
          }
          if(estimate_R){
            Rho=(temp_res$rho/temp_res$mu[dominant_marker])*theta[dominant_marker]
          }
          }

        BW=Short_Baum_Welch_marker_theo(Os,L,theta_W,Rho=Rho,Ne,beta=beta,k=n,window_scaling=window_scaling,sigma=sigma,NC=NC,mu_b=mu_b,Big_Window=Big_Window,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,theta,to_estimate=to_estimate,theta=theta[dominant_marker],Xi=Xi)
        test.env$Big_M <- BW$raw_M
        test.env$theta_W <- theta_W
        test.env$mu <- mu_marker
        test.env$mu_b <- mu_b
        test.env$Rho <- Rho
        test.env$L <- L
        test.env$k <- n
        test.env$Beta <- beta
        test.env$Self <- sigma
        test.env$NC <- NC
        test.env$Ne<-Ne
        test.env$BoxMarker<-BoxMarker
        test.env$nb_state_marker <- nb_state_marker
        test.env$Nb_marker<-Nb_marker
        test.env$Marker_supperposition<-Marker_supperposition
        results=list()
        for(marker_to_test in to_estimate){
           tableau=round(t( BW$raw_M[,c(marker_to_test,(Nb_marker+1+marker_to_test))]))
           if(any(floor(as.numeric(tableau[1,]))==0)){
             tableau[1,which(floor(as.numeric(tableau[1,]))==0)]<-1
           }
           if(any(floor(as.numeric(tableau[2,]))==0)){
             tableau[2,which(floor(as.numeric(tableau[2,]))==0)]<-1
           }
           res=list()
           res$pvalue=stats::chisq.test(tableau)
           res$tableau=tableau
           res$Tc=BW$Tc
           res$Ne=BW$Ne
           results[[(marker_to_test)]] = res
        }
      }
      }else{
      stop("data too poor")
    }
  }
  if(NC>1){

    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=list()
    L_total=vector()


    for(chr in 1:NC){

      M=dim(O[[chr]])[1]-2
      L=as.numeric(O[[chr]][dim(O[[chr]])[1],dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      Ost=list()
      count=0
      M_o=0
      theta_W=c()
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          Os_=seq_marker_theo(O[[chr]][c(k,l,(M+1),(M+2)),],L,position_removed[[1]],Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition)
          theta_W=theta_W+as.numeric(Os_$theta)
          M_o=M_o+1
          if(count==0){
            count=count+1
            Mat_symbol=Mat_symbol_create_marker_theo(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker)
            Ost[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

          }else{
            count=count+1
            Ost[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

          }

        }
      }
      Os[[chr]]=Ost
      theta_W_V[[chr]]=theta_W/M_o


    }


    print(L_total)
    L=L_total
    rm(O)
    rm(Ost)
    theta=list()
    if(length(Os)>=1){
      for(chr in 1:NC){
        for(oo in 1:length(Os[[chr]])){
          Os[[chr]][[oo]]=symbol2Num_marker_theo(Os[[chr]][[oo]])
        }
        theta[[chr]]=theta_W_V[[chr]]*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        if(any(is.na(as.numeric(theta[[chr]])))){
          theta[[chr]][which(is.na(as.numeric(theta[[chr]])))]=1
        }
      }


      print("Observed Theta:")
      print(theta)
      mu_v=numeric(Nb_marker)
      for(marker in 1:Nb_marker){
        mu_v[marker]=mu_marker[[marker]]
      }

      Not_Na_pos=which(!is.na(mu_v))
      Ne=rep(0,Nb_marker)
      for(marker in 1:Nb_marker){
        for(chr in 1:NC){
          Ne[marker]=Ne[marker]+(log((1+((log((1-(theta_W_V[[chr]][marker]*(nb_state_marker[[marker]]/(L_total[chr]*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
        }
        Ne[marker]=Ne[marker]/NC
      }
      if(any(is.na(as.numeric(Ne)))){
        Ne[which(is.na(as.numeric(Ne)))]=0
      }
      print("estimated Ne with different marker")
      print(Ne)



      Na_pos=which(is.na(mu_v))
      if(length(Na_pos)>0){



        for(marker in Na_pos){
          mu_marker[[marker]]=0
          for(chr in 1:NC){
            mu_marker[[marker]]=mu_marker[[marker]]+(1-exp((log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/Ne)))*((nb_state_marker[[marker]]-1))/nb_state_marker[[marker]]

          }
          mu_marker[[marker]]=mu_marker[[marker]]/NC
          to_estimate=c(to_estimate,marker)

        }
      }
      if(as.character(Ne)=="NaN"|any(as.character(theta)=="NaN")){
        stop()
      }

      if(check_tree){
        test.env <- new.env()
        Rho <- rho*theta[dominant_marker]



        Big_M=list()
        for (chr in 1:NC) {

          if(estimate_Pop|estimate_R){
            if(estimate_Pop){
              pop=F
            }
            if(estimate_R){
              ER=T
            }
            temp_res=Baum_Welch_algo_marker_theo(Os=Os[[chr]],L=L[chr],Ne=Ne,theta_W =theta_W[[chr]],Rho=Rho[chr],beta=beta,sigma=sigma,Popfix=pop,SB=F,SF=F,k=n,maxBit = 1,pop_vect=pop_vect,ER=ER,NC=NC,BW=BW,mu_b=mu_b,SCALED=SCALED,Big_Window=Big_Window,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,theta=theta[[chr]][dominant_marker],window_scaling=window_scaling,to_remove=to_estimate)
            if(estimate_Pop){
              Xi=temp_res$Xi
            }
            if(estimate_R){
              Rho[chr]=(temp_res$rho/temp_res$mu)*theta[dominant_marker]
            }
          }

          BW=Short_Baum_Welch_marker_theo(Os[[chr]],L[chr],theta_W[[chr]],Rho=Rho[chr],Ne,beta=beta,k=n,window_scaling=window_scaling,sigma=sigma,NC=1,mu_b=mu_b,Big_Window=Big_Window,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,to_estimate=to_estimate,theta=theta[[chr]][dominant_marker])
          Big_M[[chr]]=BW$M
        }
        test.env$Big_M <-  Big_M
        test.env$theta_W <- theta_W
        test.env$mu <- mu_marker
        test.env$mu_b <- mu_b
        test.env$Rho <- Rho
        test.env$L <- L
        test.env$k <- n
        test.env$Beta <- beta
        test.env$Self <- sigma
        test.env$NC <- NC
        test.env$Ne<-Ne
        test.env$BoxMarker<-BoxMarker
        test.env$nb_state_marker <- nb_state_marker
        test.env$Nb_marker<-Nb_marker
        test.env$Marker_supperposition<-Marker_supperposition
        results=list()
        for(marker_to_test in to_estimate){
          for(chr in 1:NC){
            if(chr==1){
              tableau=t(Big_M[[chr]][,c(marker_to_test,(Nb_marker+1+marker_to_test))])
            }else{
              tableau=tableau+t(Big_M[[chr]][,c(marker_to_test,(Nb_marker+1+marker_to_test))])
            }

          }
          if(any(floor(as.numeric(tableau[1,]))==0)){
            tableau[1,which(floor(as.numeric(tableau[1,]))==0)]<-1
          }
          if(any(floor(as.numeric(tableau[2,]))==0)){
            tableau[2,which(floor(as.numeric(tableau[2,]))==0)]<-1
          }
          res=list()
          res$pvalue=stats::chisq.test(tableau)
          res$tableau=tableau
          res$Tc=BW$Tc
          res$Ne=BW$Ne
          results[[(marker_to_test)]] = res
        }
      }
    }else{
      stop("data too poor")
    }


  }

  return(results)
}

