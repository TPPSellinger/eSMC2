#' Outputs the expected branch length of up to sample size n under the Beta coalescence of parameter alpha
#'
#' @param n : sample size
#' @param alpha : estimated mutation rate given prior
#' @param Xi : vector of relative population size through time compare to Ne
#' @param Tc : Coalescent times used for binning
#' @export
#' @return numeric vector of total branch length from sample 2 to n under the haploid beta coalescent with parameter alpha
Get_total_branch_length_SMBC<-function(n,alpha,Xi=NA,Tc=NA){

  get_coalescence_beta<-function(sample_size,alpha){
    coal_rate=numeric((sample_size-1))
    for(x in 2:sample_size){
      coal_rate[(x-1)]=choose(sample_size,x)*beta((x-alpha), (sample_size - x + alpha))/(gamma((2-alpha))*gamma((alpha)))
    }
    return(coal_rate)
  }

  Beta_branch_length<-function(L,Xi,Tc,Ti){
    if(Ti>0){
      start_pos=max(which(Tc<=Ti))
      Xi=Xi[start_pos:length(Xi)]
      if(max(which(Tc<=Ti))<length(Tc)){
        Tc=c(0,(Tc[which(Tc>Ti)]-Ti))
        D=Tc[2:(length(Tc))]-Tc[1:(length(Tc)-1)]
      }else{
        Tc=c(0)
      }

    }else{
      D=Tc[2:(length(Tc))]-Tc[1:(length(Tc)-1)]
    }
    BL=0


    if(length(Xi)>3){
      for(gamma in 1:length(Xi)){
        if(gamma==1){
          bl_temp=(Xi[1]/L) -(((Xi[1]/L)+Tc[(gamma+1)])*exp(-D[gamma]*L/Xi[gamma]))
        }
        if(gamma==2){
          bl_temp=exp(-D[(gamma-1)]*L/Xi[(gamma-1)])*(Tc[(gamma)] + (Xi[(gamma)]/L) -(((Xi[gamma]/L)+Tc[(gamma+1)])*exp(-D[gamma]*L/Xi[gamma])) )
        }
        if(gamma>2&gamma<(length(Xi))){
          bl_temp=exp(-sum(D[1:(gamma-1)]*L/Xi[1:(gamma-1)]))*(Tc[(gamma)] + (Xi[(gamma)]/L) -(((Xi[gamma]/L)+Tc[(gamma+1)])*exp(-D[gamma]*L/Xi[gamma])) )
        }
        if(gamma==length(Xi)){
          bl_temp=exp(-sum(D[1:(gamma-1)]*L/Xi[1:(gamma-1)]))*(Tc[(gamma)] + (Xi[(gamma)]/L))
        }
      #  print(bl_temp)
        BL=BL+bl_temp
      }
    }
    else{
      if(length(Xi)==1){
        BL=(Xi/L)
      }
      if(length(Xi)==2){
        BL=((Xi[1]/L) -(((Xi[1]/L)+Tc[2])*exp(-D[1]*L/Xi[1]))) + (exp(-D[1]*L/Xi[1])*(Tc[2] + (Xi[2]/L) ))

      }
      if(length(Xi)==3){
        BL = ((Xi[1]/L) -(((Xi[1]/L)+Tc[2])*exp(-D[1]*L/Xi[1]))) +  (exp(-D[1]*L/Xi[1])*(Tc[2] + (Xi[2]/L) -(((Xi[2]/L)+Tc[(3)])*exp(-D[2]*L/Xi[2]))  )) +  (exp(-sum(D[1:2]*L/Xi[1:2]))*(Tc[3] + (Xi[3]/L)))
      }

    }


    return(BL)
  }

  build_loop_matrix<-function(n){
    nb_col=2^((n-2))
    Loop_mat=matrix(0,ncol=nb_col,nrow = (n))
    Loop_mat[,1]=c(rep(0,(n-2)),1,n)
    Loop_mat[(n),]=n
    for(l in (n-1):1){
      c=1
    while (c<nb_col) {
      if(all(Loop_mat[(l+1),c:(nb_col-1)]==Loop_mat[(l+1),(c+1):nb_col])){

        vect_l=c(1)
        for(crap in 2:(Loop_mat[(l+1),c]-1)){
          vect_l=c(vect_l,rep(crap,2^(crap-2)))
        }
        Loop_mat[l,c(c:nb_col)]=vect_l
        c=nb_col
      }else{

        if(Loop_mat[(l+1),c]<2){
          c=c+1
        }else{
          if(Loop_mat[(l+1),c]==2){
            Loop_mat[l,c]=1
            c=c+1
          }else{
            if(Loop_mat[(l+1),c]>2){
              pos_temp=min(which(Loop_mat[(l+1),c:(nb_col-1)]!=Loop_mat[(l+1),(c+1):nb_col]))
              vect_l=c(1)
              for(crap in 2:(Loop_mat[(l+1),c]-1)){
                vect_l=c(vect_l,rep(crap,2^(crap-2)))
              }
              Loop_mat[l,c:(c+pos_temp-1)]=vect_l
              c=c+pos_temp
            }
          }
        }




      }


    }
    }
    Loop_mat[1,nb_col]=1
    return(Loop_mat)
  }

  get_total_branch_length<-function(event,Xi,Tc,alpha){
    BL_event=0
    Ti=0
    event=sort(event,decreasing = T)
    P_e=1
    if(all(event>0)){
   #   browser()
    }

    for(e in 1:length(which(event>1))){

      L_coal=get_coalescence_beta(event[e],alpha)

      if((event[(e+1)])>1){
        bl_temp=Beta_branch_length(sum(L_coal),Xi,Tc,Ti)

        BL_event=BL_event+(event[e]*bl_temp) # *(L_coal[(event[(e)]-event[(e+1)])]/(sum(L_coal)))

        P_e=P_e*(L_coal[(event[(e)]-event[(e+1)])]/(sum(L_coal)))

      }else{

        bl_temp=Beta_branch_length(sum(L_coal),Xi,Tc,Ti)

        BL_event=BL_event+(event[e]*bl_temp) # *(L_coal[(event[(e)]-event[(e+1)])]/(sum(L_coal)))

        P_e=P_e*(L_coal[(event[(e)]-event[(e+1)])]/(sum(L_coal)))
      }
     Ti=Ti+bl_temp
     #print(Ti)
    # print(bl_temp)
    }
    #print(BL_event)
    BL_event=P_e*BL_event
    res=list()
    res$BL_event=BL_event
    res$P_e=P_e
    return(res)
  }

  BL=rep(0,(n-1))


  if(all(!is.na(Xi))){
    Xi=(Xi^((alpha-1)))
    for(coal in c((n-1):1)){
      Ti=0
      if(coal==1){

        L=((beta((2-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
        BL[coal]=2*Beta_branch_length(L,Xi,Tc,Ti)

      }else{
        P_tot=0
        Loop_Matrix=build_loop_matrix((coal+1))
        for (c in 1:dim(Loop_Matrix)[2]){

           res=get_total_branch_length(Loop_Matrix[,c],Xi,Tc,alpha)

           #print(Loop_Matrix[,c])
           #print(res$BL_event)
           BL[coal]=BL[coal] +res$BL_event
           P_tot=P_tot+res$P_e
        }
       # print("P_tot:")
       #  print(P_tot)
      }
    }

  }else{
    #Xi=rep(1,length(Tc))
    Get_total_branch_length_SMBC_constant<-function(n,alpha){

      BL=numeric(n-1)
      for(coal in 1:(n-1)){
        if(coal==1){
          L=((beta((2-alpha), (alpha))/(gamma((2-alpha))*gamma((alpha)))))
          BL[coal]=2*(1/L)
        }else{
          L_coal=get_coalescence_beta((coal+1),alpha)
          BL[coal]=(coal+1)*(1/sum(L_coal))
          for(bonus in 1:(coal-1)){
            BL[coal]= BL[coal]+(L_coal[bonus]/sum(L_coal))*BL[(coal-bonus)]
          }
        }

      }
      return(BL)
    }
    BL=Get_total_branch_length_SMBC_constant(n,alpha)
  }




  return(BL)
}



