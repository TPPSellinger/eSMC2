#' Gets number of methylated regions,
#'
#' @param Path : Estimated hidden state concerning methylated regions (i.e. output of Path_finder_methy)
#' @param window_min : minimum sequence length of a methylated regions
#' @param nb_site_min : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param DNA : Segregating matrix used to estimate Path
#' @return : number or list of number of identified methylated regions
#'
get_nb_reg<-function(Path,window_min=100,nb_site_min=4,NC,DNA){

  window_min=window_min
  nb_site_min=nb_site_min
  if(NC==1){
    meth_reg_long=Path$seq[[1]]
    L=length(meth_reg_long)
    #meth_reg_long_zip_o=zip_meth(Path$seq)[[1]]
    #browser()
    #print("Time to create hidden states segregatin matrix :")
    ss_t=Sys.time()
    transition=which(meth_reg_long[1:(L-1)]!=meth_reg_long[2:(L)])
    meth_reg_long_zip=matrix(0,ncol=length(transition),nrow=3)
    meth_reg_long_zip[1,]=meth_reg_long[transition]
    meth_reg_long_zip[2,]=1+c(0,transition[-length(transition)])
    meth_reg_long_zip[3,]=c(transition -c(0,transition[-length(transition)]))

    ee_t=Sys.time()
    #print(ee_t-ss_t)

    for(sca in 1:2){
     # print("Time to remove too small regions :")
      ss_t=Sys.time()
      Pos_MD=as.numeric(DNA[4,which(DNA[sca,]%in%c("M","D"))])
      for(reg_id in 1:dim(meth_reg_long_zip)[2]){
        pos_temp=which(Pos_MD[1:min(2000,length(Pos_MD))]>=meth_reg_long_zip[2,reg_id]&Pos_MD[1:min(2000,length(Pos_MD))]<=(meth_reg_long_zip[2,reg_id]-1+meth_reg_long_zip[3,reg_id]))
        if(length(pos_temp)>0){
        Pos_MD_temp=Pos_MD[pos_temp]
        Pos_MD=Pos_MD[-pos_temp]
        if(length(which(Pos_MD_temp%in%c(meth_reg_long_zip[2,reg_id]:(meth_reg_long_zip[2,reg_id]-1+meth_reg_long_zip[3,reg_id]))))<nb_site_min){
          meth_reg_long_zip[1,reg_id]=1
        }
        }else{meth_reg_long_zip[1,reg_id]=1 }
      }
      ee_t=Sys.time()
    #  print(ee_t-ss_t)
    }
    meth_reg_long_zip[1,which(meth_reg_long_zip[3,]< window_min)]=1
    nb_reg=length(which(meth_reg_long_zip[1,]%in%c(9,5,6,8)))
   # browser()
  }else{

  }

  return(nb_reg)
}
