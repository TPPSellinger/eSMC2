#'  Builds the HMM matrices of the new symbol
#'
#' Builds the HMM matrices to analysed the zip signal and calculate likelihood
#' @param A : Transition matrix
#' @param E : emission matrix
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @param q : equilibrium probability
#' @param do_all : TRUE to compute all necessary matrices for the Baum-Welch, FALSE only those necessary for the Forward-Backward
#' @return A : 4 object list with matrices to calculate likelihood of zipped sequences
Build_zip_Matrix_mailund_m<-function(A,E,Mat_symbol,q,do_all=T){
  l_f=list()
  Cf=list()
  TOf=list()
  Qf=list()
  Q_f=list()
  k=length(q)
  C=list()
  TO=list()
  Q=list()
  Q_=list()
  l=vector(length =90)
  for(i in 1:dim(E)[2]){
    B=diag(x=E[,i])
    C[[i]]=B%*%A
    l[i]=1
    TO[[i]]=t(A)%*%B
    Q[[i]]=diag(1,k,k)
    Q_[[i]]=diag(1,k,k)
  }
  x=length(C)
  for(xx in c(1,3)){
    mat_trick=eigen(TO[[xx]])
    D=diag(mat_trick$values)
    if(length(as.numeric(Mat_symbol[[xx]]))>0){
      for(i in 1:dim(Mat_symbol[[xx]])[1]){
        sx=strsplit(Mat_symbol[[xx]][i,2]," ")
        sx=as.numeric(as.matrix(sx[[1]]))
        a=sx[1]
        b=sx[2]

        C[[((10*xx)+i+1)]]=as.matrix(C[[(b+1)]])%*%as.matrix(C[[(a+1)]])
        TO[[((10*xx)+i+1)]]=TO[[(a+1)]]%*%TO[[(b+1)]]
          if(b<10){
            b=b+1
          }
          if(a<10){
            a=a+1
          }

        l[((10*xx)+i)]=(l[(a)]+l[(b)])
        l_temp=(l[(a)]+l[(b)])

        if(do_all){
        Q_temp=matrix(0,dim(D)[1],dim(D)[1])
        Q_temp_=matrix(0,dim(D)[1],dim(D)[1])
        for(x1 in 1:dim(D)[1]){
          for(x2 in 1:dim(D)[1]){
            if(D[x1,x1]!=D[x2,x2]){
              Q_temp[x1,x2]=((D[x1,x1]^(l_temp))-(D[x2,x2]^(l_temp)))/(D[x1,x1]-D[x2,x2] )
              Q_temp_[x1,x2]=sum((D[x1,x1]^seq(1,l_temp,1))*(D[x2,x2]^(l_temp-seq(1,l_temp,1))))
            }
            if(D[x1,x1]==D[x2,x2]){
              Q_temp[x1,x2]=(l_temp)*(D[x2,x2]^(l_temp-1))
              Q_temp_[x1,x2]=(l_temp)*(D[x2,x2]^(l_temp))
            }
          }
        }
        Q[[((10*xx)+i)]]=Q_temp
        Q_[[((10*xx)+i)]]=Q_temp_
        }
      }
    }
  }

  output=list()
  output[[1]]=C
  output[[3]]=TO
  if(do_all){
  output[[4]]=Q
  output[[5]]=l
  output[[2]]=Q_
  }

  output[[6]]=C[[1]]
  output[[7]]=TO[[1]]

  for(cc in 2:length(TO)){

    if(!is.null(C[[cc]])){
        output[[6]]=rbind(output[[6]],C[[cc]])
      }else{
        output[[6]]=rbind(output[[6]],matrix(0,k,k))
      }
    if(!is.null(TO[[cc]])){
      output[[7]]=rbind(output[[7]],TO[[cc]])
    }else{
      output[[7]]=rbind(output[[7]],matrix(0,k,k))
    }

    #if(cc==10){
    #  output[[6]]=rbind(output[[6]],matrix(0,2*k,k))
    #  output[[7]]=rbind(output[[7]],matrix(0,2*k,k))
    #}
  }
  return(output)
}
