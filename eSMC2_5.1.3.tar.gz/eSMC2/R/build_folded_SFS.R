#' Builds and Plot the folded SFS from a segregating matrix
#'
#' @param O : segrating matrix, or list of segrgating matrix
#' @param NC : number of scaffolds
#' @param distance_min : minimum distance in kb between each SNPs to calculate SFS
#' @param print : character string corresponding to the plot name in pdf, e.g. "My_plot.pdf". if NA, plots are not printed in pdf but only displayed
#' @param scaled : TRUE to scale the SFS (i.e. dividing by the number of used sites)
#' @export
#' @return Plots of folded SFS
build_folded_SFS<-function(O,NC,distance_min=1,print=NA,scaled=T){
  distance_min=distance_min*10^3
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    s=dim(O)[1]
    count=0
    SFS=rep(0,floor(M/2))
    keep_building_SFS=T
    x=1

    while (keep_building_SFS) {

      if(length(unique(O[1:M,x]))==2){
        obs=unique(O[1:M,x])
        density=length(which(as.character(O[1:M,x])==as.character(obs[1])))
        xi=min(density,(M-density))
        SFS[xi]=SFS[xi]+1
        distance=0
        while (distance<distance_min&(x+1)<dim(O)[2]){
          distance=distance+(as.numeric(O[s,x+1])-as.numeric(O[s,x]))
          x=x+1

        }

      }else{
        x=x+1
      }

      if((x+1)>=dim(O)[2]){
        keep_building_SFS=F
      }
    }

    if(scaled){
      SFS=SFS/sum(SFS)
    }
    if(!is.na(print)){
      grDevices::pdf(print)
    }
    graphics::plot(1:floor(M/2),SFS,xlab = "Allele frequency",ylab = "Density",type = "l")
    if(!is.na(print)){
      grDevices::dev.off()
    }
  }else{
    if(!is.na(print)){
      grDevices::pdf(print)
    }
    for(chr in 1:NC){
      M=dim(O[[chr]])[1]-2
      L=as.numeric(O[[chr]][(M+2),dim(O[[chr]])[2]])
      s=dim(O[[chr]])[1]
      count=0
      vect_SNP=numeric(floor(L/distance_min))
      SFS=rep(0,floor(M/2))
      keep_building_SFS=T
      x=1
      while (keep_building_SFS) {

        if(length(unique(O[[chr]][1:M,x]))==2){
          obs=unique(O[[chr]][1:M,x])
          density=length(which(as.character(O[[chr]][1:M,x])==as.character(obs[1])))
          xi=min(density,(M-density))
          SFS[xi]=SFS[xi]+1

          distance=0
          while (distance<distance_min&(x+1)<dim(O[[chr]])[2]){
            distance=distance+(as.numeric(O[[chr]][s,x+1])-as.numeric(O[[chr]][s,x]))
            x=x+1

          }

        }else{
          x=x+1
        }

        if((x+1)>=dim(O[[chr]])[2]){
          keep_building_SFS=F
        }
      }

      if(scaled){
        SFS=SFS/sum(SFS)
      }

      graphics::plot(1:floor(M/2),SFS,xlab = "Allele frequency",ylab = "Density",type = "l")

    }
    if(!is.na(print)){
      grDevices::dev.off()
    }
  }
}
