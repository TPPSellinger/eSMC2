#' Simulate sequences with theoretical markers
#'
#' @param genealogy : matrix of genealogy (output of get_genealogy)
#' @param mu_marker : list of size equal to the number of theoretical marker, respectively containing the markers rates in generation per position
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param Ne : Population size to use for the scaling
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param Nb_region_type : Number of region displaying different rate
#' @param Region_pos : list of size equal to Nb_region_type containing the positions of the different regions on the sequence
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param initial_marker_proportion : numeric vector of length of Nb_marker containing the proportion of site of each marker on the simulated sequence
#' @export
#' @return A list containing all estimations in same format as eSMC.

Create_multiple_marker_theo<-function(genealogy,mu_marker=list(c(10^-8),c(10^-4)),Nb_marker=2,Ne,Nb_region_type=1,Region_pos=NA,nb_state_marker=list(c(2),c(2)),Marker_supperposition=T,initial_marker_proportion=NA){
  M=dim(genealogy$Coal_time)[1]
  if(M==2){
    genealogy$id_split=rbind(genealogy$id_split,genealogy$id_split)
    genealogy$id_create=rbind(genealogy$id_create,genealogy$id_create)
  }

  L=sum(genealogy$Coal_time[M,])
  Output=matrix(0,ncol=L,nrow=(M+1))
  count_L=0
  print("creating sequence")
  if(Nb_region_type==1){
    for(i in 1:dim(genealogy$Coal_time)[2]){
      L_seg=as.numeric(genealogy$Coal_time[M,i])
      Mat_seq=matrix(0,M,L_seg)
      if(Marker_supperposition){
        if(Nb_marker>1){
          for(marker in 1:Nb_marker){
            if(marker==1){
              Mat_seq[as.numeric(genealogy$id_split[1,i]),]=paste(paste("m",marker,sep=""),letters[ceiling(stats::runif(L_seg,0,nb_state_marker[[marker]]))],sep="_")
            }else{
              Mat_seq[as.numeric(genealogy$id_split[1,i]),]=paste(Mat_seq[as.numeric(genealogy$id_split[1,i]),],paste("m",marker,sep=""),letters[ceiling(stats::runif(L_seg,0,nb_state_marker[[marker]]))],sep="_")
            }

          }
        }else{
          Mat_seq[as.numeric(genealogy$id_split[1,i]),]=letters[ceiling(stats::runif(L_seg,0,nb_state_marker))]
        }

      }else{
        if(Nb_marker>1){
          sum_mu_marker=0
          for(marker in 1:Nb_marker){
            sum_mu_marker=sum_mu_marker+mu_marker[[marker]]
          }
          v_mu_marker=c()
          for(marker in 1:Nb_marker){
            v_mu_marker=mu_marker[[marker]]/sum_mu_marker
          }
          if(any(is.na(initial_marker_proportion))){
            nb_mu=stats::rmultinom(L_seg,1, v_mu_marker)
          }else{
            nb_mu=stats::rmultinom(L_seg,1, initial_marker_proportion)
          }

          for(marker in 1:Nb_marker){
            pos=which(nb_mu[marker,]==1)
            if(length(pos)>0){
              Mat_seq[as.numeric(genealogy$id_split[1,i]),pos]=paste(paste("m",marker,sep=""),letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[marker]]))],sep="_")
            }
          }

        }else{
          Mat_seq[as.numeric(genealogy$id_split[1,i]),]=letters[ceiling(stats::runif(L_seg,0,nb_state_marker))]
        }
      }


      for(j in 1:(dim(genealogy$Coal_time)[1]-1)){
        Mat_seq[genealogy$id_create[j,i],]=Mat_seq[as.numeric(genealogy$id_split[j,i]),]
        if(!Marker_supperposition){
          if(Nb_marker>1){
            for(marker in 1:Nb_marker){
              if(j==(M-1)){
                q=1-exp(-mu_marker[[marker]]*genealogy$Coal_time[j,i]*Ne*nb_state_marker[[marker]]/(nb_state_marker[[marker]]-1))
              }else{
                q=1-exp(-mu_marker[[marker]]*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker[[marker]]/(nb_state_marker[[marker]]-1))
              }
              for(seg_id in which(Mat_seq[,1]!=0)){
                L_pos=which(substr(Mat_seq[seg_id,],2,2)==as.character(marker))
                if(length(L_pos)>0){
                  nb_mu=stats::rbinom(n=length(L_pos) ,size = 1 ,prob = q)
                  pos=which(nb_mu==1)
                  if(length(pos)>0){
                    x=4
                    substr(Mat_seq[seg_id,L_pos[pos]],x,x)=letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[marker]]))]
                  }
                }
              }
            }
          }else{
            if(j==(M-1)){
              q=1-exp(-mu_marker*genealogy$Coal_time[j,i]*Ne*nb_state_marker/(nb_state_marker-1))
            }else{
              q=1-exp(-mu_marker*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker/(nb_state_marker-1))
            }
            for(seg_id in which(Mat_seq[,1]!=0)){
            nb_mu=stats::rbinom(n=L_seg ,size = 1 ,prob = q)
            pos=which(nb_mu==1)
            if(length(pos)>0){
              Mat_seq[seg_id,pos]=letters[ceiling(stats::runif(length(pos),0,nb_state_marker))]
            }
          }
        }


        }else{
          if(Nb_marker>1){
            for(marker in 1:Nb_marker){
              if(j==(M-1)){
                q=1-exp(-mu_marker[[marker]]*genealogy$Coal_time[j,i]*Ne*nb_state_marker[[marker]]/(nb_state_marker[[marker]]-1))
              }else{
                q=1-exp(-mu_marker[[marker]]*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker[[marker]]/(nb_state_marker[[marker]]-1))
              }
              for(seg_id in which(Mat_seq[,1]!=0)){

                nb_mu=stats::rbinom(n=L_seg ,size = 1 ,prob = q)
                pos=which(nb_mu==1)
                if(length(pos)>0){
                  x=4+(marker-1)*5
                  substr(Mat_seq[seg_id,pos],x,x)=letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[marker]]))]
                }
              }
            }
          }else{
            if(j==(M-1)){
              q=1-exp(-mu_marker*genealogy$Coal_time[j,i]*Ne*nb_state_marker/(nb_state_marker-1))
            }else{
              q=1-exp(-mu_marker*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker/(nb_state_marker-1))
            }
            for(seg_id in which(Mat_seq[,1]!=0)){
              nb_mu=stats::rbinom(n=L_seg ,size = 1 ,prob = q)
              pos=which(nb_mu==1)
              if(length(pos)>0){
                Mat_seq[seg_id,pos]=letters[ceiling(stats::runif(length(pos),0,nb_state_marker))]

              }
            }
          }
        }
      }
      Mat_seq=rbind(Mat_seq,c(1:L_seg))
      Mat_seq[(M+1),]=as.numeric(Mat_seq[(M+1),])+count_L
      Output[,(count_L+1):(count_L+L_seg)]=Mat_seq
      count_L=count_L+L_seg
    }
  }else{
    for(region in 1:Nb_region_type){
      count_L=0
      for(i in 1:dim(genealogy$Coal_time)[2]){
        L_seg=genealogy$Coal_time[M,i]
        if(region==1){
          Mat_seq=matrix(0,M,L_seg)
        }else{
          Mat_seq=Output[c(1:M),(count_L+1):(count_L+L_seg)]
          if(L_seg==1){
            Mat_seq=matrix(Output[c(1:M),(count_L+1):(count_L+L_seg)],M,ncol=1)
          }
        }

        potential_start_pos=max(which(Region_pos[[region]][,1]<=(count_L+1)))
        if(as.character(potential_start_pos)=="-Inf"){

          potential_start_pos=1
        }

        potential_end_pos=min(which(Region_pos[[region]][,2]>=(count_L+L_seg)))

        if(as.character(potential_end_pos)=="Inf"){
          potential_end_pos=dim(Region_pos[[region]])[1]
        }

        if(potential_start_pos==potential_end_pos){
          potential_pos=Region_pos[[region]][potential_start_pos,1]:Region_pos[[region]][potential_start_pos,2]
        }else{
          potential_pos=c()
          for(potential_index in c(potential_start_pos:potential_end_pos)){
            potential_pos=c(potential_pos,Region_pos[[region]][potential_index,1]:Region_pos[[region]][potential_index,2])
          }

        }
        pos_reg=which(c((count_L+1):(count_L+L_seg))%in%potential_pos)
        rm(potential_pos)
        #browser()
        if(length(pos_reg)>0){
          nb_pos=length(pos_reg)
          if(Marker_supperposition){
            if(Nb_marker[[region]]>1){
              for(marker in 1:Nb_marker[[region]]){
                if(marker==1){
                  Mat_seq[as.numeric(genealogy$id_split[1,i]),pos_reg]=paste(paste("m",marker,sep=""),letters[ceiling(stats::runif(nb_pos,0,nb_state_marker[[region]][[marker]]))],sep="_")
                }else{
                  Mat_seq[as.numeric(genealogy$id_split[1,i]),pos_reg]=paste(Mat_seq[as.numeric(genealogy$id_split[1,i]),pos_reg],paste("m",marker,sep=""),letters[ceiling(stats::runif(nb_pos,0,nb_state_marker[[region]][[marker]]))],sep="_")
                }

              }
            }else{
              Mat_seq[as.numeric(genealogy$id_split[1,i]),pos_reg]=letters[ceiling(stats::runif(nb_pos,0,nb_state_marker[[region]]))]
            }

          }else{
            if(Nb_marker[[region]]>1){
              sum_mu_marker=0
              for(marker in 1:Nb_marker[[region]]){
                sum_mu_marker=sum_mu_marker+mu_marker[[region]][[marker]]
              }
              v_mu_marker=c()
              for(marker in 1:Nb_marker[[region]]){
                v_mu_marker=mu_marker[[region]][[marker]]/sum_mu_marker
              }
              if(any(is.na(initial_marker_proportion[[region]]))){
                nb_mu=stats::rmultinom(nb_pos,1, v_mu_marker)
              }else{
                nb_mu=stats::rmultinom(nb_pos,1, initial_marker_proportion[[region]])
              }

              for(marker in 1:Nb_marker[[region]]){
                pos=which(nb_mu[marker,]==1)
                #browser()
                if(length(pos)>0){
                  if(!all(pos_reg%in%1:dim(Mat_seq)[2])){
                    browser()
                  }
                  Mat_seq[as.numeric(genealogy$id_split[1,i]),pos_reg[pos]]=paste(paste("m",marker,sep=""),letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[region]][[marker]]))],sep="_")

                }
              }

            }else{
              Mat_seq[as.numeric(genealogy$id_split[1,i]),pos_reg]=letters[ceiling(stats::runif(nb_pos,0,nb_state_marker[[region]]))]
            }
          }
          for(j in 1:(dim(genealogy$Coal_time)[1]-1)){
            Mat_seq[genealogy$id_create[j,i],pos_reg]=Mat_seq[as.numeric(genealogy$id_split[j,i]),pos_reg]
            if(!Marker_supperposition){
              if(Nb_marker[[region]]>1){
                for(marker in 1:Nb_marker[[region]]){
                  if(j==(M-1)){
                    q=1-exp(-mu_marker[[region]][[marker]]*genealogy$Coal_time[j,i]*Ne*nb_state_marker[[region]][[marker]]/(nb_state_marker[[region]][[marker]]-1))
                  }else{
                    q=1-exp(-mu_marker[[region]][[marker]]*Ne*nb_state_marker[[region]][[marker]]*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])/(nb_state_marker[[region]][[marker]]-1))
                  }
                  for(seg_id in which(Mat_seq[,pos_reg[1]]!=0)){
                    L_pos=which(substr(Mat_seq[seg_id,pos_reg],2,2)==as.character(marker))
                    if(length(L_pos)>0){
                      nb_mu=stats::rbinom(n=length(L_pos) ,size = 1 ,prob = q)
                      pos=which(nb_mu==1)
                      if(length(pos)>0){
                        x=4
                        #browser()
                        substr(Mat_seq[seg_id,pos_reg[L_pos[pos]]],x,x)=letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[region]][[marker]]))]
                      }
                    }
                  }
                }
              }else{
                if(j==(M-1)){
                  q=1-exp(-mu_marker[[region]]*genealogy$Coal_time[j,i]*Ne*nb_state_marker[[region]]/(nb_state_marker[[region]]-1))
                }else{
                  q=1-exp(-mu_marker[[region]]*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker[[region]]/(nb_state_marker[[region]]-1))
                }
                for(seg_id in which(Mat_seq[,pos_reg[1]]!=0)){
                nb_mu=stats::rbinom(n=nb_pos ,size = 1 ,prob = q)
                pos=which(nb_mu==1)
                if(length(pos)>0){
                  Mat_seq[seg_id,pos_reg[pos]]=letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[region]]))]

                }

              }
            }

            }else{
              if(Nb_marker>1){
                for(marker in 1:Nb_marker[[region]]){
                  if(j==(M-1)){
                    q=1-exp(-mu_marker[[region]][[marker]]*genealogy$Coal_time[j,i]*Ne*nb_state_marker[[region]][[marker]]/(nb_state_marker[[region]][[marker]]-1))
                  }else{
                    q=1-exp(-mu_marker[[region]][[marker]]*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker[[region]][[marker]]/(nb_state_marker[[region]][[marker]]-1))
                  }

                  for(seg_id in which(Mat_seq[,pos_reg[1]]!=0)){

                    nb_mu=stats::rbinom(n=nb_pos ,size = 1 ,prob = q)
                    pos=which(nb_mu==1)
                    if(length(pos)>0){
                      x=4+(marker-1)*5
                      substr(Mat_seq[seg_id,pos_reg[pos]],x,x)=letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[region]][[marker]]))]
                    }
                  }
                }
              }else{
                if(j==(M-1)){
                  q=1-exp(-mu_marker[[region]]*genealogy$Coal_time[j,i]*Ne*nb_state_marker[[region]]/(nb_state_marker[[region]]-1))
                }else{
                  q=1-exp(-mu_marker[[region]]*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*nb_state_marker[[region]]/(nb_state_marker[[region]]-1))
                }
                for(seg_id in which(Mat_seq[,pos_reg[1]]!=0)){
                  nb_mu=stats::rbinom(n=nb_pos ,size = 1 ,prob = q)
                  pos=which(nb_mu==1)
                  if(length(pos)>0){
                    Mat_seq[seg_id,pos_reg[pos]]=letters[ceiling(stats::runif(length(pos),0,nb_state_marker[[region]]))]

                  }
                }
              }
            }
          }
          # browser()
          Mat_seq=rbind(Mat_seq,c(1:L_seg))
          Mat_seq[(M+1),]=as.numeric(Mat_seq[(M+1),])+count_L
          Output[,(count_L+1):(count_L+L_seg)]=Mat_seq
        }
        count_L=count_L+L_seg
      }


    }

  }

  Output=Output[,-1]
  print("creating segregating matrix")
  if(Marker_supperposition){
    rm_pos=c()
    for(m in 2:(M)){
      if(m==2){
        rm_pos=which(Output[1,]==Output[m,])
      }else{
        if(length(rm_pos)>0){
          rm_pos=rm_pos[which(Output[1,rm_pos]==Output[m,rm_pos])]
        }
      }
    }
    if(length(rm_pos)>0){
      Output=Output[,-rm_pos]
    }

  }else{
    rm_pos=c()
    if(Nb_marker==1){
      rm_pos=c()
      for(m in 2:(M)){
        if(m==2){
          rm_pos=which(Output[1,]==Output[m,])
        }else{
          if(length(rm_pos)>0){
            rm_pos=rm_pos[which(Output[1,rm_pos]==Output[m,rm_pos])]
          }
        }
      }
      if(length(rm_pos)>0){
        Output=Output[,-rm_pos]
      }
    }else{
    if(Nb_region_type==1){
      dominant_marker=which(initial_marker_proportion==max(initial_marker_proportion))
    }else{
      dominant_marker=which(initial_marker_proportion[[1]]==max(initial_marker_proportion[[1]]))
    }
    dominant_marker=as.numeric(dominant_marker)[1]

    print("Dominant marker is : ")
    print(dominant_marker)
    for(m in 1:(M)){
      if(m==1){
        rm_pos=which(substr(Output[1,],1,2)==paste("m",dominant_marker,sep="")|substr(Output[1,],1,1)=="0")
      }else{
        if(length(rm_pos)>0){
          rm_pos=rm_pos[which(Output[1,rm_pos]==Output[m,rm_pos]|substr(Output[m,rm_pos],1,1)=="0")]
        }
      }
    }
    if(length(rm_pos)>0){
    Output=Output[,-rm_pos]
    }
    }
  }
  return(Output)
}
