#' Runs the ecological Sequentially Markovian Coalescent 2 accounting for methylation
#'
#' @param n : Number of hidden states
#' @param rho : numeric vector of prior ratio of recombination over mutation for each scaffold (or chromosome)
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param methylation : vector of size two, respectively containing the absolute values of methylation and demethylation rates in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @param region_methylation : vector of size two, respectively containing the absolute values of methylation and demethylation rates at the region level in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @param mu_r : numeric value corresponding to real mutation rate (for scaling purposes), or vector of mutation if different scaffold have different mutation rate
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param Free : TRUE to estimate methylation rates from the data (i.e. ignoring what has been inputed)
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param Region_Free : TRUE to estimate region methylation rates from the data (i.e. ignoring what has been inputed)
#' @param BoxM : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the -log10 of upper bondery.
#' @param BoxM_reg : vector of size two which are bounderies of region methylation rates. First value gives the -log10 of lower bondery and second value the -log10 of upper bondery.
#' @param window_min : minimum sequence length of a methylated regions
#' @param nb_site_min : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param P_m : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in methylated regions
#' @param P_d : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in unmethylated regions
#' @param Output_meth_Region : True to output the found region methylation level.
#' @param Output_coal_time : True to output the found coalescent time along the genome
#' @param Use_estimated_prior : True to use inferred parameter for tree branch inference
#' @param Smooth: TRUE to output the expected TMRCA
#' @export
#' @return A list containing all estimations (first list contains estimation based on the data second on the pseudo-observed data). List of results contain:LH the likelihood, Tc the expected coalescent time,L length of the sequence, rho the recombination rate,mu the mutation rate, beta the germination rate, sigma the self-fertilization rate, Xi the vector of change of population size (population size at time t is  Xi[t]*Ne/ploidy).
Methylation_rate_estimation<-function(n=40,rho=1,O,methylation=c(5,4),region_methylation=c(5,4),mu_r,NC=1,mu_b=1,sigma=0,beta=1,Big_Window=F,position_removed=NA,Free=F,Region=F,Region_Free=F,BoxM=c(2,10),BoxM_reg=c(2,10),window_min=100,nb_site_min=4,P_m=c(0.8,0.2),P_d=c(0.2,0.8),Output_meth_Region=F,Output_coal_time=F,Use_estimated_prior=FALSE, Smooth = FALSE){
  mu_m=NA
  mu_m_reg=NA
  if(Region==0){
    Region_Free=F
  }
  if(Region>0){
    Region_Free=T #  To fix
  }
  if(Region==2){
    Free=F
  }
  check_tree=F
  nb_methylation_context=1
  Check=F
  FS=F
  EM=F
  SCALED=F
  parallel=1
  LH_opt=F
  Problem_Solvable=T
  if(nb_methylation_context==1){
    mu_m=10^-methylation
    p=(mu_m[2]/(sum(mu_m)))
    #print("Expected probability to be unmethylated")
    #print(p)

  }else{
    mu_m=matrix(0,nb_methylation_context,2)
    p=c()
    for(context in 1:nb_methylation_context){
      mu_m=10^-methylation[context,]
      p=c(p,(mu_m[2]/(sum(mu_m))))
    }
  }
  if(Region>0&!Region_Free){
    mu_m_reg=10^-region_methylation
    p_reg=(mu_m_reg[2]/(sum(mu_m_reg)))
    #print("Expected probability for region to be unmethylation")
    #print(p_reg)
  }
  gamma=rho



  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[dim(O)[1],dim(O)[2]])
    Redo=T
    if(Free&Region_Free){

      for(xxx in c(1,2)){
        Redo=T
        if(xxx==1){
          Region_Free=T
          Free=T
          P_d_s=P_d
          P_m_s=P_m
          P_m=c(0.8,0.2)
          P_d=c(0.2,0.8)
          if(any(is.na(P_m))){
            p=(mu_m[2]/(sum(mu_m)))
            if(F){#(sum(mu_m)/sum(mu_m_reg))<0.5
              P_m=c(((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))),1-((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))))
            }else{
              print("Warning : Site rate much faster than region rate, region signal most likeli lost")
              P_m=c(0.8,0.2)
            }
          }
          if(any(is.na(P_d))){
            p=(mu_m[2]/(sum(mu_m)))
            if(F){ #(sum(mu_m)/sum(mu_m_reg))<0.5
              P_d=c(1-(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))),(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))))
            }else{
              print("Warning : Site rate much faster than region rate, region signal most likeli lost")
              P_d=c(0.2,0.8)
            }
          }



        }
        if(xxx==2){
          Region_Free=T
          Free=F
          Region=2
          mu_m=methylation
          mu_m_reg=region_methylation
          p=(mu_m[2]/(sum(mu_m)))
          P_d=P_d_s
          P_m=P_m_s
        }

        while(Redo){
          Redo=F
          Strange_Ne=F
          Os=list()
          count=0
          M_o=0
          theta_W=0
          theta_M=c()
          theta_D=c()
          theta_O=c()
          theta_reg=c()
          scale_meth=c()
          if(nb_methylation_context==2){
            scale_meth_2=c()
          }
          if(Free|Region_Free>0){
            p_estimated=c()
            ps=c()
            pm=c()
            pm_reg=c()
            if(nb_methylation_context==2){
              p_estimated_2=c()
              ps2=c()
            }
          }
          s_t=Sys.time()
          if(Output_meth_Region){
            meth_reg_save=list()
          }
          for(k in 1:(M-1)){
            for(l in (k+1):M){
              Os_=seqMeth(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],nb_meth=nb_methylation_context,Free=Free,Region=Region,Region_Free=Region_Free,window_min=window_min,nb_site_min=nb_site_min,P_m=P_m,P_d=P_d,Output_meth_Region=Output_meth_Region)
              if(Output_meth_Region){
                meth_reg_save[[(1+length( meth_reg_save))]]=Os_$meth_reg_long_zip
              }
              theta_W=theta_W+as.numeric(Os_$theta)
              scale_meth=c(scale_meth,(length(which(Os_$seq<2))/(L-length(which(Os_$seq==2)))))
              good_transition_rate= Os_$transition_rate

              if(Region_Free&as.numeric(Region)%in%c(1,2)){
                theta_reg=c(theta_reg,as.numeric(Os_$theta_reg))
                pm_reg=c(pm_reg,Os_$ratio_reg)
                if(Free){
                  theta_M=c(theta_M,as.numeric(Os_$theta_M))
                  pm=c(pm,Os_$pm)
                  theta_D=c(theta_D,as.numeric(Os_$theta_D))
                  theta_O=c(theta_O,as.numeric(Os_$theta_O))
                }
              }else{

                if(nb_methylation_context==2){
                  scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/(L-length(which(Os_$seq==2)))))
                  scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])

                }
                if(Free){
                  theta_M=c(theta_M,as.numeric(Os_$theta_M))
                  p_estimated=c(p_estimated,Os_$ratio_D_over_M)

                  if(nb_methylation_context==2){
                    p_estimated2=c(p_estimated2,Os_$ratio_O_over_P)
                    ps2=c(ps2,Os_$theta_O)}

                }
              }



              M_o=M_o+1
              if(count==0){
                if(length(Os_$seq)>10^6){
                  if(!LH_opt){
                    Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context,Region=Region)
                    Mat_symbol=Os_temporary[[2]]
                  }else{
                    Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                    Mat_symbol=Os_temporary[[2]]

                  }

                  #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
                  #Super_Mat_symbol=Os_temporary[[2]]
                  rm(Os_temporary)
                  L10=length(Os_$seq)/10^6
                  count=count+1
                  if(!LH_opt){
                    Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }



                }else{
                  count=count+1
                  if(!LH_opt){
                    Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context,Region=Region)
                    Mat_symbol=Os_temporary[[2]]
                    Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Build_zip_2seq_m(Os_$seq,20)
                    Mat_symbol=Os[[count]][[2]]
                    Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }




                  #Os[[count]][[3]]=Mat_symbol
                  #Os[[count]][[4]]=length(Os_$seq)

                }
              }else{
                count=count+1
                if(!LH_opt){
                  Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }
              }
            }
            rm(Os_)
          }
          e_t=Sys.time()
          print("Time to Zip sequences")
          print(e_t-s_t)
          if(length(Os)>=1){
            for(oo in 1:length(Os)){
              Os[[oo]]=symbol2Num_m(Os[[oo]])
            }
            theta_W=theta_W/M_o



            theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
            Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r*4/3))))



            mu=(-(log((1-(theta/(L*0.75))))/2))


            scale_meth=mean(scale_meth)
            if(nb_methylation_context==2){
              scale_meth_2=mean(scale_meth_2)
            }

            if(as.numeric(Region)>0){
              if(Free&as.numeric(Region)!=2){
                print("estimated equilibrium probability")
                p=1-mean(pm)
                print(p)
                ps=theta_M#1-mean(pm)
                print("Proportion of segregating sites : ")
                print(mean(ps))
                if(any(ps/min(c((1-p),p)))>=10^-2){
                  Strange_Ne=T
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    mu_m=NA
                  }
                }else{
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    Strange_Ne=T
                  }
                }

              }

              if(Region_Free){
                print("estimated region equilibrium probability")
                p=1-mean(pm_reg)
                print(p)
                ps=theta_reg
                #mu_m_reg=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

                if(any(ps/min(c((1-p),p)))>=10^-2){
                  Strange_Ne=T
                  mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                    mu_m_reg=NA
                  }
                }else{
                  mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  # (2*p*(1-p))*(1-((exp(-mean(mu_m_reg/c((1-p),p))))^2))
                  if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                    Strange_Ne=T
                  }
                }
              }
            }else{

              if(Free){
                print("estimated equilibrium probability")
                p=mean(p_estimated)
                print(p)
                ps=mean(theta_M)
                print((ps/min(c((1-p),p))))
                if(any(ps/min(c((1-p),p)))>=10^-2){
                  Strange_Ne=T
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    mu_m=NA
                  }
                }else{
                  #mu_m=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    Strange_Ne=T
                  }
                }
                if(nb_methylation_context==2){
                  print("estimated equilibrium probability in second methylation context")
                  p=mean(p_estimated2)
                  print(p)
                  ps=ps2
                  #mu_m=rbind(mu_m,c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
                  mu_m=rbind(mu_m,c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T))

                  if(any(is.na(as.numeric(as.character(mu_m[2,]))))){
                    # print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
                    #  warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

                    for(rep in 1:length(Os)){
                      pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                      if(length(pos)>0){
                        Os[[rep]][[1]][pos]=0
                      }
                    }
                    mu_m[2,]=c(0.002,0,01)
                  }
                }
              }
            }

            if(!Strange_Ne){
              print("mu_m:")
              print(mu_m/Ne)
              methylation=mu_m/Ne
              if(Region>0){
                print("mu_m_reg:")
                print(mu_m_reg/Ne)
                region_methylation=mu_m_reg/Ne
              }

            }
            if(Strange_Ne){
              check_tree=T
              if(Free&all(!is.na(mu_m))){
                print("New upper limit BoxM")
                print(-log10(mu_m/Ne))
                BoxM[2]=min(-log10(mu_m/Ne))
              }
              if(Region_Free&all(!is.na(mu_m_reg))){
                print("New upper limit BoxM_reg")
                print(-log10(mu_m_reg/Ne))
                BoxM_reg[2]=min(-log10(mu_m_reg/Ne))
              }
            }
            if(check_tree){
              test.env <- new.env()
              test.env$Free <- Free
              test.env$Region_Free <- Region_Free
              BW=Short_Baum_Welch(Os,L,mu,theta_W,rho*theta,beta=beta,k=n,sigma=sigma,NC=NC,mu_b=mu_b,Big_Window=Big_Window,Ne=Ne,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,methylation=methylation,Region=Region,region_methylation=region_methylation)
              test.env$Big_M <- BW$Big_M
              test.env$theta_W <- theta_W
              test.env$mu <- mu
              test.env$mu_b <- mu_b
              test.env$Rho <- rho*theta
              test.env$L <- L
              test.env$k <- n
              test.env$Beta <- beta
              test.env$Self <- sigma
              test.env$NC <- NC
              test.env$scale_meth <- scale_meth
              test.env$nb_methylation_context <- nb_methylation_context
              test.env$Ne<-Ne
              test.env$lh_param<-3
              function_to_minimize<-function(param){
                mu=get('mu', envir=test.env)
                Ne=get('Ne', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                Rho=get('Rho', envir=test.env)
                L=get('L', envir=test.env)
                k=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                BoxM_reg=get('BoxM_reg', envir=test.env)
                BoxM=get('BoxM', envir=test.env)
                Free=get('Free', envir=test.env)
                Big_M=get('Big_M', envir=test.env)
                Region_Free=get('Region_Free', envir=test.env)
                scale_meth=get('scale_meth', envir=test.env)
                lh_param=get('lh_param', envir=test.env)
                nb_methylation_context=get('nb_methylation_context', envir=test.env)
                start_position=0
                #print(10^-((param*(BoxM[2]-BoxM[1]))+BoxM[1]))
                if(Free){
                  p=get('p', envir=test.env)
                  start_position=start_position+1
                  methylation=Ne*c((1-p),p)*10^-((param[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])
                }else{
                  methylation=c(NA,NA)
                }

                if(Region_Free){
                  p_reg=get('p_reg', envir=test.env)
                  start_position=start_position+1
                  region_methylation=Ne*c((1-p_reg),p_reg)*10^-((param[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
                }else{
                  region_methylation=c(NA,NA)
                }
                Tc=build_Tc(n=k,Beta=Beta,scale=c(1,0),Sigma=Self,Big_Window=Big_Window)
                g=build_emi_m(mu,mu_b,Tc,Beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region=Region,scale_meth)
                x=as.vector(g)
                keep=which(x>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                LH=-sum(log(x)*m)
                return(LH)

              }

              if(Free&!Region_Free){
                nb_to_test_1=(BoxM[2]-BoxM[1])*100
              }
              if(!Free&Region_Free){
                nb_to_test_1=(BoxM_reg[2]-BoxM_reg[1])*100
              }
              if(Free&Region_Free){
                nb_to_test_1=(BoxM[2]-BoxM[1])*100
                nb_to_test_2=(BoxM_reg[2]-BoxM_reg[1])*100
              }

              param=c()
              if(Free){
                if(as.numeric(Region)>0){
                  p=1-mean(pm)
                }else{
                  p=mean(p_estimated)
                }
                test.env$p <- p

                oldrate=0.5
                param=c(param,oldrate)
              }
              if(Region_Free){
                p_reg=1-mean(pm_reg)
                test.env$p_reg <- p_reg
                oldrate_reg=0.5
                param=c(param,oldrate_reg)
              }
              if(length(param)>0){

                start=T
                if(length(param)==1){
                  for (value_1 in seq(0,1,(1/nb_to_test_1))){
                    param=c(value_1)
                    R2=function_to_minimize(param)
                    if(start){
                      R2_old=R2
                      sol=param
                      start=F
                    }else{
                      if(R2<=R2_old){
                        R2_old=R2
                        sol=param
                      }
                    }
                  }
                }else{

                  for (value_1 in seq(0,1,(1/nb_to_test_1))){
                    for(value_2 in seq(0,1,(1/nb_to_test_2))){
                      param=c(value_1,value_2)
                      R2=function_to_minimize(param)

                      if(start){
                        R2_old=R2
                        sol=param
                        start=F
                      }else{



                        if(R2<R2_old){
                          R2_old=R2
                          sol=param
                        }
                      }
                    }
                  }

                }

                start_position=0
                if(Free){
                  p=get('p', envir=test.env)
                  start_position=start_position+1
                  methylation=c((1-p),p)*10^-((sol[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])

                }

                if(Region_Free){
                  p_reg=get('p_reg', envir=test.env)
                  start_position=start_position+1
                  region_methylation=c((1-p_reg),p_reg)*10^-((sol[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
                }


              }
            }
          }else{
            stop("data too poor")
          }


        }
        print("methylation rates:")
        print(methylation)

        print("region methylation rates:")
        print(region_methylation)

        if(xxx==1){
          methylation_s=methylation
        }
        if(xxx==2){
          region_methylation_s=region_methylation
        }
      }

      region_methylation=region_methylation_s
      methylation=methylation_s
    }else{
      while(Redo){
        Redo=F
        Strange_Ne=F
        Os=list()
        count=0
        M_o=0
        theta_W=0
        theta_M=c()
        theta_D=c()
        theta_O=c()
        theta_reg=c()
        scale_meth=c()
        if(nb_methylation_context==2){
          scale_meth_2=c()
        }
        if(Free|Region_Free>0){
          p_estimated=c()
          ps=c()
          pm=c()
          pm_reg=c()
          if(nb_methylation_context==2){
            p_estimated_2=c()
            ps2=c()
          }
        }
        s_t=Sys.time()
        if(Output_meth_Region){
          meth_reg_save=list()
        }
        for(k in 1:(M-1)){
          for(l in (k+1):M){
            if(k==1&l==2){
              find_rate=T
              transition_rate=NA
            }else{
              find_rate=F
              transition_rate=good_transition_rate
              if(is.null(transition_rate)){
                find_rate=T
                transition_rate=NA
              }
            }
            Os_=seqMeth(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],nb_meth=nb_methylation_context,Free=Free,Region=Region,Region_Free=Region_Free,window_min=window_min,nb_site_min=nb_site_min,find_rate=find_rate,transition_rate=transition_rate,P_m=P_m,P_d=P_d)
            if(Output_meth_Region){
              meth_reg_save[[(1+length( meth_reg_save))]]=Os_$meth_reg_long_zip
            }
            good_transition_rate= Os_$transition_rate
            theta_W=theta_W+as.numeric(Os_$theta)
            scale_meth=c(scale_meth,(length(which(Os_$seq<2))/(L-length(which(Os_$seq==2)))))

            if(Region_Free&as.numeric(Region)%in%c(1,2)){
              theta_reg=c(theta_reg,as.numeric(Os_$theta_reg))
              print("Theta reg:")
              print(Os_$theta_reg)
              pm_reg=c(pm_reg,Os_$ratio_reg)
              if(Free){
                theta_M=c(theta_M,as.numeric(Os_$theta_M))
                pm=c(pm,Os_$pm)
                theta_D=c(theta_D,as.numeric(Os_$theta_D))
                theta_O=c(theta_O,as.numeric(Os_$theta_O))

              }
            }else{

              if(nb_methylation_context==2){
                scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/(L-length(which(Os_$seq==2)))))
                scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])

              }
              if(Free){
                theta_M=c(theta_M,as.numeric(Os_$theta_M))
                p_estimated=c(p_estimated,Os_$ratio_D_over_M)

                if(nb_methylation_context==2){
                  p_estimated2=c(p_estimated2,Os_$ratio_O_over_P)
                  ps2=c(ps2,Os_$theta_O)}

              }
            }



            M_o=M_o+1
            if(count==0){
              if(length(Os_$seq)>10^6){
                if(!LH_opt){
                  Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context,Region=Region)
                  Mat_symbol=Os_temporary[[2]]
                }else{
                  Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                  Mat_symbol=Os_temporary[[2]]

                }

                #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
                #Super_Mat_symbol=Os_temporary[[2]]
                rm(Os_temporary)
                L10=length(Os_$seq)/10^6
                count=count+1
                if(!LH_opt){
                  Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }
                #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                #Os[[count]][[3]]=Mat_symbol
                #Os[[count]][[4]]=length(Os_$seq)


              }else{
                count=count+1
                if(!LH_opt){
                  Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context,Region=Region)
                  Mat_symbol=Os_temporary[[2]]
                  Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Build_zip_2seq_m(Os_$seq,20)
                  Mat_symbol=Os[[count]][[2]]
                  Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }




                #Os[[count]][[3]]=Mat_symbol
                #Os[[count]][[4]]=length(Os_$seq)

              }
            }else{
              count=count+1
              if(!LH_opt){
                Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
              }else{
                Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
              }
            }
          }
          rm(Os_)
        }
        e_t=Sys.time()
        print("Time to Zip sequences")
        print(e_t-s_t)
        if(length(Os)>=1){
          for(oo in 1:length(Os)){
            Os[[oo]]=symbol2Num_m(Os[[oo]])
          }
          theta_W=theta_W/M_o


          theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
          Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r*4/3))))



          mu=(-(log((1-(theta/(L*0.75))))/2))
          print("mu:")
          print(mu)

          scale_meth=mean(scale_meth)
          if(nb_methylation_context==2){
            scale_meth_2=mean(scale_meth_2)
          }

          if(as.numeric(Region)>0){

            if(Free&as.numeric(Region)!=2){
              print("estimated equilibrium probability")
              p=1-mean(pm)
              print(p)
              ps=theta_M#1-mean(pm)
              if(any(ps/min(c((1-p),p)))>=10^-2){
                Strange_Ne=T
                mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                if(any(is.na(as.numeric(as.character(mu_m))))){
                  mu_m=NA
                }

              }else{
                mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                if(any(is.na(as.numeric(as.character(mu_m))))){
                  Strange_Ne=T
                }
              }

            }

            if(Region_Free){
              print("estimated region equilibrium probability")
              p=1-mean(pm_reg)
              print(p)
              ps=theta_reg
              #mu_m_reg=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

              if(any(ps/min(c((1-p),p)))>=10^-2){
                Strange_Ne=T
                mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                  mu_m_reg=NA
                }

              }else{
                mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                  Strange_Ne=T
                }
              }
            }
          }else{

            if(Free){
              print("estimated equilibrium probability")
              p=mean(p_estimated)
              print(p)
              ps=mean(theta_M)
              print((ps/min(c((1-p),p))))
              if(any(ps/min(c((1-p),p)))>=10^-2){
                Strange_Ne=T
                mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                if(any(is.na(as.numeric(as.character(mu_m))))){
                  mu_m=NA
                }
              }
              #mu_m=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)
              mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
              if(any(is.na(as.numeric(as.character(mu_m))))){
                Strange_Ne=T
              }
              if(nb_methylation_context==2){
                print("estimated equilibrium probability in second methylation context")
                p=mean(p_estimated2)
                print(p)
                ps=ps2
                #mu_m=rbind(mu_m,c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
                mu_m=rbind(mu_m,c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T))

                if(any(is.na(as.numeric(as.character(mu_m[2,]))))){
                  print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
                  warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

                  for(rep in 1:length(Os)){
                    pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                    if(length(pos)>0){
                      Os[[rep]][[1]][pos]=0
                    }
                  }
                  mu_m[2,]=c(0.002,0,01)
                }
              }
            }
          }

          if(!Strange_Ne){
            if(Free&!Region){
              print("mu_m:")
              print(mu_m/Ne)
              methylation=mu_m/Ne
            }
            if(Region>0&Region_Free){
              print("mu_m_reg:")
              print(mu_m_reg/Ne)
              region_methylation=mu_m_reg/Ne
            }
          }
          if(Strange_Ne){
            check_tree=T
            if(Free&all(!is.na(mu_m))){
              print("New upper limit BoxM")
              print(-log10(mu_m/Ne))
              BoxM[2]=min(-log10(mu_m/Ne))
            }
            if(Region_Free&all(!is.na(mu_m_reg))){
              print("New upper limit BoxM_reg")
              print(-log10(mu_m_reg/Ne))
              BoxM_reg[2]=min(-log10(mu_m_reg/Ne))
            }

          }
          if(check_tree){
            test.env <- new.env()
            test.env$Free <- Free
            test.env$Region_Free <- Region_Free
            BW=Short_Baum_Welch(Os,L,mu,theta_W,rho*theta,beta=beta,k=n,sigma=sigma,NC=NC,mu_b=mu_b,Big_Window=Big_Window,Ne=Ne,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,methylation=methylation,Region=Region,region_methylation=region_methylation)
            test.env$Big_M <- BW$Big_M
            test.env$theta_W <- theta_W
            test.env$mu <- mu
            test.env$mu_b <- mu_b
            test.env$Rho <- rho*theta
            test.env$L <- L
            test.env$k <- n
            test.env$Beta <- beta
            test.env$Self <- sigma
            test.env$NC <- NC
            test.env$scale_meth <- scale_meth
            test.env$nb_methylation_context <- nb_methylation_context
            test.env$Ne<-Ne
            function_to_minimize<-function(param){
              mu=get('mu', envir=test.env)
              Ne=get('Ne', envir=test.env)
              Big_Window=get('Big_Window', envir=test.env)
              mu_b=get('mu_b', envir=test.env)
              Rho=get('Rho', envir=test.env)
              L=get('L', envir=test.env)
              k=get('k', envir=test.env)
              Beta=get('Beta', envir=test.env)
              Self=get('Self', envir=test.env)
              BoxM_reg=get('BoxM_reg', envir=test.env)
              BoxM=get('BoxM', envir=test.env)
              Free=get('Free', envir=test.env)
              Big_M=get('Big_M', envir=test.env)
              Region_Free=get('Region_Free', envir=test.env)
              scale_meth=get('scale_meth', envir=test.env)
              nb_methylation_context=get('nb_methylation_context', envir=test.env)
              start_position=0
              #print(10^-((param*(BoxM[2]-BoxM[1]))+BoxM[1]))
              if(Free){
                p=get('p', envir=test.env)
                start_position=start_position+1
                methylation=Ne*c((1-p),p)*10^-((param[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])
              }else{
                methylation=c(NA,NA)
              }

              if(Region_Free){
                p_reg=get('p_reg', envir=test.env)
                start_position=start_position+1
                region_methylation=Ne*c((1-p_reg),p_reg)*10^-((param[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
              }else{
                region_methylation=c(NA,NA)
              }
              Tc=build_Tc(n=k,Beta=Beta,scale=c(1,0),Sigma=Self,Big_Window=Big_Window)
              g=build_emi_m(mu,mu_b,Tc,Beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region=Region,scale_meth)

              x=as.vector(g)
              keep=which(x>0)
              x=x[keep]
              m=as.vector(Big_M)
              m=m[keep]
              LH=-sum(log(x)*m)
              return( LH)
            }
            if(Free&!Region_Free){
              nb_to_test_1=(BoxM[2]-BoxM[1])*100
            }
            if(!Free&Region_Free){
              nb_to_test_1=(BoxM_reg[2]-BoxM_reg[1])*100
            }
            if(Free&Region_Free){
              nb_to_test_1=(BoxM[2]-BoxM[1])*100
              nb_to_test_2=(BoxM_reg[2]-BoxM_reg[1])*100
            }
            param=c()
            if(Free){
              if(as.numeric(Region)>0){
                p=1-mean(pm)
              }else{
                p=mean(p_estimated)
              }
              test.env$p <- p

              oldrate=0.5
              param=c(param,oldrate)
            }
            if(Region_Free){
              p_reg=1-mean(pm_reg)
              test.env$p_reg <- p_reg
              oldrate_reg=0.5
              param=c(param,oldrate_reg)
            }
            if(length(param)>0){

              start=T
              if(length(param)==1){
                for (value_1 in seq(0,1,(1/nb_to_test_1))){
                  param=c(value_1)
                  R2=function_to_minimize(param)
                  if(start){
                    R2_old=R2
                    sol=param
                    start=F
                  }else{
                    if(R2<=R2_old){
                      R2_old=R2
                      sol=param
                    }
                  }
                }
              }else{
                for (value_1 in seq(0,1,(1/nb_to_test_1))){
                  for(value_2 in seq(0,1,(1/nb_to_test_2))){
                    param=c(value_1,value_2)
                    R2=function_to_minimize(param)
                    if(start){
                      R2_old=R2
                      sol=param
                      start=F
                    }else{
                      if(R2<=R2_old){
                        R2_old=R2
                        sol=param
                      }
                    }
                  }
                }
              }

              start_position=0
              if(Free){
                p=get('p', envir=test.env)
                start_position=start_position+1
                methylation=c((1-p),p)*10^-((sol[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])

              }

              if(Region_Free){
                p_reg=get('p_reg', envir=test.env)
                start_position=start_position+1
                region_methylation=c((1-p_reg),p_reg)*10^-((sol[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
              }


            }
          }
        }else{
          stop("data too poor")
        }


      }
    }
    rm(O)

  }
  if(NC>1){
    if(length(mu_r)==1){
      mu_r=rep(mu_r,NC)
    }
    if(length(rho)==1){
      rho=rep(rho,NC)
    }
    O_o=O
    methylation=list()
    region_methylation=list()
    for(chr in 1:length(O_o)){
      O=O_o[[chr]]
      M=dim(O)[1]-2
      L=as.numeric(O[dim(O)[1],dim(O)[2]])
      if(Free&Region_Free){

        for(xxx in c(1,2)){
          Redo=T
          if(xxx==1){
            Region_Free=T
            Free=T
            if(any(is.na(P_m))){
              p=(mu_m[2]/(sum(mu_m)))
              if(F){ # (sum(mu_m)/sum(mu_m_reg))<1
                P_m=c(((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))),1-((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))))
              }else{
                print("Warning : Site rate much faster than region rate, region signal most likeli lost")
                P_m=c(0.8,0.2)
              }
            }
            if(any(is.na(P_d))){
              p=(mu_m[2]/(sum(mu_m)))
              if(F){ # (sum(mu_m)/sum(mu_m_reg))<1
                P_d=c(1-(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))),(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))))
              }else{
                print("Warning : Site rate much faster than region rate, region signal most likeli lost")
                P_d=c(0.2,0.8)
              }
            }

          }
          if(xxx==2){
            Region_Free=T
            Free=F
            Region=2
            mu_m=methylation[[chr]]
            mu_m_reg=region_methylation[[chr]]
            p=(mu_m[2]/(sum(mu_m)))
            if(F){  # (sum(mu_m)/sum(mu_m_reg))<1
              P_m=c(((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))),1-((1-p)+(p*exp(-sum(mu_m)/sum(mu_m_reg)))))
            }else{
              print("Warning : Site rate much faster than region rate, region signal most likeli lost")
              P_m=c(0.8,0.2)
            }

            p=(mu_m[2]/(sum(mu_m)))
            if(F){  #(sum(mu_m)/sum(mu_m_reg))<1
              P_d=c(1-(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))),(p+((1-p)*exp(-sum(mu_m)/sum(mu_m_reg)))))
            }else{
              print("Warning : Site rate much faster than region rate, region signal most likeli lost")
              P_d=c(0.2,0.8)
            }


          }

          while(Redo){
            Redo=F
            Strange_Ne=F
            Os=list()
            count=0
            M_o=0
            theta_W=0
            theta_M=c()
            theta_D=c()
            theta_O=c()
            theta_reg=c()
            scale_meth=c()
            if(nb_methylation_context==2){
              scale_meth_2=c()
            }
            if(Free|Region_Free>0){
              p_estimated=c()
              ps=c()
              pm=c()
              pm_reg=c()
              if(nb_methylation_context==2){
                p_estimated_2=c()
                ps2=c()
              }
            }
            s_t=Sys.time()
            if(Output_meth_Region){
              meth_reg_save=list()
            }
            for(k in 1:(M-1)){
              for(l in (k+1):M){
                Os_=seqMeth(O[c(k,l,(M+1),(M+2)),],L,position_removed[[chr]],nb_meth=nb_methylation_context,Free=Free,Region=Region,Region_Free=Region_Free,window_min=window_min,nb_site_min=nb_site_min,P_m=P_m,P_d=P_d)
                if(Output_meth_Region){
                  meth_reg_save[[(1+length( meth_reg_save))]]=Os_$meth_reg_long_zip
                }
                theta_W=theta_W+as.numeric(Os_$theta)
                scale_meth=c(scale_meth,(length(which(Os_$seq<2))/(L-length(which(Os_$seq==2)))))

                if(Region_Free&as.numeric(Region)%in%c(1,2)){
                  theta_reg=c(theta_reg,as.numeric(Os_$theta_reg))
                  pm_reg=c(pm_reg,Os_$ratio_reg)
                  if(Free){
                    theta_M=c(theta_M,as.numeric(Os_$theta_M))
                    pm=c(pm,Os_$pm)
                    theta_D=c(theta_D,as.numeric(Os_$theta_D))
                    theta_O=c(theta_O,as.numeric(Os_$theta_O))

                  }
                }else{

                  if(nb_methylation_context==2){
                    scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/(L-length(which(Os_$seq==2)))))
                    scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])

                  }
                  if(Free){
                    theta_M=c(theta_M,as.numeric(Os_$theta_M))
                    p_estimated=c(p_estimated,Os_$ratio_D_over_M)

                    if(nb_methylation_context==2){
                      p_estimated2=c(p_estimated2,Os_$ratio_O_over_P)
                      ps2=c(ps2,Os_$theta_O)}

                  }
                }



                M_o=M_o+1
                if(count==0){
                  if(length(Os_$seq)>10^6){
                    if(!LH_opt){
                      Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context,Region=Region)
                      Mat_symbol=Os_temporary[[2]]
                    }else{
                      Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                      Mat_symbol=Os_temporary[[2]]

                    }

                    #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
                    #Super_Mat_symbol=Os_temporary[[2]]
                    rm(Os_temporary)
                    L10=length(Os_$seq)/10^6
                    count=count+1
                    if(!LH_opt){
                      Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                    }else{
                      Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                    }
                    #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                    #Os[[count]][[3]]=Mat_symbol
                    #Os[[count]][[4]]=length(Os_$seq)


                  }else{
                    count=count+1
                    if(!LH_opt){
                      Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context,Region=Region)
                      Mat_symbol=Os_temporary[[2]]
                      Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                    }else{
                      Os[[count]]=Build_zip_2seq_m(Os_$seq,20)
                      Mat_symbol=Os[[count]][[2]]
                      Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                    }




                    #Os[[count]][[3]]=Mat_symbol
                    #Os[[count]][[4]]=length(Os_$seq)

                  }
                }else{
                  count=count+1
                  if(!LH_opt){
                    Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }
                }
              }
              rm(Os_)
            }
            e_t=Sys.time()
            print("Time to Zip sequences")
            print(e_t-s_t)
            if(length(Os)>=1){
              for(oo in 1:length(Os)){
                Os[[oo]]=symbol2Num_m(Os[[oo]])
              }
              theta_W=theta_W/M_o



              theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
              Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r[chr]*4/3))))



              mu=(-(log((1-(theta/(L*0.75))))/2))


              scale_meth=mean(scale_meth)
              if(nb_methylation_context==2){
                scale_meth_2=mean(scale_meth_2)
              }

              if(as.numeric(Region)>0){

                if(Free&as.numeric(Region)!=2){
                  print("estimated equilibrium probability")
                  p=1-mean(pm)
                  print(p)
                  ps=theta_M#1-mean(pm)
                  if(any(ps/min(c((1-p),p)))>=10^-2){
                    Strange_Ne=T
                    mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                    if(any(is.na(as.numeric(as.character(mu_m))))){
                      mu_m=NA
                    }
                  }else{
                    mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                    if(any(is.na(as.numeric(as.character(mu_m))))){
                      Strange_Ne=T
                    }
                  }

                }

                if(Region_Free){
                  print("estimated region equilibrium probability")
                  p=1-mean(pm_reg)
                  print(p)
                  ps=theta_reg
                  #mu_m_reg=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

                  if(any(ps/min(c((1-p),p)))>=10^-2){
                    Strange_Ne=T
                    mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                    if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                      mu_m_reg=NA
                    }
                  }else{
                    mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                    if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                      Strange_Ne=T
                    }
                  }


                }
              }else{

                if(Free){
                  print("estimated equilibrium probability")
                  p=mean(p_estimated)
                  print(p)
                  ps=mean(theta_M)
                  print((ps/min(c((1-p),p))))
                  if(any(ps/min(c((1-p),p)))>=10^-2){
                    Strange_Ne=T
                    mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                    if(any(is.na(as.numeric(as.character(mu_m))))){
                      mu_m=NA
                    }
                  }
                  #mu_m=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    Strange_Ne=T
                  }
                  if(nb_methylation_context==2){
                    print("estimated equilibrium probability in second methylation context")
                    p=mean(p_estimated2)
                    print(p)
                    ps=ps2
                    #mu_m=rbind(mu_m,c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
                    mu_m=rbind(mu_m,c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T))

                    if(any(is.na(as.numeric(as.character(mu_m[2,]))))){
                      print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
                      warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

                      for(rep in 1:length(Os)){
                        pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                        if(length(pos)>0){
                          Os[[rep]][[1]][pos]=0
                        }
                      }
                      mu_m[2,]=c(0.002,0,01)
                    }
                  }
                }
              }

              if(!Strange_Ne){
                print("mu_m:")
                print(mu_m/Ne)
                methylation[[chr]]=mu_m/Ne
                if(Region>0){
                  print("mu_m_reg:")
                  print(mu_m_reg/Ne)
                  region_methylation[[chr]]=mu_m_reg/Ne
                }

              }
              if(Strange_Ne){
                check_tree=T
                if(Free&all(!is.na(mu_m))){
                  print("New upper limit BoxM")
                  print(-log10(mu_m/Ne))
                  BoxM[2]=min(-log10(mu_m/Ne))
                }
                if(Region_Free&all(!is.na(mu_m_reg))){
                  print("New upper limit BoxM_reg")
                  print(-log10(mu_m_reg/Ne))
                  BoxM_reg[2]=min(-log10(mu_m_reg/Ne))
                }
              }
              if(check_tree){
                test.env <- new.env()
                test.env$Free <- Free
                test.env$Region_Free <- Region_Free
                BW=Short_Baum_Welch(Os,L,mu,theta_W,rho[chr]*theta,beta=beta,k=n,sigma=sigma,NC=NC,mu_b=mu_b,Big_Window=Big_Window,Ne=Ne,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,methylation=methylation,Region=Region,region_methylation=region_methylation)
                test.env$Big_M <- BW$Big_M
                test.env$theta_W <- theta_W
                test.env$mu <- mu
                test.env$mu_b <- mu_b
                test.env$Rho <- rho[chr]*theta
                test.env$L <- L
                test.env$k <- n
                test.env$Beta <- beta
                test.env$Self <- sigma
                test.env$NC <- NC
                test.env$scale_meth <- scale_meth
                test.env$nb_methylation_context <- nb_methylation_context
                test.env$Ne<-Ne
                function_to_minimize<-function(param){
                  mu=get('mu', envir=test.env)
                  Ne=get('Ne', envir=test.env)
                  Big_Window=get('Big_Window', envir=test.env)
                  mu_b=get('mu_b', envir=test.env)
                  Rho=get('Rho', envir=test.env)
                  L=get('L', envir=test.env)
                  k=get('k', envir=test.env)
                  Beta=get('Beta', envir=test.env)
                  Self=get('Self', envir=test.env)
                  BoxM_reg=get('BoxM_reg', envir=test.env)
                  BoxM=get('BoxM', envir=test.env)
                  Free=get('Free', envir=test.env)
                  Big_M=get('Big_M', envir=test.env)
                  Region_Free=get('Region_Free', envir=test.env)
                  scale_meth=get('scale_meth', envir=test.env)
                  nb_methylation_context=get('nb_methylation_context', envir=test.env)
                  start_position=0
                  #print(10^-((param*(BoxM[2]-BoxM[1]))+BoxM[1]))
                  if(Free){
                    p=get('p', envir=test.env)
                    start_position=start_position+1
                    methylation=Ne*c((1-p),p)*10^-((param[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])
                  }else{
                    methylation=c(NA,NA)
                  }

                  if(Region_Free){
                    p_reg=get('p_reg', envir=test.env)
                    start_position=start_position+1
                    region_methylation=Ne*c((1-p_reg),p_reg)*10^-((param[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
                  }else{
                    region_methylation=c(NA,NA)
                  }
                  Tc=build_Tc(n=k,Beta=Beta,scale=c(1,0),Sigma=Self,Big_Window=Big_Window)
                  g=build_emi_m(mu,mu_b,Tc,Beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region=Region,scale_meth)

                  x=as.vector(g)
                  keep=which(x>0)
                  x=x[keep]
                  m=as.vector(Big_M)
                  m=m[keep]
                  LH=-sum(log(x)*m)
                  return( LH)
                }
                param=c()

                if(Free&!Region_Free){
                  nb_to_test_1=(BoxM[2]-BoxM[1])*100
                }
                if(!Free&Region_Free){
                  nb_to_test_1=(BoxM_reg[2]-BoxM_reg[1])*100
                }
                if(Free&Region_Free){
                  nb_to_test_1=(BoxM[2]-BoxM[1])*100
                  nb_to_test_2=(BoxM_reg[2]-BoxM_reg[1])*100
                }
                if(Free){
                  if(as.numeric(Region)>0){
                    p=1-mean(pm)
                  }else{
                    p=mean(p_estimated)
                  }
                  test.env$p <- p

                  oldrate=0.5
                  param=c(param,oldrate)
                }
                if(Region_Free){
                  p_reg=1-mean(pm_reg)
                  test.env$p_reg <- p_reg
                  oldrate_reg=0.5
                  param=c(param,oldrate_reg)
                }
                if(length(param)>0){

                  start=T
                  if(length(param)==1){
                    for (value_1 in seq(0,1,(1/nb_to_test_1))){
                      param=c(value_1)
                      R2=function_to_minimize(param)
                      if(start){
                        R2_old=R2
                        sol=param
                        start=F
                      }else{
                        if(R2<=R2_old){
                          R2_old=R2
                          sol=param
                        }
                      }
                    }
                  }else{
                    for (value_1 in seq(0,1,(1/nb_to_test_1))){
                      for(value_2 in seq(0,1,(1/nb_to_test_2))){
                        param=c(value_1,value_2)
                        R2=function_to_minimize(param)
                        if(start){
                          R2_old=R2
                          sol=param
                          start=F
                        }else{
                          if(R2<=R2_old){
                            R2_old=R2
                            sol=param
                          }
                        }
                      }
                    }
                  }

                  start_position=0
                  if(Free){
                    p=get('p', envir=test.env)
                    start_position=start_position+1
                    methylation[[chr]]=c((1-p),p)*10^-((sol[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])

                  }

                  if(Region_Free){
                    p_reg=get('p_reg', envir=test.env)
                    start_position=start_position+1
                    region_methylation[[chr]]=c((1-p_reg),p_reg)*10^-((sol[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
                  }


                }
              }
            }else{
              stop("data too poor")
            }


          }
          if(xxx==1){
            methylation_s=methylation[[chr]]
          }
          if(xxx==2){
            region_methylation_s=region_methylation[[chr]]
          }
        }
        region_methylation[[chr]]=region_methylation_s
        methylation[[chr]]=methylation_s
      }else{
        Redo=T

        while(Redo){
          Redo=F
          Strange_Ne=F
          Os=list()
          count=0
          M_o=0
          theta_W=0
          theta_M=c()
          theta_D=c()
          theta_O=c()
          theta_reg=c()
          scale_meth=c()
          if(nb_methylation_context==2){
            scale_meth_2=c()
          }
          if(Free|Region_Free>0){
            p_estimated=c()
            ps=c()
            pm=c()
            pm_reg=c()
            if(nb_methylation_context==2){
              p_estimated_2=c()
              ps2=c()
            }
          }
          s_t=Sys.time()
          if(Output_meth_Region){
            meth_reg_save=list()
          }
          for(k in 1:(M-1)){
            for(l in (k+1):M){
              Os_=seqMeth(O[c(k,l,(M+1),(M+2)),],L,position_removed[[chr]],nb_meth=nb_methylation_context,Free=Free,Region=Region,Region_Free=Region_Free,window_min=window_min,nb_site_min=nb_site_min,P_m=P_m,P_d=P_d)
              if(Output_meth_Region){
                meth_reg_save[[(1+length( meth_reg_save))]]=Os_$meth_reg_long_zip
              }
              theta_W=theta_W+as.numeric(Os_$theta)
              scale_meth=c(scale_meth,(length(which(Os_$seq<2))/(L-length(which(Os_$seq==2)))))

              if(Region_Free&as.numeric(Region)%in%c(1,2)){
                theta_reg=c(theta_reg,as.numeric(Os_$theta_reg))
                pm_reg=c(pm_reg,Os_$ratio_reg)
                if(Free){
                  theta_M=c(theta_M,as.numeric(Os_$theta_M))
                  pm=c(pm,Os_$pm)
                  theta_D=c(theta_D,as.numeric(Os_$theta_D))
                  theta_O=c(theta_O,as.numeric(Os_$theta_O))

                }
              }else{

                if(nb_methylation_context==2){
                  scale_meth_2=c(scale_meth_2,(length(which(Os_$seq>5))/(L-length(which(Os_$seq==2)))))
                  scale_meth[length(scale_meth)]=1-(scale_meth[length(scale_meth)]+scale_meth_2[length(scale_meth_2)])

                }
                if(Free){
                  theta_M=c(theta_M,as.numeric(Os_$theta_M))
                  p_estimated=c(p_estimated,Os_$ratio_D_over_M)

                  if(nb_methylation_context==2){
                    p_estimated2=c(p_estimated2,Os_$ratio_O_over_P)
                    ps2=c(ps2,Os_$theta_O)}

                }
              }



              M_o=M_o+1
              if(count==0){
                if(length(Os_$seq)>10^6){
                  if(!LH_opt){
                    Os_temporary=Build_zip_ID_2seq_m(Os_$seq[1:1000000],nb_methylation_context,Region=Region)
                    Mat_symbol=Os_temporary[[2]]
                  }else{
                    Os_temporary=Build_zip_2seq_m(Os_$seq[1:1000000],20)
                    Mat_symbol=Os_temporary[[2]]

                  }

                  #Os_temporary=Build_zip_2seq_m(Os_temporary[[1]])
                  #Super_Mat_symbol=Os_temporary[[2]]
                  rm(Os_temporary)
                  L10=length(Os_$seq)/10^6
                  count=count+1
                  if(!LH_opt){
                    Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }
                  #Os[[count]]=Zip_seq(Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)[[1]],Super_Mat_symbol)
                  #Os[[count]][[3]]=Mat_symbol
                  #Os[[count]][[4]]=length(Os_$seq)


                }else{
                  count=count+1
                  if(!LH_opt){
                    Os_temporary=Build_zip_ID_2seq_m(Os_$seq,nb_methylation_context,Region=Region)
                    Mat_symbol=Os_temporary[[2]]
                    Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                  }else{
                    Os[[count]]=Build_zip_2seq_m(Os_$seq,20)
                    Mat_symbol=Os[[count]][[2]]
                    Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                  }




                  #Os[[count]][[3]]=Mat_symbol
                  #Os[[count]][[4]]=length(Os_$seq)

                }
              }else{
                count=count+1
                if(!LH_opt){
                  Os[[count]]=Zip_seq_m(Os_$seq,Mat_symbol,nb_methylation_context)
                }else{
                  Os[[count]]=Zip_seq(Os_$seq,Mat_symbol)
                }
              }
            }
            rm(Os_)
          }
          e_t=Sys.time()
          print("Time to Zip sequences")
          print(e_t-s_t)
          if(length(Os)>=1){
            for(oo in 1:length(Os)){
              Os[[oo]]=symbol2Num_m(Os[[oo]])
            }
            theta_W=theta_W/M_o



            theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
            Ne=(log((1+((log((1-(theta/(L*0.75))))/2))))/(log(1-(mu_r[chr]*4/3))))



            mu=(-(log((1-(theta/(L*0.75))))/2))


            scale_meth=mean(scale_meth)
            if(nb_methylation_context==2){
              scale_meth_2=mean(scale_meth_2)
            }

            if(as.numeric(Region)>0){

              if(Free&as.numeric(Region)!=2){
                print("estimated equilibrium probability")
                p=1-mean(pm)
                print(p)
                ps=theta_M#1-mean(pm)
                if(any(ps/min(c((1-p),p)))>=10^-2){
                  Strange_Ne=T
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    mu_m=NA
                  }
                }else{
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    Strange_Ne=T
                  }
                }

              }

              if(Region_Free){
                print("estimated region equilibrium probability")
                p=1-mean(pm_reg)
                print(p)
                ps=theta_reg
                #mu_m_reg=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)

                if(any(ps/min(c((1-p),p)))>=10^-2){
                  Strange_Ne=T
                  mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                    mu_m_reg=NA
                  }
                }else{
                  mu_m_reg=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m_reg))))){
                    Strange_Ne=T
                  }
                }


              }
            }else{

              if(Free){
                print("estimated equilibrium probability")
                p=mean(p_estimated)
                print(p)
                ps=mean(theta_M)
                print((ps/min(c((1-p),p))))
                if(any(ps/min(c((1-p),p)))>=10^-2){
                  Strange_Ne=T
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    mu_m=NA
                  }
                }else{
                  #mu_m=c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1)
                  mu_m=c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T)
                  if(any(is.na(as.numeric(as.character(mu_m))))){
                    Strange_Ne=T
                  }
                }
                if(nb_methylation_context==2){
                  print("estimated equilibrium probability in second methylation context")
                  p=mean(p_estimated2)
                  print(p)
                  ps=ps2
                  #mu_m=rbind(mu_m,c(1,(p/(1-p)))*log(sqrt((1-(ps/(2*p*(1-p))))))*(1-p)/(-1))
                  mu_m=rbind(mu_m,c((1-p),p)*mean(log(sqrt((1-(ps/(2*p*(1-p))))))/(-1),na.rm = T))

                  if(any(is.na(as.numeric(as.character(mu_m[2,]))))){
                    print("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")
                    warning("Model cannot explain the epimutation data. Rates might be too high to be inferred or there might be an unaccounted phenomenon. Hence, epimuations will be ignored.")

                    for(rep in 1:length(Os)){
                      pos=as.numeric(which(as.numeric(Os[[rep]][[1]])%in%c(3:9)))
                      if(length(pos)>0){
                        Os[[rep]][[1]][pos]=0
                      }
                    }
                    mu_m[2,]=c(0.002,0,01)
                  }
                }
              }
            }

            if(!Strange_Ne){
              print("mu_m:")
              print(mu_m/Ne)
              methylation[[chr]]=mu_m/Ne
              if(Region>0){
                print("mu_m_reg:")
                print(mu_m_reg/Ne)
                region_methylation[[chr]]=mu_m_reg/Ne
              }

            }
            if(Strange_Ne){
              check_tree=T
              if(Free&all(!is.na(mu_m))){
                print("New upper limit BoxM")
                print(-log10(mu_m/Ne))
                BoxM[2]=min(-log10(mu_m/Ne))
              }
              if(Region_Free&all(!is.na(mu_m_reg))){
                print("New upper limit BoxM_reg")
                print(-log10(mu_m_reg/Ne))
                BoxM_reg[2]=min(-log10(mu_m_reg/Ne))
              }
            }
            if(check_tree){
              test.env <- new.env()
              test.env$Free <- Free
              test.env$Region_Free <- Region_Free
              BW=Short_Baum_Welch(Os,L,mu,theta_W,rho[chr]*theta,beta=beta,k=n,sigma=sigma,NC=NC,mu_b=mu_b,Big_Window=Big_Window,Ne=Ne,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,methylation=methylation,Region=Region,region_methylation=region_methylation)
              test.env$Big_M <- BW$Big_M
              test.env$theta_W <- theta_W
              test.env$mu <- mu
              test.env$mu_b <- mu_b
              test.env$Rho <- rho[chr]*theta
              test.env$L <- L
              test.env$k <- n
              test.env$Beta <- beta
              test.env$Self <- sigma
              test.env$NC <- NC
              test.env$scale_meth <- scale_meth
              test.env$nb_methylation_context <- nb_methylation_context
              test.env$Ne<-Ne
              function_to_minimize<-function(param){
                mu=get('mu', envir=test.env)
                Ne=get('Ne', envir=test.env)
                Big_Window=get('Big_Window', envir=test.env)
                mu_b=get('mu_b', envir=test.env)
                Rho=get('Rho', envir=test.env)
                L=get('L', envir=test.env)
                k=get('k', envir=test.env)
                Beta=get('Beta', envir=test.env)
                Self=get('Self', envir=test.env)
                BoxM_reg=get('BoxM_reg', envir=test.env)
                BoxM=get('BoxM', envir=test.env)
                Free=get('Free', envir=test.env)
                Big_M=get('Big_M', envir=test.env)
                Region_Free=get('Region_Free', envir=test.env)
                scale_meth=get('scale_meth', envir=test.env)
                nb_methylation_context=get('nb_methylation_context', envir=test.env)
                start_position=0
                #print(10^-((param*(BoxM[2]-BoxM[1]))+BoxM[1]))
                if(Free){
                  p=get('p', envir=test.env)
                  start_position=start_position+1
                  methylation=Ne*c((1-p),p)*10^-((param[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])
                }else{
                  methylation=c(NA,NA)
                }

                if(Region_Free){
                  p_reg=get('p_reg', envir=test.env)
                  start_position=start_position+1
                  region_methylation=Ne*c((1-p_reg),p_reg)*10^-((param[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
                }else{
                  region_methylation=c(NA,NA)
                }
                Tc=build_Tc(n=k,Beta=Beta,scale=c(1,0),Sigma=Self,Big_Window=Big_Window)
                g=build_emi_m(mu,mu_b,Tc,Beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region=Region,scale_meth)

                x=as.vector(g)
                keep=which(x>0)
                x=x[keep]
                m=as.vector(Big_M)
                m=m[keep]
                LH=-sum(log(x)*m)
                return( LH)
              }

              if(Free&!Region_Free){
                nb_to_test_1=(BoxM[2]-BoxM[1])*100
              }
              if(!Free&Region_Free){
                nb_to_test_1=(BoxM_reg[2]-BoxM_reg[1])*100
              }
              if(Free&Region_Free){
                nb_to_test_1=(BoxM[2]-BoxM[1])*100
                nb_to_test_2=(BoxM_reg[2]-BoxM_reg[1])*100
              }

              param=c()
              if(Free){
                if(as.numeric(Region)>0){
                  p=1-mean(pm)
                }else{
                  p=mean(p_estimated)
                }
                test.env$p <- p

                oldrate=0.5
                param=c(param,oldrate)
              }
              if(Region_Free){
                p_reg=1-mean(pm_reg)
                test.env$p_reg <- p_reg
                oldrate_reg=0.5
                param=c(param,oldrate_reg)
              }
              if(length(param)>0){

                start=T
                if(length(param)==1){
                  for (value_1 in seq(0,1,(1/nb_to_test_1))){
                    param=c(value_1)
                    R2=function_to_minimize(param)
                    if(start){
                      R2_old=R2
                      sol=param
                      start=F
                    }else{
                      if(R2<=R2_old){
                        R2_old=R2
                        sol=param
                      }
                    }
                  }
                }else{
                  for (value_1 in seq(0,1,(1/nb_to_test_1))){
                    for(value_2 in seq(0,1,(1/nb_to_test_2))){
                      param=c(value_1,value_2)
                      R2=function_to_minimize(param)
                      if(start){
                        R2_old=R2
                        sol=param
                        start=F
                      }else{
                        if(R2<=R2_old){
                          R2_old=R2
                          sol=param
                        }
                      }
                    }
                  }
                }

                start_position=0
                if(Free){
                  p=get('p', envir=test.env)
                  start_position=start_position+1
                  methylation[[chr]]=c((1-p),p)*10^-((sol[start_position]*(BoxM[2]-BoxM[1]))+BoxM[1])

                }

                if(Region_Free){
                  p_reg=get('p_reg', envir=test.env)
                  start_position=start_position+1
                  region_methylation[[chr]]=c((1-p_reg),p_reg)*10^-((sol[start_position]*(BoxM_reg[2]-BoxM_reg[1]))+BoxM_reg[1])
                }


              }
            }
          }else{
            stop("data too poor")
          }


        }
      }

      rm(O)

    }

  }
  results=list()
  results$mu_m=methylation
  if(Region>0){
    results$mu_m_reg=region_methylation#/Ne
  }
  if(Output_meth_Region){
    results$meth_reg=meth_reg_save
  }
  if(Output_coal_time){


    if(Use_estimated_prior){



      results=Baum_Welch_algo_m(Os=Os,L=L,mu=mu,Ne=Ne,theta_W =theta_W,Rho=rho*theta,beta=beta,sigma=sigma,Popfix=F,SB=F,SF=F,k=n,maxBit = 1,ER=F,NC=NC,BW=F,mu_b=mu_b,Big_Window=Big_Window,methylation=methylation,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,LH_opt=F,Region=Region,region_methylation=region_methylation)


      seq_coal=Path_finder_Ts_methy(Os=Os,L=L,mu=mu,theta_W=theta_W,Rho=rho*theta,k=n,NC=NC,methylation=methylation,Region=Region,region_methylation=region_methylation,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,Beta=results$beta,Self=results$sigma,mu_b=mu_b,Xi=results$Xi,Smooth=TRUE)

    }else{
      seq_coal=Path_finder_Ts_methy(Os=Os,L=L,mu=mu,theta_W=theta_W,Rho=rho*theta,k=n,NC=NC,methylation=methylation,Region=Region,region_methylation=region_methylation,scale_meth=scale_meth,nb_methylation_context=nb_methylation_context,Beta=beta,Self=sigma,mu_b=mu_b,Xi=NA,Smooth=TRUE)
    }
    Ts_reg_long_zip=list()
    for(xxx in 1:length(seq_coal[[2]])){
      L=length(seq_coal[[2]][[xxx]])
      transition=which(seq_coal[[2]][[xxx]][1:(L-1)]!=seq_coal[[2]][[xxx]][2:(L)])
      Ts_reg_long_zip_temp=matrix(0,ncol=length(transition),nrow=3)
      Ts_reg_long_zip_temp[1,]=seq_coal[[2]][[xxx]][transition]
      Ts_reg_long_zip_temp[2,]=1+c(0,transition[-length(transition)])
      Ts_reg_long_zip_temp[3,]=c(transition -c(0,transition[-length(transition)]))
      Ts_reg_long_zip[[xxx]]=Ts_reg_long_zip_temp
    }
    results$seq_Ts=Ts_reg_long_zip
    if(Smooth){
    results$seq_Ts_smooth=seq_coal$seq_smooth
    }
    results$Ts=seq_coal[[1]]
    results$Ne = Ne
  }

  return(results)
}
