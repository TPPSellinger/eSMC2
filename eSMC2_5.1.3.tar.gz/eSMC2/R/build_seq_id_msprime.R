#' Build the exact transition matrix from sequence of genealogy
#'
#' @param genealogy : Matrix of sequence of genealogy (output of read_multiple_merger_msprime_data)
#' @param Tc : numerical vector containing the discretization of time
#' @param M_a : number of haplotype used for model
#' @return a matrix of 2 line,first one idicating the coalescent state and the second line the position
build_seq_id_msprime<-function(genealogy,Tc,M_a=3){
  M=M_a
  output=matrix(0,nrow = 2,ncol = dim(genealogy)[2])
  output[2,]=genealogy[3,]
  for(pos in 1:dim(genealogy)[2]){
    id=genealogy[2,pos]
    t_state=max(which(Tc<(genealogy[1,pos])))
    if(t_state==max(which(Tc<(genealogy[4,pos])))){
      id=4
    }
    output[1,pos]=t_state+((length(Tc)*(id-1)))
  }
  return(output)
}
