#' Runs the baum-welch algorithm to estimate theoretical marker rates
#'
#' @param Os : list containing the signal of all analysis
#' @param L : Sequence length
#' @param theta_W : average theta waterson per chromosome
#' @param Rho : vector of estimated recombination rate per sequence
#' @param Ne : Estimated effective population size
#' @param beta : germination rate
#' @param k : number of hidden states
#' @param pop_vect :  vector of hidden states sharing population size parameter (sum must be equal to k).
#' @param window_scaling : vector containing as first value a numeric value to rescale hidden states and as second a numeric value to shift the time windows of hidden states
#' @param sigma : self-fertilization rate
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param mu_marker : list of size equal to the number of theoretical marker, respectively containing the markers rates in generation per position
#' @param Nb_marker : vector of size two which are bounderies of methylation rates. First value gives the -log10 of lower bondery and second value the log10 of upper bondery.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param theta : Average rescaled theta per chromosome
#' @param to_estimate : numerical vector of index of theoretical marker to estimate
#' @param Xi : NA or numerical vector of population size
#' @return List containing of all model parameters and estimations

Short_Baum_Welch_marker_theo<-function(Os,L,theta_W,Rho,Ne,beta=1,k=20,pop_vect=NA,window_scaling=c(1,0),sigma=0.00,NC=1,mu_b=1,Big_Window=F,mu_marker=list(c(10^-8),c(10^-9)),Nb_marker=2,nb_state_marker=list(c(2),c(2)),Marker_supperposition=F,theta,to_estimate=NA,Xi=NA){

  FS=F
  EM=F
  BW=T
  if(all(is.na(Xi))){
    Popfix=T
  }else{
    Popfix=F
  }

  ER=F
  SB=F
  SF=F
  BoxP=c(1,1)
  SCALED=F
  symbol=c()
  if(NC>1){
    for(chr in 1:NC){
      for(i in 1:length(Os[[chr]])){
        symbol=sort(as.numeric(unique(c(symbol,Os[[chr]][[i]][[1]]))))
      }
    }
  }else{
    for(i in 1:length(Os)){
      symbol=sort(as.numeric(unique(c(symbol,Os[[i]][[1]]))))
    }
  }


  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  Ne_o=Ne
  Pop=Popfix
  test.env <- new.env()
  test.env$L <- L
  test.env$Ne <- Ne
  test.env$k <- k
  test.env$mu_marker <- mu_marker
  test.env$Rho <- Rho
  test.env$window_scaling <- window_scaling
  test.env$BW<-BW
  test.env$Pop<-Popfix
  test.env$NC<-NC
  test.env$FS<-FS
  test.env$mu_b <- mu_b
  test.env$Nb_marker <- Nb_marker
  test.env$Big_Window <- Big_Window
  test.env$nb_state_marker <- nb_state_marker
  test.env$Marker_supperposition <- Marker_supperposition
  if(NC>1){
    npair=NC
    test.env$npair <- NC
  }
  if(NC==1){
    npair=length(Os)
    test.env$npair <- npair
  }
  mb=0

  if(any(!is.na(pop_vect))){
    Klink=length(pop_vect)
  }
  if((all(is.na(pop_vect))|sum(pop_vect)!=k)){
    Klink=0.5*k
    pop_vect=rep(2, Klink)
    print("Default pop vector")
  }
  test.env$pop_vect <- pop_vect
  if(!SB&!SF){
    maxBit=1
  }
  if(!SB){
    Beta=beta
    test.env$beta <- beta
    BoxB=c(0,0)
  }
  if(!SF){
    Self=sigma
    oldSelf=Self
    test.env$sigma <- sigma
    Boxs=c(0,0)
  }
  if(!ER){
    Boxr=c(0,0)
  }
  if(!EM){
    BoxM=c(0,0)
  }

  print(paste("Beta:",Beta))
  print(paste("Self:",Self))
  test.env$Beta <- Beta
  test.env$Self <- Self

  mb=mb+1
  diff=1
  it <- 0




  if(!ER){
    oldrho=0


  }

  if(!EM){
    oldM=0
  }


  oldXi_=rep((BoxP[1]/sum(BoxP)),Klink)
  oldXi=vector()
  xx=0
  for(ix in 1:Klink){
    x=xx+1
    xx = xx + pop_vect[ix]
    oldXi[x:xx]=oldXi_[ix]
  }

  Do_BW=T
  diff_conv=vector()
  start_time <- Sys.time()
  it <- it+1;
  print(paste("It:",it))
  if(Popfix){
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho

    print(c("sigma:",sigma,"beta :",beta))
    print(c("rho/theta:",rho_/theta))
    Keep_going=F
    if(it==1){
      diff_o=0
    }
    if(it>1){
      gamma_temp=mean(rho_/theta)
      diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta),abs(gamma_temp_o-gamma_temp))
      count_diff_o=0
      if(diff_o>=0.005){
        if(it==maxIt){
          count_diff_o=count_diff_o+1
          maxIt=maxIt+1
        }
      }
    }
    sigma_o=sigma
    beta_o=beta
    gamma_temp_o=mean(rho_/theta)
    if(NC==1){
      builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
    }
    if(NC>1){
      builder=list()
      for(chr in 1:NC){
        builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi=NA,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
      }
    }
  }
  if(!Popfix){

    Xi_=Xi
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho

    print(c("sigma:",sigma,"beta :",beta))
    print(c("rho/theta:",rho_/theta))
    Keep_going=F
    if(it==1){
      diff_o=0
    }
    if(it>1){
      diff_o=max(abs(sigma_o-sigma),abs(beta_o-beta))
      count_diff_o=0
      if(diff_o>=0.005){
        if(it==maxIt){
          count_diff_o=count_diff_o+1
          maxIt=maxIt+1
        }
      }
    }
    sigma_o=sigma
    beta_o=beta

    if(NC==1){
      builder=build_HMM_matrix(k,(rho_),beta,L=L,Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
    }
    if(NC>1){
      builder=list()
      for(chr in 1:NC){
        builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),beta,L=L[chr],Pop=Pop,Xi_,Beta,scale=window_scaling,sigma =sigma,Sigma = Self,Big_Window=Big_Window,npair=npair)
      }
    }
  }

  if(NC==1){
    Q = builder[[1]]
    nu= builder[[2]]
    Tc=builder[[3]]
    g=build_emi_matrix_marker_theo(mu_marker,Ne,mu_b,builder[[4]],builder[[3]],beta=beta,nb_state_marker=nb_state_marker,Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition)  # (mu,Ne,mu_b,Tc,t,beta,nb_state_marker=list(c(2),c(2),c(2)),Nb_marker,Marker_supperposition)
    M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
    N=matrix(0,length(Tc),length(Tc))
    MLH=0
    q_=rep(0,length(Tc))

    if(Marker_supperposition){
      stop("to do")
      for(cc in bad_pos){
        g[,cc]=g[,2]
      }
    }else{

      if(!is.na(to_estimate)){
      bad_pos=c(to_estimate,(to_estimate+(Nb_marker+1)))

      for(cc in bad_pos){
        g[,cc]=g[,(Nb_marker+1)]
      }
      }
    }
    test=Build_zip_Matrix_mailund_marker_theo(Q,g,Os[[1]][[2]],nu)
    for(i in 1:length(Os)){

      fo=forward_zip_mailund_marker_theo(as.numeric(Os[[i]][[1]]),g,nu,test[[1]])
      MLH=MLH+fo[[3]]
      c=exp(fo[[2]])
      ba=Backward_zip_mailund_marker_theo(as.numeric(Os[[i]][[1]]),test[[3]],length(Tc),c)
      W_P=list()
      W_P_=list()
      for(oo in 1:dim(g)[2]){
        int=t(Q)%*%diag(g[,oo])
        int=eigen(int)
        W_P[[oo]]=int$vectors
        W_P_[[oo]]=solve(W_P[[oo]])
      }


      #print( symbol)
      for(ob in 1){
        truc_M=matrix(0,nrow=length(Tc),ncol=dim(g)[2])
        if(as.numeric(Os[[i]][[1]][(ob+1)])<10){
          truc_N=(fo[[1]][,ob]%*%(t(ba[,(ob+1)]*g[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]/c[(ob+1)])))
          truc_M[,(as.numeric(Os[[i]][[1]][(ob+1)])+1)]=fo[[1]][,ob]*(test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)])+1)]]%*%(ba[,(ob+1)]/c[(ob+1)]))
        }else{
          truc_N=(t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])*test[[4]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))%*%diag(g[,(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]))
          truc_M[,(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]=diag(t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%(t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]])%*%fo[[1]][,ob]%*%t(ba[,(ob+1)]/c[(ob+1)])%*%t(W_P_[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))*test[[2]][[(as.numeric(Os[[i]][[1]][(ob+1)]))]]%*%t(W_P[[(floor(log10((as.numeric(Os[[i]][[1]][(ob+1)])))))]]))
        }
        N=N+truc_N
        M=M+truc_M
      }
      for(sym in sort(as.numeric(symbol))){
        ob=as.numeric(sym)
        pos=which(as.numeric(Os[[i]][[1]][-c(1,length(Os[[i]][[1]]))])==ob)
        if(length(pos)>0){
          pos=pos+1

          if(ob<10){
            ba_t=t(t(ba[,(pos)])/c[(pos)])
            truc=c(rowSums(fo[[1]][,(pos-1)]*(test[[1]][[(ob+1)]]%*%ba_t)))
            truc=(truc/(sum(truc)))*length(pos)
            M[,(ob+1)]=M[,(ob+1)]+ truc
            truc_N=(fo[[1]][,(pos-1)]%*%(t(diag(g[,(ob+1)])%*%ba_t)))
            N=N+truc_N
          }else{
            A=(t(W_P[[(floor(log10(((ob)))))]])%*%fo[[1]][,(pos-1)]%*%t(t(t(ba[,(pos)])/c[(pos)]))%*%t(W_P_[[(floor(log10(((ob)))))]]))
            A_=A*test[[2]][[(ob)]]
            A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
            M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10(((ob)))))]+(diag(A_))
            A_=A*test[[4]][[(ob)]]
            A_=(t(W_P_[[(floor(log10(((ob)))))]])%*%A_%*%t(W_P[[(floor(log10(((ob)))))]]))
            truc_N=((A_%*%diag(g[,(floor(log10(((ob)))))])))
            N=N+truc_N
          }
        }
      }

      if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])<10){
        M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]=M[,(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])+1)]+(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])
      }
      if(as.numeric(Os[[i]][[1]][length(Os[[i]][[1]])])>9){
        M[,(floor(log10((as.numeric((ob))))))]=M[,(floor(log10((as.numeric((ob))))))]+((fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])])/sum(fo[[1]][,length(Os[[i]][[1]])]*ba[,length(Os[[i]][[1]])]))
      }
      q_=q_+((fo[[1]][,1]*ba[,(1)])/sum(fo[[1]][,1]*ba[,(1)]))
    }

    N=N*t(Q)

    if(is.complex(N)){
      N=Re(N)
    }

    if(is.complex(M)){
      M=Re(M)
    }
    results=list()
    print("Initial:N")
    print(sum(N))
    Scale_N=(L-1)/sum(N)
    N=N*Scale_N
    print("Corrected:N")
    print(sum(N))
    q_=q_/sum(q_)
    print("Initial:M")
    print(sum(M))
    results$raw_M=M
    Scale_M=L/sum(M)
    M=M*Scale_M
    print("Corrected:M")
    print(sum(M))
    # browser()



    results$M=M
    results$Tc=Tc
  }






  return(results)
}
