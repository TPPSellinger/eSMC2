#' Estimates coalescent time at each position under the SMC
#'
#' @param Os : list containing the signal of all analysis
#' @param L : Sequence length
#' @param mu : mutation rate
#' @param theta_W : estimated theta waterson
#' @param Rho : estimated recombination rate
#' @param k : number of hidden state
#' @param NC : Number of scaffold
#' @param methylation : vector of size two of methylation and demethylation rate in -log10 scale
#' @param scale_meth : numeric value corresponding to the expected probability to have methylation information at a position
#' @param nb_methylation_context : number of different methylation context
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param region_methylation : vector of size two, respectively containing the absolute values of methylation and demethylation rates at the region level in log10 (i.e. c(abs(log10(methylation_rate))),abs(log10(demethylation_rate))))
#' @param Beta : germination rate
#' @param Self : self-fertilization rate
#' @param mu_b : ratio of muation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param Big_Window : TRUE to use MSMC2 time window (bigger)
#' @param Xi : inferred population size
#' @param Smooth: TRUE to output the expected TMRCA
#' @return list of size 2, first one containing hidden states (i.e. coalescence time) and second one the sequences of expected hidden state along the genome
Path_finder_Ts_methy<-function(Os,L,mu,theta_W,Rho,k=20,NC,methylation,Region,region_methylation=c(NA,NA),scale_meth,nb_methylation_context=1,Beta=1,Self=0,mu_b=1,Big_Window=FALSE,Xi=Xi,Smooth=FALSE){
  beta=Beta
  sigma=Self
  Xi=NA
  print(paste("sequence length :",L,sep=" "))
  if(length(Rho)>1&length(Rho)!=NC){
    stop("Problem in recombination definition")
  }
  old_list=list()
  n <- length(Os[[1]][[1]]);
  Pop=T
  Popfix=T
  theta=mu*2*L
  gamma=Rho/theta
  gamma_o=gamma
  print(gamma)
  test.env <- new.env()
  test.env$L <- L
  test.env$k <- k
  test.env$mu <- mu
  test.env$Rho <- Rho
  test.env$NC<-NC
  oldrho=0
  Boxr=c(0,0)
  s_t=Sys.time()
  if(length(unique(round(gamma,digits=3)))>1){
    oldrho=rep(0,NC)
  }
  print(length(oldrho))
  start_time <- Sys.time()
  if(Popfix){
    rho_=oldrho*sum(Boxr)
    rho_=rho_-(Boxr[1])
    rho_=10^(rho_)
    rho_=rho_*Rho
    print(c("rho/theta:",rho_/theta))
    if(NC==1){
      builder=build_HMM_matrix(k,(rho_),L=L,Pop=T,scale=c(1,0),Beta=Beta,Sigma=Self,Big_Window=Big_Window,Xi=Xi)
    }
    if(NC>1){
      builder=list()
      for(chr in 1:NC){
        builder[[chr]]=build_HMM_matrix(k,(rho_[chr]),L=L[chr],Pop=T,scale=c(1,0),Beta=Beta,Sigma=Self,Big_Window=Big_Window,Xi=Xi)
      }
    }
  }
  if(NC==1){
    Q = builder[[1]]
    nu= builder[[2]]
    Tc=builder[[3]]
    g=build_emi_m(mu,mu_b,Tc,beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)

    #print(Os[[1]][[2]])


    test=Build_zip_Matrix_mailund_m(Q,g,Os[[1]][[2]],nu)
    e_t=Sys.time()
    print("time to build path mat")
    print(e_t-s_t)
    Seq_out=list()
    seq_smooth = list()
    for(i in 1:length(Os)){
      Seq_int=numeric(L)
      s_t <- Sys.time()
      fo=forward_cpp_m(as.numeric(Os[[i]][[1]]),g,nu,test[[6]])
      e_t=Sys.time()
      print("time fo")
      print(e_t-s_t)
      s_t <- Sys.time()
      c=exp(fo[[2]])
      #s_t_temp=Sys.time()
      ba=Backward_zip_mailund_m(as.numeric(Os[[i]][[1]]),test[[3]],length(Tc),c)
      e_t=Sys.time()
      print("time ba")
      print(e_t-s_t)
      s_t <- Sys.time()
      W=list()
      int=t(Q)%*%diag(g[,1])
      int=eigen(int)
      W$P=int$vectors
      W$P_=MASS::ginv(W$P)
      symbol= Os[[i]][[3]][,1]
      count_seq=1
      SAVE=F
      for(ob in 1:length(Os[[i]][[1]])){
        truc_t=(fo[[1]][,ob]*ba[,ob])/c[ob]
        truc_t=truc_t/sum(truc_t)
        Seq_int[count_seq]=sum(truc_t*Tc)

        if(SAVE){
          Seq_int[(count_seq-l):(-1+count_seq)]=Seq_int[count_seq]
        }
        count_seq=count_seq+1
        SAVE=F

        if(T){
          if(as.numeric(Os[[i]][[1]][(ob+1)])>9&ob<length(Os[[i]][[1]])){
            l=as.numeric(Os[[i]][[3]][(as.numeric(Os[[i]][[1]][(ob+1)])),2])
            SAVE=T
            count_seq=count_seq-1+l
          }
        }
      }
      e_t=Sys.time()
      print("finding hidden state")
      print(e_t-s_t)
      s_t <- Sys.time()
      print(length(Seq_int))
      print(count_seq)
      r_Seq_int=numeric(L)
      r_Tc=builder[[4]]
      for(iii in 2:k){
        pos=which(Seq_int<=r_Tc[iii]&Seq_int>r_Tc[(iii-1)])
        r_Seq_int[pos]=(iii-1)
      }
      pos=which(Seq_int>r_Tc[k])
      r_Seq_int[pos]=k
      pos_1=which(r_Seq_int==0)
      e_t=Sys.time()
      print("building output sequence")
      print(e_t-s_t)
      s_t <- Sys.time()
      #print("length pos 1")
      #print(length(pos_1))
      if(length(pos_1)>0){
        for(iii in 1:length(pos_1)){
          if(iii==1){
            r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[1:(pos_1[iii]-1)]>0))]
          }
          if(iii>1){
            r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[pos_1[(iii-1)]:(pos_1[iii]-1)]>0))]
          }
        }
      }
      Seq_out[[i]]=r_Seq_int
      if(Smooth){
        seq_smooth[[i]]=Seq_int
      }
      e_t=Sys.time()
      print(e_t-s_t)
    }
    res=list()
    res$Tc=Tc
    res$seq=Seq_out
    if(Smooth){
      res$seq_smooth=seq_smooth
    }
    return(res)
  }
  if(NC>1){
    Q=list()
    nu=list()
    Tc=list()
    g=list()
    M=list()
    N=list()
    MLH=list()
    q_=list()
    Seq_out=list()
    seq_smooth=list()
    for(chr in 1:NC){
      Q[[chr]] = builder[[chr]][[1]]
      nu[[chr]]= builder[[chr]][[2]]
      Tc[[chr]]=builder[[chr]][[3]]
      g[[chr]]=build_emi_m(mu,mu_b,Tc[[chr]],beta,nb_methylation_context,mu_m=methylation,mu_m_reg=region_methylation,Region,scale_meth)
      test=Build_zip_Matrix_mailund_m(Q[[chr]],g[[chr]],Os[[chr]][[1]][[2]],nu[[chr]])
      Seq_out_chr=list()
      seq_smooth_chr=list()
      for(i in 1:length(Os[[chr]])){
        Seq_int=numeric(L[chr])
        s_t <- Sys.time()
        fo=forward_cpp_m(as.numeric(Os[[i]][[1]]),g,nu,test[[6]])
        e_t=Sys.time()
        print("time fo")
        print(e_t-s_t)
        c=exp(fo[[2]])
        s_t <- Sys.time()
        ba=Backward_zip_mailund_m(Os[[chr]][[i]][[1]],test[[3]],length(Tc[[chr]]),c)
        e_t=Sys.time()
        print("time ba")
        print(e_t-s_t)
        s_t <- Sys.time()
        W=list()
        int=t(Q[[chr]])%*%diag(g[[chr]][,1])
        int=eigen(int)
        W$P=int$vectors
        W$P_=MASS::ginv(W$P)
        symbol= Os[[chr]][[i]][[3]][,1]
        count_seq=1
        SAVE=F
        for(ob in 1:length(Os[[chr]][[i]][[1]])){
          truc_t=(fo[[1]][,ob]*ba[,ob])/c[ob]
          truc_t=truc_t/sum(truc_t)
          Seq_int[count_seq]=sum(truc_t*Tc[[chr]])

          if(SAVE){
            Seq_int[(count_seq-l):(-1+count_seq)]=Seq_int[count_seq]
          }
          count_seq=count_seq+1
          SAVE=F

          if(T){
            if(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])>9&ob<length(Os[[chr]][[i]][[1]])){
              l=as.numeric(Os[[chr]][[i]][[3]][(as.numeric(Os[[chr]][[i]][[1]][(ob+1)])+1),2])
              SAVE=T
              count_seq=count_seq-1+l
            }
          }
        }
        e_t=Sys.time()
        print("finding hidden state")
        print(e_t-s_t)
        s_t <- Sys.time()
        #print(length(Seq_int))
        r_Seq_int=numeric(L[chr])
        r_Tc=builder[[chr]][[4]]
        for(iii in 2:k){
          pos=which(Seq_int<=r_Tc[iii]&Seq_int>r_Tc[(iii-1)])
          r_Seq_int[pos]=(iii-1)
        }
        pos=which(Seq_int>r_Tc[k])
        r_Seq_int[pos]=k
        pos_1=which(r_Seq_int==0)
        e_t=Sys.time()
        print("building output sequence")
        print(e_t-s_t)
        s_t <- Sys.time()
        #print("length pos 1")
        #print(length(pos_1))
        if(length(pos_1)>0){
          for(iii in 1:length(pos_1)){
            if(iii==1){
              r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[1:(pos_1[iii]-1)]>0))]
            }
            if(iii>1){
              r_Seq_int[pos_1[iii]]=r_Seq_int[max(which(r_Seq_int[pos_1[(iii-1)]:(pos_1[iii]-1)]>0))]
            }
          }
        }
        Seq_out_chr[[i]]=r_Seq_int
        if(Smooth){
          seq_smooth_chr[[i]]=Seq_int
        }
        e_t=Sys.time()
        print(e_t-s_t)
      }
      Seq_out[[chr]]=Seq_out_chr
      if(Smooth){
        seq_smooth[[chr]]=seq_smooth_chr
      }
    }
    res=list()
    res$Tc=Tc
    res$seq=Seq_out
    if(Smooth){
      res$seq_smooth=seq_smooth
    }
    return(res)
  }
}
