#' build baum-welch matrices from simulated genealogy
#'
#' @param file : path to the simulated data
#' @param gamma : initial ration of recombination over mutation
#' @param theta : theta used for simulation (i.e theta=1000 if command line is scrm :  -t 1000 ) or mutation rate per generation per bp if simulator is msprime
#' @param L : length of simulated sequence
#' @param n : Number of hidden states
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param NC : Number of scaffold
#' @param build_M : TRUE or FALSE to build emission matrix
#' @param simulator : "msprime" or "scrm" or NA if N is given
#' @param M : sample size of data
#' @param decimal_separator : character use asdecimal separator , "\\." or ","
#' @export
#' @return A list of size 3 containing all 3 matrices build from genealogy (emission M , transition N  and initial q_)
get_Mat<-function(file,gamma,theta=NA,L,n=40,window_scaling=c(1,0),sigma=0,beta=1,Big_Window=F,NC=1,build_M=F,simulator,M,decimal_separator="\\."){
  output=list()
  FS=F
  npair=2
  M_a=2
  Correct_window=T
  mut=T
  BW=build_M
  scale_T=1
  if(simulator=='msprime'){
    mu_real=theta
  }
  if(NC==1){

    if(simulator=="scrm"){
      mu=theta
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M-1))))*L)
      scale_T=mu_/mu
      Ne=NA
    }else{
      theta=get_theta(file)
      mu_=theta/((2*sum(1/(1:(M-1))))*L)
      theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
      Ne=mu_/(mu)
    }
    mu=mu_

    #b=get_first_coal_time(file,mut)

    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5
    if(simulator=="scrm"){
      b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne,decimal_separator=decimal_separator)
    }
    if(simulator=="msprime"){
      b=get_genealogy(file,M,mut=mut,simulator,Ne=Ne,decimal_separator=decimal_separator)
    }

    Rho=gamma*2*L*mu
    Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/(extra_l*(beta^2)*window_scaling[1]))
    Tc=Tc*scale_T


    if(M_a<M){
      print("extracting sub genealogies then building N")
      if(M_a==3){
        count_ind=0
        for(i in 1:(M-1)){
          possible_ind=i:M
          if(i>1){
            if(i<(M-1)){
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }else{
              b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
            }
          }else{
            b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
          }
          for(j in (i+1):(M-1)){
            count_ind=count_ind+1
            ind=c(i,j)
            if(length(ind)<length(possible_ind)){
              b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
            }else{
              b_a=b_a_temp1
            }
            if(count_ind==1){
              N=build_N(b_a,Tc)
            }else{
              N=N+build_N(b_a,Tc)
            }
          }
        }
      }

    }else{
      print("building N")
      N=build_N(b,Tc)
    }

    if(BW){
      a=Get_sim_data(file,L,2,1)
      res=build_M(a[[1]],b,Tc)
      print("M is built")
      M=res$M
      print(sum(M))
      q_=res$q
    }
  }else{

    if(length(mu)==1){
      theta=rep(theta,NC)
    }
    if(length(L)==1){
      L=rep(L,NC)
    }


    if(simulator=="scrm"){
      mu=theta
      mu_=c()
      for(chr in 1:NC){
        theta=get_theta(file[chr])
        mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
      }
      scale_T=mean(mu_/mu)
      Ne=NA
    }else{
      mu_=c()
      for(chr in 1:NC){
        theta=get_theta(file[chr])
        mu_=c(mu_,theta/((2*sum(1/(1:(M-1))))*L[chr]))
      }
      theta=mu_*((2*sum(1/(1:(M_a-1))))*L)
      Ne=mean(mu_/(mu))
    }
    mu=mu_

    #b=get_first_coal_time(file,mut)

    Vect=0:(n-1)
    extra_l=M_a*(M_a-1)*0.5

    Rho=gamma*2*L*mu
    Tc= window_scaling[2] -(0.5*(2-sigma)*log(1-(Vect/n))/(extra_l*(beta^2)*window_scaling[1]))
    Tc=Tc*scale_T
    N_total=list()
    M_total=list()
    for(chr in 1:NC){

      b=get_genealogy(file[chr],M,mut=mut,simulator,Ne=Ne,decimal_separator=decimal_separator)

      if(M_a<M){
        print("extracting sub genealogies then building N")
        if(M_a==3){
          count_ind=0
          for(i in 1:(M-1)){
            possible_ind=i:M
            if(i>1){
              if(i<(M-1)){
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
              }else{
                b_a_temp1=get_sub_genealogy(b,ind=c(possible_ind),update_index=T)
              }
            }else{
              b_a_temp1=b#get_sub_genealogy(b,ind=c(possible_ind),update_index=F)
            }
            for(j in (i+1):(M-1)){
              count_ind=count_ind+1
              ind=c(i,j)
              if(length(ind)<length(possible_ind)){
                b_a=get_sub_genealogy(b_a_temp1,ind,update_index=T)
              }else{
                b_a=b_a_temp1
              }
              if(count_ind==1){
                N=build_N(b_a,Tc)
              }else{
                N=N+build_N(b_a,Tc)
              }
            }
          }
        }

      }else{
        print("building N")
        N=build_N(b,Tc)
      }

      if(BW){
        a=Get_sim_data(file,L,2,1)
        res=build_M(a[[1]],b,Tc)
        print("M is built")
        M=res$M
        print(sum(M))
        q_=res$q
        M_total[[chr]]=M
      }

      N_total[[chr]]=N
    }
    N=N_total
    M=M_total
  }
  print("N is built")

  output$N=N
  if(build_M){
  output$M=M
  output$q=q_
  }else{
    output$M=0
    output$q=0
  }
  return(output)

}

