#' find index of a multiple mergercoalescent event
#'
#' @param id : index of coalescent event
#' @param new_id : index of an individual joining a coalescent event
#' @return numerical value giving coalescent event index for hidden state definition
find_index_SMBC<-function(id,new_id){
  index_2<-function(i){if(i==1){return(c(1,2))};if(i==2){return(c(1,3))};if(i==3){return(c(1,4))};if(i==4){return(c(2,3))};if(i==5){return(c(2,4))};if(i==6){return(c(3,4))}}
  ind=c(index_2(id),new_id)
  if(paste(sort(ind),collapse ="")=="123"){
    id=7
  }
  if(paste(sort(ind),collapse ="")=="124"){
    id=8
  }
  if(paste(sort(ind),collapse ="")=="134"){
    id=9
  }
  if(paste(sort(ind),collapse ="")=="234"){
    id=10
  }
  return(id)
}
