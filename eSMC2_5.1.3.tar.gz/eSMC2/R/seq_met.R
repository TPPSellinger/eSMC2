#' Build signal to estimate region level methylation state
#'
#' @param DNA : matrix of segregating sites for the whole sample with the methylation information
#' @param n : sequence length
#' @param position_removed : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @return : sequence of 0 and 1 (1 mutation, 0 no mutation)
seq_met<-function(DNA,n,position_removed=NA){
  output=list()
  DNA=as.matrix(DNA)
  pos_1_M=which(DNA[1,]=="M")
  pos_1_D=which(DNA[1,]=="D")
  pos_2_M=which(DNA[2,]=="M")
  pos_2_D=which(DNA[2,]=="D")

  pos_1_other=which(DNA[1,]%in%c("C","A","T","G"))
  pos_2_other=which(DNA[2,]%in%c("C","A","T","G"))

  if(all(!is.na(position_removed))){
    position_to_be_removed=numeric()
    for(ii in 1:length(position_removed)){
      position_to_be_removed=c( position_to_be_removed,c(position_removed[[ii]][1]:position_removed[[ii]][2]))
    }
    position_removed=position_to_be_removed
    rm(position_to_be_removed)
  }

    seq=rep(0,n)

    pos_M=which(pos_1_M%in%pos_2_M)
    seq[as.numeric(DNA[4,pos_1_M[pos_M]])]=1
    pos_D=which(pos_1_D%in%pos_2_D)
    seq[as.numeric(DNA[4,pos_1_D[pos_D]])]=2
    rm(pos_M)
    rm(pos_D)
    pos_MD=which(pos_1_D%in%pos_2_M)
    pos_DM=which(pos_1_M%in%pos_2_D)

    if(length(pos_MD)>0){
      seq[as.numeric(DNA[4,pos_1_D[pos_MD]])]=3
    }
    if(length(pos_DM)>0){
      seq[as.numeric(DNA[4,pos_1_M[pos_DM]])]=4
    }
    rm(pos_DM)
    rm(pos_MD)
    pos_DO=which(pos_1_D%in%pos_2_other)
    pos_MO=which(pos_1_M%in%pos_2_other)

    if(length(pos_DO)>0){
      seq[as.numeric(DNA[4,pos_1_D[pos_DO]])]=5
    }
    if(length(pos_MO)>0){
      seq[as.numeric(DNA[4,pos_1_M[pos_MO]])]=6
    }

    rm(pos_DO)
    rm(pos_MO)
    pos_OD=which(pos_1_other%in%pos_2_D)
    pos_OM=which(pos_1_other%in%pos_2_M)

    if(length(pos_OD)>0){
      seq[as.numeric(DNA[4,pos_1_other[pos_OD]])]=7
    }
    if(length(pos_OM)>0){
      seq[as.numeric(DNA[4,pos_1_other[pos_OM]])]=8
    }

    rm(pos_OD)
    rm(pos_OM)





  if(all(!is.na(position_removed))){
    seq[c(position_removed)]=0
    rm(position_removed)
  }





  return(seq)
}
