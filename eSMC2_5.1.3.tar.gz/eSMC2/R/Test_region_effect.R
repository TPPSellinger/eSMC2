#' Test for region effect of methylation
#'
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param alpha : probability to build alpha interval
#' @export
#' @return A list containing number of methylated sites, number of unmethylated sites, number of sites with methylation states similar to the previous one,  number of sites with methylation states different to the previous one, expected probability of similar methylation states under a bionimal, observed probability of similar methylation states, Boolean indicating if there is significant region effect.
Test_region_effect<-function(O,alpha=0.05){
  #alpha=(1-alpha)/2
  nb_M=c()
  nb_D=c()
  nb_same=c()
  nb_diff=c()
  M=dim(O)[1]-2
  output=list()
  for(k in 1:M){
    good_pos=which(O[k,]%in%c("M","D"))
    O_temp=O[k,good_pos]
    nb_M=c(nb_M,length(which(O_temp=="M")))
    nb_D=c(nb_D,length(which(O_temp=="D")))

    nb_same=c(nb_same,length(which(O_temp[-length(O_temp)]==O_temp[-1])))
    nb_diff=c(nb_diff,length(which(O_temp[-length(O_temp)]!=O_temp[-1])))

    nb_MM=length(which(which(O_temp[-length(O_temp)]==O_temp[-1])%in%which(O_temp=="M")))
    nb_DD=length(which(which(O_temp[-length(O_temp)]==O_temp[-1])%in%which(O_temp=="D")))
  }
  p=sum(nb_D)/(sum(nb_D)+sum(nb_M))
  q=1-p
  p_same=(p*p)+(q*q)

  if((p_same*(sum(nb_same)+sum(nb_diff)))>10 & ((1-p_same)*(sum(nb_same)+sum(nb_diff)))>10){
    mu=p_same
    sigma=sqrt(p_same*(1-p_same))
    z_a=stats::qnorm((1-(alpha/2)))



    p_same_observed=sum(nb_same)/(sum(nb_same)+sum(nb_diff))

    if((abs(p_same_observed-mu)/(sigma/sqrt((sum(nb_same)+sum(nb_diff)))))>z_a ){
      region_effect=T
    }else{
      region_effect=F
    }


    output$nb_M=nb_M
    output$nb_D=nb_D
    output$nb_same=nb_same
    output$nb_diff=nb_diff
    output$p_same=p_same
    output$p_same_observed=p_same_observed
    output$region_effect=region_effect
    output$p_value=2*(1-(stats::pnorm(abs((p_same_observed-mu)/(sigma/sqrt((sum(nb_same)+sum(nb_diff))))))))


  }else{
    print("Not enough data for test.")
    output$nb_M=nb_M
    output$nb_D=nb_D
    output$nb_same=nb_same
    output$nb_diff=nb_diff
    output$p_same=p_same
    region_effect=NULL
    p_same_observed=sum(nb_same)/c(sum(nb_same)+sum(nb_diff))
    output$p_same_observed=p_same_observed
    output$region_effect=region_effect

  }
  output$nb_MM=nb_MM
  output$nb_DD=nb_DD
      return(output)
}
