#' Estimates methylation state of regions along the genome
#'
#' @param transition_rate : rate at which hidden state can change (i.e. changing state probability)
#' @param O : Segregating site matrix of methylation data (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param window_min : minimum sequence length of a methylated regions
#' @param nb_site_min : list containingvectors of size 2 indicating begining and end positions to remove from the sequence.
#' @param find_rate : True to find best transition rate
#' @param P_m : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in methylated regions
#' @param P_d : Numeric vector probability of size 2 indicating the proportion of methylated and unmethylated sites in unmethylated regions
#' @export
#' @return numeric vector or list of numeric vector (for each scafolds or chromosome) containing the sequence of expected hidden state along the genome. The hidden states are : 1 (regions with no methylation information), 2 (no methylation information in individual 1 & mainly methylated region in individual 2) , 3 (no methylation information in individual 1 & mainly unmethylated region in individual 2) , 4 (no methylation information in individual 2 & mainly methylated region in individual 1) , 5 ( mainly methylated region in individual 1 & mainly methylated region in individual 2) , 6 ( mainly methylated region in individual 1 & mainly unmethylated region in individual 2) , 7 ( mainly unmethylated region in individual 1 & no methylation information in individual 2) , 8 ( mainly unmethylated region in individual 1 & mainly methylated region in individual 2) , 9 ( mainly unmethylated region in individual 1 & mainly unmethylated region in individual 2)
Seq_Methy<-function(transition_rate=10^-3,O,NC=1,window_min=100,nb_site_min=4,find_rate=T,P_m=c(0.8,0.2),P_d=c(0.2,0.8)){
  DNA=O
  NC=1
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[(M+2),dim(O)[2]])
    Os=list()
    count=0
    s=dim(O)[1]
      for(k in 1:(M-1)){
        for(l in (k+1):M){
            Os_=as.numeric(seq_met(O[c(k,l,(s-1),s),],L))
            count=count+1
            #print(count)
            if(count==1){
              Os[[count]]=Build_zip_ID_2seq(Os_)
              Mat_symbol=Os[[count]][[2]]
            }
            if(count>1){
              Os[[count]]=Zip_seq(Os_,Mat_symbol)
            }
            Os[[count]]=symbol2Num(Os[[count]][[1]],Os[[count]][[2]])
        }
      }
    if(length(Os)==0){
      stop("data too poor")
    }

  }
  if(length(Os)>=1){

    if(find_rate){
      nb_reg_f=0
      diff=1
      good_transition_rate=10^-1
      results=Path_finder_methy(Os=Os,L=L,transition_rate=0.1,NC=NC,P_m=P_m,P_d=P_d)
      nb_reg_s=get_nb_reg(results,window_min=window_min,nb_site_min=nb_site_min,NC=NC,DNA=DNA)
      #nb_reg_f=nb_reg_s
      for(transition_rate in seq(2,10,1)){
        s_t=Sys.time()
        if(transition_rate>2){
          nb_reg_s=nb_reg
        }
        #browser()
        #Os_t=list(Os[[1]][[1]][1:min(10^6,length(Os[[1]][[1]]))],Os[[1]][[2]],Os[[1]][[3]])
        results=Path_finder_methy(Os=list(list(Os[[1]][[1]][1:min(10^5,length(Os[[1]][[1]]))],Os[[1]][[2]],Os[[1]][[3]])),L=L,transition_rate=10^-(transition_rate),NC=NC,P_m=P_m,P_d=P_d)
        #results=Path_finder_methy(Os=Os,L=L,transition_rate=10^-(transition_rate),NC=NC,P_m=P_m,P_d=P_d)
        e_t=Sys.time()
        #print("Time to build path to search rate:")
        #print(e_t-s_t)
        s_t=Sys.time()
        nb_reg=get_nb_reg(results,window_min=window_min,nb_site_min=nb_site_min,NC=NC,DNA=DNA)
        e_t=Sys.time()
        print("nb_reg:")
        print(nb_reg)
        #print("Time to get nb region:")
        #print(e_t-s_t)
        diff=abs(nb_reg-nb_reg_s)/nb_reg_s
        if(nb_reg>=nb_reg_f){ #  # diff<0.05
          good_transition_rate=10^-(transition_rate)
          save_results= Path_finder_methy(Os=Os,L=L,transition_rate=10^-(transition_rate),NC=NC,P_m=P_m,P_d=P_d)
          nb_reg_f=nb_reg
          save_results$good_transition_rate=good_transition_rate
          #break
        }
      }
      #print("nb region final:")
      #print(nb_reg_f)
      print("Good transition rate:")
      print(good_transition_rate)
    }else{
      if(is.null(transition_rate)){
        browser()
      }
        s_t=Sys.time()
        save_results=Path_finder_methy(Os=Os,L=L,transition_rate=transition_rate,NC=NC,P_m=P_m,P_d=P_d)
        e_t=Sys.time()
       # print("Time to build path to search rate:")
        #print(e_t-s_t)
        save_results$good_transition_rate=transition_rate
      }



  }

  return(save_results)


}
