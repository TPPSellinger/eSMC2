#' Backward alagorithm
#'
#'Runs the Backward alagorithm on a zipped sequences
#' @param y : zip signal
#' @param TO : matrix for the zip signal
#' @param n : number of  hidden states
#' @param c : vector of rescaling outputed by the forward algorihtm
#' @return Matrix result from the Backward algorithm.
Backward_zip_mailund_marker_theo<-function(y,TO,n,c){
  dims <- n;
  n<- length(y);
  beta <- matrix(1, nrow=dims[1], ncol=n);
  for (t in seq((n-1), 1, -1)){
    beta[,t] = (TO[[(1+as.numeric(y[(t+1)]))]] %*% beta[, (t+1)] )/ c[t+1];
  }
  return(beta);

}
