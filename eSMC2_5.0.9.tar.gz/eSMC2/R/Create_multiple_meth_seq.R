#' Simulate sequences with site epimutations markers
#'
#' @param genealogy : matrix of genealogy (output of get_genealogy)
#' @param mu : numeric value corresponding to real mutation rate (for scaling purposes)
#' @param Ne : numeric value of the population size to use to scale genealogy
#' @param Gbm_rates : numeric vector of size two containing the methylation and demethylation rates in gene body methylation regions
#' @param Gbu_rates : numeric vector of size two containing the methylation and demethylation rates in gene body unmethylation regions
#' @param Gbm_pos : list of vector of size two containing the position on the sequence of the gene body methylation regions
#' @param Gbu_pos : list of vector of size two containing the position on the sequence of the gene body unmethylation regions
#' @param symbol : vector of length of methylation context containing character string of nucleotide on which to methylate the cytosine
#' @param c_pos : numeric vector of length of methylation context indicating on which mucleotide to put the methylation
#' @export
Create_multiple_meth_seq<-function(genealogy,mu=10^-8,Ne=10^4,Gbm_rates=c(10^-5,5*10^-5),Gbu_rates=c(10^-5,5*10^-5),Gbm_pos=NA,Gbu_pos=NA,symbol=c("CG"),c_pos=c(1)){

  M=dim(genealogy$Coal_time)[1]
  if(M==2){
    genealogy$id_split=rbind(genealogy$id_split,genealogy$id_split)
    genealogy$id_create=rbind(genealogy$id_create,genealogy$id_create)
  }
  L=sum(genealogy$Coal_time[M,])
  Output=matrix(0,ncol=L,nrow=(M+1))
  count_L=0
  print(mu)
  print("creating sequence")
  nucl_vect=1:4
  for(i in 1:dim(genealogy$Coal_time)[2]){
    L_seg=genealogy$Coal_time[M,i]
    Mat_seq=matrix(0,M,L_seg)
    Mat_seq[as.numeric(genealogy$id_split[1,i]),]=ceiling(stats::runif(L_seg,0,4))
    for(j in 1:(dim(genealogy$Coal_time)[1]-1)){
      Mat_seq[genealogy$id_create[j,i],]=Mat_seq[as.numeric(genealogy$id_split[j,i]),]
      if(j==(M-1)){
        q=1-exp(-mu*genealogy$Coal_time[j,i]*Ne*4/3)
      }else{
        q=1-exp(-mu*(genealogy$Coal_time[j,i]-genealogy$Coal_time[(j+1),i])*Ne*4/3)
      }
      for(seg_id in which(Mat_seq[,1]!=0)){
        nb_mu=stats::rbinom(n=L_seg ,size = 1 ,prob = q)
        pos=which(nb_mu==1)
        if(length(pos)>0){
          Mat_seq[seg_id,pos]=ceiling(stats::runif(length(pos),0,4))

        }
      }
    }
    Mat_seq=rbind(Mat_seq,c(1:L_seg))
    Mat_seq[(M+1),]=Mat_seq[(M+1),]+count_L
    Output[,(count_L+1):(count_L+L_seg)]=Mat_seq
    count_L=count_L+L_seg
  }
  Output=Output[,-1]
  if(all(!is.na(Gbm_pos))|all(!is.na(Gbu_pos))){
    if(all(!is.na(Gbm_pos))){
      Meth_pos=Gbm_pos
      mu_m=Gbm_rates
      print("adding methylation in gbm")
      real_symbol=c()
      for(i in 1:nchar(symbol)){
        real_symbol=c(real_symbol,substr(symbol,i,i))
      }
      for(nucl in c("A","T","G","C")){
        if(any(nucl%in%real_symbol)){
          real_symbol[which(real_symbol==nucl)]=which(c("A","T","G","C")==nucl)
        }
      }
      num_symbol=paste(as.numeric(real_symbol),collapse = "")
      pos_m=list()
      for(m in 1:M){
        pos_m[[m]]=as.numeric(gregexpr(as.character(num_symbol),paste(as.character(Output[m,]),collapse = ""))[[1]])
      }

      if(all(!is.na(Meth_pos))){
        v_pos=c()
        for(pp in 1:length(Meth_pos) ){
          v_pos=c(v_pos,Meth_pos[[pp]][1]:Meth_pos[[pp]][2])
        }
        for(m in 1:M){
          pos_m[[m]]=pos_m[[m]][(pos_m[[m]])%in%v_pos]+(c_pos-1)
          Output[m,pos_m[[m]]]=6
        }
      }


      count_L=0
      p=(mu_m[2]/(sum(mu_m))) # Equilibrium probability to be unmethylated
      print(p)
      for(i in 1:dim(genealogy$Coal_time)[2]){
        L_seg=genealogy$Coal_time[M,i]
        Pos_meth= sort(as.numeric(as.vector(unique(c( pos_m[[as.numeric(genealogy$id_split[1,i])]][which((pos_m[[as.numeric(genealogy$id_split[1,i])]][1:min(c(length(pos_m[[as.numeric(genealogy$id_split[1,i])]]),(L_seg)))]<=(count_L+L_seg)))])))))
        #print(length(Pos_meth))
        if(length(Pos_meth)>0){
          ancestral_meth_position=stats::rbinom(length(Pos_meth),1,p)
          Output[as.numeric(genealogy$id_split[1,i]),Pos_meth[which(ancestral_meth_position==0)]]=5
        }else{
          #browser()
        }

        vect_to_put_methylation=c(as.numeric(genealogy$id_split[1,i]))
        if(M>2){
          p_m1=c((p+((1-p)*exp(-sum(mu_m)*(genealogy$Coal_time[1:(M-2),i]-genealogy$Coal_time[2:(M-1),i])*Ne))),(p+((1-p)*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay unmethylated
          p_m2=c(((1-p)+(p*exp(-sum(mu_m)*(genealogy$Coal_time[1:(M-2),i]-genealogy$Coal_time[2:(M-1),i])*Ne))),((1-p)+(p*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay methylated
        }else{
          p_m1=c((p+((1-p)*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay unmethylated
          p_m2=c(((1-p)+(p*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay methylated
        }

        for(j in 1:(M-1)){
          Pos_meth= sort(as.numeric(as.vector(unique(c( pos_m[[as.numeric(genealogy$id_split[j,i])]][which((pos_m[[as.numeric(genealogy$id_split[j,i])]][1:min(c(length(pos_m[[as.numeric(genealogy$id_split[j,i])]]),(L_seg)))]<=(count_L+L_seg)))])))))

          vect_to_put_methylation=c(vect_to_put_methylation,genealogy$id_create[j,i])
          possible_pos=sort(as.numeric(as.vector(unique(pos_m[[genealogy$id_create[j,i]]][which((pos_m[[genealogy$id_create[j,i]]][1:min(c(length(pos_m[[genealogy$id_create[j,i]]]),(L_seg)))]<=(count_L+L_seg)))]))))

          if(length(possible_pos)>0){
            herited_meth_pos=possible_pos[which(possible_pos%in%Pos_meth)]
            if(length(herited_meth_pos)>0){
              Output[genealogy$id_create[j,i],herited_meth_pos]= Output[as.numeric(genealogy$id_split[j,i]),Pos_meth[which(Pos_meth%in%herited_meth_pos)]]
            }
            new_meth_pos=possible_pos[which(!(possible_pos%in%Pos_meth))]
            if(length(new_meth_pos)>0){
              ancestral_meth_position=stats::rbinom(length(new_meth_pos),1,p)
              Output[genealogy$id_create[j,i],new_meth_pos[which(ancestral_meth_position==0)]]=5
            }

          }
          for(m in vect_to_put_methylation){
            possible_pos=sort(as.numeric(as.vector(unique(pos_m[[m]][which(pos_m[[m]][1:min(c(length(pos_m[[m]]),(L_seg)))]<=(count_L+L_seg))]))))

            if(length(possible_pos)>0){
              possible_pos_M=possible_pos[which(Output[m,possible_pos]==5)]
              possible_pos_U=possible_pos[which(Output[m,possible_pos]==6)]
              #browser()
              if(any(sort(possible_pos)!=sort(unique(c(possible_pos_M,possible_pos_U))))){
                browser()
              }
              if(length(possible_pos_M)>0){
                new_unmeth_position=which(stats::rbinom(length(possible_pos_M),1,p_m2[j])==0)
                if(length(new_unmeth_position)>0){
                  Output[m,possible_pos_M[new_unmeth_position]]=6
                }
              }
              if(length(possible_pos_U)>0){
                new_meth_position=which(stats::rbinom(length(possible_pos_U),1,p_m1[j])==0)
                if(length(new_meth_position)>0){
                  Output[m,possible_pos_U[new_meth_position]]=5
                }
              }
            }
          }
        }

        count_L=count_L+L_seg
        #print(count_L)
        for(m in 1:M){
          remove_pos_old_pos=which(pos_m[[m]][1:min(c(length(pos_m[[m]]),(count_L)))]<count_L)
          if(length(remove_pos_old_pos)>0){
            pos_m[[m]]=pos_m[[m]][-remove_pos_old_pos]
          }
        }

      }
      print("creating segregating matrix")
      rm_pos=c()
      for(m in 2:(M)){
        if(m==2){
          rm_pos=which(Output[1,]==Output[m,])
        }else{
          if(length(rm_pos)>0){
            rm_pos=rm_pos[which(Output[1,rm_pos]==Output[m,rm_pos])]

          }
        }
      }
      rm_pos=rm_pos[which(Output[1,rm_pos]<=4)]
      if(length(rm_pos)>0){
        Output=Output[,-rm_pos]
      }

    }
    if(all(!is.na(Gbu_pos))){
      Meth_pos=Gbu_pos
      mu_m=Gbu_rates
      print("adding methylation in Gbu")
      real_symbol=c()
      for(i in 1:nchar(symbol)){
        real_symbol=c(real_symbol,substr(symbol,i,i))
      }
      for(nucl in c("A","T","G","C")){
        if(any(nucl%in%real_symbol)){
          real_symbol[which(real_symbol==nucl)]=which(c("A","T","G","C")==nucl)
        }
      }
      num_symbol=paste(as.numeric(real_symbol),collapse = "")
      pos_m=list()
      for(m in 1:M){
        pos_m[[m]]=as.numeric(gregexpr(as.character(num_symbol),paste(as.character(Output[m,]),collapse = ""))[[1]])
      }

      if(all(!is.na(Meth_pos))){
        v_pos=c()
        for(pp in 1:length(Meth_pos) ){
          v_pos=c(v_pos,Meth_pos[[pp]][1]:Meth_pos[[pp]][2])
        }
        for(m in 1:M){
          pos_m[[m]]=pos_m[[m]][(pos_m[[m]])%in%v_pos]+(c_pos-1)
          Output[m,pos_m[[m]]]=6
        }
      }


      count_L=0
      p=(mu_m[2]/(sum(mu_m))) # Equilibrium probability to be unmethylated
      print(p)
      for(i in 1:dim(genealogy$Coal_time)[2]){
        L_seg=genealogy$Coal_time[M,i]
        Pos_meth= sort(as.numeric(as.vector(unique(c( pos_m[[as.numeric(genealogy$id_split[1,i])]][which((pos_m[[as.numeric(genealogy$id_split[1,i])]][1:min(c(length(pos_m[[as.numeric(genealogy$id_split[1,i])]]),(L_seg)))]<=(count_L+L_seg)))])))))
        #print(length(Pos_meth))
        if(length(Pos_meth)>0){
          ancestral_meth_position=stats::rbinom(length(Pos_meth),1,p)
          Output[as.numeric(genealogy$id_split[1,i]),Pos_meth[which(ancestral_meth_position==0)]]=5
        }else{
          #browser()
        }

        vect_to_put_methylation=c(as.numeric(genealogy$id_split[1,i]))
        if(M>2){
          p_m1=c((p+((1-p)*exp(-sum(mu_m)*(genealogy$Coal_time[1:(M-2),i]-genealogy$Coal_time[2:(M-1),i])*Ne))),(p+((1-p)*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay unmethylated
          p_m2=c(((1-p)+(p*exp(-sum(mu_m)*(genealogy$Coal_time[1:(M-2),i]-genealogy$Coal_time[2:(M-1),i])*Ne))),((1-p)+(p*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay methylated
        }else{
          p_m1=c((p+((1-p)*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay unmethylated
          p_m2=c(((1-p)+(p*exp(-sum(mu_m)*genealogy$Coal_time[(M-1),i]*Ne)))) # probability to stay methylated
        }

        for(j in 1:(M-1)){
          Pos_meth= sort(as.numeric(as.vector(unique(c( pos_m[[as.numeric(genealogy$id_split[j,i])]][which((pos_m[[as.numeric(genealogy$id_split[j,i])]][1:min(c(length(pos_m[[as.numeric(genealogy$id_split[j,i])]]),(L_seg)))]<=(count_L+L_seg)))])))))

          vect_to_put_methylation=c(vect_to_put_methylation,genealogy$id_create[j,i])
          possible_pos=sort(as.numeric(as.vector(unique(pos_m[[genealogy$id_create[j,i]]][which((pos_m[[genealogy$id_create[j,i]]][1:min(c(length(pos_m[[genealogy$id_create[j,i]]]),(L_seg)))]<=(count_L+L_seg)))]))))

          if(length(possible_pos)>0){
            herited_meth_pos=possible_pos[which(possible_pos%in%Pos_meth)]
            if(length(herited_meth_pos)>0){
              Output[genealogy$id_create[j,i],herited_meth_pos]= Output[as.numeric(genealogy$id_split[j,i]),Pos_meth[which(Pos_meth%in%herited_meth_pos)]]
            }
            new_meth_pos=possible_pos[which(!(possible_pos%in%Pos_meth))]
            if(length(new_meth_pos)>0){
              ancestral_meth_position=stats::rbinom(length(new_meth_pos),1,p)
              Output[genealogy$id_create[j,i],new_meth_pos[which(ancestral_meth_position==0)]]=5
            }

          }
          for(m in vect_to_put_methylation){
            possible_pos=sort(as.numeric(as.vector(unique(pos_m[[m]][which(pos_m[[m]][1:min(c(length(pos_m[[m]]),(L_seg)))]<=(count_L+L_seg))]))))

            if(length(possible_pos)>0){
              possible_pos_M=possible_pos[which(Output[m,possible_pos]==5)]
              possible_pos_U=possible_pos[which(Output[m,possible_pos]==6)]
              #browser()
              if(any(sort(possible_pos)!=sort(unique(c(possible_pos_M,possible_pos_U))))){
                browser()
              }
              if(length(possible_pos_M)>0){
                new_unmeth_position=which(stats::rbinom(length(possible_pos_M),1,p_m2[j])==0)
                if(length(new_unmeth_position)>0){
                  Output[m,possible_pos_M[new_unmeth_position]]=6
                }
              }
              if(length(possible_pos_U)>0){
                new_meth_position=which(stats::rbinom(length(possible_pos_U),1,p_m1[j])==0)
                if(length(new_meth_position)>0){
                  Output[m,possible_pos_U[new_meth_position]]=5
                }
              }
            }
          }
        }

        count_L=count_L+L_seg
        #print(count_L)
        for(m in 1:M){
          remove_pos_old_pos=which(pos_m[[m]][1:min(c(length(pos_m[[m]]),(count_L)))]<count_L)
          if(length(remove_pos_old_pos)>0){
            pos_m[[m]]=pos_m[[m]][-remove_pos_old_pos]
          }
        }

      }
      print("creating segregating matrix")
      rm_pos=c()
      for(m in 2:(M)){
        if(m==2){
          rm_pos=which(Output[1,]==Output[m,])
        }else{
          if(length(rm_pos)>0){
            rm_pos=rm_pos[which(Output[1,rm_pos]==Output[m,rm_pos])]

          }
        }
      }
      rm_pos=rm_pos[which(Output[1,rm_pos]<=4)]
      if(length(rm_pos)>0){
        Output=Output[,-rm_pos]
      }

    }


  }else{
    print("creating segregating matrix")
    rm_pos=c()
    for(m in 2:(M)){
      if(m==2){
        rm_pos=which(Output[1,]==Output[m,])
      }else{
        if(length(rm_pos)>0){
          rm_pos=rm_pos[which(Output[1,rm_pos]==Output[m,rm_pos])]

        }
      }
    }
    Output=Output[,-rm_pos]
  }


  Output=rbind(Output[1:M,],as.numeric(c(as.numeric(Output[(M+1),])-as.numeric(c(0,Output[(M+1),-dim(Output)[2]])))),Output[(M+1),])
  return(Output)
}
