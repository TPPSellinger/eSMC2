#' Builds the emission matrix of the Sequentially Markovian Coalescent with methylation
#'
#' @param mu : estimated mutation rate given prior
#' @param mu_b : ratio of mutation rate in seed bank over mutation rate during sexual event.
#' @param Tc : coalescent times to discretize time
#' @param beta : germination rate of vector of germination rates
#' @param nb_methylation_context : number of different methylation context
#' @param mu_m : vector of size two of methylation and demethylation rate in -log10 scale
#' @param mu_m_reg :vector of size two of region methylation and demethylation  rate in -log10 scale
#' @param Region : FALSE, to ignore spatial structure of methylation, TRUE to account for spatial structure of methylation ,  2 to account for spatial structure of methylation but to ignore SMPs,  3 to only account for spatial structure for SMPs
#' @param scale_meth : Proportion of the genome with methylation information
#' @return The emission matrix
build_emi_m<-function(mu,mu_b,Tc,beta,nb_methylation_context,mu_m,mu_m_reg,Region,scale_meth){

  expected_time<-function(t,lambda){
    t_e=(1/lambda)- ((t*exp(-lambda*t))/(1-exp(-lambda*t)))
    return(t_e)
  }

  if(as.numeric(Region)==0){
     if(nb_methylation_context==1){
    g=matrix(0,nrow=length(Tc),ncol=6)


    p=(mu_m[2]/(sum(mu_m)))
    p_m1=(p+((1-p)*exp(-sum(mu_m)*Tc))) # *Ne
    p_m2=((1-p)+(p*exp(-sum(mu_m)*Tc))) # *Ne
    g[,1]= scale_meth*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,3]=1
    g[,6]=(1-scale_meth)*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,4]=(1-scale_meth)*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,5]=(1-scale_meth)*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
  }else{

    mu_m_s=mu_m

    g=matrix(0,nrow=length(Tc),ncol=9)


    mu_m=mu_m_s[1,]
    p=(mu_m[2]/(sum(mu_m)))
    p_m1=(p+((1-p)*exp(-sum(mu_m)*Tc))) # *Ne
    p_m2=((1-p)+(p*exp(-sum(mu_m)*Tc))) # *Ne
    g[,1]= (1-sum(scale_meth))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,3]=1
    g[,6]=(scale_meth[1,1])*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,4]=(scale_meth[1,1])*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,5]=(scale_meth[1,1])*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

    mu_m=mu_m_s[2,]

    p=(mu_m[2]/(sum(mu_m)))
    p_m1=(p+((1-p)*exp(-sum(mu_m)*Tc))) # *Ne
    p_m2=((1-p)+(p*exp(-sum(mu_m)*Tc))) # *Ne
    g[,9]=(scale_meth[2,1])*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,7]=(scale_meth[2,1])*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    g[,8]=(scale_meth[2,1])*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
  }
  }else{

    if(Region!=2){
      g=matrix(0,nrow=length(Tc),ncol=10)





      p_reg=(mu_m_reg[2]/(sum(mu_m_reg)))
      p_m1_reg=(p_reg+((1-p_reg)*exp(-sum(mu_m_reg)*Tc))) # Reg Unmethylated
      p_m2_reg=((1-p_reg)+(p_reg*exp(-sum(mu_m_reg)*Tc))) # Reg methylated

      p=(mu_m[2]/(sum(mu_m)))

      t_m=rep((1/sum(mu_m_reg)),length(Tc))
      for(tt in 1:length(t_m)){
       #  t_m[tt]=min(t_m[tt],Tc[tt])
      }

      p_eq1=(p+((1-p)*exp(-sum(mu_m)*(t_m)))) # Unmethylated
      p_eq2=((1-p)+(p*exp(-sum(mu_m)*(t_m)))) # methylated


      p_m1=(p+((1-p)*exp(-sum(mu_m)*(Tc)))) # Unmethylated
      p_m2=((1-p)+(p*exp(-sum(mu_m)*(Tc))))# methylated

      g[,1]= scale_meth*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,3]=1

      #g[,6]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,4]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,5]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

      #g[,9]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(p*(2*p_m1*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,7]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(p*(p_m1*p_m1))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,8]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(p*((1-p_m1)*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))


      #g[,6]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,4]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,5]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))

      #g[,9]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*((2*p_m1*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))  # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))
      #g[,7]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*((p_m1*p_m1))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc))) # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))
      #g[,8]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_m1)*(1-p_m1)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc))) # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))



      #g[,6]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((2*p_eq2*p_m2*p_eq2*(1-p_m2)))+((1-p_eq2)*(1-p_eq2)*(2*p_m1*(1-p_m1))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,4]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p_eq2)*(1-p_eq2)*(p_m1*p_m1))+((p_eq2)*(p_eq2)*(1-p_m2)*(1-p_m2)) )*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,5]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((p_eq2)*(p_eq2)*((p_m2)*(p_m2)))+((1-p_eq2)*(1-p_eq2)*((1-p_m1)*(1-p_m1))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))



      #g[,9]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*((p_eq1*(2*p_m1*(1-p_m1)))+((1-p_eq1)*(2*p_m2*(1-p_m2))) ) *(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))  # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))
      #g[,7]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*((p_eq1*(p_m1*p_m1))+((1-p_eq1)*((1-p_m2)*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc))) # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))
      #g[,8]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_eq1)*((p_m2)*(p_m2)))+((p_eq1)*((1-p_m1)*(1-p_m1))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc))) # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))




      #g[,6]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((2*p_eq2*p_m2*p_eq2*(1-p_m2)))+((1-p_eq2)*(1-p_eq2)*(2*p_m1*(1-p_m1))) + ((2*p_eq2*p_m2*(1-p_eq2)*(p_m1)))+ ((2*p_eq2*(1-p_m2)*(1-p_eq2)*(1-p_m1))) )*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,4]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((1-p_eq2)*(1-p_eq2)*(p_m1*p_m1))+((p_eq2)*(p_eq2)*(1-p_m2)*(1-p_m2)) + ((2*p_eq2*(1-p_m2)*(1-p_eq2)*(p_m1)))  )*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      #g[,5]=(1-scale_meth)*((p_reg*((1-p_m1_reg)*(1-p_m1_reg)))+((1-p_reg)*(p_m2_reg)*(p_m2_reg)))*(((p_eq2)*(p_eq2)*((p_m2)*(p_m2)))+((1-p_eq2)*(1-p_eq2)*((1-p_m1)*(1-p_m1))) + ((2*p_eq2*p_m2*(1-p_eq2)*(1-p_m1))) )*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))



      #g[,9]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*((p_eq1*p_eq1*(2*p_m1*(1-p_m1)))+((1-p_eq1)*(1-p_eq1)*(2*p_m2*(1-p_m2))) + ((2*p_eq1*p_m1*(1-p_eq1)*(p_m2))) +((2*p_eq1*(1-p_m1)*(1-p_eq1)*(1-p_m2))) ) *(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))  # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))
      #g[,7]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*((p_eq1*p_eq1*(p_m1*p_m1))+((1-p_eq1)*(1-p_eq1)*((1-p_m2)*(1-p_m2)))+ ((2*p_eq1*p_m1*(1-p_eq1)*(1-p_m2))) )*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc))) # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))
      #g[,8]=(1-scale_meth)*((p_reg*(p_m1_reg*p_m1_reg))+((1-p_reg)*(1-p_m2_reg)*(1-p_m2_reg)))*(((1-p_eq1)*(1-p_eq1)*((p_m2)*(p_m2)))+((p_eq1)*(p_eq1)*((1-p_m1)*(1-p_m1)))+ ((2*p_eq1*(1-p_m1)*(1-p_eq1)*(p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc))) # *(((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))

      P_O=(p_reg)*(1-p_eq1)
      P_P=(p_reg)*(p_eq1)
      P_U=(1-p_reg)*(1-p_eq2)
      P_M=(1-p_reg)*(p_eq2)

      T_last_event=expected_time(Tc,sum(mu_m_reg))
      if(Tc[1]==0){T_last_event[1]=0}
      p_m1_small=(p+((1-p)*exp(-sum(mu_m)*(T_last_event))))  # Unmethylated
      p_m2_small=((1-p)+(p*exp(-sum(mu_m)*(T_last_event))))  # methylated
      P_no_reg_event=(exp(-sum(mu_m_reg)*Tc))



      P_O_O=p_m1_reg* ( ((1-P_no_reg_event)*(1-p_m1_small))  +  (P_no_reg_event*(p_m2)) )
      P_O_P=p_m1_reg* ( ((1-P_no_reg_event)*(p_m1_small))  +  (P_no_reg_event*(1-p_m2)) )
      P_O_M=(1-p_m1_reg)*p_m2_small
      P_O_U=(1-p_m1_reg)*(1-p_m2_small)

      P_P_O=p_m1_reg* ( ((1-P_no_reg_event)*(1-p_m1_small))  +  (P_no_reg_event*(1-p_m1)) )
      P_P_P=p_m1_reg* ( ((1-P_no_reg_event)*(p_m1_small))  +  (P_no_reg_event*(p_m1)) )
      P_P_M=(1-p_m1_reg)*p_m2_small
      P_P_U=(1-p_m1_reg)*(1-p_m2_small)


      P_M_O=(1-p_m2_reg)*(1-p_m1_small)
      P_M_P=(1-p_m2_reg)*(p_m1_small)
      P_M_M=p_m2_reg*( ((1-P_no_reg_event)*(p_m2_small))  +  (P_no_reg_event*(p_m2)) )
      P_M_U=p_m2_reg*( ((1-P_no_reg_event)*(1-p_m2_small))  +  (P_no_reg_event*(1-p_m2)) )


      P_U_O=(1-p_m2_reg)*(1-p_m1_small)
      P_U_P=(1-p_m2_reg)*(p_m1_small)
      P_U_M=p_m2_reg*( ((1-P_no_reg_event)*(p_m2_small))  +  (P_no_reg_event*(1-p_m1)) )
      P_U_U=p_m2_reg*( ((1-P_no_reg_event)*(1-p_m2_small))  +  (P_no_reg_event*(p_m1)) )


      g[,6]=(1-scale_meth)*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))*( (P_O*(2*P_O_U*P_O_M) ) + (P_P*(2*P_P_U*P_P_M) ) + (P_M*(2*P_M_U*P_M_M) ) + (P_U*(2*P_U_U*P_U_M) )  )
      g[,4]=(1-scale_meth)*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))*( (P_O*(P_O_U*P_O_U) ) + (P_P*(P_P_U*P_P_U) ) + (P_M*(P_M_U*P_M_U) ) + (P_U*(P_U_U*P_U_U) )  )
      g[,5]=(1-scale_meth)*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))*( (P_O*(P_O_M*P_O_M) ) + (P_P*(P_P_M*P_P_M) ) + (P_M*(P_M_M*P_M_M) ) + (P_U*(P_U_M*P_U_M) )  )



      g[,9]=(1-scale_meth)*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))* ( (P_O*(2*P_O_P*P_O_O) ) + (P_P*(2*P_P_P*P_P_O) ) + (P_M*(2*P_M_P*P_M_O) ) + (P_U*(2*P_U_P*P_U_O) )  )
      g[,7]=(1-scale_meth)*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))* ( (P_O*(P_O_P*P_O_P) ) + (P_P*(P_P_P*P_P_P) ) + (P_M*(P_M_P*P_M_P) ) + (P_U*(P_U_P*P_U_P) )  )
      g[,8]=(1-scale_meth)*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))* ( (P_O*(P_O_O*P_O_O) ) + (P_P*(P_P_O*P_P_O) ) + (P_M*(P_M_O*P_M_O) ) + (P_U*(P_U_O*P_U_O) )  )




      g[,10]= (1-scale_meth)*((p_reg*(2*p_m1_reg*(1-p_m1_reg)))+((1-p_reg)*(2*p_m2_reg*(1-p_m2_reg))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))



    }else{
      g=matrix(0,nrow=length(Tc),ncol=6)
      p=(mu_m_reg[2]/(sum(mu_m_reg)))
      p_m1=(p+((1-p)*exp(-sum(mu_m_reg)*Tc))) # *Ne
      p_m2=((1-p)+(p*exp(-sum(mu_m_reg)*Tc))) # *Ne
      g[,1]= scale_meth*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,2]=(0.75 - (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,3]=1
      g[,6]=(1-scale_meth)*((p*(2*p_m1*(1-p_m1)))+((1-p)*(2*p_m2*(1-p_m2))))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,4]=(1-scale_meth)*((p*(p_m1*p_m1))+((1-p)*(1-p_m2)*(1-p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
      g[,5]=(1-scale_meth)*((p*((1-p_m1)*(1-p_m1)))+((1-p)*(p_m2)*(p_m2)))*(0.25 + (0.75*exp(-mu*(beta+((1-beta)*mu_b))*2*Tc)))
    }
  }
  return(g)
}
