#'  Builds the HMM matrices of the new symbol
#'
#' Builds the HMM matrices to analysed the zip signal and calculate likelihood
#' @param A : Transition matrix
#' @param E : emission matrix
#' @param Mat_symbol : Symbol matrix with the zipping pattern
#' @param q : equilibrium probability
#' @param do_all : TRUE to compute all necessary matrices for the Baum-Welch, FALSE only those necessary for the Forward-Backward
#' @return A : 4 object list with matrices to calculate likelihood of zipped sequences
Build_zip_Matrix_mailund<-function(A,E,Mat_symbol,q,do_all=T){
  l_f=list()
  Cf=list()
  TOf=list()
  Qf=list()
  Q_f=list()
  k=length(q)
  C=list()
  TO=list()
  Q=list()
  Q_=list()
  l=vector(length = 40)
  for(i in 1:dim(E)[2]){
    B=diag(x=E[,i])
    C[[i]]=B%*%A
    l[i]=1
    TO[[i]]=t(A)%*%B
    Q[[i]]=diag(1,k,k)
    Q_[[i]]=diag(1,k,k)
  }
  x=length(C)
  count_x=0
  for(xx in c(1,3)){
    count_x=count_x+1
    mat_trick=eigen(TO[[xx]])
    D=diag(mat_trick$values)
    if(length(as.numeric(Mat_symbol[[count_x]]))>0){
      for(i in 1:dim(Mat_symbol[[count_x]])[1]){
        sx=strsplit(Mat_symbol[[count_x]][i,2]," ")
        sx=as.numeric(as.matrix(sx[[1]]))
        a=sx[1]
        b=sx[2]
        if(b<10){
          b=b+1
        }
        if(a<10){
          a=a+1
        }
        C[[((10*xx)+i)]]=as.matrix(C[[(b)]])%*%as.matrix(C[[(a)]])
        l[((10*xx)+i)]=(l[(a)]+l[(b)])
        TO[[((10*xx)+i)]]=TO[[(a)]]%*%TO[[(b)]]
        l_temp=(l[(a)]+l[(b)])
        if(do_all){
        Q_temp=matrix(0,dim(D)[1],dim(D)[1])
        Q_temp_=matrix(0,dim(D)[1],dim(D)[1])
        for(x1 in 1:dim(D)[1]){
          good_pos=which(D[x1,x1]==diag(D))
          bad_pos=which(D[x1,x1]!=diag(D))
          if(length(good_pos)>0){
            Q_temp[x1,good_pos]=(l_temp)*(mat_trick$values[good_pos]^(l_temp-1))
            Q_temp_[x1,good_pos]=mat_trick$values[good_pos]*Q_temp[x1,good_pos]
          }
          if(length(bad_pos)>0){
            Q_temp[x1,bad_pos]=((D[x1,x1]^(l_temp))-(mat_trick$values[bad_pos]^(l_temp)))/(D[x1,x1]-mat_trick$values[bad_pos])
            for(bad_bad_pos in bad_pos){
            Q_temp_[x1,bad_bad_pos]=Q_temp_[x1,bad_bad_pos]+sum((D[x1,x1]^seq(1,l_temp,1))*(mat_trick$values[bad_bad_pos]^(l_temp-seq(1,l_temp,1))))
            }
          }
        }
        Q[[((10*xx)+i)]]=Q_temp
        Q_[[((10*xx)+i)]]=Q_temp_
        }
      }
    }
  }
  output=list()
  output[[1]]=C
  output[[3]]=TO
  if(do_all){
  output[[2]]=Q_
  output[[4]]=Q
  output[[5]]=l
  }
  return(output)
}
