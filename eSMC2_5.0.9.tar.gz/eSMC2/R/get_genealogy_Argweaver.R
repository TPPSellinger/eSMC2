#' get the genealogy from the output of Argweaver
#'
#' @param file : path to the Argweaver output
#' @param M : number of simulated sequences
#' @param Ne : estimated effective population size
#' @param decimal_separator : character use as decimal separator , "\\." or ","
#' @export
#' @return list of size 3 containing matrices describing genealogy. First and second list object contain index of coalescing individual, first coalescent event being in last line and  each column is a different genealogy. Last object sequence length of genealogy on last line and coalescent times on others lines (starting at line M-1)
get_genealogy_Argweaver<-function(file,M,Ne,decimal_separator="\\."){
  data=Get_data(file,heavy = T,simulator="argweaver")
  character_size=ceiling(log10((2*M)+1))
  Output=list()
  coal_time=matrix(0,nrow = (M), ncol= (length(data)))

  id_split=matrix("a",nrow = (M-1), ncol= (length(data)))
  id_create=matrix(0,nrow = (M-1), ncol= (length(data)))
  start=T
  end=F
  bonus=0
  start_i=0
  if(decimal_separator==","){
    c_0=1
  }else{
    c_0=0
  }
  for(i in 1:length(data)){
    if(!end){

        genealogy=data[[i]]

          coal_time[M,(i-start_i+bonus)]=as.numeric(genealogy[1])
          genealogy=genealogy[-1]
         # if(i==1){
        #    print(genealogy)
        #  }
          j=0
          while(j <(M-1)){
            j_ad=0
            j=j+1

            #print(genealogy)
            #print(coal_time[,i])
            #print(id_split[,i])
            #print(id_create[,i])
            truc_expr=as.numeric(gregexpr(genealogy,pattern = ":")[[1]])
            for(xx in 1:length(as.numeric(gregexpr(genealogy,pattern = ")")[[1]]))){
                id1_v=as.numeric(gregexpr(genealogy,pattern = ",")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])<as.numeric(gregexpr(genealogy,pattern = ")")[[1]][xx]))]
                id1=max(id1_v[which(id1_v<max(truc_expr[which(truc_expr<as.numeric(gregexpr(genealogy,pattern = ")")[[1]][xx]))]))])


              if(is.infinite(id1)|is.na(as.numeric(id1))){
                browser()
              }

              if(xx==1){

                pos_p1=max(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])<id1)])
                pos_p2=min(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])>id1)])



                  for(id_count in 1:character_size){


                    name1=as.numeric(substr(genealogy,(truc_expr[min(which(truc_expr>id1))]-id_count),(truc_expr[min(which(truc_expr>id1))]-1)))
                    name2=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]-id_count),(truc_expr[max(which(truc_expr<id1))]-1)))
                    if(!is.na(name1)){
                      if(name1<M){
                      name_pot1=as.numeric(name1)
                      }
                    }
                    if(!is.na(name2)){
                      if(name2<M){
                      name_pot2=as.numeric(name2)
                      }
                    }
                  }
                  name_split=min(as.numeric(c(name_pot1,name_pot2)))
                  name_create=max(as.numeric(c(name_pot1,name_pot2)))
                  id_split[(M-j),(i-start_i+bonus)]=name_split



                  id_create[(M-j),(i-start_i+bonus)]=name_create

                  if(as.numeric(id_split[(M-j),(i-start_i+bonus)])=="a"){
                    browser()
                  }

                  if(T){
                    coal_time_exp=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                    if(decimal_separator==","){
                      coal_time_exp=gsub(",",".",coal_time_exp)
                    }
                    if(is.na(as.numeric(coal_time_exp))){
                      browser()
                    }
                    #browser()
                    coal_time[(M-j),(i-start_i+bonus)]=as.numeric(coal_time_exp)
                  }

                  x_k=xx
                  id1_s=id1



                j_ad=length(which(truc_expr>pos_p1&truc_expr<pos_p2))-2
              }
              if(xx>1){
                if(id1>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][(xx-1)])){
                  PASS=T
                  for(ppp in 1:(1+character_size)){
                    if(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]-ppp),(truc_expr[max(which(truc_expr<id1))]-ppp))==")"){
                      PASS=F
                    }
                  }

                  if(PASS){

                    if(T){
                      check_expr=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                      if(decimal_separator==","){
                        check_expr=gsub(",",".",check_expr)
                      }
                    }
                    if(is.na(as.numeric(check_expr))|is.na(as.numeric(coal_time[(M-j),(i-start_i+bonus)]))){
                      browser()
                    }
                    if(as.numeric(check_expr)<(coal_time[(M-j),(i-start_i+bonus)])){

                      pos_p1=max(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])<id1)])
                      pos_p2=min(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])[which(as.numeric(gregexpr(genealogy,pattern = ")")[[1]])>id1)])


                        for(id_count in 1:character_size){
                          name1=as.numeric(substr(genealogy,(truc_expr[min(which(truc_expr>id1))]-id_count),(truc_expr[min(which(truc_expr>id1))]-1)))
                          name2=as.numeric(substr(genealogy,(truc_expr[max(which(truc_expr<id1))]-id_count),(truc_expr[max(which(truc_expr<id1))]-1)))
                          if(!is.na(name1)){
                            if(as.numeric(name1)<M){
                            name_pot1=as.numeric(name1)
                            }
                          }
                          if(!is.na(name2)){
                            if(as.numeric(name2)<M){
                            name_pot2=as.numeric(name2)
                            }
                          }
                        }
                        name_split=min(as.numeric(c(name_pot1,name_pot2)))
                        name_create=max(as.numeric(c(name_pot1,name_pot2)))
                        id_split[(M-j),(i-start_i+bonus)]=name_split
                        id_create[(M-j),(i-start_i+bonus)]=name_create
                        if(as.numeric(id_split[(M-j),(i-start_i+bonus)])=="a"){
                          browser()
                        }

                        if(T){
                          coal_time_exp=substr(genealogy,(truc_expr[max(which(truc_expr<id1))]+1),(id1-1))
                          if(decimal_separator==","){
                            coal_time_exp=gsub(",",".",coal_time_exp)
                          }
                          coal_time[(M-j),(i-start_i+bonus)]=as.numeric(coal_time_exp)
                        }
                        x_k=xx
                        id1_s=id1




                      j_ad=length(which(truc_expr>pos_p1&truc_expr<pos_p2))-2

                    }


                  }
                }
              }

            }
            if((j+j_ad)<(M-1)){
              pos_e=c()
              if(x_k<xx){
                pos_e=c(pos_e,as.numeric((gregexpr(genealogy,pattern = ")")[[1]][x_k+1]-1)))
              }

              if(T){
                if(!is.na(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][(c_0+min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k]))))])))){
                  pos_e=c(pos_e,(as.numeric((gregexpr(genealogy,pattern = ",")[[1]][(c_0+min(na.rm =T,which(as.numeric(gregexpr(genealogy,pattern = ",")[[1]])>as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k]))))]))-1))
                }
                pos_e=min(pos_e)
                #browser()
               #time_in=substr(genealogy,(max(gregexpr(substr(genealogy,1,as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k])),pattern = ":")[[1]])+1),c(gregexpr(genealogy,pattern = ")")[[1]][x_k]-1))

                time_exp=   substr(genealogy,(gregexpr(genealogy,pattern = ")")[[1]][x_k]+c(gregexpr(substr(genealogy,as.numeric(gregexpr(genealogy,pattern = ")")[[1]][x_k]),nchar(genealogy)),pattern = ":")[[1]])[1]),pos_e)

                if(decimal_separator==","){
                  time_exp=gsub(",",".",time_exp)
                }
                if(is.na(as.numeric(time_exp))){
                  browser()
                }
                time=(coal_time[(M-j),(i-start_i+bonus)])+as.numeric(time_exp)
                if(decimal_separator==","){
                  time=gsub(".",",",as.character(time), fixed = TRUE)
                }
                new_ind=paste(id_split[(M-j),(i-start_i+bonus)],":",time,sep="")

              }
              if(length(truc_expr[which(truc_expr>=id1_s&truc_expr<pos_e)])>2){
                browser()
              }

              #genealogy=paste(substr(genealogy,1,as.numeric(truc_expr[max(which(truc_expr<id1_s))]-3)),new_ind,substr(genealogy,(pos_e+1),nchar(genealogy)),sep = "")
              #browser()
              if(j_ad>0){
                # browser()
              }
             # browser()
              genealogy=paste(substr(genealogy,1,(max(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]][which(as.numeric(gregexpr(genealogy,pattern = "\\(")[[1]])<as.numeric(truc_expr[max(which(truc_expr<id1_s))]))]))-1)),new_ind,substr(genealogy,(pos_e+1),nchar(genealogy)),sep = "")

            }
            if(any(is.na(as.numeric(coal_time[,(i-start_i+bonus)])))){
              browser()
            }
            j=j+j_ad
          }





    }



  }

  if(T){
    coal_time[1:(M-1),]=as.numeric(coal_time[1:(M-1),])/(Ne)#
    #coal_time[M,]=round(as.numeric(coal_time[M,]))
  }
  Output$Coal_time=coal_time
  for(ll in 1:dim(id_split)[1]){
    id_split[ll,]=as.numeric(id_split[ll,])+1
    id_create[ll,]=as.numeric(id_create[ll,])+1
  }

  Output$id_split=id_split
  Output$id_create=id_create
  Output=purge_gen(Output)
  return(Output)
}
