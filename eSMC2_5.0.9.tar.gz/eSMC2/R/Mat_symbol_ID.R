#'  Builds the matrix symbol
#'
#' @return A list of matrix symbol
Mat_symbol_ID<-function(){
  max_count_v=c(13,9)
  output=list()
  mat_symbol=list()
  Mat_symbol=list()
  count_l=0
  for(iii in c(1,2)){
    max_count=max_count_v[(iii)]
    mat_symbol[[(iii)]]=vector()
    count=0
    if(iii==1){
      default_symbol=c("00","aa","bb","cc","dd","ee","ff","gg","hh","ii","jj","kk","ll")
    }else{
      default_symbol=c("22","nn","oo","pp","qq","rr","ss","tt","uu")
    }
    while(count<max_count){
      count=count+1
      new_symbol=letters[count+count_l]
      symbol=default_symbol[count]
      real_symb=vector()
      if(length(symbol)>0){
        rep_symbol=symbol
        mat_symbol[[(iii)]]=rbind(mat_symbol[[(iii)]],c(new_symbol,rep_symbol))
      }
    }
    count_l=count+count_l
  }
  return(mat_symbol)
}
