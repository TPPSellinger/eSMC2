#' Calculate r² LD from mutations
#'
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param D_max : max distance to calculte r²
#' @param D_min : min distance to calculte r²
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @export
#' @return A list of size two, one being the r² and the other being the distance between the two allele in bp
LD_mut<-function(O,D_max=NA,D_min=NA,NC){


  if(any(is.na(D_min))){
    D_min=0
  }

  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[dim(O)[1],dim(O)[2]])
    if(any(is.na(D_max))){
      D_max=L
    }
    pos_keep=c()
    for(cc in 1:dim(O)[2]){
      allel=as.vector(unique(O[1:M,cc]))
      if(length(allel)==2){
       pos_keep=c(pos_keep,cc)
       O[1:M,cc][which(O[1:M,cc]==allel[1])]="X"
       O[1:M,cc][which(O[1:M,cc]==allel[2])]="Y"
      }
    }
    if(length(pos_keep)>0){
      if(length(pos_keep)>10^4){
        new_pos_keep=sample(pos_keep,10^4,replace = F)
        O=O[,sort(new_pos_keep)]
      }else{
        O=O[,sort(pos_keep)]
      }

    }

    LD=matrix(0,nrow=2,ncol = (0.5*dim(O)[2]*(dim(O)[2]-1)))
    count=0
    for(k in 1:(dim(O)[2]-1)){
      for(l in (k+1):dim(O)[2]){
        dist=(as.numeric(O[(M+2),l])-as.numeric(O[(M+2),k]))
        if(dist>=D_min&dist<=D_max){
          count=count+1

          Allele=paste(O[1:M,k],O[1:M,l],sep="")
          x11=length(which(Allele=="XX"))/M
          x12=length(which(Allele=="XY"))/M
          x21=length(which(Allele=="YX"))/M
          x22=length(which(Allele=="YY"))/M
          p1=x11+x12
          p2=x21+x22
          q1=x11+x21
          q2=x12+x22
          D=x11-(p1*q1)#(x11*x22)-(x21*x12)
          LD[1,count]=((D^2))/(p1*p2*q1*q2)
          LD[2,count]=dist

        }
      }
    }
    LD=LD[,1:count]
    results=LD
  }
  if(NC>1){
    results=list()
    for(chr in 1:NC){
      M=dim(O[[chr]])[1]-2
      L=as.numeric(O[[chr]][dim(O)[1],dim(O[[chr]])[2]])
      if(any(is.na(D_max))){
        D_max=L
      }
      pos_keep=c()
      for(cc in 1:dim(O[[chr]])[2]){
        allel=as.vector(unique(O[[chr]][1:M,cc]))
        if(length(allel)==2){
          pos_keep=c(pos_keep,cc)
          O[[chr]][1:M,cc][which(O[[chr]][1:M,cc]==allel[1])]="X"
          O[[chr]][1:M,cc][which(O[[chr]][1:M,cc]==allel[2])]="Y"
        }

      }
      if(length(pos_keep)>10^4){
        new_pos_keep=sample(pos_keep,10^4,replace = F)
        O[[chr]]=O[[chr]][,sort(new_pos_keep)]
      }else{
        O[[chr]]=O[[chr]][,sort(pos_keep)]
      }
      LD=matrix(0,nrow=2,ncol = (0.5*dim(O[[chr]])[2]*(dim(O[[chr]])[2]-1)))
      count=0
      for(k in 1:(dim(O[[chr]])[2]-1)){
        for(l in (k+1):dim(O[[chr]])[2]){
          dist=(as.numeric(O[[chr]][(M+2),l])-as.numeric(O[[chr]][(M+2),k]))
          if(dist>=D_min&dist<=D_max){
            count=count+1
            Allele=paste(O[[chr]][1:M,k],O[[chr]][1:M,l],sep="")
            x11=length(which(Allele=="XX"))/M
            x12=length(which(Allele=="XY"))/M
            x21=length(which(Allele=="YX"))/M
            x22=length(which(Allele=="YY"))/M
            p1=x11+x12
            p2=x21+x22
            q1=x11+x21
            q2=x12+x22
            D=(x11*x22)-(x21*x12)
            LD[1,count]=((D^2))/(p1*p2*q1*q2)
            LD[2,count]=dist
          }
        }
      }
      LD=LD[,1:count]
      results[[chr]]=LD
    }
  }

  return(results)
}
