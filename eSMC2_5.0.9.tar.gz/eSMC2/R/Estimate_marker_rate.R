#' Runs the  Sequentially Markovian Coalescent on theoretical markers
#'
#' @param n : Number of hidden states
#' @param rho : numeric vector of prior ratio of recombination over mutation
#' @param O : Segregating site matrix (or list of segregating site matrix to use more than one chromosome/scaffold)
#' @param mu_marker : list of size equal to the number of theoretical marker, respectively containing the markers rates in generation per position. If marker rates need to be estimated the put NA
#' @param Nb_marker : vector of size two which are boundaries of methylation rates. First value gives the -log10 of lower boundary and second value the log10 of upper boundary.
#' @param nb_state_marker :  list of size equal to the number of theoretical marker containing the number of different possible state for each marker
#' @param Marker_supperposition : True is multiple marker can hit the same position.
#' @param BoxMarker : boundaries of the germination rate ( first value must be  bigger than 0)
#' @param NC : Number of chromosome or scaffold (must be equal of the size of the list is O is a list of Segregating site matrix)
#' @param mu_b : ratio of mutation rate in seed bank  over mutation rate during sexual event (per generation)
#' @param sigma : initial value for self-fertilization rate
#' @param beta : initial value for germination rate
#' @param Big_Window : TRUE to use MSMC2 time window (bigger), user can also put numerical value if a window has been defined in Build_HMM_matrix.R
#' @param position_removed : list of length NC ( one for each scaffold) of a list of vector of size 2 indicating begining and end positions to remove from the sequence.
#' @param dominant_marker : index of the marker to use for scaling
#' @param window_scaling : numerical vector of size 2. Time window is divided by first value, and second value is added to time window to shift it in past or present
#' @export
Estimate_marker_rate<-function(n=40,rho=1,O,mu_marker=list(c(10^-8),c(NA)),Nb_marker=2,nb_state_marker=list(c(2),c(2)),Marker_supperposition=F,BoxMarker=c(2,10),NC=1,mu_b=1,sigma=0,beta=1,Big_Window=F,position_removed=NA,dominant_marker=1,window_scaling=c(1,0)){
  Check=F
  FS=F
  EM=F
  BW=F
  SF=F
  SB=F
  ER=F
  pop_vect=NA
  check_tree=F
  SCALED=F
  Max_G=10^9
  if(Max_G<1){
    print("Max_G must be bigger than 1 ! If your computer has less then 1 Gb of memroy you should probably not use this methond on your machine. Hence it is set back to 1 and will try to run. Sorry :/")
    Max_G=1
  }

  gamma=rho


  if(any(is.na(pop_vect))){
    pop_vect=rep(2,(n*0.5))
  }
  to_estimate=c()
  if(NC==1){
    M=dim(O)[1]-2
    L=as.numeric(O[dim(O)[1],dim(O)[2]])
    Os=list()
    count=0
    M_o=0
    theta_W=rep(0,Nb_marker)
    s_t=Sys.time()
    for(k in 1:(M-1)){
      for(l in (k+1):M){
        Os_=seq_marker_theo(O[c(k,l,(M+1),(M+2)),],L,position_removed[[1]],Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition,dominant_marker = dominant_marker)
        theta_W=theta_W+as.numeric(Os_$theta)
        M_o=M_o+1
        if(count==0){
          count=count+1

          Mat_symbol=Mat_symbol_create_marker_theo(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker)
          Os[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

        }else{
          count=count+1
          Os[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)
        }
        print(paste("Zipping sequence",count,"over",((M-1)*M*0.5),"",sep=" "))
      }
    }
    e_t=Sys.time()
    print("Time to Zip allsequences")
    print(e_t-s_t)
    rm(O)
    rm(Os_)

    if(length(Os)>=1){
      for(oo in 1:length(Os)){
        Os[[oo]]=symbol2Num_marker_theo(Os[[oo]])
      }

      theta_W=theta_W/M_o


      theta=theta_W*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
      print("Observed Theta:")
      print(theta)
      mu_v=numeric(Nb_marker)
      for(marker in 1:Nb_marker){
        mu_v[marker]=mu_marker[[marker]]
      }

      Not_Na_pos=which(!is.na(mu_v))
      Ne=c()
      for(marker in Not_Na_pos){
        Ne[marker]=(log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
      }
      if(any(is.na(as.numeric(Ne)))){
        Ne[which(is.na(as.numeric(Ne)))]=0
      }
      print("estimated Ne with different marker")
      print(Ne)

      if(any(is.na(as.numeric(theta)))){
        theta[which(is.na(as.numeric(theta)))]=1
      }

      Na_pos=which(is.na(mu_v))
      if(length(Na_pos)>0){


        for(marker in Na_pos){
          mu_marker[[marker]]=(1-exp((log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/Ne)))*((nb_state_marker[[marker]]-1))/nb_state_marker[[marker]]
          if(as.character(mu_marker[[marker]])=="NaN"){
            check_tree=T
            to_estimate=c(to_estimate,marker)
          }else{
            if((mu_marker[[marker]]*Ne)>0.001){
              check_tree=T
              to_estimate=c(to_estimate,marker)
            }
          }

        }

      }
      if(as.character(Ne)=="NaN"|any(as.character(theta)=="NaN")){
        stop()
      }

      if(check_tree){
        test.env <- new.env()
        Rho <- rho*theta[dominant_marker]
        BW=Short_Baum_Welch_marker_theo(Os,L,theta_W,Rho=Rho,Ne,beta=beta,k=n,window_scaling=window_scaling,sigma=sigma,NC=NC,mu_b=mu_b,Big_Window=Big_Window,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,theta,to_estimate=to_estimate,theta=theta[dominant_marker])
        test.env$Big_M <- BW$M
        test.env$theta_W <- theta_W
        test.env$mu <- mu_marker
        test.env$mu_b <- mu_b
        test.env$Rho <- Rho
        test.env$L <- L
        test.env$k <- n
        test.env$Beta <- beta
        test.env$Self <- sigma
        test.env$NC <- NC
        test.env$Ne<-Ne
        test.env$BoxMarker<-BoxMarker
        test.env$nb_state_marker <- nb_state_marker
        test.env$Nb_marker<-Nb_marker
        test.env$Marker_supperposition<-Marker_supperposition
        function_to_minimize<-function(param){
          mu=get('mu', envir=test.env)
          Ne=get('Ne', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Rho=get('Rho', envir=test.env)
          L=get('L', envir=test.env)
          k=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Self=get('Self', envir=test.env)
          BoxMarker=get('BoxMarker', envir=test.env)
          marker=get('marker', envir=test.env)
          Big_M=get('Big_M', envir=test.env)
          nb_state_marker=get('nb_state_marker', envir=test.env)
          Nb_marker=get('Nb_marker', envir=test.env)
          Marker_supperposition=get('Marker_supperposition', envir=test.env)
          mu[[marker]]=10^-((param*(BoxMarker[2]-BoxMarker[1]))+BoxMarker[1])
          Tc=build_Tc(n=k,Beta=Beta,scale=c(1,0),Sigma=Self,Big_Window=Big_Window)
          builder=build_HMM_matrix(k,1000,beta,Pop = T,L=10^6,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window)
          t=builder[[3]]
          g=build_emi_matrix_marker_theo(mu,Ne,mu_b,Tc,t,beta,nb_state_marker=nb_state_marker,Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition)
          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          m=as.vector(Big_M)
          m=m[keep]
          LH=-sum(log(x)*m)
          return( LH)
        }
        start=T
        for(marker in to_estimate){
          test.env$marker<-marker
          for (value_1 in seq(0,1,0.001)){
            param=c(value_1)
            R2=function_to_minimize(param)
            if(start){
              R2_old=R2
              mu_marker[[marker]]=10^-((value_1*(BoxMarker[2]-BoxMarker[1]))+BoxMarker[1])
              start=F
            }else{
              if(R2<=R2_old){
                R2_old=R2
                mu_marker[[marker]]=10^-((value_1*(BoxMarker[2]-BoxMarker[1]))+BoxMarker[1])
              }
            }
          }
        }
      }
    }else{
      stop("data too poor")
    }
  }

  if(NC>1){

    if(length(O)!=NC){
      stop("Not good number of chromosome given")
    }
    Os=list()
    theta_W_V=list()
    L_total=vector()


    for(chr in 1:NC){

      M=dim(O[[chr]])[1]-2
      L=as.numeric(O[[chr]][dim(O[[chr]])[1],dim(O[[chr]])[2]])
      L_total=c(L_total,L)
      Ost=list()
      count=0
      M_o=0
      theta_W=c()
      for(k in 1:(M-1)){
        for(l in (k+1):M){
          Os_=seq_marker_theo(O[[chr]][c(k,l,(M+1),(M+2)),],L,position_removed[[1]],Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=Marker_supperposition)
          theta_W=theta_W+as.numeric(Os_$theta)
          M_o=M_o+1
          if(count==0){
            count=count+1
            Mat_symbol=Mat_symbol_create_marker_theo(Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition,dominant_marker=dominant_marker)
            Ost[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

          }else{
            count=count+1
            Ost[[count]]=Zip_seq_marker_theo(Os_$seq,Mat_symbol)

          }

        }
      }
      Os[[chr]]=Ost
      theta_W_V[[chr]]=theta_W/M_o


    }


    print(L_total)
    L=L_total
    rm(O)
    rm(Ost)
    theta=list()
    if(length(Os)>=1){
      for(chr in 1:NC){
      for(oo in 1:length(Os[[chr]])){
        Os[[chr]][[oo]]=symbol2Num_marker_theo(Os[[chr]][[oo]])
      }
        theta[[chr]]=theta_W_V[[chr]]*(beta*beta)*2/((2-sigma)*(beta+((1-beta)*mu_b)))
        if(any(is.na(as.numeric(theta[[chr]])))){
          theta[[chr]][which(is.na(as.numeric(theta[[chr]])))]=1
        }
      }


      print("Observed Theta:")
      print(theta)
      mu_v=numeric(Nb_marker)
      for(marker in 1:Nb_marker){
        mu_v[marker]=mu_marker[[marker]]
      }

      Not_Na_pos=which(!is.na(mu_v))
      Ne=rep(0,Nb_marker)
      for(marker in 1:Nb_marker){
        for(chr in 1:NC){
          Ne[marker]=Ne[marker]+(log((1+((log((1-(theta_W_V[[chr]][marker]*(nb_state_marker[[marker]]/(L_total[chr]*(nb_state_marker[[marker]]-1))))))/2))))/(log(1-(mu_marker[[marker]]*(nb_state_marker[[marker]]/((nb_state_marker[[marker]]-1)))))))
        }
        Ne[marker]=Ne[marker]/NC
      }
      if(any(is.na(as.numeric(Ne)))){
        Ne[which(is.na(as.numeric(Ne)))]=0
      }
      print("estimated Ne with different marker")
      print(Ne)



      Na_pos=which(is.na(mu_v))
      if(length(Na_pos)>0){


        for(marker in Na_pos){
          mu_marker[[marker]]=0
          for(chr in 1:NC){
            mu_marker[[marker]]=mu_marker[[marker]]+(1-exp((log((1+((log((1-(theta[marker]*(nb_state_marker[[marker]]/(L*(nb_state_marker[[marker]]-1))))))/2))))/Ne)))*((nb_state_marker[[marker]]-1))/nb_state_marker[[marker]]

          }
          mu_marker[[marker]]=mu_marker[[marker]]/NC
          if(as.character(mu_marker[[marker]])=="NaN"){
            check_tree=T
            to_estimate=c(to_estimate,marker)
          }else{
            if((mu_marker[[marker]]*Ne)>0.001){
              check_tree=T
              to_estimate=c(to_estimate,marker)
            }
          }

        }

      }
      if(as.character(Ne)=="NaN"|any(as.character(theta)=="NaN")){
        stop()
      }

      if(check_tree){
        test.env <- new.env()
        Rho <- rho*theta[dominant_marker]
        Big_M=list()
        for (chr in 1:NC) {
          BW=Short_Baum_Welch_marker_theo(Os[[chr]],L[chr],theta_W[[chr]],Rho=Rho[chr],Ne,beta=beta,k=n,window_scaling=window_scaling,sigma=sigma,NC=1,mu_b=mu_b,Big_Window=Big_Window,mu_marker=mu_marker,Nb_marker=Nb_marker,nb_state_marker=nb_state_marker,Marker_supperposition=F,theta[[chr]],to_estimate=to_estimate,theta=theta[[chr]][dominant_marker])
          Big_M[[chr]]=BW$M
        }
        test.env$Big_M <-  Big_M
        test.env$theta_W <- theta_W
        test.env$mu <- mu_marker
        test.env$mu_b <- mu_b
        test.env$Rho <- Rho
        test.env$L <- L
        test.env$k <- n
        test.env$Beta <- beta
        test.env$Self <- sigma
        test.env$NC <- NC
        test.env$Ne<-Ne
        test.env$BoxMarker<-BoxMarker
        test.env$nb_state_marker <- nb_state_marker
        test.env$Nb_marker<-Nb_marker
        test.env$Marker_supperposition<-Marker_supperposition
        function_to_minimize<-function(param){
          mu=get('mu', envir=test.env)
          Ne=get('Ne', envir=test.env)
          Big_Window=get('Big_Window', envir=test.env)
          mu_b=get('mu_b', envir=test.env)
          Rho=get('Rho', envir=test.env)
          L=get('L', envir=test.env)
          k=get('k', envir=test.env)
          Beta=get('Beta', envir=test.env)
          Self=get('Self', envir=test.env)
          BoxMarker=get('BoxMarker', envir=test.env)
          marker=get('marker', envir=test.env)
          Big_M=get('Big_M', envir=test.env)
          nb_state_marker=get('nb_state_marker', envir=test.env)
          Nb_marker=get('Nb_marker', envir=test.env)
          Marker_supperposition=get('Marker_supperposition', envir=test.env)
          mu[[marker]]=10^-((param*(BoxMarker[2]-BoxMarker[1]))+BoxMarker[1])
          Tc=build_Tc(n=k,Beta=Beta,scale=c(1,0),Sigma=Self,Big_Window=Big_Window)

          builder=build_HMM_matrix(k,1000,beta,Pop = T,L=10^6,Beta=Beta,scale=window_scaling,sigma = sigma,Sigma = Self,Big_Window=Big_Window)
          t=builder[[3]]
          g=build_emi_matrix_marker_theo(mu,Ne,mu_b,Tc,t,beta,nb_state_marker=nb_state_marker,Nb_marker=Nb_marker,Marker_supperposition=Marker_supperposition)
          x=as.vector(g)
          keep=which(x>0)
          x=x[keep]
          LH=0
          for(chr in 1:NC){
          m=as.vector(Big_M[[chr]])
          m=m[keep]
          LH= LH-sum(log(x)*m)
          }
          return( LH)
        }
        start=T
        for(marker in to_estimate){
          test.env$marker<-marker
          for (value_1 in seq(0,1,0.001)){
            param=c(value_1)
            R2=function_to_minimize(param)
            if(start){
              R2_old=R2
              mu_marker[[marker]]=10^-((value_1*(BoxMarker[2]-BoxMarker[1]))+BoxMarker[1])
              start=F
            }else{
              if(R2<=R2_old){
                R2_old=R2
                mu_marker[[marker]]=10^-((value_1*(BoxMarker[2]-BoxMarker[1]))+BoxMarker[1])
              }
            }
          }
        }
      }
    }else{
      stop("data too poor")
    }


  }
  results=list()
  results$mu_marker=mu_marker
  return(results)
}
