#' Get simulated data
#'
#' Builds segregating matrix from data simulated with scrm through the R package scrm
#' @param Data : output of the R function scrm
#' @param L : length of the simulated sequence
#' @param M : number of haplotypes
#' @export
#' @return List of segregating matrix for each simulated data set
get_data_R_scrm<-function(Data,M,L){
  nsim=length(Data$seg_sites)
  output=list()
  for(i in 1:nsim){
    Os=as.matrix(Data$seg_sites[[i]])
    pos=ceiling(as.numeric(dimnames(Os)[[2]])*L)
    pos_m=unique(pos)
    keep=match(pos_m,pos)
    called_position=c(pos_m[1],c(pos_m[2:length(pos_m)]-pos_m[1:(length(pos_m)-1)]))
    o=rbind(Os[,keep],called_position,pos_m)
    o=unname(o)
    output[[i]]=o
    rm(o)
  }
  return(output)
}
