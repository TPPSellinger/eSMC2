
"""
example how to run varying selfing rates / or recombination rates; we use
Nordborg's approximation whithout the refinment on biallelic loci
"""

import tskit
import msprime
from mspts_SS_TS import *
import random

def main(Ne,nsim,nsam,L,nchr):
    class params:
        L=L
        nsam = nsam
        r =[[1e-8,0]]
        mu =1e-8
        pop_size_fn = [[Ne, 0],[0.2*Ne,0.1*Ne],[Ne, Ne]]
        sigma_fn = [[0.8, 0],[0.2,0.5*Ne]] 
        beta_fn= [[1,0]]
    class output:
        ts = f"example.ts"

    # parameter preparation
        pop_sizes, pop_size_times = pop_size_over_time(params.pop_size_fn)
        recombination_rates, recombination_times = (r_over_time(params.r, params.sigma_fn, params.beta_fn))
        rescaled_pop_sizes, rescaled_pop_size_times = rescale_pop_size(params.pop_size_fn, params.sigma_fn, params.beta_fn,params.r)

    # simulation parameters
        simulation_parameters = {
            "sample_size": params.nsam,
            "pop_size_over_time": rescaled_pop_sizes,
            "pop_size_times": rescaled_pop_size_times,
            "length": params.L,
            "recombination_rate_over_time": recombination_rates,
            "recombination_rate_times": recombination_times,
            "population_configurations": None,
            "demographic_events": [
        	msprime.SimulationModelChange(1e6, "smc_prime")
            ],
            "model":"hudson"# starting model
        }

	# simulate trees
        for x in range(nsim):
            for chr in range(nchr):
                ts = simulate_change_in_recombination(simulation_parameters, False)
                ts=ts.simplify()
                ts = msprime.mutate(ts, rate=params.mu, random_seed=random.randint(1,2**32-1), model=None, keep=True)
                name="Tutorial_4_D_simul_seq_"+"x"+str(x)+".vcf"
                with open(name, "w") as vcf_file:
                     ts.write_vcf(vcf_file,2)
                vcf_file.close()

Ne=10**5
nsim=3
nsam=10
L=10**7
nchr=1
main(Ne,nsim,nsam,L,nchr)
