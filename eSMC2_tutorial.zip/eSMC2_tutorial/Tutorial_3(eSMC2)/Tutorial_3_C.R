
###################
# Source function #
###################
library(eSMC2)
library(plot.matrix)
########
#Script#
########

##############
# parameters #
##############

mu=10^-8 # mutation rate
M=4 # number of haploid genome 
r=10^-8 # recombination rate
nsim=1
Pop=10^4

shartp_v=c(2,5,10,50)
N_list=list()
par(mfrow=c(2,2))
sharp=3
V_l=c(10^6,10^7,10^8,10^9)
count=0
for(L in c(10^6,10^7,10^8,10^9)){
  count=count+1
  strength=shartp_v[sharp]
  N=matrix(nrow = 40*40,ncol = nsim)
  for(x in 1:nsim){
    setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
    test=Optimize_N(file=paste("Scenario_3_x",x,"_Strength_",strength,"_Length_",log10(L),"_rec_",-log10(r),"_m_",-(log10(mu)),".txt",sep ="" ),theta=mu,gamma=1,L=L,n=40,ER=T,Pop=F,Boxr=c(1,1),simulator = "msprime",M=M,decimal_separator ="\\.")# Add the decimal separator ("," or "\\.") used in simulation (look at the simulated .txt file)
    N[,x]=as.numeric(test$N)
    N[which(is.na(as.numeric(N[,x]))),x]<-0
  }
  N_list[[count]]=N
  ##################
  # Amount of data #
  ##################
  plot(test$N,main=paste( letters[count],") Length : ",V_l[count],sep=""),breaks=c(0,1,10,1000,10^9))
}
dev.off()

# More genome -> More information -> convergence to truth

######################
# Did you converge ? #
######################
par(mfrow=c(2,2))
for(L_c in c(1,2,3,4)){
  N_heat=matrix(c(apply(N_list[[L_c]],1,sd)/apply(N_list[[L_c]],1,mean)),nrow = 40,ncol = 40)
  plot(N_heat,main=paste( letters[L_c],") Length : ",V_l[L_c],sep=""),breaks=c(0,0.1,1,2,3,4))
}



