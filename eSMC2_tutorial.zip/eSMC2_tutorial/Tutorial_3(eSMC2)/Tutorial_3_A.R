
###################
# Source function #
###################
library(eSMC2)
########
#Script#
########

##############
# parameters #
##############

mu=10^-8 # mutation rate
L=10^8 # sequence length
M=4 # number of haploid genome 
r=10^-8 # recombination rate
nsim=1 # number of simulation 
Pop=10^4

shartp_v=c(2,5,10,50)
for(sharp in c(1,2,3,4)){
        strength=shartp_v[sharp]
        ER=T
        Pop_size=vector()
        x_ab=c(seq(0,1000,1),seq(1001,10^5,10),seq((1+10^5),10^7,10^3))
        total=list()
        Tc=list()
        mu_ex=matrix(0,ncol = nsim,nrow=1)
        rm_ex=matrix(0,ncol = nsim,nrow=1)
        for(t in x_ab){
              t=t/(4*Pop)
              Pop_t=Pop
              count=0
              if(t<=(100/(4*Pop))){
                Pop_t=Pop
              }
              if(t>(1000/(4*Pop))){
                Pop_t=Pop/strength
              }
              if(t>(10000/(4*Pop))){
                Pop_t=Pop
              }
              Pop_size=c(Pop_size,Pop_t)
            }
            for(x in 1:nsim){
              setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
                test=Optimize_N(file=paste("Scenario_1_x",x,"_Strength_",strength,"_Length_",log10(L),"_rec_",-log10(r),"_m_",-(log10(mu)),".txt",sep ="" ),theta=mu,gamma=1,L=L,n=40,ER=T,Pop=T,Boxr=c(1,1),simulator = "msprime",M=M,decimal_separator = "\\.") # Add the decimal separator ("," or "\\.") used in simulation (look at the simulated .txt file)
                total[[(1+length(total))]]=as.numeric(test$Xi)
                Tc[[(1+length(Tc))]]=test$Tc
                rm_ex[1,x]=(test$rho/(test$mu))
                mu_ex[1,x]=test$mu
            }
        if(T){
          gen <- 1
          name_sc=c(" Bottleneck")
          col_u=c("red","orange","green","blue","purple")
          plot(c(10,10^6),c(1,1), log=c("x"), ylim =c(2,6) , type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")
          for(x in 1:nsim){
            test_<-total[[x]]
            Pop_=mu_ex[1,x]/(mu)
            lines((Tc[[x]]*Pop_), log10((test_)*0.5*Pop_), type="s", col=col_u[1])
          }
          lines(x_ab,log10(Pop_size), type="s", col="black")
          legend("topright",legend=c("eSMC"), col=col_u[1], lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)
        }
     }


