
###################
# Source function #
###################
library(eSMC2)
########
#Script#
########
L=10^7 # Sequence length
M=10 # number of haploid sequences
nsim=1 # number simulation 
Pop=10^5 # population size in simulations
mu=10^-8#mutation rate
r=10^-8#recombination rate
NC=1 # number of scaffold/chromosome
x_ab=c(seq(0,10*Pop,0.0001*Pop),seq(((10*Pop)+(0.01*Pop)),100*Pop,0.01*Pop),seq(((100*Pop)+(0.01*Pop)),1000*Pop,5*Pop))
Pop_size=c()
sigma_t=rep(0.8,length(x_ab))
sigma_t[which(x_ab>(0.5*Pop))]=0.2

for(t in x_ab){
  if(t<=(0.1*Pop)){
  Pop_t=Pop
  }
  if(t>=(0.1*Pop)){
  Pop_t=Pop/5
  }
  if(t>(Pop)){
  Pop_t=Pop
  }
  Pop_size=c(Pop_size,Pop_t)
}
results=list()
setwd("~/Documents/eSMC2_tutorial/Tutorial_2(simulation)/")
for(x in 1:nsim){
  Os=Process_vcf_data(paste("Tutorial_4_D_simul_seq_","x",(x-1),".vcf",sep =""))
  #Os=Os[c(1,2,11,12),]
  results[[x]]=teSMC(n=40, rho=r/mu, Os ,model = "One transition",estimate = "SF",Constant_Pop = F,BoxP=c(3,3),Boxs = list(list(c(0,0.99),c(0,0.99))),Boxr=list(c(1,1)),BoxB=list(c(0.1,1)),sigma=0,beta=1,LH_opt = F,NC=NC,mu_b=1,window_scaling = c(1, 0))
}

gen <- 1
pdf(paste("Results_Tutorial_teSMC_vcf.pdf",sep = ""),)
par(mfrow=c(1,2),pty="s")
plot(c(1000,10^6),c(1,1), log=c("x"), ylim =c(2,6) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="population size (log10)",main = "")


for(x in 1:nsim){
  Ne_t<-results[[x]]$Xi
  Ne=results[[x]]$mu/mu
  lines((results[[x]]$Tc*Ne), log10((Ne_t)*0.5*Ne), type="s", col="red")
}
lines(x_ab,log10(Pop_size), type="s", col="black")
legend("topright",legend=c("M:10 L:10^7","True"), col=c("red","black"), lty=c(1,1),cex=0.75,x.intersp=0.5,y.intersp=0.8)



plot(c(1000,10^6),c(1,1), log=c("x"), ylim =c(0,1.1) ,type="n", xlab= paste("Generations ago",sep=" "), ylab="selfing rate",main = "")


for(x in 1:nsim){
  Ne=results[[x]]$mu/mu
  lines((results[[x]]$Tc*Ne),results[[x]]$sigma, type="s", col="red")
}
lines(x_ab,sigma_t)
dev.off()
