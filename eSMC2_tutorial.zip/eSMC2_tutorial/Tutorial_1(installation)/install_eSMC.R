####################
# Installing eSMC2 #
####################
install.packages("devtools") # If not already installed
library(devtools)
path="~Downloads/eSMC2_5.0.1.tar.gz" # Path to the dowloaded eSMC package
# To install package normally
devtools::install_local(path)
# To install package without root permissions (in a local folder) use this command:
withr::with_libpaths(new = "~/R/your_local_dir", install_local("eSMC2_5.0.1.tar.gz")) # change path name