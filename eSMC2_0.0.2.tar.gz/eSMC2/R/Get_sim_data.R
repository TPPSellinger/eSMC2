#' Get simulated data
#'
#' Builds segregating matrix from data simulated with SCRM or ms
#' @param path : location of the file
#' @param L : length of the simulated sequence
#' @param M : number of haplotypes
#' @param nsim : number of repetition
#' @export
#' @return a list with the segregating matrix for each repetition
Get_sim_data<-function(path,L,M,nsim){
  DNAseqfile=Get_data(path)
  O_total=Seqlist2data(DNAseqfile,L,M,nsim)
  return(O_total)
}
