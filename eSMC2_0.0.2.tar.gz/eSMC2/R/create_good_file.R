#' Creates a file from a multihetsep file
#'
#' @param path : location of the file
#' @param M : number of  haplotypes
#' @param filename : name of the file
#' @return A file similar to ms output
create_good_file<-function(path,M,filename){
  old_wd=getwd()
  if(!is.na(path)){
    setwd(path)
    con = file(paste(path,"/",filename,sep=""), "r")
  }else{
    con = file(filename, "r")
  }


  a=system(paste("wc -l",filename,sep=" "),intern =T)
  nb_line=as.numeric(substr(a,1,(nchar(a)-1-nchar(filename))))
  pos=0
  while ( TRUE ) {
    line = readLines(con, n = 1)
    if ( length(line) == 0 ) {
      break
    }
    pos=pos+1
    if(pos==1){
      nb_col=length(as.vector(unlist(strsplit(as.vector(line),"\t"))))
      DNAseqfile=matrix(NA,nrow=nb_line,ncol =nb_col )
    }
    DNAseqfile[pos,]=as.vector(unlist(strsplit(as.vector(line),"\t")))
  }
  close(con)
  L=as.numeric(DNAseqfile[dim(DNAseqfile)[1],2])
  DNAseqfile=DNAseqfile[,-1]
  output=matrix(NA,ncol=nb_line,nrow=(1+M))
  for(i in 1:dim(DNAseqfile)[1]){
    output[1:M,i]=as.vector(unlist(strsplit(DNAseqfile[i,3],"")))[1:M]
    output[(M+1),i]=as.numeric(DNAseqfile[i,1])
  }
  res=list()
  res$L=L
  res$output=output
  setwd(old_wd)
  return(res)
}
