#' Build simulation to check results
#'
#'  Build simulation from eSMC output to check if estimated scenario can be retrieve from prior
#' @param NC : Number of different chromosome or scaffold analyzed
#' @param n : number of hidden states
#' @param param : vector containing model parameters outputed by eSMC
#' @return simulation results estimated under the estimated demographic history
Build_simu<-function(NC,n,param){
  O=list()
  for(chr in 1:NC){
    parameters=param[[chr]]
    M=parameters[1]
    theta=parameters[2]
    rho=parameters[3]
    L=parameters[4]
    beta=parameters[5]
    sigma=parameters[6]
    chi=parameters[7:(6+n)]
    time=parameters[(7+n):(6+n+n)]
    theta=theta*(2-sigma)/(beta*beta*2)
    rho=rho*(1-sigma)/beta
    command_simu=paste(M,1,"-t",theta,"-r",rho,L,sep=" ")
    for(x in 1:length(chi)){
      command_simu=paste(command_simu,"-eN",time[x],chi[x],sep=" ")
    }
    command_simu=paste(command_simu," -p ",ceiling(log10(L)),sep=" ")
    simu=scrm::scrm(command_simu)
    O[[chr]]= get_data_R_scrm(simu,M,L)[[1]]
  }
  return(O)
}
