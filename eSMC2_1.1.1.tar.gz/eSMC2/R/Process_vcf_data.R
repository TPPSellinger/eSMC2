#' Builds a segregatic matrix from a vcf file
#'
#' @param path : location of the vcf file
#' @export
#' @return The segregating matrix of the vcf file
Process_vcf_data<-function(path){
  data=Get_vcf_data(path)
  M=length(data[[15]][c(10:length(data[[15]]))])*2
  SNP_mat=matrix(0,ncol = length(data),nrow = (M+1))
  i=0
  for(ii in 7:length(data)){
    i=i+1
    SNP_mat[(M+1),i]=as.numeric(data[[ii]][2])
    temp_seq=strsplit(paste(data[[ii]][c(10:length(data[[ii]]))],collapse = ""),"")[[1]]
    SNP_mat[1:M,i]=temp_seq[which(temp_seq!="|")]
  }
  return(SNP_mat)
}
